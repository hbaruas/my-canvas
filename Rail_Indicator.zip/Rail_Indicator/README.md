# Rail Busyness Indicator — Publication Pipeline

Turns the 8 disclosure-safe CSV exports into four stakeholder deliverables:
a published Excel dataset, a combined methodology + findings Word report, a
PowerPoint findings deck, and a self-contained interactive HTML page (Plotly)
for the stakeholder to explore directly in a browser.

## Windows — easiest way

Two files sit in this folder, `Rail_Indicator\`:

1. **`1_install.bat`** — double-click once. Finds Python (checks the known ONS path
   first, then PATH), creates a self-contained environment in a `.venv` folder
   inside `Rail_Indicator\`, and installs the required packages into it. Safe to
   double-click again later — it skips creation if `.venv` already exists.
2. **`2_run.bat`** — double-click to run the pipeline. Uses the `.venv` from step 1,
   so nothing gets reinstalled and nothing touches the machine's main Python.

If `1_install.bat` can't find Python automatically, open it in Notepad and set the
`PYTHON_EXE=` line near the top to your `python.exe`'s full path, then run it again.

## macOS / manual setup (any platform)

```
pip install -r requirements.txt
```

## Folder structure (must stay exactly this shape)

```
Rail_Indicator/
  Data/
    Input_data/     <- put the 8 exported CSVs here
    Output_data/    <- the 3 deliverables land here after running
  scripts/
    build_publication.py   <- run this
    rail_indicator_config.py
    load_data.py
    build_charts.py
    build_excel.py
    build_word.py
    build_pptx.py
```

The `Rail_Indicator/Data/Input_data` subpath is fixed. The drive/parent folder
it sits under is not — if it's not sitting next to `scripts/` (e.g. it's on a
D: drive on Windows), set `RAIL_INDICATOR_ROOT` to the folder that *contains*
`Rail_Indicator` before running:

```
# Windows (PowerShell)
$env:RAIL_INDICATOR_ROOT = "D:\"

# macOS / Linux
export RAIL_INDICATOR_ROOT=/path/to/parent
```

## Running it (macOS / manual — on Windows just use 2_run.bat)

```
cd Rail_Indicator/scripts
python build_publication.py
```

Input files are matched by the stable part of their filename (e.g.
`busyness_indicator_DISCLOSURE_SAFE_indexed_monthly`), not the full name —
the ticket-number/date prefix and `_CHECKED` suffix on each export will be
different every time and are ignored automatically.

## If it errors with a KeyError on a real file

`rail_indicator_config.py` is the one place column names are defined. Most of
them are CONFIRMED (taken directly from the code that built the exports) but
a few are ASSUMED (best reconstruction, not verified against a real file —
each one is flagged as such in that file's comments). A KeyError naming a
column is almost always fixed by correcting that one entry.

## The interactive HTML page

`rail_busyness_indicator_interactive.html` is self-contained — one file, no
install, no server — and safe to email or share with the stakeholder as-is.
It loads Plotly from a CDN (`cdn.plot.ly`) so it needs an internet connection
to render; everything else (the data) is baked into the file itself. It is
NOT a 1:1 copy of every static chart in the Word report — interactivity
replaces some of that variety directly: "every region" becomes a legend you
click through rather than a 12-panel grid, "monthly vs weekly" becomes a
button rather than two separate charts. The exhaustive static breakdown
(every region individually, every frequency, as fixed images with full
methodology text) is the Word report's job; this page is for exploring.

## What's test-verified vs. not

Every part of this pipeline has been run end-to-end against synthetic test
fixtures (`scripts/make_test_fixtures.py` — fabricated numbers, same
structure as the real exports) and produces valid output: a 9-sheet Excel
workbook, a 20-image Word report, a 12-slide PowerPoint deck, and a
10-section interactive HTML page (parsed and checked for well-formed
structure, but not visually rendered in an actual browser — no browser tool
was available to do that from here). It has **not** been run against real
exported data, since that data never left the environment this was built in.
The column-name risk above is the most likely thing to need a small fix on
the first real run.
