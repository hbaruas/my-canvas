"""
Loading and light normalization of the 8 disclosure-safe export files.
Kept separate from the chart/doc-building code so both the Excel export
(which must preserve "c" literally) and the chart code (which needs real
NaNs to show breaks) can each use the view they need from one load.
"""

import pandas as pd
from rail_indicator_config import ALL_FILE_KEYS, FILE_SCHEMA, find_input_file, INPUT_DIR


def load_all(input_dir=INPUT_DIR) -> dict[str, pd.DataFrame]:
    """Returns {file_key: raw_dataframe}. Measure columns stay exactly as
    read from CSV (so a suppressed cell is literally the string "c") --
    callers that need numeric values for charting should use numeric_view()."""
    data = {}
    for key in ALL_FILE_KEYS:
        path = find_input_file(key, input_dir)
        df = pd.read_csv(path, dtype=str)  # read everything as string first,
        # then convert back deliberately -- this avoids pandas silently
        # upcasting a column with one "c" in it to object anyway, and
        # keeps behaviour identical and predictable across every column.
        data[key] = _restore_types(df, key)
    return data


def _restore_types(df: pd.DataFrame, key: str) -> pd.DataFrame:
    schema = FILE_SCHEMA[key]
    numeric_candidates = set(schema["measures"]) | set(schema["extra"]) - {"is_within_region"}
    for col in numeric_candidates:
        if col not in df.columns:
            continue
        is_marker = df[col] == "c"
        converted = pd.to_numeric(df[col], errors="coerce")
        df[col] = converted.astype(object)
        df.loc[is_marker, col] = "c"
    if "is_within_region" in df.columns:
        df["is_within_region"] = df["is_within_region"].map({"True": True, "False": False, "true": True, "false": False}).astype("boolean")
    if "low_count_flag" in df.columns:
        df["low_count_flag"] = df["low_count_flag"].map({"True": True, "False": False, "true": True, "false": False}).astype("boolean")
    return df


def numeric_view(df: pd.DataFrame, cols: list[str]) -> pd.DataFrame:
    """Copy of df with the given columns coerced to float; a suppressed "c"
    cell becomes NaN -- the correct behaviour for charting (a real gap, not
    a zero) and for any aggregate sum/mean (NaN is excluded automatically,
    never silently treated as 0)."""
    out = df.copy()
    for col in cols:
        out[col] = pd.to_numeric(out[col], errors="coerce")
    return out


def suppression_rate(df: pd.DataFrame) -> float:
    if "low_count_flag" not in df.columns or len(df) == 0:
        return 0.0
    return float(df["low_count_flag"].sum()) / len(df)


def derive_dest_daily_from_od(od_daily_df: pd.DataFrame) -> pd.DataFrame:
    """No destination-only file exists at daily grain (only weekly/monthly
    were exported at that grain) -- but it can be derived by summing the
    origin-destination daily file over origin, collapsing it to
    destination + day. IMPORTANT CAVEAT, carried in every chart built from
    this: od_daily has its own suppression, so a destination-day total
    derived this way is a slight UNDERCOUNT wherever an origin-level cell
    was suppressed (that origin's contribution is excluded from the sum,
    not zero) -- the same "NaN excluded, never treated as zero" rule as
    everywhere else in this pipeline, just compounded by going through an
    extra aggregation step."""
    from rail_indicator_config import OD_MEASURES
    nv = numeric_view(od_daily_df, OD_MEASURES)
    g = nv.groupby(["travel_date", "destination_region_code", "destination_region_name"])[OD_MEASURES].sum(min_count=1)
    return g.reset_index()
