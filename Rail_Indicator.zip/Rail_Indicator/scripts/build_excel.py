"""
Builds the publishable Excel workbook: one tab per disclosure-safe file,
values exactly as exported (a suppressed cell stays the literal string "c"
-- no reinterpretation), plus a README/cover tab explaining what each tab
is and pointing to the methodology document for full column definitions.
"""

import pandas as pd
from openpyxl.styles import Font, Alignment, PatternFill
from openpyxl.utils import get_column_letter
from datetime import date

from rail_indicator_config import ALL_FILE_KEYS, OUTPUT_DIR

SHEET_TITLES = {
    "weekly":          "Destination - Weekly",
    "monthly":         "Destination - Monthly",
    "indexed_weekly":  "Destination - Weekly (Indexed)",
    "indexed_monthly": "Destination - Monthly (Indexed)",
    "od_daily":        "Origin-Destination - Daily",
    "od_weekly":       "Origin-Destination - Weekly",
    "od_monthly":      "Origin-Destination - Monthly",
    "od_yearly":       "Origin-Destination - Yearly",
}

HEADER_FILL = PatternFill(start_color="2A78D6", end_color="2A78D6", fill_type="solid")
HEADER_FONT = Font(color="FFFFFF", bold=True)


def build_workbook(data: dict[str, pd.DataFrame], out_path=None) -> "Path":
    out_path = out_path or (OUTPUT_DIR / "rail_busyness_indicator_published_dataset.xlsx")
    out_path.parent.mkdir(parents=True, exist_ok=True)

    with pd.ExcelWriter(out_path, engine="openpyxl") as writer:
        _write_readme(writer, data)
        for key in ALL_FILE_KEYS:
            df = data[key]
            sheet_name = SHEET_TITLES[key][:31]  # Excel's own sheet-name length limit
            df.to_excel(writer, sheet_name=sheet_name, index=False)
            _style_sheet(writer.sheets[sheet_name], df)

    return out_path


def _write_readme(writer, data):
    rows = [
        ("GB Rail Busyness Indicator -- Published Dataset", ""),
        ("Generated", date.today().isoformat()),
        ("", ""),
        ("Tab", "Contents"),
    ]
    for key in ALL_FILE_KEYS:
        rows.append((SHEET_TITLES[key], f"{len(data[key]):,} rows"))
    rows += [
        ("", ""),
        ("Suppression marker", "A cell showing \"c\" means the underlying figure was built from 10 or fewer "
                                 "source records and has been masked for statistical disclosure control. "
                                 "This is not a missing value in the usual sense -- it means a real figure "
                                 "exists but cannot be published at this level of detail."),
        ("Column definitions", "See the accompanying methodology document for what every column means and "
                                 "how it was calculated."),
    ]
    df = pd.DataFrame(rows, columns=["", ""])
    df.to_excel(writer, sheet_name="README", index=False, header=False)
    ws = writer.sheets["README"]
    ws.column_dimensions["A"].width = 32
    ws.column_dimensions["B"].width = 90
    ws["A1"].font = Font(bold=True, size=14)
    for r in (4,):
        ws.cell(row=r, column=1).font = Font(bold=True)
        ws.cell(row=r, column=2).font = Font(bold=True)
    for row in ws.iter_rows(min_row=1, max_row=len(rows)):
        for cell in row:
            cell.alignment = Alignment(wrap_text=True, vertical="top")


def _style_sheet(ws, df: pd.DataFrame):
    for col_idx, col_name in enumerate(df.columns, start=1):
        cell = ws.cell(row=1, column=col_idx)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        max_len = max([len(str(col_name))] + [len(str(v)) for v in df[col_name].astype(str).head(200)])
        ws.column_dimensions[get_column_letter(col_idx)].width = min(max(max_len + 2, 10), 40)
    ws.freeze_panes = "A2"
