"""
Builds the stakeholder PowerPoint deck -- a condensed, visual summary of the
same findings as the Word report. The Word document is the source of truth
for methodology detail; this deck is for presenting, not for reading alone.
"""

from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from datetime import date

INK = RGBColor(0x0B, 0x0B, 0x0B)
ACCENT = RGBColor(0x2A, 0x78, 0xD6)
MUTED = RGBColor(0x52, 0x51, 0x4E)
SURFACE = RGBColor(0xFC, 0xFC, 0xFB)

SLIDE_W = Inches(13.333)
SLIDE_H = Inches(7.5)


def _blank_slide(prs):
    layout = prs.slide_layouts[6]  # blank
    return prs.slides.add_slide(layout)


def _set_background(slide, color=SURFACE):
    bg = slide.background
    bg.fill.solid()
    bg.fill.fore_color.rgb = color


def _add_textbox(slide, left, top, width, height, text, size=18, bold=False,
                  color=INK, align=PP_ALIGN.LEFT):
    box = slide.shapes.add_textbox(left, top, width, height)
    tf = box.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.alignment = align
    run = p.add_run()
    run.text = text
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = color
    run.font.name = "Calibri"
    return box


def _add_title_bar(slide, title, subtitle=None):
    _add_textbox(slide, Inches(0.6), Inches(0.35), Inches(12.1), Inches(0.7),
                 title, size=28, bold=True, color=INK)
    if subtitle:
        _add_textbox(slide, Inches(0.6), Inches(0.95), Inches(12.1), Inches(0.5),
                     subtitle, size=14, color=MUTED)
    line = slide.shapes.add_connector(1, Inches(0.6), Inches(1.4), Inches(12.7), Inches(1.4))
    line.line.color.rgb = RGBColor(0xC3, 0xC2, 0xB7)
    line.line.width = Pt(1)


def _add_chart_slide(prs, title, chart, takeaway=None):
    slide = _blank_slide(prs)
    _set_background(slide)
    _add_title_bar(slide, title)
    pic_top = Inches(1.65)
    pic = slide.shapes.add_picture(str(chart["path"]), Inches(0.8), pic_top, height=Inches(5.0))
    # keep centered horizontally regardless of the saved PNG's aspect ratio
    pic.left = Emu(int((SLIDE_W - pic.width) / 2))
    if takeaway:
        _add_textbox(slide, Inches(0.8), Inches(6.85), Inches(11.7), Inches(0.5),
                     takeaway, size=12, color=MUTED)
    return slide


def build_deck(charts: dict, headline_stats: dict, out_path):
    prs = Presentation()
    prs.slide_width = SLIDE_W
    prs.slide_height = SLIDE_H

    # --- Title slide ---
    slide = _blank_slide(prs)
    _set_background(slide)
    _add_textbox(slide, Inches(1), Inches(2.6), Inches(11.3), Inches(1.2),
                 "GB Rail Busyness Indicator", size=44, bold=True, color=INK, align=PP_ALIGN.CENTER)
    _add_textbox(slide, Inches(1), Inches(3.7), Inches(11.3), Inches(0.6),
                 "Findings summary", size=20, color=MUTED, align=PP_ALIGN.CENTER)
    _add_textbox(slide, Inches(1), Inches(4.3), Inches(11.3), Inches(0.5),
                 date.today().strftime("%d %B %Y"), size=14, color=MUTED, align=PP_ALIGN.CENTER)

    # --- Headline stats slide ---
    slide = _blank_slide(prs)
    _set_background(slide)
    _add_title_bar(slide, "Headline figures", "Built from the published, disclosure-safe dataset")
    stat_items = list(headline_stats.items())
    n = len(stat_items)
    col_w = Inches(11.7) / max(n, 1)
    for i, (label, value) in enumerate(stat_items):
        left = Inches(0.8) + col_w * i
        _add_textbox(slide, left, Inches(2.6), col_w, Inches(1.0), value,
                     size=36, bold=True, color=ACCENT, align=PP_ALIGN.CENTER)
        _add_textbox(slide, left, Inches(3.6), col_w, Inches(1.0), label,
                     size=14, color=MUTED, align=PP_ALIGN.CENTER)
    _add_textbox(slide, Inches(0.8), Inches(6.6), Inches(11.7), Inches(0.6),
                 "Figures calculated from non-suppressed rows only; suppressed cells are excluded, "
                 "not treated as zero.", size=11, color=MUTED)

    # --- Chart slides ---
    # A curated subset -- the headline view of each metric. Every chart here
    # (plus every region individually, plus the weekly versions) is in the
    # full Word report; this deck is for presenting, not reading alone.
    slide_specs = [
        ("overall_monthly", "Overall journey volume over time",
         "Gaps reflect genuine suppression, not zero activity. Full report also covers weekly and derived daily."),
        ("top6_monthly", "Busiest destination regions",
         "Each region keeps the same color throughout this deck and the full report. Every region individually is in the Word report."),
        ("avglen_monthly", "Average journey length",
         "Miles per passenger journey, summed totals divided once -- never an average of averages."),
        ("cl_share_monthly", "Commute vs. leisure split",
         "Provisional 30-mile-per-journey threshold -- see the methodology report for detail."),
        ("index_byregion_monthly", "Regional growth, indexed to a common base",
         "Each region compared only to its own starting point -- not comparable across regions in absolute terms."),
        ("od_heatmap", "Where journeys start and end",
         "Gray cells are suppressed or have no recorded journeys between that pair."),
        ("all_routes", "Cross-region routes, ranked by volume",
         "Every cross-region route with data, busiest to least busy -- not a top-10 selection."),
        ("suppression", "How much of each file is masked",
         "Finer-grained files are suppressed more often -- fewer records per published cell."),
    ]
    for key, title, takeaway in slide_specs:
        if key in charts:
            _add_chart_slide(prs, title, charts[key], takeaway)

    # --- Methodology summary slide ---
    slide = _blank_slide(prs)
    _set_background(slide)
    _add_title_bar(slide, "How this is protected", "Two layers applied to every published figure")
    items = [
        ("1. Suppression", "Any row built from 10 or fewer underlying records has every figure "
                            "replaced with \"c\" -- not a missing value, a masked one."),
        ("2. Rounding", "Every surviving figure is rounded to the nearest 5, so no published "
                        "number is ever the exact original count."),
    ]
    top = Inches(2.2)
    for label, text in items:
        _add_textbox(slide, Inches(0.8), top, Inches(11.7), Inches(0.5), label, size=20, bold=True, color=ACCENT)
        _add_textbox(slide, Inches(0.8), top + Inches(0.55), Inches(11.3), Inches(1.0), text, size=15, color=INK)
        top += Inches(1.7)
    _add_textbox(slide, Inches(0.8), top + Inches(0.3), Inches(11.7), Inches(1.0),
                 "Full methodology, column definitions, and known limitations are in the "
                 "accompanying Word report.", size=13, color=MUTED)

    # --- Closing slide ---
    slide = _blank_slide(prs)
    _set_background(slide)
    _add_textbox(slide, Inches(1), Inches(3.2), Inches(11.3), Inches(1.0),
                 "Questions / discussion", size=32, bold=True, color=INK, align=PP_ALIGN.CENTER)
    _add_textbox(slide, Inches(1), Inches(4.1), Inches(11.3), Inches(0.6),
                 "Full detail: methodology report and published dataset (Excel)", size=14,
                 color=MUTED, align=PP_ALIGN.CENTER)

    prs.save(out_path)
    return out_path
