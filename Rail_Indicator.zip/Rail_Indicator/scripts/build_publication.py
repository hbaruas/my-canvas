"""
GB Rail Busyness Indicator -- Publication Pipeline
====================================================

Reads the 8 disclosure-safe CSV exports and produces three deliverables:
  1. A published Excel workbook (Output_data/rail_busyness_indicator_published_dataset.xlsx)
  2. A combined Word methodology + findings report (Output_data/rail_busyness_indicator_methodology_and_report.docx)
  3. A PowerPoint findings deck (Output_data/rail_busyness_indicator_findings.pptx)

USAGE
-----
    python build_publication.py

See README.md for the folder structure and RAIL_INDICATOR_ROOT override.

REQUIREMENTS
------------
    pip install pandas numpy matplotlib openpyxl python-docx python-pptx

Tested against synthetic fixtures (make_test_fixtures.py), not real data --
see rail_indicator_config.py for which column names are CONFIRMED vs ASSUMED.
"""

import sys
import numpy as np

from rail_indicator_config import INPUT_DIR, OUTPUT_DIR, ALL_FILE_KEYS
from load_data import load_all, numeric_view, suppression_rate, derive_dest_daily_from_od
import build_charts as bc
from build_excel import build_workbook
from build_word import build_document
from build_pptx import build_deck
from build_html import build_html_page
from chart_text import (
    JOURNEY_METHOD, JOURNEY_READ, DAILY_DERIVED_CAVEAT, LEN_METHOD, LEN_READ,
    CL_METHOD, SHARE_READ, VOL_READ, IDX_METHOD, IDX_READ,
    HEAT_METHOD, HEAT_READ, ROUTE_METHOD, ROUTE_READ, SUPP_METHOD, SUPP_READ,
)


def add_avg_journey_length(df, out_col="avg_journey_miles_calc"):
    """total_passenger_miles / net_passenger_journeys, computed fresh at
    whatever grain df is already at -- never averaged from a lower grain's
    already-computed average (same principle as the TRE pipeline)."""
    nv = numeric_view(df, ["total_passenger_miles", "net_passenger_journeys"])
    out = df.copy()
    denom = nv["net_passenger_journeys"].replace(0, np.nan)
    out[out_col] = nv["total_passenger_miles"] / denom
    return out


def build_all_charts(data: dict) -> dict:
    charts = {}
    weekly, monthly = data["weekly"], data["monthly"]
    idx_weekly, idx_monthly = data["indexed_weekly"], data["indexed_monthly"]
    od_daily, od_yearly = data["od_daily"], data["od_yearly"]

    all_regions = bc.all_regions_sorted(monthly)
    top6 = bc.top_regions_by_volume(monthly, n=6)
    colors_all = bc.region_color_map(all_regions)
    colors_top6 = {r: colors_all[r] for r in top6}

    # --- 1-3: Overall volume, three frequencies ---
    charts["overall_monthly"] = bc.build_overall_trend(
        monthly, "month", "net_passenger_journeys", "01a_overall_monthly",
        "Total passenger journeys by month (all destination regions)",
        "Net passenger journeys (count)", JOURNEY_METHOD, JOURNEY_READ)

    charts["overall_weekly"] = bc.build_overall_trend(
        weekly, "iso_week", "net_passenger_journeys", "01b_overall_weekly",
        "Total passenger journeys by week (all destination regions)",
        "Net passenger journeys (count)", JOURNEY_METHOD, JOURNEY_READ)

    dest_daily = derive_dest_daily_from_od(od_daily)
    charts["overall_daily"] = bc.build_overall_trend(
        dest_daily, "travel_date", "net_passenger_journeys", "01c_overall_daily_derived",
        "Total passenger journeys by day (all destination regions) -- derived",
        "Net passenger journeys (count)", JOURNEY_METHOD, JOURNEY_READ,
        color=bc.CATEGORICAL[2], caveats=[DAILY_DERIVED_CAVEAT])

    # --- 4: Top-6 overlay (quick-read companion) ---
    charts["top6_monthly"] = bc.build_top_overlay(
        monthly, "month", "destination_region_name", "net_passenger_journeys", colors_top6,
        "02_top6_regions_monthly", "Passenger journeys by month -- 6 busiest destination regions",
        "Net passenger journeys (count)", JOURNEY_METHOD,
        JOURNEY_READ + " This chart shows only the 6 busiest regions by total volume, as a quick "
        "comparison -- see the small-multiples chart for every region individually.")

    # --- 5-6: every region, small multiples, monthly + weekly ---
    charts["byregion_monthly"] = bc.build_small_multiples_by_region(
        monthly, "month", "destination_region_name",
        [("net_passenger_journeys", "Journeys", bc.CATEGORICAL[0])], all_regions,
        "03a_byregion_monthly", "Passenger journeys by month -- every destination region",
        "Net passenger journeys (count)", JOURNEY_METHOD, JOURNEY_READ)

    charts["byregion_weekly"] = bc.build_small_multiples_by_region(
        weekly, "iso_week", "destination_region_name",
        [("net_passenger_journeys", "Journeys", bc.CATEGORICAL[0])], all_regions,
        "03b_byregion_weekly", "Passenger journeys by week -- every destination region",
        "Net passenger journeys (count)", JOURNEY_METHOD, JOURNEY_READ)

    # --- 7-10: average journey length, overall + by region, monthly + weekly ---
    monthly_len = add_avg_journey_length(monthly)
    weekly_len = add_avg_journey_length(weekly)

    charts["avglen_monthly"] = bc.build_overall_trend(
        monthly_len, "month", "avg_journey_miles_calc", "04a_avglen_monthly",
        "Average journey length by month, all regions combined",
        "Miles per passenger journey", LEN_METHOD, LEN_READ, color=bc.CATEGORICAL[2])
    charts["avglen_weekly"] = bc.build_overall_trend(
        weekly_len, "iso_week", "avg_journey_miles_calc", "04b_avglen_weekly",
        "Average journey length by week, all regions combined",
        "Miles per passenger journey", LEN_METHOD, LEN_READ, color=bc.CATEGORICAL[2])
    charts["avglen_byregion_monthly"] = bc.build_small_multiples_by_region(
        monthly_len, "month", "destination_region_name",
        [("avg_journey_miles_calc", "Avg miles", bc.CATEGORICAL[2])], all_regions,
        "04c_avglen_byregion_monthly", "Average journey length by month -- every destination region",
        "Miles per passenger journey", LEN_METHOD, LEN_READ)
    charts["avglen_byregion_weekly"] = bc.build_small_multiples_by_region(
        weekly_len, "iso_week", "destination_region_name",
        [("avg_journey_miles_calc", "Avg miles", bc.CATEGORICAL[2])], all_regions,
        "04d_avglen_byregion_weekly", "Average journey length by week -- every destination region",
        "Miles per passenger journey", LEN_METHOD, LEN_READ)

    # --- 11-15: commute/leisure, share + volume, overall + by region ---
    charts["cl_share_monthly"] = bc.build_commute_leisure_share(
        monthly, "month", "05a_cl_share_monthly", "Commute-like vs. leisure-like journey share, by month",
        CL_METHOD, SHARE_READ)
    charts["cl_share_weekly"] = bc.build_commute_leisure_share(
        weekly, "iso_week", "05b_cl_share_weekly", "Commute-like vs. leisure-like journey share, by week",
        CL_METHOD, SHARE_READ)
    charts["cl_volume_monthly"] = bc.build_commute_leisure_volume(
        monthly, "month", "05c_cl_volume_monthly", "Commute-like vs. leisure-like journeys (raw counts), by month",
        CL_METHOD, VOL_READ)
    charts["cl_volume_weekly"] = bc.build_commute_leisure_volume(
        weekly, "iso_week", "05d_cl_volume_weekly", "Commute-like vs. leisure-like journeys (raw counts), by week",
        CL_METHOD, VOL_READ)
    charts["cl_byregion_monthly"] = bc.build_small_multiples_by_region(
        monthly, "month", "destination_region_name",
        [("commute_like_journeys", "Commute-like", bc.CATEGORICAL[0]),
         ("leisure_like_journeys", "Leisure-like", bc.CATEGORICAL[1])],
        all_regions, "05e_cl_byregion_monthly",
        "Commute-like vs. leisure-like journeys (raw counts), by month -- every region",
        "Net passenger journeys (count)", CL_METHOD, VOL_READ)

    # --- 16-17: indexed, by region, monthly + weekly ---
    charts["index_byregion_monthly"] = bc.build_index_small_multiples(
        idx_monthly, "month", "06a_index_byregion_monthly",
        "Journey volume index by region, by month (base period = 100)",
        IDX_METHOD, IDX_READ, all_regions)
    charts["index_byregion_weekly"] = bc.build_index_small_multiples(
        idx_weekly, "iso_week", "06b_index_byregion_weekly",
        "Journey volume index by region, by week (base period = 100)",
        IDX_METHOD, IDX_READ, all_regions)

    # --- 18: OD heatmap ---
    charts["od_heatmap"] = bc.build_od_heatmap(
        od_yearly, "year", "07a_od_heatmap", "Origin -> destination journey volume",
        HEAT_METHOD, HEAT_READ)

    # --- 19: all routes ranked ---
    charts["all_routes"] = bc.build_all_routes_ranked(
        od_yearly, "year", "07b_all_routes_ranked", "Cross-region routes, ranked by volume",
        ROUTE_METHOD, ROUTE_READ)

    # --- 20: suppression summary ---
    rates = {k: suppression_rate(df) for k, df in data.items()}
    charts["suppression"] = bc.build_suppression_summary(
        rates, "08_suppression_summary", "Share of rows suppressed, by published file", SUPP_METHOD, SUPP_READ)

    return charts


def compute_headline_stats(data: dict) -> dict:
    nv = numeric_view(data["monthly"], ["net_passenger_journeys"])
    latest_month = nv["month"].max()
    latest_total = nv[nv["month"] == latest_month]["net_passenger_journeys"].sum()
    n_regions = data["monthly"]["destination_region_name"].nunique()
    overall_suppression = sum(df["low_count_flag"].sum() for df in data.values()) / sum(len(df) for df in data.values())
    return {
        f"Journeys, {latest_month}": f"{latest_total/1e6:,.1f}M",
        "Regions covered": str(n_regions),
        "Overall suppression rate": f"{overall_suppression*100:.1f}%",
    }


def main():
    print(f"Reading input from: {INPUT_DIR}")
    if not INPUT_DIR.exists():
        print(f"ERROR: input folder does not exist: {INPUT_DIR}", file=sys.stderr)
        sys.exit(1)

    data = load_all(INPUT_DIR)
    for key in ALL_FILE_KEYS:
        rate = suppression_rate(data[key])
        print(f"  loaded {key}: {len(data[key]):,} rows ({rate*100:.1f}% suppressed)")

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    print("\nBuilding charts...")
    charts = build_all_charts(data)
    print(f"  {len(charts)} chart artifacts written to {bc.CHARTS_DIR}")

    print("\nBuilding Excel workbook...")
    xlsx_path = build_workbook(data)
    print(f"  wrote {xlsx_path}")

    print("\nBuilding Word report...")
    row_counts = {k: len(df) for k, df in data.items()}
    docx_path = build_document(charts, row_counts, OUTPUT_DIR / "rail_busyness_indicator_methodology_and_report.docx")
    print(f"  wrote {docx_path}")

    print("\nBuilding PowerPoint deck...")
    stats = compute_headline_stats(data)
    pptx_path = build_deck(charts, stats, OUTPUT_DIR / "rail_busyness_indicator_findings.pptx")
    print(f"  wrote {pptx_path}")

    print("\nBuilding interactive HTML page...")
    html_path = build_html_page(data, OUTPUT_DIR / "rail_busyness_indicator_interactive.html")
    print(f"  wrote {html_path}")

    print("\nDone. Four deliverables in:", OUTPUT_DIR)


if __name__ == "__main__":
    main()
