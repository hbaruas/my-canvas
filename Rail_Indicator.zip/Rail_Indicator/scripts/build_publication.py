"""
GB Rail Busyness Indicator -- Publication Pipeline
====================================================

Reads the 8 disclosure-safe CSV exports and produces three deliverables:
  1. A published Excel workbook (Output_data/rail_busyness_indicator_published_dataset.xlsx)
  2. A combined Word methodology + findings report (Output_data/rail_busyness_indicator_methodology_and_report.docx)
  3. A PowerPoint findings deck (Output_data/rail_busyness_indicator_findings.pptx)

USAGE
-----
Run from anywhere, as long as the folder structure below is intact relative
to this script's location (Rail_Indicator/scripts/build_publication.py):

    Rail_Indicator/
      Data/
        Input_data/   <- put the 8 exported CSVs here (any filename containing
                          the expected pattern -- see rail_indicator_config.py)
        Output_data/  <- the 3 deliverables are written here

    python build_publication.py

To point at a different location (e.g. the files live somewhere other than
next to this script), set the RAIL_INDICATOR_ROOT environment variable to
the folder that CONTAINS "Rail_Indicator/Data/Input_data" before running:

    Windows (PowerShell):  $env:RAIL_INDICATOR_ROOT = "D:\\"
    macOS/Linux:            export RAIL_INDICATOR_ROOT=/path/to/parent

REQUIREMENTS
------------
    pip install pandas numpy matplotlib openpyxl python-docx python-pptx

This script has been run and verified against synthetic test fixtures with
the same structure as the real exports (see make_test_fixtures.py) -- NOT
against real data, since that never left the environment this was written
in. The one thing most likely to need a small fix on the first real run is
column names that turn out to differ from what's assumed in
rail_indicator_config.py (clearly flagged there as ASSUMED vs CONFIRMED) --
if you get a KeyError, that file is the one place to look.
"""

import sys
from pathlib import Path

from rail_indicator_config import INPUT_DIR, OUTPUT_DIR, ALL_FILE_KEYS
from load_data import load_all, numeric_view, suppression_rate
import build_charts as bc
from build_excel import build_workbook
from build_word import build_document
from build_pptx import build_deck


def compute_headline_stats(data: dict) -> dict:
    nv = numeric_view(data["monthly"], ["net_passenger_journeys"])
    latest_month = nv["month"].max()
    latest_total = nv[nv["month"] == latest_month]["net_passenger_journeys"].sum()
    n_regions = data["monthly"]["destination_region_name"].nunique()
    overall_suppression = sum(df["low_count_flag"].sum() for df in data.values()) / sum(len(df) for df in data.values())
    return {
        f"Journeys, {latest_month}": f"{latest_total/1e6:,.1f}M",
        "Regions covered": str(n_regions),
        "Overall suppression rate": f"{overall_suppression*100:.1f}%",
    }


def main():
    print(f"Reading input from: {INPUT_DIR}")
    if not INPUT_DIR.exists():
        print(f"ERROR: input folder does not exist: {INPUT_DIR}", file=sys.stderr)
        print("Set RAIL_INDICATOR_ROOT or check the folder structure described in this file's docstring.", file=sys.stderr)
        sys.exit(1)

    data = load_all(INPUT_DIR)
    for key in ALL_FILE_KEYS:
        rate = suppression_rate(data[key])
        print(f"  loaded {key}: {len(data[key]):,} rows ({rate*100:.1f}% suppressed)")

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    print("\nBuilding charts...")
    regions = bc.top_regions_by_volume(data["monthly"])
    colors = bc.region_color_map(regions)
    charts = {
        "01_overall_monthly_trend": bc.chart_overall_monthly_trend(data["monthly"]),
        "02_top_regions_monthly": bc.chart_top_regions_monthly(data["monthly"], colors),
        "03_avg_journey_length": bc.chart_avg_journey_length(data["monthly"]),
        "04_commute_leisure_share": bc.chart_commute_leisure_share(data["monthly"]),
        "05_indexed_regional": bc.chart_indexed_regional(data["indexed_monthly"], colors),
        "06_od_heatmap": bc.chart_od_heatmap(data["od_yearly"]),
        "07_top_routes": bc.chart_top_routes(data["od_yearly"]),
        "08_suppression_summary": bc.chart_suppression_summary(
            {k: suppression_rate(df) for k, df in data.items()}
        ),
    }
    print(f"  {len(charts)} charts written to {bc.CHARTS_DIR}")

    print("\nBuilding Excel workbook...")
    xlsx_path = build_workbook(data)
    print(f"  wrote {xlsx_path}")

    print("\nBuilding Word report...")
    row_counts = {k: len(df) for k, df in data.items()}
    docx_path = build_document(charts, row_counts, OUTPUT_DIR / "rail_busyness_indicator_methodology_and_report.docx")
    print(f"  wrote {docx_path}")

    print("\nBuilding PowerPoint deck...")
    stats = compute_headline_stats(data)
    pptx_path = build_deck(charts, stats, OUTPUT_DIR / "rail_busyness_indicator_findings.pptx")
    print(f"  wrote {pptx_path}")

    print("\nDone. Three deliverables in:", OUTPUT_DIR)


if __name__ == "__main__":
    main()
