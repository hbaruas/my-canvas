"""
Shared configuration and schema definitions for the Rail Busyness Indicator
publication pipeline.

This is the ONE place to fix things if the real exported files turn out to
differ from what's assumed here. Everything else (the main pipeline, the
chart code, the Word/Excel/PPT builders) reads column names FROM this file
rather than hardcoding them again -- so a mismatch only needs fixing once.

ASSUMPTIONS FLAGGED BELOW were reconstructed from the project's own
conversation history (the actual SQL/pandas code that built these exports),
not verified against a real exported file. Anything marked CONFIRMED came
directly from pasted code; anything marked ASSUMED is a best reconstruction
and is the first thing to check if the pipeline errors on a real file with
a KeyError.
"""

from __future__ import annotations
import re
from pathlib import Path

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

# The one fixed assumption: this subpath never changes, even though the
# drive/parent folder will differ between the Windows machine and the Mac.
# Override by setting the RAIL_INDICATOR_ROOT environment variable, or by
# editing DEFAULT_ROOT below for a specific machine.
RELATIVE_DATA_SUBPATH = Path("Rail_Indicator") / "Data"

import os

def _default_root() -> Path:
    env_root = os.environ.get("RAIL_INDICATOR_ROOT")
    if env_root:
        return Path(env_root)
    # Fall back to "wherever this script's repo root is" -- two levels up
    # from scripts/rail_indicator_config.py is the Rail_Indicator folder's
    # parent, so Rail_Indicator/Data resolves correctly without hardcoding
    # a drive letter or a home directory.
    return Path(__file__).resolve().parent.parent.parent

DEFAULT_ROOT = _default_root()
INPUT_DIR = DEFAULT_ROOT / RELATIVE_DATA_SUBPATH / "Input_data"
OUTPUT_DIR = DEFAULT_ROOT / RELATIVE_DATA_SUBPATH / "Output_data"

DISCLOSURE_SUPPRESSION_MARKER = "c"  # CONFIRMED

# ---------------------------------------------------------------------------
# File discovery: match on the STABLE middle part of the filename only.
# Real filenames look like:
#   0022292_14092026_busyness_indicator_DISCLOSURE_SAFE_indexed_monthly_CHECKED.csv
# The numeric ticket prefix and the date will be different on every future
# export, and the _CHECKED suffix may or may not always be present -- so
# matching is done with a substring search on the part that won't change.
# ---------------------------------------------------------------------------

FILE_PATTERNS = {
    # destination-only (4 files)
    "weekly":          "busyness_indicator_DISCLOSURE_SAFE_weekly",
    "monthly":         "busyness_indicator_DISCLOSURE_SAFE_monthly",
    "indexed_weekly":  "busyness_indicator_DISCLOSURE_SAFE_indexed_weekly",
    "indexed_monthly": "busyness_indicator_DISCLOSURE_SAFE_indexed_monthly",
    # origin-destination (4 files)
    "od_daily":        "busyness_OD_DISCLOSURE_SAFE_od_daily",
    "od_weekly":       "busyness_OD_DISCLOSURE_SAFE_od_weekly",
    "od_monthly":      "busyness_OD_DISCLOSURE_SAFE_od_monthly",
    "od_yearly":       "busyness_OD_DISCLOSURE_SAFE_od_yearly",
}
# NOTE: "weekly" as a substring does NOT accidentally match "indexed_weekly"
# or vice versa, because the check below requires the pattern for "weekly"
# (ending "SAFE_weekly") to be followed immediately by a non-letter
# (underscore or end of string) -- "SAFE_weekly" is not a substring of
# "SAFE_indexed_weekly" at all, so this is safe without extra logic.

# ---------------------------------------------------------------------------
# Column schema per file key.
# "period_col" is the x-axis / time grouping column for that grain.
# "keys" are the non-measure identifying columns (region codes/names etc).
# "measures" are the published count/total columns -- these are the ones
# that get suppressed (replaced with "c") and, in the next export onward,
# rounded to base 5.
# "extra" are derived columns present but not part of the suppression set
# in quite the same way (e.g. journeys_index, is_within_region).
# ---------------------------------------------------------------------------

DEST_ONLY_KEYS = ["destination_region_code", "destination_region_name"]  # CONFIRMED (names), ASSUMED (these are the only keys)

# ASSUMED: the exact period column name for the destination-only weekly/
# monthly files. Confirmed convention from the OD table is "iso_week" /
# "month" (ISO-week string "YYYY-Www", month string "YYYY-MM") -- assumed
# consistent here since it's the same pipeline file. If real headers say
# "week" instead of "iso_week", fix PERIOD_COL below only.
PERIOD_COL = {
    "weekly": "iso_week",
    "monthly": "month",
    "indexed_weekly": "iso_week",
    "indexed_monthly": "month",
    "od_daily": "travel_date",
    "od_weekly": "iso_week",
    "od_monthly": "month",
    "od_yearly": "year",
}  # CONFIRMED for od_* (pasted code); ASSUMED for the destination-only ones

RAW_MASK_COLUMNS = [  # CONFIRMED -- grepped directly from the pipeline file
    "net_passenger_journeys",
    "net_tickets",
    "total_passenger_miles",
    "total_ticket_miles_unweighted",
    "commute_like_journeys",
    "leisure_like_journeys",
    "avg_journey_miles_weighted",
    "avg_journey_miles_unweighted",
    "row_count",
]

# These two columns are genuine AVERAGES despite the "_weighted"/"_unweighted"
# names (a naming artifact from before Bug 2 was fixed -- the formula
# changed, the column name didn't). Reported meaning, for anything written
# about them in the methodology doc:
#   avg_journey_miles_weighted   -> average journey length (miles per passenger journey)
#   avg_journey_miles_unweighted -> average passenger-miles per ticket sold
AVERAGE_COLUMNS_DEST = ["avg_journey_miles_weighted", "avg_journey_miles_unweighted"]

INDEXED_EXTRA_COLUMNS = ["journeys_index"]  # CONFIRMED name; ASSUMED no other extra cols

OD_KEYS = [  # CONFIRMED -- pasted code
    "origin_region_code", "origin_region_name",
    "destination_region_code", "destination_region_name",
]

OD_MEASURES = [  # CONFIRMED -- pasted code (_od_measures)
    "net_passenger_journeys", "net_tickets", "total_passenger_miles",
    "commute_like_journeys", "leisure_like_journeys", "row_count",
]

OD_AVERAGE_COLUMNS = ["avg_journey_miles", "avg_passenger_miles_per_ticket"]  # CONFIRMED
OD_EXTRA_COLUMNS = ["is_within_region"]  # CONFIRMED

# Columns present in every file that are never suppressed and never rounded.
COMMON_META_COLUMNS = ["low_count_flag", "disclosure_status"]  # CONFIRMED

FILE_SCHEMA = {
    "weekly":          {"keys": DEST_ONLY_KEYS, "measures": RAW_MASK_COLUMNS, "extra": [], "kind": "dest"},
    "monthly":         {"keys": DEST_ONLY_KEYS, "measures": RAW_MASK_COLUMNS, "extra": [], "kind": "dest"},
    "indexed_weekly":  {"keys": DEST_ONLY_KEYS, "measures": RAW_MASK_COLUMNS, "extra": INDEXED_EXTRA_COLUMNS, "kind": "dest"},
    "indexed_monthly": {"keys": DEST_ONLY_KEYS, "measures": RAW_MASK_COLUMNS, "extra": INDEXED_EXTRA_COLUMNS, "kind": "dest"},
    "od_daily":        {"keys": OD_KEYS, "measures": OD_MEASURES + OD_AVERAGE_COLUMNS, "extra": OD_EXTRA_COLUMNS, "kind": "od"},
    "od_weekly":       {"keys": OD_KEYS, "measures": OD_MEASURES + OD_AVERAGE_COLUMNS, "extra": OD_EXTRA_COLUMNS, "kind": "od"},
    "od_monthly":       {"keys": OD_KEYS, "measures": OD_MEASURES + OD_AVERAGE_COLUMNS, "extra": OD_EXTRA_COLUMNS, "kind": "od"},
    "od_yearly":       {"keys": OD_KEYS, "measures": OD_MEASURES + OD_AVERAGE_COLUMNS, "extra": OD_EXTRA_COLUMNS, "kind": "od"},
}

COUNT_LIKE_MEASURES = {
    # Which measures in each file are genuine "counts" (rounded to base 5
    # from the next export onward) vs continuous derived figures (never
    # rounded). Mirrors the _is_roundable() logic from the TRE pipeline.
    "net_passenger_journeys", "net_tickets", "total_passenger_miles",
    "total_ticket_miles_unweighted", "commute_like_journeys",
    "leisure_like_journeys", "row_count",
}

ALL_FILE_KEYS = list(FILE_PATTERNS.keys())


def find_input_file(file_key: str, input_dir: Path = INPUT_DIR) -> Path:
    """Find the real file on disk matching this file_key's stable pattern,
    regardless of the ticket-number/date prefix or _CHECKED-style suffix."""
    pattern = FILE_PATTERNS[file_key]
    candidates = [p for p in input_dir.glob("*.csv") if pattern in p.name]
    if not candidates:
        raise FileNotFoundError(
            f"No file matching pattern '{pattern}' found in {input_dir}. "
            f"Expected something like '..._{pattern}_....csv'."
        )
    if len(candidates) > 1:
        # Prefer the most recently modified -- if an old export was left
        # behind alongside a newer one, don't silently pick the stale file.
        candidates.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    return candidates[0]
