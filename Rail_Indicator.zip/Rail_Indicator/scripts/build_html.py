"""
Builds a single, self-contained, shareable HTML page with interactive
Plotly charts + the same methodology text as the Word report, so a
stakeholder with no GCP/TRE access can explore the data themselves --
hover for exact values, zoom, click a region in a legend to isolate or
compare it, switch frequency/year/region via dropdown where that's the
natural interactive replacement for what the static report shows as
several separate images.

Design note, worth stating explicitly rather than leaving implicit: this
is NOT a 1:1 interactive copy of all 20 static chart images. Interactivity
replaces some of that variety directly -- "every region" becomes a legend
you click through rather than a 12-panel grid; "monthly vs weekly" becomes
a button rather than two separate charts. The full exhaustive static
breakdown (every region individually, every frequency, as fixed images)
remains the Word report's job. This page is for exploring, not auditing.
"""

from __future__ import annotations
import html as htmllib
from datetime import date

import numpy as np
import pandas as pd
import plotly.graph_objects as go

from load_data import numeric_view, suppression_rate, derive_dest_daily_from_od
import build_charts as bc
import chart_text as ct

PLOTLY_CDN = "https://cdn.plot.ly/plotly-2.35.2.min.js"


def _fig_to_div(fig, div_id):
    fig.update_layout(
        paper_bgcolor=bc.SURFACE, plot_bgcolor=bc.SURFACE,
        font=dict(family="system-ui, -apple-system, sans-serif", color=bc.INK_PRIMARY),
        margin=dict(t=60, l=60, r=30, b=60),
        legend=dict(bgcolor="rgba(0,0,0,0)"),
        hovermode="x unified",
    )
    fig.update_xaxes(gridcolor=bc.GRID, zerolinecolor=bc.BASELINE)
    fig.update_yaxes(gridcolor=bc.GRID, zerolinecolor=bc.BASELINE)
    return fig.to_html(full_html=False, include_plotlyjs=False, div_id=div_id)


def _freq_buttons(n_per_freq: list[int], labels: list[str]):
    """n_per_freq: number of traces belonging to each frequency option, in
    the order traces were added. Returns updatemenu buttons that show only
    one frequency's traces at a time."""
    total = sum(n_per_freq)
    buttons = []
    offset = 0
    for n, label in zip(n_per_freq, labels):
        visible = [False] * total
        for i in range(offset, offset + n):
            visible[i] = True
        buttons.append(dict(label=label, method="update", args=[{"visible": visible}]))
        offset += n
    return buttons


# ---------------------------------------------------------------------------
# Figure builders
# ---------------------------------------------------------------------------

def fig_overall_volume(monthly, weekly, dest_daily):
    fig = go.Figure()
    specs = [("Monthly", monthly, "month"), ("Weekly", weekly, "iso_week"), ("Daily (derived)", dest_daily, "travel_date")]
    for i, (label, df, pcol) in enumerate(specs):
        nv = numeric_view(df, ["net_passenger_journeys"])
        s = nv.groupby(pcol)["net_passenger_journeys"].sum(min_count=1).sort_index()
        fig.add_trace(go.Scatter(x=s.index, y=s.values, mode="lines+markers", name=label,
                                  line=dict(color=bc.CATEGORICAL[0 if i < 2 else 2], width=2.5),
                                  visible=(i == 0)))
    fig.update_layout(
        title="Total passenger journeys, all destination regions",
        yaxis_title="Net passenger journeys",
        updatemenus=[dict(type="buttons", direction="right", x=1, xanchor="right", y=1.18,
                           buttons=_freq_buttons([1, 1, 1], ["Monthly", "Weekly", "Daily (derived)"]))],
    )
    return fig


def fig_by_region_overlay(monthly, weekly, regions, colors, value_col="net_passenger_journeys", y_title="Net passenger journeys"):
    fig = go.Figure()
    for df, pcol in [(monthly, "month"), (weekly, "iso_week")]:
        nv = numeric_view(df, [value_col])
        for region in regions:
            sub = nv[nv["destination_region_name"] == region].sort_values(pcol)
            fig.add_trace(go.Scatter(x=sub[pcol], y=sub[value_col], mode="lines", name=region,
                                      line=dict(color=colors[region], width=2),
                                      visible=(df is monthly), legendgroup=region))
    fig.update_layout(
        title="By destination region -- click a region in the legend to isolate or compare it",
        yaxis_title=y_title,
        updatemenus=[dict(type="buttons", direction="right", x=1, xanchor="right", y=1.18,
                           buttons=_freq_buttons([len(regions), len(regions)], ["Monthly", "Weekly"]))],
    )
    return fig


def fig_commute_leisure(monthly, weekly, mode="share"):
    fig = go.Figure()
    for i, (df, pcol) in enumerate([(monthly, "month"), (weekly, "iso_week")]):
        nv = numeric_view(df, ["commute_like_journeys", "leisure_like_journeys"])
        g = nv.groupby(pcol)[["commute_like_journeys", "leisure_like_journeys"]].sum(min_count=1).sort_index()
        if mode == "share":
            g = g.div(g.sum(axis=1), axis=0) * 100
        fig.add_trace(go.Bar(x=g.index.astype(str), y=g["commute_like_journeys"], name="Commute-like",
                              marker_color=bc.CATEGORICAL[0], visible=(i == 0), legendgroup="commute", offsetgroup=1 if mode != "share" else None))
        fig.add_trace(go.Bar(x=g.index.astype(str), y=g["leisure_like_journeys"], name="Leisure-like",
                              marker_color=bc.CATEGORICAL[1], visible=(i == 0), legendgroup="leisure", offsetgroup=2 if mode != "share" else None))
    fig.update_layout(
        barmode="stack" if mode == "share" else "group",
        title=f"Commute-like vs. leisure-like journeys ({'% share' if mode == 'share' else 'raw counts'})",
        yaxis_title="% of journeys" if mode == "share" else "Net passenger journeys",
        updatemenus=[dict(type="buttons", direction="right", x=1, xanchor="right", y=1.18,
                           buttons=_freq_buttons([2, 2], ["Monthly", "Weekly"]))],
    )
    return fig


def fig_commute_leisure_by_region(monthly, regions):
    fig = go.Figure()
    nv = numeric_view(monthly, ["commute_like_journeys", "leisure_like_journeys"])
    for i, region in enumerate(regions):
        sub = nv[nv["destination_region_name"] == region].sort_values("month")
        fig.add_trace(go.Bar(x=sub["month"], y=sub["commute_like_journeys"], name="Commute-like",
                              marker_color=bc.CATEGORICAL[0], visible=(i == 0), showlegend=(i == 0)))
        fig.add_trace(go.Bar(x=sub["month"], y=sub["leisure_like_journeys"], name="Leisure-like",
                              marker_color=bc.CATEGORICAL[1], visible=(i == 0), showlegend=(i == 0)))
    buttons = []
    for i, region in enumerate(regions):
        visible = [False] * (2 * len(regions))
        visible[2 * i] = True
        visible[2 * i + 1] = True
        buttons.append(dict(label=region, method="update", args=[{"visible": visible}, {"title": f"Commute-like vs. leisure-like journeys -- {region}"}]))
    fig.update_layout(
        barmode="group", title=f"Commute-like vs. leisure-like journeys -- {regions[0]}",
        yaxis_title="Net passenger journeys",
        updatemenus=[dict(type="dropdown", x=1, xanchor="right", y=1.18, buttons=buttons)],
    )
    return fig


def fig_index_by_region(idx_monthly, idx_weekly, regions, colors):
    fig = go.Figure()
    for df, pcol in [(idx_monthly, "month"), (idx_weekly, "iso_week")]:
        nv = numeric_view(df, ["journeys_index"])
        for region in regions:
            sub = nv[nv["destination_region_name"] == region].sort_values(pcol)
            fig.add_trace(go.Scatter(x=sub[pcol], y=sub["journeys_index"], mode="lines", name=region,
                                      line=dict(color=colors[region], width=2), visible=(df is idx_monthly), legendgroup=region))
    fig.add_hline(y=100, line_color=bc.BASELINE)
    fig.update_layout(
        title="Journey volume index by region (each region's own base period = 100)",
        yaxis_title="Index",
        updatemenus=[dict(type="buttons", direction="right", x=1, xanchor="right", y=1.18,
                           buttons=_freq_buttons([len(regions), len(regions)], ["Monthly", "Weekly"]))],
    )
    return fig


def fig_heatmap(od_yearly):
    years = sorted(od_yearly["year"].dropna().unique())
    regions_master = sorted(set(od_yearly["origin_region_name"]) | set(od_yearly["destination_region_name"]))
    fig = go.Figure()
    for i, year in enumerate(years):
        df = od_yearly[od_yearly["year"] == year]
        nv = numeric_view(df, ["net_passenger_journeys"])
        pivot = nv.pivot_table(index="origin_region_name", columns="destination_region_name",
                                values="net_passenger_journeys", aggfunc="sum").reindex(index=regions_master, columns=regions_master)
        fig.add_trace(go.Heatmap(z=pivot.values, x=regions_master, y=regions_master,
                                  colorscale=[[0, bc.SEQ_BLUE[0]], [1, bc.SEQ_BLUE[-1]]],
                                  colorbar=dict(title="Journeys"), visible=(i == 0),
                                  hovertemplate="From %{y}<br>To %{x}<br>%{z:,.0f} journeys<extra></extra>"))
    buttons = [dict(label=year, method="update", args=[{"visible": [j == i for j in range(len(years))]}])
               for i, year in enumerate(years)]
    fig.update_layout(
        title=f"Origin -> destination journey volume -- {years[0]}",
        xaxis_title="Destination region", yaxis_title="Origin region",
        updatemenus=[dict(type="dropdown", x=1, xanchor="right", y=1.18, buttons=buttons)] if len(years) > 1 else [],
    )
    return fig


def fig_all_routes(od_yearly):
    years = sorted(od_yearly["year"].dropna().unique())
    fig = go.Figure()
    for i, year in enumerate(years):
        df = od_yearly[(od_yearly["year"] == year) & (od_yearly["is_within_region"] == False)]
        nv = numeric_view(df, ["net_passenger_journeys"]).dropna(subset=["net_passenger_journeys"])
        nv = nv.assign(route=nv["origin_region_name"] + " -> " + nv["destination_region_name"]).sort_values("net_passenger_journeys")
        fig.add_trace(go.Bar(x=nv["net_passenger_journeys"], y=nv["route"], orientation="h",
                              marker_color=bc.CATEGORICAL[0], visible=(i == 0)))
    buttons = [dict(label=year, method="update", args=[{"visible": [j == i for j in range(len(years))]}])
               for i, year in enumerate(years)]
    fig.update_layout(
        title=f"Cross-region routes, ranked by volume -- {years[0]}",
        xaxis_title="Net passenger journeys", height=max(500, 22 * od_yearly["origin_region_name"].nunique() ** 2 // 4),
        updatemenus=[dict(type="dropdown", x=1, xanchor="right", y=1.18, buttons=buttons)] if len(years) > 1 else [],
    )
    return fig


def fig_suppression(rates: dict):
    fig = go.Figure(go.Bar(x=[v * 100 for v in rates.values()], y=list(rates.keys()), orientation="h",
                            marker_color=bc.CATEGORICAL[0]))
    fig.update_layout(title="Share of rows suppressed, by published file", xaxis_title="% suppressed")
    return fig


# ---------------------------------------------------------------------------
# Page assembly
# ---------------------------------------------------------------------------

def _esc(text):
    return htmllib.escape(text)


def _section_html(title, div, date_range, methodology, how_to_read, caveats):
    caveat_html = "".join(f"<li>{_esc(c)}</li>" for c in caveats)
    caveat_block = f'<ul class="caveats">{caveat_html}</ul>' if caveats else ""
    return f"""
    <section class="chart-section">
      <h2>{_esc(title)}</h2>
      <p class="date-range">Data coverage: {_esc(date_range)}</p>
      <div class="chart-wrap">{div}</div>
      <div class="meta-grid">
        <div><strong>How this is calculated:</strong> {_esc(methodology)}</div>
        <div><strong>How to read this chart:</strong> {_esc(how_to_read)}</div>
      </div>
      {caveat_block}
    </section>
    """


def build_html_page(data: dict, out_path):
    weekly, monthly = data["weekly"], data["monthly"]
    idx_weekly, idx_monthly = data["indexed_weekly"], data["indexed_monthly"]
    od_daily, od_yearly = data["od_daily"], data["od_yearly"]
    dest_daily = derive_dest_daily_from_od(od_daily)

    all_regions = bc.all_regions_sorted(monthly)
    colors = bc.region_color_map(all_regions)

    sections = []

    sections.append(_section_html(
        "Total passenger journeys over time",
        _fig_to_div(fig_overall_volume(monthly, weekly, dest_daily), "fig1"),
        bc.date_range_text(monthly, "month"), ct.JOURNEY_METHOD,
        ct.JOURNEY_READ + " Use the buttons above the chart to switch between monthly, weekly, and derived-daily views.",
        [ct.DAILY_DERIVED_CAVEAT]))

    sections.append(_section_html(
        "Journey volume by region",
        _fig_to_div(fig_by_region_overlay(monthly, weekly, all_regions, colors), "fig2"),
        bc.date_range_text(monthly, "month"), ct.JOURNEY_METHOD,
        ct.JOURNEY_READ + " Every region is plotted -- click any region's name in the legend to hide/show it, "
        "or double-click one to isolate it.", []))

    monthly_len = monthly.copy()
    weekly_len = weekly.copy()
    for df in (monthly_len, weekly_len):
        nv = numeric_view(df, ["total_passenger_miles", "net_passenger_journeys"])
        df["avg_journey_miles_calc"] = nv["total_passenger_miles"] / nv["net_passenger_journeys"].replace(0, np.nan)

    sections.append(_section_html(
        "Average journey length, by region",
        _fig_to_div(fig_by_region_overlay(monthly_len, weekly_len, all_regions, colors,
                                           value_col="avg_journey_miles_calc", y_title="Miles per passenger journey"), "fig3"),
        bc.date_range_text(monthly, "month"), ct.LEN_METHOD, ct.LEN_READ, []))

    sections.append(_section_html(
        "Commute-like vs. leisure-like journeys -- share",
        _fig_to_div(fig_commute_leisure(monthly, weekly, "share"), "fig4"),
        bc.date_range_text(monthly, "month"), ct.CL_METHOD, ct.SHARE_READ, []))

    sections.append(_section_html(
        "Commute-like vs. leisure-like journeys -- raw volumes",
        _fig_to_div(fig_commute_leisure(monthly, weekly, "volume"), "fig5"),
        bc.date_range_text(monthly, "month"), ct.CL_METHOD, ct.VOL_READ, []))

    sections.append(_section_html(
        "Commute-like vs. leisure-like journeys -- by region",
        _fig_to_div(fig_commute_leisure_by_region(monthly, all_regions), "fig6"),
        bc.date_range_text(monthly, "month"), ct.CL_METHOD,
        ct.VOL_READ + " Use the dropdown above the chart to pick a region.", []))

    sections.append(_section_html(
        "Journey volume index, by region",
        _fig_to_div(fig_index_by_region(idx_monthly, idx_weekly, all_regions, colors), "fig7"),
        bc.date_range_text(idx_monthly, "month"), ct.IDX_METHOD, ct.IDX_READ, []))

    sections.append(_section_html(
        "Where journeys start and end",
        _fig_to_div(fig_heatmap(od_yearly), "fig8"),
        bc.date_range_text(od_yearly, "year"), ct.HEAT_METHOD, ct.HEAT_READ,
        ["Gray/blank cells mean suppressed or genuinely zero journeys between that pair -- "
         "the two cannot be told apart from the published data alone."]))

    sections.append(_section_html(
        "Cross-region routes, ranked by volume",
        _fig_to_div(fig_all_routes(od_yearly), "fig9"),
        bc.date_range_text(od_yearly, "year"), ct.ROUTE_METHOD, ct.ROUTE_READ, []))

    rates = {k: suppression_rate(df) for k, df in data.items()}
    sections.append(_section_html(
        "Data completeness",
        _fig_to_div(fig_suppression(rates), "fig10"),
        "all files, full period each covers", ct.SUPP_METHOD, ct.SUPP_READ, []))

    page = f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>GB Rail Busyness Indicator -- Interactive Findings</title>
<script src="{PLOTLY_CDN}"></script>
<style>
  :root {{
    --surface: {bc.SURFACE}; --ink: {bc.INK_PRIMARY}; --muted: {bc.INK_SECONDARY};
    --accent: {bc.CATEGORICAL[0]}; --border: {bc.BASELINE};
  }}
  body {{ font-family: system-ui, -apple-system, "Segoe UI", sans-serif; background: var(--surface);
          color: var(--ink); margin: 0; padding: 0 16px 60px; }}
  .wrap {{ max-width: 1100px; margin: 0 auto; }}
  header {{ padding: 40px 0 20px; border-bottom: 1px solid var(--border); margin-bottom: 20px; }}
  h1 {{ font-size: 1.8rem; margin: 0 0 6px; }}
  .subtitle {{ color: var(--muted); font-size: 1rem; }}
  nav {{ background: #fff; border: 1px solid var(--border); border-radius: 8px; padding: 14px 18px;
         margin-bottom: 30px; font-size: 0.9rem; }}
  nav a {{ color: var(--accent); text-decoration: none; margin-right: 14px; display: inline-block; }}
  .chart-section {{ border: 1px solid var(--border); border-radius: 10px; padding: 24px;
                     margin-bottom: 28px; background: #fff; }}
  .chart-section h2 {{ margin-top: 0; font-size: 1.25rem; }}
  .date-range {{ color: var(--muted); font-size: 0.85rem; font-style: italic; margin-top: -8px; }}
  .chart-wrap {{ margin: 16px 0; }}
  .meta-grid {{ display: grid; grid-template-columns: 1fr 1fr; gap: 16px; font-size: 0.92rem; }}
  .meta-grid strong {{ color: var(--ink); }}
  @media (max-width: 720px) {{ .meta-grid {{ grid-template-columns: 1fr; }} }}
  ul.caveats {{ font-size: 0.85rem; color: var(--muted); font-style: italic; margin-top: 14px; }}
  footer {{ color: var(--muted); font-size: 0.85rem; text-align: center; padding: 30px 0; }}
</style>
</head>
<body>
<div class="wrap">
  <header>
    <h1>GB Rail Busyness Indicator -- Interactive Findings</h1>
    <p class="subtitle">Generated {date.today().strftime('%d %B %Y')} from the published, disclosure-safe dataset.
    Hover any chart for exact values; click a legend entry to toggle a series; use the buttons/dropdowns above a
    chart to switch frequency, region, or year. Full methodology and every region as individual static charts are
    in the accompanying Word report.</p>
  </header>
  <nav>{''.join(f'<a href="#s{i}">{_esc(s.split("<h2>")[1].split("</h2>")[0])}</a>' for i, s in enumerate(sections))}</nav>
  {''.join(f'<div id="s{i}">{s}</div>' for i, s in enumerate(sections))}
  <footer>GB Rail Busyness Indicator -- provisional, pre-approval output. Suppressed and rounded per standard
  statistical disclosure control rules.</footer>
</div>
</body>
</html>"""

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(page, encoding="utf-8")
    return out_path
