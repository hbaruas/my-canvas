"""
Shared plain-language methodology/how-to-read text, used by BOTH the static
(matplotlib, for Word/PPT) and interactive (plotly, for the HTML page) chart
builders -- kept in one place so the two don't drift apart when one gets
edited and the other doesn't.
"""

JOURNEY_METHOD = (
    "Starts from individual ticket sale and refund transactions in the source rail settlement "
    "data (LENNON). Each transaction carries a passenger-journeys figure (people x journey "
    "factor -- a return ticket counts as 2 journeys, a season ticket as many more, spread across "
    "its validity). These are summed for every transaction landing in a given destination region "
    "and time period; a refund subtracts from the total it originally added, so a ticket sold and "
    "later fully refunded nets to zero. That sum is 'net passenger journeys' -- 'net' meaning net "
    "of refunds, nothing more."
)
JOURNEY_READ = (
    "Each point is the total number of passenger journeys ending in that region (or overall) "
    "during that time period. A gap in the line means the figure for that period was suppressed "
    "(10 or fewer underlying records) -- treat it as unknown, not as zero."
)

DAILY_DERIVED_CAVEAT = (
    "No destination-only file exists at daily grain -- this is DERIVED by taking the "
    "origin-destination daily file and summing over origin (collapsing origin+destination+day "
    "down to just destination+day). Because the origin-destination file has its own, "
    "finer-grained suppression, this derived daily total is a slight UNDERCOUNT wherever an "
    "origin-level cell was suppressed -- more so than the directly-published weekly/monthly files."
)

LEN_METHOD = (
    "For every transaction, the source data gives a 'ticket miles' figure -- already the total "
    "passenger-miles represented by that transaction (distance of the flow x number of journeys "
    "it covers, NOT a per-journey distance that needs multiplying again). These are summed across "
    "all transactions in a region/period to give total passenger-miles, and separately all the "
    "passenger journeys are summed. The average journey length is total passenger-miles divided "
    "by total passenger journeys, computed ONCE from those two summed totals -- never by averaging "
    "a lower-grain average (e.g. never by averaging 4 weekly averages to get a monthly one), which "
    "would be mathematically wrong whenever the underlying weeks have different volumes."
)
LEN_READ = (
    "Each point is the average distance of a passenger journey (in miles) ending in that region "
    "(or overall) during that period. A longer average suggests more long-distance/leisure travel "
    "relative to short commuter hops; a shorter one suggests the opposite. Not weighted by fare or "
    "revenue -- purely by distance."
)

CL_METHOD = (
    "Every transaction's distance (ticket miles / passenger journeys, i.e. miles per journey, not "
    "total passenger-miles) is compared against a single threshold, currently 30 miles. Journeys "
    "at or under the threshold are classed commute-like; longer journeys are leisure-like. Each "
    "transaction's passenger-journeys figure is added to whichever side it falls on, then those "
    "are summed per region/period -- this is a provisional classification by distance only, not "
    "an actual record of trip purpose."
)
SHARE_READ = (
    "Each bar is 100% of that period's journeys, split into the commute-like share (bottom) and "
    "leisure-like share (top). Shows the MIX shifting over time -- a growing leisure share could "
    "mean leisure travel genuinely grew, or commute travel fell, or both; this chart alone can't "
    "distinguish those. Pair with the raw-volume version to tell them apart."
)
VOL_READ = (
    "Each pair of bars/lines is the actual count of commute-like and leisure-like journeys in that "
    "period. Unlike the share chart, this shows real volume changes, not just the mix."
)

IDX_METHOD = (
    "For each region, one period is fixed as the base (=100). Every other period's net passenger "
    "journeys for that SAME region is divided by that region's own base-period value and multiplied "
    "by 100. Each region is therefore indexed only against its own history, independently of every "
    "other region."
)
IDX_READ = (
    "A value of 150 means that region had 50% more journeys than in its own base period; 80 means "
    "20% fewer. The horizontal line at 100 is each region's own starting point, not a shared "
    "reference across regions -- two regions both showing 120 does NOT mean they have the same "
    "volume, only the same relative growth from their own baselines."
)

HEAT_METHOD = (
    "Every transaction's origin region and destination region are both recorded, and passenger "
    "journeys are summed for every origin-destination pair in the chosen year. Each cell in the "
    "grid is one such pair's total."
)
HEAT_READ = (
    "Read a cell as 'journeys FROM the row region TO the column region.' Darker blue means more "
    "journeys; the diagonal (same origin and destination) is within-region travel, not inter-region "
    "flow. This matrix is not symmetric -- a row/column pair can differ from its mirror image, "
    "reflecting a genuine imbalance in flow direction."
)

ROUTE_METHOD = (
    "Same underlying sum as the heatmap (passenger journeys by origin-destination pair, for the "
    "chosen year), restricted to pairs where origin and destination differ (cross-region travel "
    "only), then sorted from highest to lowest and drawn as one bar per route."
)
ROUTE_READ = (
    "Each bar is one specific origin -> destination route; length is the total passenger journeys "
    "on that route in the stated year. Routes are ranked busiest to least busy -- every cross-region "
    "route with any non-suppressed data, not a top-10 selection."
)

SUPP_METHOD = (
    "For each published file, the share of rows where disclosure control suppressed every figure "
    "(because row_count or a published count was 10 or fewer) is counted directly from that file."
)
SUPP_READ = (
    "Higher bars mean more of that file is masked rather than real figures. Finer-grained files "
    "(more time periods, or both origin and destination) are suppressed more often because each "
    "individual cell covers fewer underlying records."
)
