"""
Builds every chart as a saved PNG under Output_data/charts/, for embedding
into the Word report and the PowerPoint deck.

Every chart-building function returns a dict with everything the Word report
needs to write a full, plain-language methodology section next to the image:
  path          -- the saved PNG
  title
  date_range    -- "data covers X to Y", computed from the actual data, not hardcoded
  methodology   -- how the raw GCP data becomes this number (the aggregation
                   logic in words, not code)
  how_to_read   -- what the chart tells you and how to interpret it
  x_label / y_label -- plain-language explanation of each axis, not just the
                   column name
  caveats       -- list of strings, anything a reader needs to know before
                   trusting the chart at face value

Palette and mark rules follow the project's dataviz skill: fixed categorical
hue order (a region keeps the same color in every chart it appears in), one
hue for sequential/magnitude encodings, one axis only, hairline recessive
gridlines, thin lines with rounded caps, a legend whenever there are 2+
series, no rainbow colormaps, no dual axes, no scientific-notation axis
numbers (an "M"/"K" suffix formatter is applied everywhere a count appears).
"""

from __future__ import annotations
import math
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
from matplotlib.colors import LinearSegmentedColormap
import numpy as np
import pandas as pd

from rail_indicator_config import OUTPUT_DIR
from load_data import numeric_view

CHARTS_DIR = OUTPUT_DIR / "charts"

# --- Validated palette (light mode), from references/palette.md ----------
CATEGORICAL = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#6250d6", "#008300", "#e34948"]
SEQ_BLUE = ["#cde2fb", "#9ec5f4", "#6da7ec", "#3987e5", "#1c5cab", "#0d366b"]
INK_PRIMARY = "#0b0b0b"
INK_SECONDARY = "#52514e"
INK_MUTED = "#898781"
GRID = "#e1e0d9"
BASELINE = "#c3c2b7"
SURFACE = "#fcfcfb"
SUPPRESSED_GRAY = "#d9d8d2"

plt.rcParams.update({
    "figure.facecolor": SURFACE, "axes.facecolor": SURFACE,
    "axes.edgecolor": BASELINE, "axes.labelcolor": INK_SECONDARY,
    "text.color": INK_PRIMARY, "xtick.color": INK_MUTED, "ytick.color": INK_MUTED,
    "font.family": "sans-serif", "font.size": 11,
    "axes.titlesize": 13, "axes.titleweight": "bold", "axes.titlecolor": INK_PRIMARY,
    "grid.color": GRID, "grid.linewidth": 0.8, "legend.frameon": False,
})


def _count_formatter(x, _pos=None):
    ax = abs(x)
    if ax >= 1_000_000:
        return f"{x/1_000_000:.1f}M".replace(".0M", "M")
    if ax >= 1_000:
        return f"{x/1_000:.0f}K"
    return f"{x:,.0f}"


def _clean_axes(ax, value_axis="y"):
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color(BASELINE)
    ax.spines["bottom"].set_color(BASELINE)
    ax.set_axisbelow(True)
    if value_axis == "y":
        ax.grid(axis="y")
        ax.yaxis.set_major_formatter(mticker.FuncFormatter(_count_formatter))
    elif value_axis == "x":
        ax.grid(axis="x")
        ax.xaxis.set_major_formatter(mticker.FuncFormatter(_count_formatter))


def _save(fig, name):
    CHARTS_DIR.mkdir(parents=True, exist_ok=True)
    path = CHARTS_DIR / f"{name}.png"
    fig.tight_layout()
    fig.savefig(path, dpi=200, facecolor=SURFACE)
    plt.close(fig)
    return path


def date_range_text(df: pd.DataFrame, period_col: str) -> str:
    vals = sorted(df[period_col].dropna().unique())
    if not vals:
        return "no data"
    return f"{vals[0]} to {vals[-1]} ({len(vals)} periods)"


def region_color_map(region_names: list[str]) -> dict[str, str]:
    """Fixed hue assignment, reused across every chart that shows regions --
    a given region is always the same color wherever it appears. Past 8
    regions, colors repeat (small multiples carry identity via the panel
    title in that case, not color alone, so this stays safe)."""
    return {name: CATEGORICAL[i % len(CATEGORICAL)] for i, name in enumerate(region_names)}


def top_regions_by_volume(dest_df: pd.DataFrame, value_col="net_passenger_journeys", n=6) -> list[str]:
    nv = numeric_view(dest_df, [value_col])
    totals = nv.groupby("destination_region_name")[value_col].sum()
    totals = totals[totals.index != "Unknown region"]
    return totals.sort_values(ascending=False).head(n).index.tolist()


def all_regions_sorted(dest_df: pd.DataFrame, value_col="net_passenger_journeys") -> list[str]:
    """Every region, busiest first, with Unknown region always last regardless
    of its volume -- it's not a real place, so it shouldn't be ranked as if
    comparing locations."""
    nv = numeric_view(dest_df, [value_col])
    totals = nv.groupby("destination_region_name")[value_col].sum()
    named = totals[totals.index != "Unknown region"].sort_values(ascending=False).index.tolist()
    return named + (["Unknown region"] if "Unknown region" in totals.index else [])


# ---------------------------------------------------------------------------
# Generic builders
# ---------------------------------------------------------------------------

def build_overall_trend(df, period_col, value_col, chart_id, title, y_label,
                         methodology, how_to_read, color=CATEGORICAL[0], caveats=None):
    nv = numeric_view(df, [value_col])
    series = nv.groupby(period_col)[value_col].sum(min_count=1).sort_index()
    fig, ax = plt.subplots(figsize=(8, 4.2))
    ax.plot(series.index, series.values, color=color, linewidth=2.2,
            solid_capstyle="round", marker="o", markersize=4)
    ax.set_title(title)
    ax.set_ylabel(y_label)
    plt.setp(ax.get_xticklabels(), rotation=45, ha="right")
    _clean_axes(ax, "y")
    path = _save(fig, chart_id)
    return {
        "path": path, "title": title,
        "date_range": date_range_text(df, period_col),
        "methodology": methodology, "how_to_read": how_to_read,
        "x_label": f"Time period ({period_col.replace('_', ' ')})",
        "y_label": y_label,
        "caveats": caveats or [],
    }


def build_small_multiples_by_region(df, period_col, region_col, series_specs, regions,
                                     chart_id, title, y_label, methodology, how_to_read,
                                     colors=None, caveats=None, ncols=None):
    """series_specs: list of (value_col, legend_label, color). One or more
    series per panel (e.g. just journeys, or commute+leisure together).
    regions: the exact, ordered list of panels to draw -- every single
    region the caller passes, never silently trimmed to a top-N."""
    n = len(regions)
    ncols = ncols or min(4, max(2, math.ceil(math.sqrt(n))))
    nrows = math.ceil(n / ncols)
    fig, axes = plt.subplots(nrows, ncols, figsize=(3.1 * ncols, 2.5 * nrows), sharex=False)
    axes = np.array(axes).reshape(-1)

    for i, region in enumerate(regions):
        ax = axes[i]
        sub = df[df[region_col] == region]
        for value_col, label, color in series_specs:
            nv = numeric_view(sub, [value_col]).groupby(period_col)[value_col].sum(min_count=1).sort_index()
            ax.plot(nv.index, nv.values, color=color, linewidth=1.6, solid_capstyle="round", label=label)
        ax.set_title(region, fontsize=10, fontweight="bold", loc="left")
        ax.tick_params(labelsize=7, rotation=45)
        ax.yaxis.set_major_formatter(mticker.FuncFormatter(_count_formatter))
        for spine in ("top", "right"):
            ax.spines[spine].set_visible(False)
        ax.spines["left"].set_color(BASELINE)
        ax.spines["bottom"].set_color(BASELINE)
        ax.grid(axis="y", linewidth=0.6)
        ax.set_axisbelow(True)

    for j in range(n, len(axes)):
        axes[j].axis("off")

    if len(series_specs) > 1:
        handles = [plt.Line2D([0], [0], color=c, linewidth=2, label=l) for _, l, c in series_specs]
        fig.legend(handles=handles, loc="lower center", ncol=len(series_specs), bbox_to_anchor=(0.5, -0.02))

    fig.suptitle(title, fontsize=15, fontweight="bold", y=1.0)
    path = _save(fig, chart_id)
    return {
        "path": path, "title": title,
        "date_range": date_range_text(df, period_col),
        "methodology": methodology, "how_to_read": how_to_read,
        "x_label": f"Time period ({period_col.replace('_', ' ')})",
        "y_label": y_label,
        "caveats": (caveats or []) + [
            "Every region is shown on its own panel with its own small y-axis -- panels are NOT on a "
            "shared scale, so comparing line heights visually between two panels does not compare their "
            "volumes directly. Use the overall/top-region overlay chart for that comparison instead."
        ],
    }


def build_top_overlay(df, period_col, region_col, value_col, colors, chart_id, title, y_label,
                       methodology, how_to_read, caveats=None):
    nv = numeric_view(df, [value_col])
    fig, ax = plt.subplots(figsize=(8.5, 4.6))
    for region, color in colors.items():
        sub = nv[nv[region_col] == region].sort_values(period_col)
        ax.plot(sub[period_col], sub[value_col], color=color, linewidth=2,
                solid_capstyle="round", label=region)
    ax.set_title(title)
    ax.set_ylabel(y_label)
    plt.setp(ax.get_xticklabels(), rotation=45, ha="right")
    _clean_axes(ax, "y")
    ax.legend(loc="upper left", bbox_to_anchor=(1.01, 1.0), fontsize=9)
    path = _save(fig, chart_id)
    return {
        "path": path, "title": title, "date_range": date_range_text(df, period_col),
        "methodology": methodology, "how_to_read": how_to_read,
        "x_label": f"Time period ({period_col.replace('_', ' ')})", "y_label": y_label,
        "caveats": caveats or [],
    }


def build_commute_leisure_share(df, period_col, chart_id, title, methodology, how_to_read):
    nv = numeric_view(df, ["commute_like_journeys", "leisure_like_journeys"])
    g = nv.groupby(period_col)[["commute_like_journeys", "leisure_like_journeys"]].sum(min_count=1).sort_index()
    share = g.div(g.sum(axis=1), axis=0) * 100
    fig, ax = plt.subplots(figsize=(8, 4.2))
    ax.bar(share.index.astype(str), share["commute_like_journeys"], color=CATEGORICAL[0], label="Commute-like", width=0.6)
    ax.bar(share.index.astype(str), share["leisure_like_journeys"], bottom=share["commute_like_journeys"],
           color=CATEGORICAL[1], label="Leisure-like", width=0.6)
    ax.set_title(title)
    ax.set_ylabel("% of journeys")
    ax.set_ylim(0, 100)
    plt.setp(ax.get_xticklabels(), rotation=45, ha="right")
    _clean_axes(ax, None)
    ax.grid(axis="y")
    ax.legend(loc="upper left", bbox_to_anchor=(1.01, 1.0))
    path = _save(fig, chart_id)
    return {
        "path": path, "title": title, "date_range": date_range_text(df, period_col),
        "methodology": methodology, "how_to_read": how_to_read,
        "x_label": f"Time period ({period_col.replace('_', ' ')})",
        "y_label": "Share of journeys (%), commute-like + leisure-like always summing to 100%",
        "caveats": [
            "The commute/leisure split is a provisional classification by a 30-mile-per-journey "
            "threshold, not a confirmed definition -- see Section 3.3 of the methodology.",
        ],
    }


def build_commute_leisure_volume(df, period_col, chart_id, title, methodology, how_to_read):
    nv = numeric_view(df, ["commute_like_journeys", "leisure_like_journeys"])
    g = nv.groupby(period_col)[["commute_like_journeys", "leisure_like_journeys"]].sum(min_count=1).sort_index()
    fig, ax = plt.subplots(figsize=(8, 4.2))
    width = 0.38
    x = np.arange(len(g.index))
    ax.bar(x - width/2, g["commute_like_journeys"], width=width, color=CATEGORICAL[0], label="Commute-like")
    ax.bar(x + width/2, g["leisure_like_journeys"], width=width, color=CATEGORICAL[1], label="Leisure-like")
    ax.set_xticks(x)
    ax.set_xticklabels(g.index.astype(str), rotation=45, ha="right")
    ax.set_title(title)
    ax.set_ylabel("Net passenger journeys")
    _clean_axes(ax, "y")
    ax.legend(loc="upper left", bbox_to_anchor=(1.01, 1.0))
    path = _save(fig, chart_id)
    return {
        "path": path, "title": title, "date_range": date_range_text(df, period_col),
        "methodology": methodology, "how_to_read": how_to_read,
        "x_label": f"Time period ({period_col.replace('_', ' ')})",
        "y_label": "Net passenger journeys (count, not %)",
        "caveats": [
            "Raw counts, not percentages -- compare this against the matching share-of-journeys chart "
            "to separate \"the mix changed\" from \"overall volume changed.\"",
        ],
    }


def build_index_small_multiples(indexed_df, period_col, chart_id, title, methodology, how_to_read, regions):
    n = len(regions)
    ncols = min(4, max(2, math.ceil(math.sqrt(n))))
    nrows = math.ceil(n / ncols)
    fig, axes = plt.subplots(nrows, ncols, figsize=(3.1 * ncols, 2.5 * nrows))
    axes = np.array(axes).reshape(-1)
    nv = numeric_view(indexed_df, ["journeys_index"])
    for i, region in enumerate(regions):
        ax = axes[i]
        sub = nv[nv["destination_region_name"] == region].sort_values(period_col)
        ax.axhline(100, color=BASELINE, linewidth=1)
        ax.plot(sub[period_col], sub["journeys_index"], color=CATEGORICAL[0], linewidth=1.6, solid_capstyle="round")
        ax.set_title(region, fontsize=10, fontweight="bold", loc="left")
        ax.tick_params(labelsize=7, rotation=45)
        for spine in ("top", "right"):
            ax.spines[spine].set_visible(False)
        ax.spines["left"].set_color(BASELINE)
        ax.spines["bottom"].set_color(BASELINE)
        ax.grid(axis="y", linewidth=0.6)
        ax.set_axisbelow(True)
    for j in range(n, len(axes)):
        axes[j].axis("off")
    fig.suptitle(title, fontsize=15, fontweight="bold", y=1.0)
    path = _save(fig, chart_id)
    return {
        "path": path, "title": title, "date_range": date_range_text(indexed_df, period_col),
        "methodology": methodology, "how_to_read": how_to_read,
        "x_label": f"Time period ({period_col.replace('_', ' ')})",
        "y_label": "Index (base period = 100)",
        "caveats": [
            "Each region is indexed against its OWN base-period value -- regions are not comparable to "
            "each other in absolute terms here, only in trend relative to their own starting point. The "
            "horizontal line at 100 marks each region's own baseline, not a shared reference level.",
        ],
    }


def build_od_heatmap(od_df, period_col, chart_id, title, methodology, how_to_read, period_value=None):
    df = od_df.copy()
    if period_value is None:
        period_value = sorted(df[period_col].dropna().unique())[-1]
    df = df[df[period_col] == period_value]
    nv = numeric_view(df, ["net_passenger_journeys"])
    pivot = nv.pivot_table(index="origin_region_name", columns="destination_region_name",
                            values="net_passenger_journeys", aggfunc="sum")
    regions = sorted(set(pivot.index) | set(pivot.columns))
    pivot = pivot.reindex(index=regions, columns=regions)
    cmap = LinearSegmentedColormap.from_list("seq_blue", SEQ_BLUE)
    cmap.set_bad(SUPPRESSED_GRAY)
    masked = np.ma.masked_invalid(pivot.values)
    fig, ax = plt.subplots(figsize=(8.5, 7.5))
    im = ax.imshow(masked, cmap=cmap)
    ax.set_xticks(range(len(regions))); ax.set_xticklabels(regions, rotation=45, ha="right", fontsize=8)
    ax.set_yticks(range(len(regions))); ax.set_yticklabels(regions, fontsize=8)
    ax.set_title(f"{title} -- {period_value}")
    ax.set_xlabel("Destination region"); ax.set_ylabel("Origin region")
    for spine in ax.spines.values():
        spine.set_visible(False)
    cbar = fig.colorbar(im, ax=ax, fraction=0.04, pad=0.03)
    cbar.set_label("Net passenger journeys")
    cbar.ax.yaxis.set_major_formatter(mticker.FuncFormatter(_count_formatter))
    cbar.outline.set_visible(False)
    path = _save(fig, chart_id)
    return {
        "path": path, "title": f"{title} -- {period_value}", "date_range": f"{period_value} only",
        "methodology": methodology, "how_to_read": how_to_read,
        "x_label": "Destination region (where the journey ended)",
        "y_label": "Origin region (where the journey started)",
        "caveats": [
            "Gray cells mean suppressed (10 or fewer underlying records) or genuinely zero recorded "
            "journeys between that pair -- the two cannot be told apart from the published data alone.",
        ],
    }


def build_all_routes_ranked(od_df, period_col, chart_id, title, methodology, how_to_read,
                             period_value=None, exclude_within_region=True):
    df = od_df.copy()
    if period_value is None:
        period_value = sorted(df[period_col].dropna().unique())[-1]
    df = df[df[period_col] == period_value]
    if exclude_within_region:
        df = df[df["is_within_region"] == False]
    nv = numeric_view(df, ["net_passenger_journeys"])
    nv = nv.dropna(subset=["net_passenger_journeys"])
    nv["route"] = nv["origin_region_name"] + " -> " + nv["destination_region_name"]
    ranked = nv.sort_values("net_passenger_journeys", ascending=True)  # ascending for barh (top = busiest)
    n = len(ranked)
    fig, ax = plt.subplots(figsize=(9, max(4, 0.22 * n)))
    if n == 0:
        ax.text(0.5, 0.5, "No cross-region routes had a published (non-suppressed) value\nfor this period.",
                ha="center", va="center", fontsize=12, color=INK_MUTED, transform=ax.transAxes)
        ax.set_xticks([]); ax.set_yticks([])
        for spine in ax.spines.values():
            spine.set_visible(False)
    else:
        ax.barh(ranked["route"], ranked["net_passenger_journeys"], color=CATEGORICAL[0])
        ax.tick_params(axis="y", labelsize=8)
        _clean_axes(ax, "x")
    ax.set_title(f"{title} -- {period_value}")
    ax.set_xlabel("Net passenger journeys (count)")
    path = _save(fig, chart_id)
    return {
        "path": path, "title": f"{title} -- {period_value}", "date_range": f"{period_value} only",
        "methodology": methodology, "how_to_read": how_to_read,
        "x_label": "Net passenger journeys on that route (count, not an index or a rate)",
        "y_label": "Origin -> destination route, ranked busiest (top) to least busy (bottom)",
        "caveats": [
            f"Shows every cross-region route with at least one non-suppressed, non-zero published "
            f"value in {period_value} ({n} routes) -- within-region travel (origin = destination) is "
            "excluded here specifically to focus on inter-region flow; it's covered separately.",
            "Routes that were fully suppressed in every period, or had zero recorded journeys, do not "
            "appear in this ranking at all.",
        ],
    }


def build_suppression_summary(suppression_rates: dict, chart_id, title, methodology, how_to_read):
    names = list(suppression_rates.keys())
    values = [suppression_rates[k] * 100 for k in names]
    fig, ax = plt.subplots(figsize=(7.5, 4.2))
    ax.barh(names, values, color=CATEGORICAL[0])
    ax.set_title(title)
    ax.set_xlabel("% of rows suppressed (10 or fewer underlying records)")
    _clean_axes(ax, None)
    ax.grid(axis="x")
    path = _save(fig, chart_id)
    return {
        "path": path, "title": title, "date_range": "all files, full period each covers",
        "methodology": methodology, "how_to_read": how_to_read,
        "x_label": "Share of rows suppressed (%)", "y_label": "Published file",
        "caveats": [],
    }
