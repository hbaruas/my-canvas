"""
Builds every chart as a saved PNG under Output_data/charts/, for embedding
into the Word report and the PowerPoint deck.

Palette and mark rules follow the project's dataviz skill: fixed categorical
hue order (never reassigned per chart -- a region keeps the same color in
every chart it appears in), one hue for sequential/magnitude encodings, one
axis only, hairline recessive gridlines, thin lines with rounded caps, a
legend whenever there are 2+ series, no rainbow colormaps, no dual axes.
"""

from __future__ import annotations
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.colors import LinearSegmentedColormap
import numpy as np
import pandas as pd
from pathlib import Path

from rail_indicator_config import OUTPUT_DIR
from load_data import numeric_view

CHARTS_DIR = OUTPUT_DIR / "charts"

# --- Validated palette (light mode), from references/palette.md ----------
CATEGORICAL = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#6250d6", "#008300", "#e34948"]
SEQ_BLUE = ["#cde2fb", "#9ec5f4", "#6da7ec", "#3987e5", "#1c5cab", "#0d366b"]
INK_PRIMARY = "#0b0b0b"
INK_SECONDARY = "#52514e"
INK_MUTED = "#898781"
GRID = "#e1e0d9"
BASELINE = "#c3c2b7"
SURFACE = "#fcfcfb"
SUPPRESSED_GRAY = "#d9d8d2"

plt.rcParams.update({
    "figure.facecolor": SURFACE,
    "axes.facecolor": SURFACE,
    "axes.edgecolor": BASELINE,
    "axes.labelcolor": INK_SECONDARY,
    "text.color": INK_PRIMARY,
    "xtick.color": INK_MUTED,
    "ytick.color": INK_MUTED,
    "font.family": "sans-serif",
    "font.size": 11,
    "axes.titlesize": 13,
    "axes.titleweight": "bold",
    "axes.titlecolor": INK_PRIMARY,
    "grid.color": GRID,
    "grid.linewidth": 0.8,
    "legend.frameon": False,
})


def _clean_axes(ax):
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color(BASELINE)
    ax.spines["bottom"].set_color(BASELINE)
    ax.grid(axis="y", zorder=0)
    ax.set_axisbelow(True)


def _save(fig, name, caption=None):
    CHARTS_DIR.mkdir(parents=True, exist_ok=True)
    path = CHARTS_DIR / f"{name}.png"
    fig.tight_layout()
    fig.savefig(path, dpi=200, facecolor=SURFACE)
    plt.close(fig)
    return {"path": path, "caption": caption or ""}


def region_color_map(region_names: list[str]) -> dict[str, str]:
    """Fixed hue assignment, reused across every chart that shows regions,
    so a given region is always the same color wherever it appears."""
    return {name: CATEGORICAL[i % len(CATEGORICAL)] for i, name in enumerate(region_names)}


def top_regions_by_volume(dest_monthly_df: pd.DataFrame, n=6) -> list[str]:
    nv = numeric_view(dest_monthly_df, ["net_passenger_journeys"])
    totals = nv.groupby("destination_region_name")["net_passenger_journeys"].sum()
    totals = totals[totals.index != "Unknown region"]  # ranked separately from the real regions
    return totals.sort_values(ascending=False).head(n).index.tolist()


def chart_overall_monthly_trend(dest_monthly_df: pd.DataFrame):
    nv = numeric_view(dest_monthly_df, ["net_passenger_journeys"])
    series = nv.groupby("month")["net_passenger_journeys"].sum().sort_index()
    fig, ax = plt.subplots(figsize=(8, 4.2))
    ax.plot(series.index, series.values, color=CATEGORICAL[0], linewidth=2.2,
            solid_capstyle="round", marker="o", markersize=4)
    ax.set_title("Total passenger journeys by month (all destination regions)")
    ax.set_ylabel("Net passenger journeys")
    ax.yaxis.set_major_formatter(lambda x, _: f"{x/1e6:.1f}M" if x >= 1e6 else f"{x:,.0f}")
    plt.setp(ax.get_xticklabels(), rotation=45, ha="right")
    _clean_axes(ax)
    return _save(fig, "01_overall_monthly_trend",
                 "Sum of net passenger journeys across all destination regions, by month. "
                 "Suppressed cells are excluded from the sum (treated as missing, not zero), "
                 "so totals in months/regions with more suppression are a slight undercount.")


def chart_top_regions_monthly(dest_monthly_df: pd.DataFrame, colors: dict[str, str]):
    nv = numeric_view(dest_monthly_df, ["net_passenger_journeys"])
    fig, ax = plt.subplots(figsize=(8.5, 4.6))
    for region in colors:
        sub = nv[nv["destination_region_name"] == region].sort_values("month")
        ax.plot(sub["month"], sub["net_passenger_journeys"], color=colors[region],
                 linewidth=2, solid_capstyle="round", label=region)
    ax.set_title("Passenger journeys by month -- top destination regions")
    ax.set_ylabel("Net passenger journeys")
    ax.yaxis.set_major_formatter(lambda x, _: f"{x/1e6:.1f}M" if x >= 1e6 else f"{x:,.0f}")
    plt.setp(ax.get_xticklabels(), rotation=45, ha="right")
    _clean_axes(ax)
    ax.legend(loc="upper left", bbox_to_anchor=(1.01, 1.0), fontsize=9)
    return _save(fig, "02_top_regions_monthly",
                 "The busiest destination regions by total journey volume, each kept in the same "
                 "color throughout this report. A gap in a line means that region/month was suppressed.")


def chart_avg_journey_length(dest_monthly_df: pd.DataFrame):
    nv = numeric_view(dest_monthly_df, ["total_passenger_miles", "net_passenger_journeys"])
    g = nv.groupby("month")[["total_passenger_miles", "net_passenger_journeys"]].sum().sort_index()
    g["avg"] = g["total_passenger_miles"] / g["net_passenger_journeys"]
    fig, ax = plt.subplots(figsize=(8, 4.2))
    ax.plot(g.index, g["avg"], color=CATEGORICAL[2], linewidth=2.2,
            solid_capstyle="round", marker="o", markersize=4)
    ax.set_title("Average journey length, all regions combined")
    ax.set_ylabel("Miles per passenger journey")
    plt.setp(ax.get_xticklabels(), rotation=45, ha="right")
    _clean_axes(ax)
    return _save(fig, "03_avg_journey_length",
                 "SUM(total passenger miles) / SUM(net passenger journeys) per month -- computed from "
                 "the summed totals, never averaged from a lower grain's already-computed average.")


def chart_commute_leisure_share(dest_monthly_df: pd.DataFrame):
    nv = numeric_view(dest_monthly_df, ["commute_like_journeys", "leisure_like_journeys"])
    g = nv.groupby("month")[["commute_like_journeys", "leisure_like_journeys"]].sum().sort_index()
    share = g.div(g.sum(axis=1), axis=0) * 100
    fig, ax = plt.subplots(figsize=(8, 4.2))
    ax.bar(share.index, share["commute_like_journeys"], color=CATEGORICAL[0], label="Commute-like", width=0.6)
    ax.bar(share.index, share["leisure_like_journeys"], bottom=share["commute_like_journeys"],
           color=CATEGORICAL[1], label="Leisure-like", width=0.6)
    ax.set_title("Commute-like vs. leisure-like journey share, by month")
    ax.set_ylabel("% of journeys")
    ax.set_ylim(0, 100)
    plt.setp(ax.get_xticklabels(), rotation=45, ha="right")
    _clean_axes(ax)
    ax.legend(loc="upper left", bbox_to_anchor=(1.01, 1.0))
    return _save(fig, "04_commute_leisure_share",
                 "Provisional split by a 30-mile-per-journey threshold -- not a final classification; "
                 "see the methodology section.")


def chart_indexed_regional(indexed_monthly_df: pd.DataFrame, colors: dict[str, str]):
    nv = numeric_view(indexed_monthly_df, ["journeys_index"])
    fig, ax = plt.subplots(figsize=(8.5, 4.6))
    ax.axhline(100, color=BASELINE, linewidth=1.2)
    for region in colors:
        sub = nv[nv["destination_region_name"] == region].sort_values("month")
        ax.plot(sub["month"], sub["journeys_index"], color=colors[region],
                 linewidth=2, solid_capstyle="round", label=region)
    ax.set_title("Journey volume index by region (base period = 100)")
    ax.set_ylabel("Index")
    plt.setp(ax.get_xticklabels(), rotation=45, ha="right")
    _clean_axes(ax)
    ax.legend(loc="upper left", bbox_to_anchor=(1.01, 1.0), fontsize=9)
    return _save(fig, "05_indexed_regional",
                 "Each region indexed against its OWN base-period value -- regions are not comparable "
                 "to each other in absolute terms here, only in trend relative to their own baseline.")


def chart_od_heatmap(od_yearly_df: pd.DataFrame, year: str | None = None):
    df = od_yearly_df.copy()
    if year is None:
        year = sorted(df["year"].unique())[-1]
    df = df[df["year"] == year]
    nv = numeric_view(df, ["net_passenger_journeys"])
    pivot = nv.pivot_table(index="origin_region_name", columns="destination_region_name",
                            values="net_passenger_journeys", aggfunc="sum")
    regions = sorted(set(pivot.index) | set(pivot.columns))
    pivot = pivot.reindex(index=regions, columns=regions)

    cmap = LinearSegmentedColormap.from_list("seq_blue", SEQ_BLUE)
    cmap.set_bad(SUPPRESSED_GRAY)
    masked = np.ma.masked_invalid(pivot.values)

    fig, ax = plt.subplots(figsize=(8.5, 7.5))
    im = ax.imshow(masked, cmap=cmap)
    ax.set_xticks(range(len(regions)))
    ax.set_xticklabels(regions, rotation=45, ha="right", fontsize=8)
    ax.set_yticks(range(len(regions)))
    ax.set_yticklabels(regions, fontsize=8)
    ax.set_title(f"Origin -> destination journey volume, {year}")
    ax.set_xlabel("Destination")
    ax.set_ylabel("Origin")
    for spine in ax.spines.values():
        spine.set_visible(False)
    cbar = fig.colorbar(im, ax=ax, fraction=0.04, pad=0.03)
    cbar.set_label("Net passenger journeys")
    cbar.outline.set_visible(False)
    return _save(fig, "06_od_heatmap",
                 f"Origin-destination matrix for {year}. Gray cells are suppressed "
                 "(10 or fewer underlying rows) or have no recorded journeys between that pair.")


def chart_top_routes(od_yearly_df: pd.DataFrame, year: str | None = None, n=10, exclude_within_region=True):
    df = od_yearly_df.copy()
    if year is None:
        year = sorted(df["year"].unique())[-1]
    df = df[df["year"] == year]
    if exclude_within_region:
        df = df[df["is_within_region"] == False]
    nv = numeric_view(df, ["net_passenger_journeys"])
    nv["route"] = nv["origin_region_name"] + " -> " + nv["destination_region_name"]
    top = nv.nlargest(n, "net_passenger_journeys").sort_values("net_passenger_journeys")
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.barh(top["route"], top["net_passenger_journeys"], color=CATEGORICAL[0])
    ax.set_title(f"Busiest cross-region routes, {year}")
    ax.set_xlabel("Net passenger journeys")
    _clean_axes(ax)
    ax.grid(axis="x")
    ax.grid(axis="y", visible=False)
    return _save(fig, "07_top_routes",
                 f"Top {n} origin->destination region pairs by journey volume in {year}, excluding "
                 "within-region travel (origin = destination).")


def chart_suppression_summary(suppression_rates: dict[str, float]):
    names = list(suppression_rates.keys())
    values = [suppression_rates[k] * 100 for k in names]
    fig, ax = plt.subplots(figsize=(7.5, 4.2))
    ax.barh(names, values, color=CATEGORICAL[0])
    ax.set_title("Share of rows suppressed, by file")
    ax.set_xlabel("% of rows suppressed (10 or fewer underlying records)")
    _clean_axes(ax)
    ax.grid(axis="x")
    ax.grid(axis="y", visible=False)
    return _save(fig, "08_suppression_summary",
                 "How much of each published file is masked. Finer-grained files (daily, "
                 "origin-destination) are suppressed more often because each cell covers fewer records.")
