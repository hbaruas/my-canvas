"""
TEST-ONLY. Generates synthetic CSV files that mimic the structure of the
real disclosure-safe exports, so the publication pipeline can be built and
tested end to end without needing the real exported data.

This is NOT part of the delivered pipeline and should not be run against
real data or shipped anywhere -- it exists purely so the rest of this
project could be developed and verified. Every number in these files is
fabricated.

Run once: python make_test_fixtures.py
"""

import numpy as np
import pandas as pd
from pathlib import Path

from rail_indicator_config import (
    INPUT_DIR, FILE_PATTERNS, FILE_SCHEMA, DEST_ONLY_KEYS, OD_KEYS,
    DISCLOSURE_SUPPRESSION_MARKER,
)

rng = np.random.default_rng(42)

REGIONS = [
    ("E12000001", "North East"), ("E12000002", "North West"),
    ("E12000003", "Yorkshire and The Humber"), ("E12000004", "East Midlands"),
    ("E12000005", "West Midlands"), ("E12000006", "East of England"),
    ("E12000007", "London"), ("E12000008", "South East"),
    ("E12000009", "South West"), ("S99999999", "Scotland"),
    ("W99999999", "Wales"), ("UNKNOWN", "Unknown region"),
]


def _round_to_base_5(x):
    if pd.isna(x):
        return x
    sign = 1 if x >= 0 else -1
    return float(sign * np.floor(abs(x) / 5 + 0.5) * 5)


def _fake_cell(rng, big=True):
    """Return (row_count, net_passenger_journeys, net_tickets,
    total_passenger_miles, commute_like, leisure_like) for one fabricated
    cell, occasionally small enough to trigger suppression."""
    if big and rng.random() < 0.92:
        row_count = int(rng.integers(50, 50_000))
        journeys = float(rng.integers(100, 2_000_000))
    else:
        row_count = int(rng.integers(1, 30))
        journeys = float(rng.integers(0, 15))
    tickets = max(1, int(journeys * rng.uniform(0.5, 1.0)))
    miles_per_journey = rng.uniform(3, 60)
    total_miles = journeys * miles_per_journey
    commute_share = rng.uniform(0.2, 0.8)
    commute = round(journeys * commute_share, 1)
    leisure = round(journeys - commute, 1)
    return row_count, journeys, tickets, round(total_miles, 1), commute, leisure


def _apply_suppression(df, measure_cols):
    flag = (df["row_count"] <= 10)
    for col in ["net_passenger_journeys", "net_tickets", "commute_like_journeys", "leisure_like_journeys"]:
        if col in df.columns:
            flag = flag | ((df[col] != 0) & (df[col].abs() <= 10))
    df["low_count_flag"] = flag
    df["disclosure_status"] = flag.map({True: "Suppressed (underlying rows <= 10)", False: "OK"})
    for col in measure_cols:
        df[col] = df[col].astype(object).where(~flag, DISCLOSURE_SUPPRESSION_MARKER)
    return df


def _finalize_dest(df, kind):
    schema = FILE_SCHEMA[kind]
    df = _apply_suppression(df, schema["measures"])
    return df[schema["keys"] + [period_col_for(kind)] + schema["measures"] + schema["extra"] + ["low_count_flag", "disclosure_status"]]


def period_col_for(key):
    from rail_indicator_config import PERIOD_COL
    return PERIOD_COL[key]


def build_dest_only(periods, key):
    rows = []
    for p in periods:
        for code, name in REGIONS:
            row_count, journeys, tickets, total_miles, commute, leisure = _fake_cell(rng)
            avg_w = round(total_miles / journeys, 2) if journeys else np.nan
            avg_u = round(total_miles / row_count, 2) if row_count else np.nan
            rows.append({
                "destination_region_code": code,
                "destination_region_name": name,
                period_col_for(key): p,
                "net_passenger_journeys": journeys,
                "net_tickets": tickets,
                "total_passenger_miles": total_miles,
                "total_ticket_miles_unweighted": round(total_miles * rng.uniform(0.9, 1.1), 1),
                "commute_like_journeys": commute,
                "leisure_like_journeys": leisure,
                "avg_journey_miles_weighted": avg_w,
                "avg_journey_miles_unweighted": avg_u,
                "row_count": row_count,
            })
    df = pd.DataFrame(rows)
    if "indexed" in key:
        base = df.groupby("destination_region_code")["net_passenger_journeys"].transform("first")
        df["journeys_index"] = (100 * df["net_passenger_journeys"] / base).round(1)
    return _finalize_dest(df, key)


def build_od(periods, key):
    rows = []
    for p in periods:
        for o_code, o_name in REGIONS:
            for d_code, d_name in REGIONS:
                if rng.random() < 0.55 and o_code != d_code:
                    continue  # sparsity, same as the real OD table
                row_count, journeys, tickets, total_miles, commute, leisure = _fake_cell(rng, big=(o_code == d_code))
                avg_j = round(total_miles / journeys, 2) if journeys else np.nan
                avg_t = round(total_miles / row_count, 2) if row_count else np.nan
                rows.append({
                    "origin_region_code": o_code, "origin_region_name": o_name,
                    "destination_region_code": d_code, "destination_region_name": d_name,
                    period_col_for(key): p,
                    "net_passenger_journeys": journeys,
                    "net_tickets": tickets,
                    "total_passenger_miles": total_miles,
                    "commute_like_journeys": commute,
                    "leisure_like_journeys": leisure,
                    "row_count": row_count,
                    "avg_journey_miles": avg_j,
                    "avg_passenger_miles_per_ticket": avg_t,
                    "is_within_region": o_code == d_code,
                })
    df = pd.DataFrame(rows)
    schema = FILE_SCHEMA[key]
    df = _apply_suppression(df, schema["measures"])
    return df[schema["keys"] + [period_col_for(key)] + schema["measures"] + schema["extra"] + ["low_count_flag", "disclosure_status"]]


def main():
    INPUT_DIR.mkdir(parents=True, exist_ok=True)

    weeks = [f"2026-W{w:02d}" for w in range(1, 10)]
    months = [f"2026-{m:02d}" for m in range(1, 10)]
    days = pd.date_range("2026-01-01", "2026-01-20").strftime("%Y-%m-%d").tolist()
    years = ["2023", "2024", "2025", "2026"]

    builders = {
        "weekly":          lambda: build_dest_only(weeks, "weekly"),
        "monthly":         lambda: build_dest_only(months, "monthly"),
        "indexed_weekly":  lambda: build_dest_only(weeks, "indexed_weekly"),
        "indexed_monthly": lambda: build_dest_only(months, "indexed_monthly"),
        "od_daily":        lambda: build_od(days, "od_daily"),
        "od_weekly":       lambda: build_od(weeks, "od_weekly"),
        "od_monthly":      lambda: build_od(months, "od_monthly"),
        "od_yearly":       lambda: build_od(years, "od_yearly"),
    }

    # Simulate the real naming convention: ticket number + date + pattern + _CHECKED
    ticket, date_str = "0099999", "02112026"
    for key, builder in builders.items():
        df = builder()
        pattern = FILE_PATTERNS[key]
        filename = f"{ticket}_{date_str}_{pattern}_CHECKED.csv"
        df.to_csv(INPUT_DIR / filename, index=False)
        print(f"wrote {filename}: {len(df):,} rows")


if __name__ == "__main__":
    main()
