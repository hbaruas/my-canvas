"""
Builds the single Word document that serves both as methodology reference
(dataset overview + column-by-column definitions) and as the findings
report (the recreated charts + narrative) -- written to stand alone for a
reader who has only the published Excel file and this document, with or
without the PowerPoint in the room.
"""

from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from datetime import date

INK = RGBColor(0x0B, 0x0B, 0x0B)
ACCENT = RGBColor(0x2A, 0x78, 0xD6)
MUTED = RGBColor(0x52, 0x51, 0x4E)


def _add_page_break(doc):
    doc.add_page_break()


def _style_heading(p, color=ACCENT):
    for run in p.runs:
        run.font.color.rgb = color


def _add_toc_field(doc):
    paragraph = doc.add_paragraph()
    run = paragraph.add_run()
    fld_begin = OxmlElement('w:fldChar')
    fld_begin.set(qn('w:fldCharType'), 'begin')
    instr = OxmlElement('w:instrText')
    instr.set(qn('xml:space'), 'preserve')
    instr.text = 'TOC \\o "1-2" \\h \\z \\u'
    fld_sep = OxmlElement('w:fldChar')
    fld_sep.set(qn('w:fldCharType'), 'separate')
    fld_text = OxmlElement('w:t')
    fld_text.text = "Right-click and choose 'Update Field' to generate the table of contents."
    fld_end = OxmlElement('w:fldChar')
    fld_end.set(qn('w:fldCharType'), 'end')
    r_element = run._r
    r_element.append(fld_begin)
    r_element.append(instr)
    r_element.append(fld_sep)
    r_element.append(fld_text)
    r_element.append(fld_end)


def _add_caveat_box(doc, text):
    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = table.cell(0, 0)
    cell.text = ""
    p = cell.paragraphs[0]
    run = p.add_run("Caveat: " + text)
    run.italic = True
    run.font.size = Pt(10)
    run.font.color.rgb = MUTED
    shading = OxmlElement('w:shd')
    shading.set(qn('w:fill'), 'F2F2EE')
    cell._tc.get_or_add_tcPr().append(shading)
    doc.add_paragraph()


def _add_column_table(doc, rows, headers=("Column", "Meaning")):
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = "Light Grid Accent 1"
    for i, h in enumerate(headers):
        table.rows[0].cells[i].text = h
        for p in table.rows[0].cells[i].paragraphs:
            for r in p.runs:
                r.bold = True
    for row in rows:
        cells = table.add_row().cells
        for i, val in enumerate(row):
            cells[i].text = str(val)
    doc.add_paragraph()


def _add_chart_block(doc, chart):
    title_p = doc.add_paragraph()
    title_run = title_p.add_run(chart["title"])
    title_run.bold = True
    title_run.font.size = Pt(13)

    range_p = doc.add_paragraph()
    range_run = range_p.add_run(f"Data coverage: {chart['date_range']}")
    range_run.italic = True
    range_run.font.size = Pt(10)
    range_run.font.color.rgb = MUTED

    doc.add_picture(str(chart["path"]), width=Inches(6.2))
    doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER

    def _labeled(label, text, bold_label=True):
        p = doc.add_paragraph()
        r1 = p.add_run(label + ": ")
        r1.bold = bold_label
        r1.font.size = Pt(10.5)
        r2 = p.add_run(text)
        r2.font.size = Pt(10.5)

    _labeled("How this is calculated", chart["methodology"])
    _labeled("How to read this chart", chart["how_to_read"])
    _labeled("X-axis", chart["x_label"])
    _labeled("Y-axis", chart["y_label"])
    for caveat in chart.get("caveats", []):
        p = doc.add_paragraph(caveat, style="List Bullet")
        for r in p.runs:
            r.font.size = Pt(9.5)
            r.italic = True
            r.font.color.rgb = MUTED
    doc.add_paragraph()


def build_document(charts: dict, file_row_counts: dict, out_path):
    doc = Document()

    # --- Title page ---
    title = doc.add_heading("GB Rail Busyness Indicator", level=0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    sub = doc.add_paragraph("Methodology and Findings Report")
    sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    sub.runs[0].font.size = Pt(16)
    sub.runs[0].font.color.rgb = MUTED
    date_p = doc.add_paragraph(f"Published {date.today().strftime('%d %B %Y')}")
    date_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    date_p.runs[0].font.color.rgb = MUTED
    doc.add_paragraph()
    intro = doc.add_paragraph(
        "This document explains what the GB Rail Busyness Indicator measures, how every "
        "published figure was calculated, and what the resulting data shows. It is written "
        "to be read on its own -- everything referenced here is in the accompanying "
        "published Excel dataset; nothing in this report depends on access to the source "
        "systems it was built from."
    )
    intro.alignment = WD_ALIGN_PARAGRAPH.CENTER
    _add_page_break(doc)

    doc.add_heading("Contents", level=1)
    _add_toc_field(doc)
    _add_page_break(doc)

    # --- Section 1: About this document ---
    doc.add_heading("1. About this document", level=1)
    doc.add_paragraph(
        "This report combines two things in one place: a methodology section explaining "
        "what the dataset is and how each published figure was calculated, and a findings "
        "section presenting the indicator itself -- journey volumes, trends, and the "
        "origin-destination pattern -- built entirely from the published dataset."
    )
    doc.add_paragraph(
        "Every chart and figure in this report can be reproduced directly from the "
        "accompanying Excel workbook using the definitions in Section 3. Nothing shown "
        "here relies on any system or access beyond that file."
    )

    # --- Section 2: Dataset overview ---
    doc.add_heading("2. Dataset overview", level=1)
    doc.add_paragraph(
        "The indicator is built from GB rail ticket sales and refund transaction data "
        "(the LENNON fares and settlement system), aggregated to the level of a time "
        "period and a region -- never to an individual ticket, traveller, or transaction. "
        "Two families of output are published, covering the same underlying activity at "
        "different levels of geographic detail."
    )

    doc.add_heading("2.1 Destination-only files", level=2)
    doc.add_paragraph(
        "Journeys grouped by the region they ended in, at weekly and monthly grain, each "
        "also available as an index (see Section 3.3). These answer \"how busy was each "
        "region, over time\" without reference to where journeys started."
    )
    rows = [
        ("Destination - Weekly", f"{file_row_counts.get('weekly', 0):,} rows"),
        ("Destination - Monthly", f"{file_row_counts.get('monthly', 0):,} rows"),
        ("Destination - Weekly (Indexed)", f"{file_row_counts.get('indexed_weekly', 0):,} rows"),
        ("Destination - Monthly (Indexed)", f"{file_row_counts.get('indexed_monthly', 0):,} rows"),
    ]
    _add_column_table(doc, rows, headers=("File", "Size"))

    doc.add_heading("2.2 Origin-destination files", level=2)
    doc.add_paragraph(
        "Journeys grouped by BOTH the region they started in and the region they ended "
        "in, at daily, weekly, monthly, and yearly grain. These answer the questions the "
        "destination-only files can't: which routes are busiest, how much travel stays "
        "within one region, and the balance of flow in each direction between two regions."
    )
    rows = [
        ("Origin-Destination - Daily", f"{file_row_counts.get('od_daily', 0):,} rows"),
        ("Origin-Destination - Weekly", f"{file_row_counts.get('od_weekly', 0):,} rows"),
        ("Origin-Destination - Monthly", f"{file_row_counts.get('od_monthly', 0):,} rows"),
        ("Origin-Destination - Yearly", f"{file_row_counts.get('od_yearly', 0):,} rows"),
    ]
    _add_column_table(doc, rows, headers=("File", "Size"))

    doc.add_heading("2.3 Statistical disclosure control", level=2)
    doc.add_paragraph(
        "Two protections are applied to every published figure before release, in this order:"
    )
    doc.add_paragraph(
        "Suppression: any row where a published count (journeys, tickets, or either side "
        "of the commute/leisure split) is 10 or fewer has every figure in that row replaced "
        "with the letter \"c\". This is not a missing value -- it means a real figure exists "
        "but is too small to publish without risking identifying the underlying activity.",
        style="List Bullet"
    )
    doc.add_paragraph(
        "Rounding: every figure that is not suppressed is rounded to the nearest 5, so no "
        "published number (however large) is ever the exact original count.",
        style="List Bullet"
    )
    _add_caveat_box(doc,
        "Because of suppression, sums and averages calculated across a published file will "
        "not exactly match the true underlying totals -- suppressed rows are necessarily "
        "excluded from any such calculation. The gap is small (suppressed rows are, by "
        "definition, the smallest ones) but it is not zero."
    )

    _add_page_break(doc)

    # --- Section 3: Column-by-column methodology ---
    doc.add_heading("3. Methodology -- how each figure is calculated", level=1)

    doc.add_heading("3.1 Shared identifying columns", level=2)
    _add_column_table(doc, [
        ("destination_region_code / destination_region_name",
         "The ITL1 (formerly NUTS1) region a journey ended in. \"UNKNOWN\"/\"Unknown region\" "
         "means no region could be determined for that end of the journey from the source data."),
        ("origin_region_code / origin_region_name",
         "The equivalent for where a journey started. Only present in the origin-destination files."),
        ("is_within_region",
         "True where the origin and destination region are the same (origin-destination files only)."),
        ("row_count",
         "The number of underlying source transaction rows behind that published figure. Used to "
         "decide suppression -- not a journey count itself."),
        ("low_count_flag / disclosure_status",
         "Whether that row was suppressed, and why, stated in plain text."),
    ])

    doc.add_heading("3.2 Volume and distance measures", level=2)
    _add_column_table(doc, [
        ("net_passenger_journeys",
         "Count of passenger journeys, net of refunds -- a refund subtracts from the count it "
         "originally added, so a ticket bought and fully refunded contributes zero."),
        ("net_tickets",
         "Count of ticket sales, net of refunds. Differs from journeys because one ticket (e.g. "
         "a return, or a season ticket) can represent more than one journey."),
        ("total_passenger_miles",
         "Total passenger-miles travelled -- the distance of the flow multiplied by the number "
         "of journeys it represents, summed across every underlying transaction."),
        ("avg_journey_miles_weighted  (destination files)  /  avg_journey_miles  (origin-destination files)",
         "Average distance per passenger journey: total passenger-miles divided by net passenger "
         "journeys. Despite the \"_weighted\" name in the destination-only files, this is the "
         "headline average journey length figure."),
        ("avg_journey_miles_unweighted  (destination files)  /  avg_passenger_miles_per_ticket  (origin-destination files)",
         "A different average: total passenger-miles divided by the number of underlying ticket "
         "rows rather than by journeys. Answers \"how many passenger-miles does a typical ticket "
         "sold represent\", not \"how long is a typical journey\"."),
        ("total_ticket_miles_unweighted  (destination files only)",
         "A secondary distance total, included for cross-validation against total_passenger_miles."),
    ])

    doc.add_heading("3.3 Commute/leisure split", level=2)
    doc.add_paragraph(
        "Journeys are split into \"commute-like\" and \"leisure-like\" using a single distance "
        "threshold applied per journey (not to the total passenger-miles of a row): journeys of "
        "30 miles or fewer are commute-like; longer journeys are leisure-like."
    )
    _add_caveat_box(doc,
        "This threshold is explicitly provisional, chosen as a round, defensible starting point "
        "rather than derived from a formal review of commuting patterns. It is a single configurable "
        "value in the pipeline and may be revised."
    )

    doc.add_heading("3.4 Indexed files", level=2)
    _add_column_table(doc, [
        ("journeys_index",
         "That region's journey count in the given period, as a percentage of that SAME region's "
         "count in a fixed base period (=100). Each region is indexed against its own baseline "
         "independently."),
    ])
    _add_caveat_box(doc,
        "Index values are not comparable ACROSS regions in absolute terms -- a region showing 150 "
        "and another showing 120 does not mean the first is busier, only that it has grown further "
        "relative to its own starting point. Use the raw (non-indexed) files for absolute comparison "
        "between regions."
    )

    _add_page_break(doc)

    # --- Section 4: Findings ---
    doc.add_heading("4. Findings", level=1)
    doc.add_paragraph(
        "Every chart below is built directly from the published dataset. Each one states: the date "
        "range it covers, exactly how the figure was calculated from the raw transaction data (the "
        "logic, not code), what each axis means, how to read the chart, and any caveats specific to it. "
        "Nothing here requires access beyond the accompanying Excel workbook to reproduce."
    )

    sections = [
        ("4.1 Overall journey volume, by time period", ["overall_monthly", "overall_weekly", "overall_daily", "top6_monthly"]),
        ("4.2 Journey volume by region -- every region", ["byregion_monthly", "byregion_weekly"]),
        ("4.3 Average journey length", ["avglen_monthly", "avglen_weekly", "avglen_byregion_monthly", "avglen_byregion_weekly"]),
        ("4.4 Commute-like vs. leisure-like journeys", ["cl_share_monthly", "cl_share_weekly", "cl_volume_monthly", "cl_volume_weekly", "cl_byregion_monthly"]),
        ("4.5 Journey volume index, by region", ["index_byregion_monthly", "index_byregion_weekly"]),
        ("4.6 Where journeys start and end", ["od_heatmap", "all_routes"]),
        ("4.7 Data completeness", ["suppression"]),
    ]

    for section_title, keys in sections:
        doc.add_heading(section_title, level=2)
        for key in keys:
            if key not in charts:
                continue
            chart = charts[key]
            _add_chart_block(doc, chart)

    _add_page_break(doc)

    # --- Section 5: Limitations ---
    doc.add_heading("5. Known limitations", level=1)
    doc.add_paragraph(
        "This is a provisional indicator, published ahead of formal methodology approval. The "
        "following are known, stated limitations rather than discovered defects:",
    )
    for text in [
        "TfL contactless/PAYG and Trainline-resold tickets are included, not filtered out. These "
        "represent a substantial share of all activity -- readers expecting \"National Rail only\" "
        "figures should note this explicitly.",
        "The \"Unknown region\" bucket is not evenly distributed over time -- it is a materially "
        "larger share of journeys from mid-2023 onward than before. A region's volume appearing to "
        "fall is sometimes this effect, not a real change in travel.",
        "The commute/leisure threshold (30 miles per journey) is provisional and may change.",
        "Suppression and rounding mean any total calculated from this published data is a close "
        "approximation of the true figure, never an exact reproduction of it.",
    ]:
        doc.add_paragraph(text, style="List Bullet")

    doc.save(out_path)
    return out_path
