@echo off
cd /d "%~dp0"

echo ============================================================
echo  Rail Busyness Indicator -- Run
echo ============================================================
echo.

if not exist ".venv\Scripts\python.exe" (
    echo No virtual environment found in .venv.
    echo Please double-click 1_install.bat first ^(just needs doing once^).
    echo.
    pause
    exit /b 1
)

".venv\Scripts\python.exe" "scripts\build_publication.py"
set "RESULT=%errorlevel%"

echo.
if "%RESULT%"=="0" (
    echo ============================================================
    echo  Done. Check the Data\Output_data folder for the 4 files:
    echo    - rail_busyness_indicator_published_dataset.xlsx
    echo    - rail_busyness_indicator_methodology_and_report.docx
    echo    - rail_busyness_indicator_findings.pptx
    echo    - rail_busyness_indicator_interactive.html
    echo ============================================================
) else (
    echo ============================================================
    echo  Something went wrong -- see the error above.
    echo  If it mentions a missing column, that's the one thing most
    echo  likely to need a small fix in scripts\rail_indicator_config.py
    echo ============================================================
)
pause
