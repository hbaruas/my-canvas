@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo ============================================================
echo  Rail Busyness Indicator -- Install
echo ============================================================
echo.
echo This sets up a self-contained Python environment inside this
echo folder (in a ".venv" subfolder). You only need to run this
echo once -- after that, just use 2_run.bat.
echo.

set "PYTHON_EXE="

rem --- Candidate 1: the known ONS-managed Python 3.10 path ---
if exist "C:\ONSapps\My_Python\Python_3_10\python.exe" (
    set "PYTHON_EXE=C:\ONSapps\My_Python\Python_3_10\python.exe"
)

rem --- Candidate 2: whatever "python3_10" resolves to on PATH ---
if "!PYTHON_EXE!"=="" (
    where python3_10 >nul 2>nul
    if !errorlevel! equ 0 (
        for /f "delims=" %%P in ('where python3_10') do set "PYTHON_EXE=%%P"
    )
)

rem --- Candidate 3: plain "python" on PATH ---
if "!PYTHON_EXE!"=="" (
    where python >nul 2>nul
    if !errorlevel! equ 0 (
        set "PYTHON_EXE=python"
    )
)

if "!PYTHON_EXE!"=="" (
    echo Could not find a Python installation automatically.
    echo.
    echo Open this file in Notepad, find the line below, and set it to
    echo the full path of your python.exe, then save and run it again:
    echo.
    echo     set "PYTHON_EXE=C:\path\to\python.exe"
    echo.
    pause
    exit /b 1
)

echo Using Python: !PYTHON_EXE!
"!PYTHON_EXE!" --version
if errorlevel 1 (
    echo.
    echo That Python could not be run. Edit this file and set PYTHON_EXE
    echo to a working python.exe path, then try again.
    pause
    exit /b 1
)

if exist ".venv\Scripts\python.exe" (
    echo.
    echo A virtual environment already exists in .venv -- skipping creation.
    echo ^(Delete the .venv folder if you want to rebuild it from scratch.^)
) else (
    echo.
    echo Creating a virtual environment in .venv ...
    "!PYTHON_EXE!" -m venv ".venv"
    if errorlevel 1 (
        echo.
        echo Failed to create the virtual environment. See the error above.
        pause
        exit /b 1
    )
)

echo.
echo Installing required packages into .venv ...
".venv\Scripts\python.exe" -m pip install --upgrade pip
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (
    echo.
    echo Package install failed -- see the error above.
    echo ^(If this is a proxy/certificate error, that's an ONS network
    echo setting, not something this script controls.^)
    pause
    exit /b 1
)

echo.
echo ============================================================
echo  Install complete. You can now double-click 2_run.bat
echo ============================================================
pause
