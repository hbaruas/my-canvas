@echo off
REM Build a transferable zip of this project (excludes the environment).
REM Must match package.command. It did not: the echo claimed the SIC5 file was
REM excluded while the exclusion list omitted it, so a Windows-built zip
REM carried an extra 820MB and could exceed Compress-Archive's 2GB limit.
cd /d "%~dp0"
setlocal
if not exist dist mkdir dist
set "OUT=dist\production_monitor.zip"
if exist "%OUT%" del "%OUT%"
echo Packaging -^> %OUT%
echo ^(excluding .venv, outputs, dist and the SIC5 file - all rebuilt or unused^)
echo This takes a few minutes.
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$root = (Get-Location).Path;" ^
  "$skipDirs = @('.venv','outputs','dist','.git','__pycache__','.pytest_cache');" ^
  "$files = Get-ChildItem -Path . -Recurse -File -Force | Where-Object {" ^
  "  $rel = $_.FullName.Substring($root.Length + 1);" ^
  "  $parts = $rel -split '\\\\';" ^
  "  (-not ($parts | Where-Object { $skipDirs -contains $_ })) -and" ^
  "  ($_.Name -notlike '*sic5*') -and ($_.Name -notlike '*.pyc') -and" ^
  "  ($_.Name -ne '.DS_Store') };" ^
  "Write-Host ('  {0} files, {1:N0} MB' -f $files.Count, (($files ^| Measure-Object Length -Sum).Sum/1MB));" ^
  "Compress-Archive -Path $files.FullName -DestinationPath '%OUT%' -Force"
if errorlevel 1 (
    echo.
    echo ERROR: packaging failed.
    pause
    exit /b 1
)
echo.
for %%F in ("%OUT%") do echo Created %%~fF  (%%~zF bytes)
echo Copy it across, unzip, then run install.bat then run-full.bat.
pause
