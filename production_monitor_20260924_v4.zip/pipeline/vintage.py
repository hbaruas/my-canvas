"""Snapshot store and revision diffing.

Each delivery restates the entire history, not just the new month, and the
workbook's own cover sheet says work is ongoing to improve sample size, data
quality and industry classification. So a prior month's figure can change
between releases.

Loading each delivery as a complete snapshot and diffing against the previous
one turns that from an invisible problem into a reported one: a revision shows
up as a revision, instead of surfacing later as a phantom economic shock.
"""
from __future__ import annotations

import json
import logging
from pathlib import Path

import pandas as pd

from . import config as cfg

log = logging.getLogger(__name__)

# A revision smaller than this is rounding noise, not a restatement.
# Value is rounded to the nearest £1,000 at source.
MATERIAL_REVISION_GBP = 1_000.0
MATERIAL_REVISION_PCT = 0.001          # 0.1%


def _vintage_dir(release: pd.Timestamp | None) -> Path:
    key = release.strftime("%Y-%m-%d") if release is not None else "unknown"
    return cfg.VINTAGES / key


def list_vintages() -> list[Path]:
    """Existing snapshots, oldest first."""
    if not cfg.VINTAGES.exists():
        return []
    return sorted(d for d in cfg.VINTAGES.iterdir()
                  if d.is_dir() and (d / "sic2.parquet").exists())


def write_snapshot(edges: dict[str, pd.DataFrame],
                   lookup: pd.DataFrame,
                   release: pd.Timestamp | None) -> Path:
    """Persist this delivery as a vintage. Returns the vintage directory."""
    out = _vintage_dir(release)
    out.mkdir(parents=True, exist_ok=True)
    for grain, df in edges.items():
        df.to_parquet(out / f"{grain}.parquet", index=False)
    lookup.to_parquet(out / "lookup.parquet", index=False)

    meta = {
        "release": release.strftime("%Y-%m-%d") if release is not None else None,
        "grains": {g: {"rows": int(len(d)),
                       "first_month": str(d.month.min().date()),
                       "last_month": str(d.month.max().date())}
                   for g, d in edges.items()},
    }
    (out / "meta.json").write_text(json.dumps(meta, indent=2))
    log.info("snapshot written to %s", out.relative_to(cfg.ROOT))
    return out


def load_snapshot(vintage: Path, grain: str = cfg.LEVEL_SIC2) -> pd.DataFrame | None:
    path = vintage / f"{grain}.parquet"
    return pd.read_parquet(path) if path.exists() else None


def diff(current: pd.DataFrame, previous: pd.DataFrame,
         grain: str = cfg.LEVEL_SIC2) -> pd.DataFrame:
    """Industry-months whose value changed between two vintages.

    Also reports cells that appeared or disappeared, since a cell moving in or
    out of suppression is a revision too - and one that would otherwise read as
    an economic change (BUILD_SPEC 6.7).
    """
    keys = ["payer", "payee", "month"]
    if grain == cfg.LEVEL_SIC2_REGION:
        keys = ["payer", "payer_region", "payee", "payee_region", "month"]

    merged = previous[keys + ["value"]].merge(
        current[keys + ["value"]], on=keys, how="outer",
        suffixes=("_prev", "_new"), indicator=True)

    prev, new = merged.value_prev, merged.value_new
    changed = (
        (prev.notna() & new.notna() & (prev - new).abs().gt(MATERIAL_REVISION_GBP))
        | (prev.isna() & new.notna())
        | (prev.notna() & new.isna())
    )
    out = merged[changed].copy()
    if out.empty:
        return out.assign(pct_revision=[], kind=[])

    out["pct_revision"] = (out.value_new - out.value_prev) / out.value_prev.abs()
    out["kind"] = "restated"
    out.loc[out.value_prev.isna(), "kind"] = "appeared"
    out.loc[out.value_new.isna(), "kind"] = "disappeared"
    return out.drop(columns="_merge")


def reconcile(edges: dict[str, pd.DataFrame],
              lookup: pd.DataFrame,
              release: pd.Timestamp | None) -> tuple[Path, pd.DataFrame]:
    """Write this delivery's snapshot and diff it against the one before.

    Returns (vintage directory, revisions). On a first run the revisions frame
    is empty - there is nothing to compare against yet.
    """
    existing = [v for v in list_vintages() if v != _vintage_dir(release)]
    current = _vintage_dir(release)
    previous = existing[-1] if existing else None

    write_snapshot(edges, lookup, release)

    if previous is None:
        log.info("first vintage - no revision comparison available yet")
        cols = ["payer", "payee", "month", "value_prev", "value_new",
                "pct_revision", "kind", "vintage_from", "vintage_to"]
        empty = pd.DataFrame(columns=cols)
        empty.to_csv(cfg.OUTPUTS / "revisions.csv", index=False)
        return current, empty

    prev_edges = load_snapshot(previous)
    revisions = diff(edges[cfg.LEVEL_SIC2], prev_edges)
    revisions["vintage_from"] = previous.name
    revisions["vintage_to"] = current.name
    revisions.to_csv(cfg.OUTPUTS / "revisions.csv", index=False)

    if len(revisions):
        log.warning("%s industry-months revised since vintage %s (%s)",
                    f"{len(revisions):,}", previous.name,
                    revisions.kind.value_counts().to_dict())
    else:
        log.info("no revisions against vintage %s", previous.name)
    return current, revisions
