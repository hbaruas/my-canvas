"""Build the industry panels from the normalised edge table.

Definitions follow BUILD_SPEC 6.1-6.4. The rules that matter:

  * SIC 00 and 'unknown' region are labelled categories, never filters. They
    are excluded from the classified basis and kept as separate columns, so
    nothing is hidden - SIC 00 is 32-68% of an industry's inflows.
  * payer == payee is a normal flow (14.3% of classified value). It is included
    in inflow and outflow and subtracted once from PFI.
  * Suppressed cells are null, never zero, and are counted as a coverage metric.
"""
from __future__ import annotations

import logging

import numpy as np
import pandas as pd

from . import config as cfg

log = logging.getLogger(__name__)

UNCL = cfg.UNCLASSIFIED_SIC


def safe_divide(numerator, denominator):
    """Divide, returning null rather than infinity when the denominator is zero.

    Plain division does not raise here - numpy returns `inf`, which then flows
    into a CSV and onto a page as a real-looking number. It bit us on
    `inflow / n_tx_in`: value is rounded to the nearest £1,000 and transaction
    counts to the nearest 100, so a cell with a handful of payments reports
    £7,000 of value against 0 transactions. 96 rows came out infinite.
    """
    num = pd.to_numeric(numerator, errors="coerce")
    den = pd.to_numeric(denominator, errors="coerce")
    out = num / den.where(den != 0)
    return out.replace([np.inf, -np.inf], np.nan)


def _throughput(inflow: pd.Series, outflow: pd.Series,
                self_flow: pd.Series) -> pd.Series:
    """inflow + outflow - self_flow, treating nulls as unknown rather than zero.

    Returns null where neither leg is recorded, so that "no data" never reads
    as "no activity" - and never as negative throughput.
    """
    both = pd.concat([inflow, outflow], axis=1)
    total = both.sum(axis=1, min_count=1)
    return total - self_flow.fillna(0)


def _side(df: pd.DataFrame, side: str, keys: list[str], name: str) -> pd.DataFrame:
    """Aggregate value and transaction count onto one side of the edge."""
    g = df.groupby(keys, dropna=False, observed=True)
    return pd.DataFrame({
        name: g.value.sum(min_count=1),
        f"n_tx_{side}": g.n_tx.sum(min_count=1),
        f"suppressed_cells_{side}": g.suppressed_type.apply(lambda s: s.notna().sum()),
    })


def build_national(edges: pd.DataFrame, lookup: pd.DataFrame) -> pd.DataFrame:
    """Per-industry monthly panel: inflow, outflow, PFI on both bases."""
    df = edges[edges.grain == cfg.LEVEL_SIC2].copy()

    classified = df[(df.payer != UNCL) & (df.payee != UNCL)]

    # --- classified basis (the detection series) ---
    inflow = _side(classified, "in", ["payee", "month"], "inflow")
    inflow.index.names = ["sic2", "month"]
    outflow = _side(classified, "out", ["payer", "month"], "outflow")
    outflow.index.names = ["sic2", "month"]

    # --- including SIC 00 (the full-money view) ---
    inflow_all = (df.groupby(["payee", "month"], observed=True).value.sum(min_count=1)
                    .rename("inflow_incl00"))
    inflow_all.index.names = ["sic2", "month"]
    outflow_all = (df.groupby(["payer", "month"], observed=True).value.sum(min_count=1)
                     .rename("outflow_incl00"))
    outflow_all.index.names = ["sic2", "month"]

    # --- component parts kept visible (BUILD_SPEC 6.1, 6.2) ---
    # Self-flows are computed on BOTH bases. Subtracting the full-table
    # self-flow from a classified inflow mixes bases: SIC 00 has no classified
    # counterparties, so its classified inflow is null while its 00->00 flow is
    # £75bn, and the difference comes out as negative throughput.
    self_flow = (classified[classified.payer == classified.payee]
                 .groupby(["payee", "month"], observed=True).value.sum(min_count=1)
                 .rename("self_flow"))
    self_flow.index.names = ["sic2", "month"]
    self_flow_all = (df[df.payer == df.payee]
                     .groupby(["payee", "month"], observed=True).value.sum(min_count=1)
                     .rename("self_flow_incl00"))
    self_flow_all.index.names = ["sic2", "month"]
    from_00 = (df[df.payer == UNCL]
               .groupby(["payee", "month"], observed=True).value.sum(min_count=1)
               .rename("from_00"))
    from_00.index.names = ["sic2", "month"]
    to_00 = (df[df.payee == UNCL]
             .groupby(["payer", "month"], observed=True).value.sum(min_count=1)
             .rename("to_00"))
    to_00.index.names = ["sic2", "month"]

    panel = (inflow.join(outflow, how="outer")
                   .join(inflow_all, how="outer")
                   .join(outflow_all, how="outer")
                   .join(self_flow, how="outer")
                   .join(self_flow_all, how="outer")
                   .join(from_00, how="outer")
                   .join(to_00, how="outer")
                   .reset_index())

    # PFI = inflow + outflow - self_flow. Self-flows are genuine receipts and
    # genuine payments, so they belong in both legs - but counting them twice
    # in a throughput measure would overstate an industry by up to 32% of its
    # inflow (SIC 64 financial services, latest month).
    #
    # min_count=1 rather than fillna(0): a suppressed cell is unknown, not zero.
    # An industry with no recorded flow at all gets a null PFI, not a number
    # manufactured out of missing values.
    panel["pfi"] = _throughput(panel.inflow, panel.outflow, panel.self_flow)
    panel["pfi_incl00"] = _throughput(panel.inflow_incl00, panel.outflow_incl00,
                                      panel.self_flow_incl00)

    panel["avg_tx_value_in"] = safe_divide(panel.inflow, panel.n_tx_in)
    panel["share_from_00"] = safe_divide(panel.from_00, panel.inflow_incl00)

    panel = panel.merge(
        lookup.rename(columns={"division": "name"})[
            ["sic2", "name", "section", "section_desc", "gdp_grouping"]],
        on="sic2", how="left")

    cols = ["sic2", "name", "section", "section_desc", "gdp_grouping", "month",
            "inflow", "outflow", "pfi",
            "inflow_incl00", "outflow_incl00", "pfi_incl00",
            "self_flow", "self_flow_incl00", "from_00", "to_00",
            "n_tx_in", "n_tx_out", "avg_tx_value_in",
            "suppressed_cells_in", "suppressed_cells_out", "share_from_00"]
    panel = panel[cols].sort_values(["sic2", "month"]).reset_index(drop=True)
    log.info("national panel: %s rows, %d industries, %d months",
             f"{len(panel):,}", panel.sic2.nunique(), panel.month.nunique())
    return panel


def build_section(national: pd.DataFrame) -> pd.DataFrame:
    """Aggregate to section and GDP grouping (BUILD_SPEC 6.3).

    For reporting and comparison against GVA/VAT only. Detection stays at
    division level, where 52% more of the signal survives.
    """
    value_cols = ["inflow", "outflow", "pfi", "inflow_incl00", "outflow_incl00",
                  "pfi_incl00", "self_flow", "self_flow_incl00", "from_00", "to_00",
                  "n_tx_in", "n_tx_out", "suppressed_cells_in",
                  "suppressed_cells_out"]
    out = (national.groupby(["section", "section_desc", "gdp_grouping", "month"],
                            observed=True)[value_cols]
                   .sum(min_count=1)
                   .reset_index())
    out["avg_tx_value_in"] = safe_divide(out.inflow, out.n_tx_in)
    out["share_from_00"] = safe_divide(out.from_00, out.inflow_incl00)
    log.info("section panel: %s rows, %d sections",
             f"{len(out):,}", out.section.nunique())
    return out.sort_values(["section", "month"]).reset_index(drop=True)


def build_regional(edges: pd.DataFrame, lookup: pd.DataFrame) -> pd.DataFrame | None:
    """Per-industry-per-region panel.

    18 months only, so no seasonal baseline is possible - levels and MoM/YoY
    changes only. 'unknown' is one of the 13 region categories, never dropped.
    """
    df = edges[edges.grain == cfg.LEVEL_SIC2_REGION]
    if df.empty:
        return None
    df = df.copy()
    classified = df[(df.payer != UNCL) & (df.payee != UNCL)]

    inflow = _side(classified, "in", ["payee", "payee_region", "month"], "inflow")
    inflow.index.names = ["sic2", "region", "month"]
    outflow = _side(classified, "out", ["payer", "payer_region", "month"], "outflow")
    outflow.index.names = ["sic2", "region", "month"]

    def _self(frame, name):
        out = (frame[(frame.payer == frame.payee)
                     & (frame.payer_region == frame.payee_region)]
               .groupby(["payee", "payee_region", "month"], observed=True)
               .value.sum(min_count=1).rename(name))
        out.index.names = ["sic2", "region", "month"]
        return out

    def _leg(frame, side, name):
        keys = (["payee", "payee_region", "month"] if side == "in"
                else ["payer", "payer_region", "month"])
        out = (frame.groupby(keys, observed=True).value.sum(min_count=1)
               .rename(name))
        out.index.names = ["sic2", "region", "month"]
        return out

    # Both bases, exactly as the national panel carries them. Building only the
    # classified one here left the regional panel without _incl00 columns, so
    # selecting a region and the including-SIC-00 basis raised a KeyError.
    panel = (inflow.join(outflow, how="outer")
                   .join(_self(classified, "self_flow"), how="outer")
                   .join(_leg(df, "in", "inflow_incl00"), how="outer")
                   .join(_leg(df, "out", "outflow_incl00"), how="outer")
                   .join(_self(df, "self_flow_incl00"), how="outer")
                   .reset_index())
    panel["pfi"] = _throughput(panel.inflow, panel.outflow, panel.self_flow)
    panel["pfi_incl00"] = _throughput(panel.inflow_incl00, panel.outflow_incl00,
                                      panel.self_flow_incl00)
    panel["region_name"] = panel.region.map(cfg.ITL1_NAMES).fillna(panel.region)
    panel = panel.merge(
        lookup.rename(columns={"division": "name"})[
            ["sic2", "name", "section", "section_desc", "gdp_grouping"]],
        on="sic2", how="left")
    panel = panel.sort_values(["sic2", "region", "month"]).reset_index(drop=True)
    log.info("regional panel: %s rows, %d regions, %d months",
             f"{len(panel):,}", panel.region.nunique(), panel.month.nunique())
    return panel


def write_edge_store(edges: dict[str, pd.DataFrame], vintage: str) -> None:
    """Persist the edge list, partitioned by level and month.

    Phase 1 has no view that reads this. It exists because every Phase 2
    network feature needs edges rather than node series, and adding it later
    would mean reworking the pipeline (BUILD_SPEC 12.6 hook 1).
    """
    for grain, df in edges.items():
        keep = df[df.value.notna()].copy()
        keep["vintage"] = vintage
        for month, part in keep.groupby("month", observed=True):
            out = cfg.EDGES / f"level={grain}" / f"month={month:%Y-%m}"
            out.mkdir(parents=True, exist_ok=True)
            part.drop(columns="month").to_parquet(out / "edges.parquet", index=False)
        log.info("edge store: %s, %d monthly partitions", grain, keep.month.nunique())
