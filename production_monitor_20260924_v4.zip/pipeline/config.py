"""Paths, constants and shared vocabulary.

Every magic string in the pipeline lives here so it is defined once.
"""
from __future__ import annotations

from pathlib import Path

# --- paths -------------------------------------------------------------
ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "Data"
INCOMING = DATA / "incoming"
ARCHIVE = DATA / "archive"
OUTPUTS = ROOT / "outputs"
EDGES = OUTPUTS / "edges"
VINTAGES = OUTPUTS / "vintages"
REFERENCE = ROOT / "reference"

# Directories the pipeline creates on demand.
_MANAGED = (INCOMING, ARCHIVE, OUTPUTS, EDGES, VINTAGES, REFERENCE)


def ensure_dirs() -> None:
    for d in _MANAGED:
        d.mkdir(parents=True, exist_ok=True)


# --- suppression (BUILD_SPEC 5.1 rule 1) -------------------------------
# These are NULL, never zero, and the distinction between them is kept.
SUPPRESSED_DISCLOSURE = "[c]"   # withheld for disclosure control
SUPPRESSED_NO_DATA = "[-]"      # no interaction recorded
SUPPRESSION_TOKENS = {
    "[c]": "disclosure",
    "[C]": "disclosure",
    "[-]": "no_data",
}
# Not a token in the source: assigned when the combined sheet publishes a cell
# that the yearly sheet withholds, and the stricter treatment is applied.
WITHHELD_IN_YEARLY = "withheld_in_yearly_sheet"

# --- categories that are never dropped (BUILD_SPEC 6.1) ----------------
UNCLASSIFIED_SIC = "00"
UNKNOWN_REGION = "unknown"

# The lookup sheet's Section column holds the literal string "N/A" for SIC 00.
# pandas converts that to NaN unless keep_default_na=False is passed - and it
# does so again on every CSV round-trip, silently dropping Unclassified from
# any section aggregation. We therefore normalise it, at read time, to a code
# that cannot be mistaken for a missing value. Sections A-U are real SIC
# sections; X is unused, so it is unambiguous and sorts last.
UNCLASSIFIED_SECTION_RAW = "N/A"      # as it appears in the workbook
UNCLASSIFIED_SECTION = "X"            # as it appears everywhere downstream

# --- ITL1 regions (BUILD_SPEC 2.3) -------------------------------------
ITL1_NAMES = {
    "TLC": "North East",
    "TLD": "North West",
    "TLE": "Yorkshire and The Humber",
    "TLF": "East Midlands",
    "TLG": "West Midlands",
    "TLH": "East of England",
    "TLI": "London",
    "TLJ": "South East",
    "TLK": "South West",
    "TLL": "Wales",
    "TLM": "Scotland",
    "TLN": "Northern Ireland",
    UNKNOWN_REGION: "Unknown / unattributed",
}

# --- GDP groupings (BUILD_SPEC 6.3) ------------------------------------
# The level monthly GDP bulletins lead with.
GDP_GROUPING = {
    "A": "Agriculture",
    "B": "Production", "C": "Production", "D": "Production", "E": "Production",
    "F": "Construction",
    **{s: "Services" for s in "GHIJKLMNOPQRST"},
    "U": "Extraterritorial",
    UNCLASSIFIED_SECTION: "Unclassified",
    UNCLASSIFIED_SECTION_RAW: "Unclassified",
}

# --- node id scheme (BUILD_SPEC 12.6 hook 2) ---------------------------
LEVEL_SIC2 = "sic2"
LEVEL_SIC5 = "sic5"
LEVEL_SIC2_REGION = "sic2_region"


def node_id(level: str, code: str, region: str | None = None) -> str:
    """Stable node identifier across every granularity.

    >>> node_id("sic2", "29")
    'sic2:29'
    >>> node_id("sic2_region", "29", "TLL")
    'sic2_region:29|TLL'
    """
    return f"{level}:{code}" if region is None else f"{level}:{code}|{region}"


# --- COVID window excluded from variance estimation (PROJECT_PLAN 2.5) --
COVID_START = "2020-03-01"
COVID_END = "2021-06-01"
