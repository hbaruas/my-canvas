"""Dataset profile: what is actually in the delivery.

Written for the analyst who opens the dashboard each month and needs to say
what the data covers, how much of it is attributable, and what has changed
since last time - without reading any code.
"""
from __future__ import annotations

import logging

import pandas as pd

from .series import safe_divide

from . import config as cfg

log = logging.getLogger(__name__)

U = cfg.UNCLASSIFIED_SIC


def _splits(df: pd.DataFrame) -> pd.DataFrame:
    """Rows, value and transactions by how well the two ends are identified."""
    masks = {
        "Both parties classified": (df.payer != U) & (df.payee != U),
        "One party unclassified": (df.payer == U) ^ (df.payee == U),
        "Both parties unclassified": (df.payer == U) & (df.payee == U),
    }
    rows = []
    for label, m in masks.items():
        s = df[m]
        rows.append({
            "category": label,
            "rows": int(len(s)),
            "rows_with_value": int(s.value.notna().sum()),
            "rows_suppressed": int(s.value.isna().sum()),
            "value": float(s.value.sum()),
            "transactions": float(s.n_tx.sum()),
        })
    out = pd.DataFrame(rows)
    out["share_of_value"] = out.value / out.value.sum()
    out["share_of_transactions"] = out.transactions / out.transactions.sum()
    out["share_of_rows"] = out.rows / out.rows.sum()
    return out


def _regional_splits(df: pd.DataFrame) -> pd.DataFrame:
    """The same question for geography: how many ends resolve to a region."""
    unk = cfg.UNKNOWN_REGION
    masks = {
        "Both regions known": (df.payer_region != unk) & (df.payee_region != unk),
        "One region unknown": (df.payer_region == unk) ^ (df.payee_region == unk),
        "Both regions unknown": (df.payer_region == unk) & (df.payee_region == unk),
    }
    rows = []
    for label, m in masks.items():
        s = df[m]
        rows.append({"category": label, "rows": int(len(s)),
                     "value": float(s.value.sum()),
                     "transactions": float(s.n_tx.sum())})
    out = pd.DataFrame(rows)
    out["share_of_value"] = out.value / out.value.sum()
    return out


def build(edges: dict[str, pd.DataFrame]) -> dict[str, pd.DataFrame]:
    """Profile every grain present in the delivery."""
    out: dict[str, pd.DataFrame] = {}

    sic2 = edges.get(cfg.LEVEL_SIC2)
    if sic2 is not None:
        out["classification"] = _splits(sic2)

        # Suppression is applied by the data provider before we see the file.
        supp = (sic2.suppressed_type.value_counts(dropna=True)
                .rename_axis("suppression").reset_index(name="rows"))
        supp["share_of_rows"] = supp.rows / len(sic2)
        supp["meaning"] = supp.suppression.map({
            "disclosure": "[c] withheld by the provider for disclosure control",
            "no_data": "[-] no interaction recorded between these industries",
            "unparsed": "value could not be read - investigate",
        }).fillna("unknown token")
        out["suppression"] = supp

        # One row per month, so an analyst can see coverage move.
        g = sic2.groupby("month", observed=True)
        classified = sic2[(sic2.payer != U) & (sic2.payee != U)]
        monthly = pd.DataFrame({
            "rows": g.size(),
            "value": g.value.sum(min_count=1),
            "transactions": g.n_tx.sum(min_count=1),
            "rows_suppressed": g.value.apply(lambda s: s.isna().sum()),
            "classified_value": classified.groupby("month", observed=True)
                                          .value.sum(min_count=1),
            "industries_active": g.payee.nunique(),
        }).reset_index()
        monthly["share_suppressed"] = safe_divide(monthly.rows_suppressed, monthly.rows)
        monthly["share_classified"] = safe_divide(monthly.classified_value, monthly.value)
        monthly["avg_transaction_value"] = safe_divide(monthly.value, monthly.transactions)
        out["monthly"] = monthly

    reg = edges.get(cfg.LEVEL_SIC2_REGION)
    if reg is not None:
        out["regional_classification"] = _splits(reg)
        out["regional_geography"] = _regional_splits(reg)

    log.info("dataset profile: %s", ", ".join(out))
    return out


def write(profiles: dict[str, pd.DataFrame]) -> None:
    for name, df in profiles.items():
        df.to_csv(cfg.OUTPUTS / f"profile_{name}.csv", index=False)
