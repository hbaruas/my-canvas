"""Coverage and suppression metrics.

These are a deliverable in their own right, not diagnostics. The findings that
justify the rest of the design - 63% of value involving an unclassified
counterparty, intermittent cell suppression, the Education break - all come
out of this table.
"""
from __future__ import annotations

import logging

import numpy as np
import pandas as pd

from .series import safe_divide

from . import config as cfg

log = logging.getLogger(__name__)

UNCL = cfg.UNCLASSIFIED_SIC


def build(edges: pd.DataFrame) -> pd.DataFrame:
    """Per-month coverage metrics for the national panel."""
    df = edges[edges.grain == cfg.LEVEL_SIC2]
    g = df.groupby("month", observed=True)

    total = g.value.sum(min_count=1)
    classified = (df[(df.payer != UNCL) & (df.payee != UNCL)]
                  .groupby("month", observed=True).value.sum(min_count=1))
    involving_00 = (df[(df.payer == UNCL) | (df.payee == UNCL)]
                    .groupby("month", observed=True).value.sum(min_count=1))

    out = pd.DataFrame({
        "total_value": total,
        "classified_value": classified,
        "unclassified_value": involving_00,
        "share_unclassified": involving_00 / total,
        "cells": g.size(),
        "cells_suppressed": g.suppressed_type.apply(lambda s: s.notna().sum()),
        "n_tx": g.n_tx.sum(min_count=1),
    })
    out["share_cells_suppressed"] = safe_divide(out.cells_suppressed, out.cells)
    out["active_industries"] = (
        df[df.value.notna()].groupby("month", observed=True).payee.nunique())

    # Month-on-month deltas: a jump in coverage is the thing that masquerades
    # as an economic move.
    for c in ("share_unclassified", "share_cells_suppressed", "active_industries"):
        out[f"{c}_delta"] = out[c].diff()

    out["volume_outlier"], out["volume_vs_neighbours"] = _flag_volume_outliers(out)
    return out.reset_index()


# How far below its neighbours a month's transaction count sits before we
# report it. A measurement of the delivery, not a judgement about it.
VOLUME_OUTLIER_THRESHOLD = 0.75


def _flag_volume_outliers(q: pd.DataFrame) -> tuple[pd.Series, pd.Series]:
    """Months whose transaction count sits far below the months around them.

    This reports a property of the delivery; it does not second-guess it. The
    data is the ground truth, so what we can say is that July 2021 records
    52.2m transactions against 81.7m in June and 76.7m in August, and £90.1bn
    against £120.1bn and £112.6bn. Whether that reflects the economy, the
    sample of organisations covered, or how the month was collected is not
    something the data can settle, and we do not assert it.

    What does follow - as arithmetic on our own figures, not a claim about the
    source - is that a year-on-year comparison against such a month divides by
    a much smaller base. For July 2022, 74 of 88 industries show growth above
    25% on that basis while month-on-month growth is 0.4%.
    """
    n_tx = q.n_tx
    neighbours = n_tx.rolling(7, center=True, min_periods=3).median()
    ratio = safe_divide(n_tx, neighbours)
    return ratio < VOLUME_OUTLIER_THRESHOLD, ratio


def build_regional(edges: pd.DataFrame) -> pd.DataFrame | None:
    """Unknown-region shares, tracked on both sides.

    Payer-side unknown has fallen from 19.3% to 16.0% over 18 months. As
    attribution improves, named regions gain value that was previously
    unknown - indistinguishable from regional growth unless this is shown.
    """
    df = edges[edges.grain == cfg.LEVEL_SIC2_REGION]
    if df.empty:
        return None
    df = df[(df.payer != UNCL) & (df.payee != UNCL)]
    g = df.groupby("month", observed=True)
    total = g.value.sum(min_count=1)
    unk = cfg.UNKNOWN_REGION
    out = pd.DataFrame({
        "classified_value": total,
        "unknown_payee_share": (df[df.payee_region == unk]
                                .groupby("month", observed=True)
                                .value.sum(min_count=1) / total),
        "unknown_payer_share": (df[df.payer_region == unk]
                                .groupby("month", observed=True)
                                .value.sum(min_count=1) / total),
        "both_known_share": (df[(df.payer_region != unk) & (df.payee_region != unk)]
                             .groupby("month", observed=True)
                             .value.sum(min_count=1) / total),
    })
    return out.reset_index()


def cell_stability(edges: pd.DataFrame, top_n: int = 50) -> pd.DataFrame:
    """Counterparty relationships that move in and out of suppression.

    This is what turns "SIC 29 collapsed" into "one cell stopped being
    reported" - the SIC 84 -> SIC 29 cell ran at 81-186m for six months and
    then vanished entirely (BUILD_SPEC 6.7).
    """
    df = edges[edges.grain == cfg.LEVEL_SIC2]
    n_months = df.month.nunique()
    g = df.groupby(["payer", "payee"], observed=True)
    stats = pd.DataFrame({
        "months_present": g.value.apply(lambda s: s.notna().sum()),
        "months_absent": g.value.apply(lambda s: s.isna().sum()),
        "mean_value_when_present": g.value.mean(),
        "max_value": g.value.max(),
    }).reset_index()
    # Intermittent = present sometimes, absent sometimes.
    stats = stats[(stats.months_present > 0) & (stats.months_absent > 0)]
    stats["intermittency"] = stats.months_absent / n_months
    # Rank by how much value moves in and out of view.
    stats["value_at_risk"] = (stats.mean_value_when_present.fillna(0)
                              * stats.intermittency)
    return (stats.sort_values("value_at_risk", ascending=False)
                 .head(top_n).reset_index(drop=True))
