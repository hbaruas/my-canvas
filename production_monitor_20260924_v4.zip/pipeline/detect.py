"""Anomaly detection: which industries moved unusually, and how much to trust it.

Two numbers are reported separately rather than blended into one, because they
answer different questions:

    severity    how statistically unusual the move is (0-100)
    confidence  how likely it is to be economic rather than an artefact

Blending them would hide exactly the case that matters most - a huge move that
is entirely a reporting change. The canonical case is SIC 19 in October 2025:
the break register records a -65.5% level shift, and 92% of the year-on-year
inflow fall is a single retail counterparty that has a figure in October 2024
and none in October 2025.

Figures in this docstring are illustrative and were measured on the delivery of
16 July 2026. The user-facing version of this example is computed at render
time by app_pages.method.suppression_case(), because a written-down figure goes
stale: an earlier draft of it said "£330m of a £348m fall" long after the data
said £313m of £342m.

Ranking is on a continuous severity score rather than a binary threshold
because a fixed z cut-off means wildly different economic sensitivity across
industries: the median industry needs a 32% year-on-year move to clear |z|=3,
the upper quartile 47%, and 27 of 78 need more than 40%.
"""
from __future__ import annotations

import logging

import numpy as np
import pandas as pd
from scipy import stats

from . import config as cfg
from . import decompose
from .series import safe_divide

log = logging.getLogger(__name__)

MEASURES = ("inflow", "outflow", "pfi")
BASES = ("MoM", "YoY")

MIN_HISTORY = 12          # months of baseline before a z-score means anything
FULL_BASELINE = 24        # below this the baseline is thin and the score provisional
MIN_MONTHLY_VALUE = 50e6  # industries below this are too small to score
SIGNAL_THRESHOLD = 2.0    # a signal "fires" above this
CUSUM_WINDOW = 6          # months of drift the CUSUM accumulates over

# Severity maps the strongest signal onto 0-100 through a saturating curve:
#   z=2 -> 49,  z=3 -> 63,  z=4.5 -> 78,  z=6 -> 86,  z=9 -> 95
SEVERITY_SCALE = 3.0


def _mad(x: pd.Series) -> float:
    x = x.dropna()
    if len(x) < 4:
        return float("nan")
    m = (x - x.median()).abs().median() * 1.4826
    return float(m) if m > 0 else float("nan")


def _finite_sample_z(ratio: float, n: int) -> float:
    """Discount a z-score for the uncertainty in its own baseline.

    A median and MAD estimated from 15 months are themselves uncertain, so the
    raw ratio overstates how surprising a point is. Education came back from
    its March-2025 break with a tight 15-month baseline and scored 97.8 on a
    +12% move - above a -36% move in an industry with six years of history.

    The ratio is referenced to a t distribution on n-1 degrees of freedom and
    converted back to the equivalent normal deviate, so a thin baseline has to
    work harder for the same severity. With a long baseline the correction
    vanishes, which is the behaviour we want.
    """
    if not np.isfinite(ratio) or n < 3:
        return float("nan")
    tail = stats.t.sf(abs(ratio), df=n - 1)
    tail = max(tail, 1e-12)                  # keep the inverse finite
    return float(np.sign(ratio) * stats.norm.isf(tail))


def _baseline_mask(index: pd.DatetimeIndex, segment_start) -> pd.Series:
    """Months usable for estimating a baseline.

    Excludes COVID, whose variance is so wide that including it desensitises
    everything after it, and anything before the industry's last structural
    break, whose level no longer applies.
    """
    mask = ~((index >= pd.Timestamp(cfg.COVID_START))
             & (index <= pd.Timestamp(cfg.COVID_END)))
    if pd.notna(segment_start):
        mask &= index >= pd.Timestamp(segment_start)
    return pd.Series(mask, index=index)


def _rolling_robust_z(x: pd.Series,
                      usable: pd.Series) -> tuple[pd.Series, pd.Series]:
    """Robust z of each point against only the history preceding it.

    Strictly prior - using the full sample would let a shock contribute to the
    baseline it is being measured against.

    Returns (z, months_of_baseline) so a thin baseline can be reported rather
    than silently trusted. Requiring a full 24 months instead cost 28 months of
    history and made COVID - the largest outlier in the series - unscoreable,
    while changing the recent alert rate from 3.9 to 4.1 a month.

    The history is dropna'd before it is counted. It used to be counted as
    rows of the index, which is not the same thing: a year-on-year series has
    no value in its first twelve months, and a suppressed cell leaves a hole.
    SIC 68 in June 2026 was reported as resting on 73 months of baseline when
    61 months actually carried a value, and the finite-sample correction was
    applied on 72 degrees of freedom instead of 60. Both the published depth
    and the discount were therefore wrong in the direction of overconfidence.
    """
    out = pd.Series(np.nan, index=x.index)
    depth = pd.Series(np.nan, index=x.index)
    for i in range(len(x)):
        hist = x.iloc[:i][usable.iloc[:i]].dropna()
        if len(hist) < MIN_HISTORY or pd.isna(x.iloc[i]):
            continue
        scale = _mad(hist)
        if not np.isfinite(scale):
            continue
        out.iloc[i] = _finite_sample_z((x.iloc[i] - hist.median()) / scale,
                                       len(hist))
        depth.iloc[i] = len(hist)
    return out, depth


def _cusum(z: pd.Series, window: int = CUSUM_WINDOW) -> pd.Series:
    """Sustained drift: moderate deviation held over months, which no single
    month would flag.

    Reported as the MEAN z over the window, not the sum over sqrt(n). The
    sqrt normalisation assumes independent observations; year-on-year z-scores
    are strongly autocorrelated because consecutive months share eleven of
    their twelve base months, so the sum grows roughly linearly and the
    statistic inflates. Measured on this data, sqrt-normalised CUSUM fired
    14.6 times a month against 3.1 for a single-month z on the same series.

    As a mean it is directly comparable with a single-month z and reads
    plainly: "this industry has averaged z = -2 for six months".
    """
    return z.rolling(window, min_periods=3).mean()


def _breadth(edges, code: str, month: pd.Timestamp,
             base: pd.Timestamp, measure: str = "inflow") -> tuple[float, float, float]:
    """How the move is distributed across counterparties.

    Decomposed on the same measure and basis the alert was scored on, so the
    shares describe the number being reported.
    Returns (breadth, presence_share, top_counterparty_share).
    """
    rows = decompose.decompose_measure(edges, code, month, base, measure=measure,
                                       include_unclassified=False)
    if rows.empty:
        return float("nan"), float("nan"), float("nan")
    s = decompose.summarise(rows)
    total = s["total_change"]
    if not total:
        return float("nan"), s["presence_share"], float("nan")
    same = np.sign(rows.contribution) == np.sign(total)
    top_share = abs(s["top_contribution"]) / abs(total)
    return float(same.mean()), float(s["presence_share"]), float(top_share)


SYSTEMIC_COMMON_PCT = 0.20      # the whole economy moved this much


CONCENTRATION_LIMIT = 0.70      # one counterparty carrying most of the move


def _confidence(presence: float, breadth: float, on_break: bool,
                sic00_shift: float, suppressed_share: float,
                common_pct: float = np.nan,
                top_share: float = np.nan,
                baseline_months: float = np.nan) -> tuple[str, str]:
    """How much of this move looks economic. Returns (label, reason)."""
    if np.isfinite(common_pct) and abs(common_pct) >= SYSTEMIC_COMMON_PCT:
        return "low", (f"the whole economy moved {common_pct:+.0%} this month - "
                       "likely a data event, not an industry shock")
    if on_break:
        return "low", "inside a known structural break"
    if np.isfinite(presence) and presence >= 0.5:
        return "low", "driven by counterparties appearing or disappearing"
    if np.isfinite(sic00_shift) and abs(sic00_shift) >= 0.20:
        return "low", "counterparty classification shifted"
    if np.isfinite(suppressed_share) and suppressed_share > 0.5:
        return "low", "over half of this industry's cells are suppressed"
    # Breadth counts how many counterparties moved the same way; it says
    # nothing about how the SIZE is distributed. SIC 66 had most counterparties
    # falling AND a single one carrying 102% of the fall - reporting that as
    # "broad-based" beside a driver line naming one counterparty is a
    # contradiction the reader has to resolve.
    if np.isfinite(top_share) and top_share >= CONCENTRATION_LIMIT:
        return "medium", (f"{top_share:.0%} of the move is a single "
                          f"counterparty")
    if np.isfinite(breadth) and breadth < 0.4:
        return "medium", "concentrated in a few counterparties"
    if np.isfinite(presence) and presence >= 0.25:
        return "medium", "partly driven by counterparty presence"
    if np.isfinite(baseline_months) and baseline_months < FULL_BASELINE:
        return "medium", (f"provisional - only {baseline_months:.0f} months of "
                          f"baseline behind this score")
    return "high", "broad-based"


def _severity(*signals: float) -> float:
    """Strongest available signal, saturating onto 0-100.

    No invented weights: the signals are reported individually alongside, and
    corroboration is shown as a count rather than folded into the score.
    """
    vals = [abs(s) for s in signals if np.isfinite(s)]
    if not vals:
        return float("nan")
    return float(round(100 * (1 - np.exp(-max(vals) / SEVERITY_SCALE)), 1))


def common_component(panel: pd.DataFrame, measure: str, lag: int) -> pd.Series:
    """The typical industry's log change in each month.

    Scoring an industry only against its own history treats a system-wide move
    as an industry-specific shock. It is not: Andrew's requirement is to
    surface industries that moved DIFFERENTLY from the rest of the economy.

    This matters on real data. July 2021 is an incomplete month - £90.1bn
    against £120.1bn in June, on 52.2m transactions against 81.7m - so every
    year-on-year comparison against it is inflated. In July 2022, 74 of 88
    industries rose more than 25% year-on-year with a median of +58.8%, while
    month-on-month growth was +0.4%. Without this correction the detector
    reports 74 economic shocks that never happened.

    Subtracting the cross-sectional median removes any common movement,
    whether its cause is macroeconomic or a data artefact, and leaves the
    industry-specific part.
    """
    wide = panel[panel.sic2 != cfg.UNCLASSIFIED_SIC].pivot_table(
        index="month", columns="sic2", values=measure)
    logs = np.log(wide.where(wide > 0))
    return logs.diff(lag).median(axis=1)


def build(panel: pd.DataFrame, edges: pd.DataFrame,
          breaks: pd.DataFrame | None = None) -> pd.DataFrame:
    """Score every industry-month. Returns the ranked alert table."""
    break_months: set[tuple[str, pd.Timestamp]] = set()
    if breaks is not None and len(breaks):
        break_months = {(r.sic2, pd.Timestamp(r.break_month))
                        for r in breaks.itertuples()}

    # The common component per measure: what every industry did together.
    common = {m: {lag: common_component(panel, m, lag) for lag in (1, 12)}
              for m in MEASURES}

    records: list[dict] = []
    for sic2, grp in panel.groupby("sic2", observed=True):
        grp = grp.sort_values("month").set_index("month")
        if sic2 == cfg.UNCLASSIFIED_SIC or grp.inflow.mean() < MIN_MONTHLY_VALUE:
            continue
        usable = _baseline_mask(grp.index, grp.get("segment_start", pd.NaT).iloc[0]
                                if "segment_start" in grp else pd.NaT)

        for measure in MEASURES:
            level = grp[measure]
            sa = grp.get(f"{measure}_sa", level)
            logs = np.log(level.where(level > 0))

            # Signal 1: single-month deviation of the SA level from expected.
            resid = sa - sa.rolling(12, min_periods=6).median()
            z_level, depth_level = _rolling_robust_z(resid, usable)

            # Signal 2: year-on-year, in EXCESS of what every industry did.
            # Year-on-year is inherently seasonally controlled; subtracting the
            # cross-sectional median also strips out system-wide movement.
            yoy_raw = logs.diff(12)
            yoy = yoy_raw - common[measure][12].reindex(yoy_raw.index)
            z_yoy, depth_yoy = _rolling_robust_z(yoy, usable)

            # Signal 3: accumulated drift in that excess.
            cusum = _cusum(z_yoy)

            for basis in BASES:
                lag = 1 if basis == "MoM" else 12
                delta = level - level.shift(lag)
                pct = safe_divide(level, level.shift(lag)) - 1
                for month in grp.index[lag:]:
                    zl, zy, cu = z_level.get(month), z_yoy.get(month), cusum.get(month)
                    sev = _severity(zl, zy, cu)
                    if not np.isfinite(sev):
                        continue
                    records.append({
                        "month": month, "level": "division", "code": sic2,
                        "name": grp["name"].iloc[0], "section": grp["section"].iloc[0],
                        "gdp_grouping": grp["gdp_grouping"].iloc[0],
                        "measure": measure, "basis": basis,
                        "severity": sev,
                        "direction": "up" if (delta.get(month) or 0) > 0 else "down",
                        "z_level": zl, "z_yoy": zy, "cusum": cu,
                        "gbp_delta": delta.get(month), "pct_delta": pct.get(month),
                        "common_pct": float(np.expm1(
                            common[measure][lag].get(month, np.nan))),
                        "excess_pct": (pct.get(month) - float(np.expm1(
                            common[measure][lag].get(month, np.nan)))
                            if pd.notna(pct.get(month)) else np.nan),
                        "n_signals": int(sum(np.isfinite(v) and abs(v) > SIGNAL_THRESHOLD
                                             for v in (zl, zy, cu))),
                        "baseline_months": np.nanmax([
                            depth_level.get(month, np.nan),
                            depth_yoy.get(month, np.nan)]),
                        "break_flag": (sic2, month) in break_months,
                        "suppressed_share": (grp.suppressed_cells_in.get(month, np.nan)
                                             / 89.0),
                    })

    alerts = pd.DataFrame(records)
    if alerts.empty:
        return alerts
    log.info("scored %s industry-month-measure combinations", f"{len(alerts):,}")
    return alerts


def roll_up(alerts: pd.DataFrame, panel: pd.DataFrame) -> pd.DataFrame:
    """Add section and GDP-grouping rows, inherited from their divisions.

    A section's score is NOT re-estimated on the aggregate. Running the same
    detector on section totals finds 1.04 alerts a month against 3.57 at
    division level: only 48% of division alerts survive aggregation, and the
    median alert loses 30% of its strength. SIC 51 air transport scored -4.9
    while its section showed -0.3.

    So a section inherits the severity of its most anomalous division and says
    which one it was. Detect low, report high - the money is summed, the signal
    is not diluted.
    """
    if alerts.empty:
        return alerts
    div = alerts[alerts.level == "division"]
    out = [alerts]

    for level, key in (("section", "section"), ("gdp_grouping", "gdp_grouping")):
        # Money aggregates; the signal is inherited from the strongest member.
        sums = (div.groupby([key, "month", "measure", "basis"], observed=True)
                   .agg(gbp_delta=("gbp_delta", "sum"),
                        n_divisions=("code", "nunique")))
        lead_idx = (div.groupby([key, "month", "measure", "basis"], observed=True)
                       .severity.idxmax().dropna())
        lead = div.loc[lead_idx].set_index([key, "month", "measure", "basis"])

        rolled = lead.join(sums, rsuffix="_agg")
        rolled = rolled.reset_index()
        rolled["level"] = level
        rolled["driver_code"] = rolled["code"]
        rolled["driver_name"] = rolled["name"]
        rolled["code"] = rolled[key]
        rolled["name"] = rolled[key]
        rolled["gbp_delta"] = rolled["gbp_delta_agg"]
        rolled["pct_delta"] = np.nan          # recomputed in the app from levels
        out.append(rolled.drop(columns=[c for c in ("gbp_delta_agg",) if c in rolled]))

    combined = pd.concat(out, ignore_index=True)
    # Keep these as text: a NaN on the division rows would make the column
    # float and turn code "66" into "66.0" everywhere downstream.
    for c in ("driver_code", "driver_name"):
        combined[c] = combined.get(c, "").fillna("").astype(str)
    log.info("rolled up to %d section and %d GDP-grouping rows",
             int((combined.level == "section").sum()),
             int((combined.level == "gdp_grouping").sum()))
    return combined


def enrich(alerts: pd.DataFrame, edges, per_month: int = 10) -> pd.DataFrame:
    """Add breadth, presence and confidence to the top rows IN EACH MONTH.

    Per month, not globally: a global top-N is dominated by the most extreme
    months, so the current one - the only one anyone opens - gets nothing.
    That is how the SIC-00 shift flag came to fire on zero rows despite
    Education's 47-point shift sitting in the data.

    Each row costs one counterparty decomposition, which is ~8 ms against a
    month-indexed edge table.
    """
    if alerts.empty:
        return alerts
    alerts = alerts.sort_values("severity", ascending=False).reset_index(drop=True)
    edges = decompose.as_index(edges)
    # Breadth is a counterparty decomposition, which only exists at division
    # level; section rows inherit their driver's figures in roll_up().
    head = (alerts[alerts.level == "division"]
            .groupby(["month", "measure", "basis"], observed=True)
            .head(per_month))

    breadth, presence, sic00, tops = [], [], [], []
    for r in head.itertuples():
        lag = 1 if r.basis == "MoM" else 12
        base = r.month - pd.DateOffset(months=lag)
        b, p, t = _breadth(edges, r.code, r.month, base, r.measure)
        breadth.append(b)
        presence.append(p)
        tops.append(t)
        sic00.append(decompose._sic00_shift(edges, r.code, r.month, base))

    alerts["breadth"] = np.nan
    alerts["presence_share"] = np.nan
    alerts["sic00_share_shift"] = np.nan
    alerts["top_counterparty_share"] = np.nan
    alerts.loc[head.index, "breadth"] = breadth
    alerts.loc[head.index, "presence_share"] = presence
    alerts.loc[head.index, "sic00_share_shift"] = sic00
    alerts.loc[head.index, "top_counterparty_share"] = tops

    conf = [
        _confidence(r.presence_share, r.breadth, r.break_flag,
                    r.sic00_share_shift, r.suppressed_share, r.common_pct,
                    r.top_counterparty_share, r.baseline_months)
        for r in alerts.itertuples()
    ]
    alerts["confidence"] = [c[0] for c in conf]
    alerts["confidence_reason"] = [c[1] for c in conf]

    # The spec's named flags (BUILD_SPEC 5.2), derived from the values above so
    # a consumer of the CSV does not have to re-apply the thresholds.
    alerts["sic00_shift_flag"] = alerts.sic00_share_shift.abs() >= 0.20
    alerts["quality_flag"] = alerts.confidence.eq("low")
    alerts["provisional"] = alerts.baseline_months < FULL_BASELINE
    return alerts


def add_revision_flags(alerts: pd.DataFrame,
                       revisions: pd.DataFrame) -> pd.DataFrame:
    """Mark alerts whose month was restated in the latest delivery.

    A revised figure can produce an alert that is entirely an artefact of the
    restatement, so it is flagged rather than left to look like news.
    """
    alerts = alerts.copy()
    alerts["revision_flag"] = False
    if revisions is None or revisions.empty or "month" not in revisions:
        return alerts
    revised = set(zip(pd.to_datetime(revisions.month),
                      revisions.get("payee", pd.Series(dtype=str)).astype(str)))
    if not revised:
        return alerts
    alerts["revision_flag"] = [
        (m, c) in revised for m, c in zip(alerts.month, alerts.code)]
    return alerts
