"""Structural anomalies: an industry whose relationships change shape.

Phase 2, chunk 3. The Phase 1 detector asks whether an industry's MONEY moved
unusually. This asks a different question: has the *shape* of its trading
changed - who it trades with, how many, how concentrated, how much of its
activity is internal - even when the totals look ordinary.

The two are complements. An industry flagged by both moved and reorganised; one
flagged only here has reorganised quietly, which no level series shows.

Why Isolation Forest and not a graph neural network. The spec considered a GNN
and rejected it for two reasons that still hold: 88 nodes x 90 months is 7,920
observations, nowhere near enough to train one; and the payment graph is ~78%
dense, so neighbourhood aggregation averages over almost the whole network and
the embeddings collapse toward a common mean. Engineered features keep every
input readable, which matters when an economist asks why something was flagged.

Every feature is standardised WITHIN an industry before scoring, so the model
answers "is this month unusual for this industry" rather than "is this industry
unusual", which would simply rediscover that industries differ in size.
"""
from __future__ import annotations

import logging

import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest

from . import config as cfg
from . import decompose

log = logging.getLogger(__name__)

# Each is a property of an industry's relationships, not of its size.
FEATURES = (
    "n_counterparties",        # how many industries pay it
    "hhi",                     # how concentrated those payments are by VALUE
    "hhi_volume",              # ... and by NUMBER of payments
    "top_share",               # the largest single relationship
    "self_share",              # how much activity is internal
    "unclassified_share",      # how much arrives from unidentified payers
    "churn",                   # counterparties gained or lost since last month
    "avg_payment",             # value per payment - price and mix
    "pagerank",                # position in the network
)

# Value and volume answer different questions. A relationship worth the same
# money through half as many payments has changed character - larger, less
# frequent settlements - and no value-only feature sees it. Concentration is
# therefore measured both ways, and the average payment carries the split
# between price and activity directly.

MIN_HISTORY = 12               # months before a month can be scored
CONTAMINATION = 0.03           # expected share of anomalies; ~2-3 a month
RANDOM_STATE = 0               # a fixed seed: the same data must score the same


def _hhi(values: pd.Series) -> float:
    """Herfindahl index of counterparty shares: 1 = a single relationship."""
    total = values.sum()
    if not total:
        return float("nan")
    shares = values / total
    return float((shares ** 2).sum())


def build_features(edges: pd.DataFrame,
                   node_metrics: pd.DataFrame | None = None) -> pd.DataFrame:
    """One row per industry-month describing the shape of its inflows."""
    df = edges[edges.grain == cfg.LEVEL_SIC2]
    df = df[df.value.notna() & (df.value > 0)]

    rows = []
    previous: dict[str, set] = {}
    for month in sorted(df.month.unique()):
        cur = df[df.month == month]
        classified = cur[(cur.payer != cfg.UNCLASSIFIED_SIC)
                         & (cur.payee != cfg.UNCLASSIFIED_SIC)]
        for code, grp in classified.groupby("payee", observed=True):
            payers = set(grp.payer)
            prev = previous.get(code)
            # Churn is symmetric: relationships gained and lost both count.
            # The first month an industry appears has nothing to compare with -
            # left null rather than scored as total turnover, which would flag
            # every industry in January 2019.
            if prev is None or not (payers | prev):
                churn = np.nan
            else:
                churn = len(payers ^ prev) / len(payers | prev)
            all_in = cur[cur.payee == code]
            total_in = all_in.value.sum()
            from_00 = all_in.loc[all_in.payer == cfg.UNCLASSIFIED_SIC, "value"].sum()
            self_flow = grp.loc[grp.payer == code, "value"].sum()
            n_tx = grp.n_tx.fillna(0)
            rows.append({
                "sic2": code, "month": month,
                "n_counterparties": len(payers),
                "hhi": _hhi(grp.value),
                "hhi_volume": _hhi(n_tx) if n_tx.sum() else np.nan,
                "avg_payment": float(grp.value.sum() / n_tx.sum())
                               if n_tx.sum() else np.nan,
                "top_share": float(grp.value.max() / grp.value.sum())
                             if grp.value.sum() else np.nan,
                "self_share": float(self_flow / grp.value.sum())
                              if grp.value.sum() else np.nan,
                "unclassified_share": float(from_00 / total_in) if total_in else np.nan,
                "churn": churn,
                "inflow": float(grp.value.sum()),
            })
            previous[code] = payers

    out = pd.DataFrame(rows)
    if node_metrics is not None and len(node_metrics):
        pr = node_metrics[node_metrics.metric == "pagerank"].copy()
        pr["sic2"] = pr.node_id.str.split(":").str[-1]
        out = out.merge(pr[["sic2", "month", "value"]]
                        .rename(columns={"value": "pagerank"}),
                        on=["sic2", "month"], how="left")
    else:
        out["pagerank"] = np.nan
    log.info("structural features: %s industry-months", f"{len(out):,}")
    return out


def _standardise_within_industry(features: pd.DataFrame) -> pd.DataFrame:
    """Express each feature as a robust z against that industry's own history.

    Without this the model finds that industries differ from each other, which
    is true and useless. With it, the model finds months that differ from an
    industry's own normal.
    """
    out = features.copy()
    for col in FEATURES:
        if col not in out:
            continue
        grouped = out.groupby("sic2")[col]
        median = grouped.transform("median")
        mad = grouped.transform(lambda s: (s - s.median()).abs().median()) * 1.4826

        # A robust scale collapses on a feature that is usually constant.
        # Counterparty churn is zero in most months for most industries, so its
        # median AND its MAD are zero - which nulled 95% of rows and left the
        # model 360 of 7,783 to learn from. Fall back to the standard
        # deviation, which is non-zero whenever the feature ever moves.
        sd = grouped.transform("std")
        scale = mad.where(mad > 0, sd)

        z = (out[col] - median) / scale
        # Genuinely constant for this industry: no deviation exists, so the
        # feature carries no information here rather than being unknown.
        z = z.mask((scale.isna()) | (scale == 0), 0.0)
        out[f"z_{col}"] = z
    return out


def score(features: pd.DataFrame,
          contamination: float = CONTAMINATION) -> pd.DataFrame:
    """Isolation Forest over the standardised structural features."""
    std = _standardise_within_industry(features)
    cols = [f"z_{c}" for c in FEATURES if f"z_{c}" in std]
    usable = std.dropna(subset=cols)
    if len(usable) < 100:
        log.warning("too few complete rows to score (%d)", len(usable))
        std["structural_score"] = np.nan
        return std

    model = IsolationForest(contamination=contamination,
                            random_state=RANDOM_STATE, n_estimators=300)
    model.fit(usable[cols])
    # decision_function: negative is more anomalous. Flip and rescale so the
    # number reads the same way as the Phase 1 severity - higher is stranger.
    raw = -model.decision_function(usable[cols])
    std.loc[usable.index, "structural_raw"] = raw
    lo, hi = np.nanpercentile(raw, [1, 99])
    std.loc[usable.index, "structural_score"] = np.clip(
        (raw - lo) / (hi - lo) * 100, 0, 100).round(1)
    std.loc[usable.index, "structural_flag"] = model.predict(usable[cols]) == -1

    flagged = int(std.structural_flag.eq(True).sum())
    log.info("structural anomalies: %d of %d industry-months flagged",
             flagged, len(usable))
    return std


def explain(row: pd.Series, top_n: int = 2) -> str:
    """Which features made this month unusual - in plain words.

    An Isolation Forest gives no coefficients, so the explanation is the
    standardised features themselves: the ones furthest from the industry's own
    normal are the ones that isolated it.
    """
    labels = {
        "n_counterparties": ("more industries paying it", "fewer industries paying it"),
        "hhi": ("payments more concentrated by value", "payments more spread by value"),
        "hhi_volume": ("payments more concentrated by number",
                       "payments more spread by number"),
        "avg_payment": ("larger payments", "smaller payments"),
        "top_share": ("larger share from one payer", "smaller share from its largest payer"),
        "self_share": ("more activity within the industry", "less activity within the industry"),
        "unclassified_share": ("more arriving from unclassified payers",
                               "less arriving from unclassified payers"),
        "churn": ("unusual turnover of counterparties", "unusually stable counterparties"),
        "pagerank": ("more central in the network", "less central in the network"),
    }
    scores = {c: row.get(f"z_{c}", np.nan) for c in FEATURES}
    ranked = sorted((c for c in scores if np.isfinite(scores[c])),
                    key=lambda c: -abs(scores[c]))[:top_n]
    if not ranked:
        return ""
    parts = []
    for c in ranked:
        up, down = labels[c]
        parts.append(f"{up if scores[c] > 0 else down} ({scores[c]:+.1f} vs normal)")
    return "; ".join(parts)


def build(edges: pd.DataFrame, node_metrics: pd.DataFrame | None = None
          ) -> pd.DataFrame:
    """Features, scores and explanations for every industry-month."""
    scored = score(build_features(edges, node_metrics))
    if "structural_score" not in scored:
        return scored
    scored["structural_reason"] = [
        explain(r) if pd.notna(r.get("structural_score")) else ""
        for _, r in scored.iterrows()]
    return scored
