"""Seasonal adjustment and structural break detection.

Two jobs, both prerequisites for detection rather than refinements of it:

  * Seasonal adjustment. Monthly payment values carry heavy month-length and
    trading-day effects. STL is used rather than X-13ARIMA-SEATS: it is pure
    Python, so it behaves identically on macOS ARM and Windows x64 with no
    binary dependency. `adjust()` is written as a pluggable interface so X-13
    can be dropped in if a publication ever requires the ONS standard.

  * Break detection. SIC 85 Education falls 57% in March 2025 and stays there,
    with suppressed-cell counts unchanged across the break - a classification
    or coverage change, not an economic event. It scores z of about -13 to
    -16.5 and would otherwise rank first on the alert table every month for a
    year. Detecting breaks is therefore a precondition for the dashboard being
    credible, not a nicety.

A break is a PERMANENT level shift. A shock is a deviation that recovers. The
distinction is the whole point, so persistence is required, and the COVID
window is excluded from candidates - we know it was a shock.
"""
from __future__ import annotations

import logging

import numpy as np
import pandas as pd
from statsmodels.tsa.seasonal import STL

from . import config as cfg

log = logging.getLogger(__name__)

MEASURES = ("inflow", "outflow", "pfi")

# --- break detection parameters ---------------------------------------
MIN_SEGMENT = 6          # months either side; below this a "break" is a blip
MIN_PERSIST = 6          # the new level must hold for at least this long
MIN_SHIFT_LOG = 0.25     # ~22%; smaller shifts are trend, not break
MIN_SCORE = 4.0          # shift measured in robust scale units
MIN_MONTHLY_VALUE = 50e6  # below this a series is too small to condition


# A floor for the noise estimate. Chosen so that a shift of exactly
# MIN_SHIFT_LOG against a perfectly smooth series scores exactly MIN_SCORE:
# without it, a series with no month-to-month variation has zero scale and
# every break becomes a division by zero.
SCALE_FLOOR = MIN_SHIFT_LOG / MIN_SCORE


def _robust_scale(x: pd.Series) -> float:
    """MAD-based scale of month-to-month change, in log space."""
    d = x.diff().dropna()
    if len(d) < 4:
        return float("nan")
    mad = (d - d.median()).abs().median() * 1.4826
    if mad > 0:
        return float(mad)
    # Fall back to standard deviation, then to the floor. A very smooth series
    # is not evidence that any shift in it is insignificant.
    sd = float(d.std())
    return sd if sd > 0 else SCALE_FLOOR


def _best_break(logs: pd.Series, covid_mask: pd.Series) -> tuple[int, float, float] | None:
    """Single most significant persistent level shift, or None.

    The break is LOCATED by least squares - the reduction in within-segment
    sum of squares from splitting at t - because that has a single sharp
    maximum at a true step. A median-based search scores many nearby positions
    identically and then picks arbitrarily among them.

    It is then MEASURED robustly, with medians and a MAD scale, so that a
    couple of outliers cannot inflate the size of the shift.

    Returns (index position, score, shift in logs).
    """
    n = len(logs)
    if n < 2 * MIN_SEGMENT + MIN_PERSIST:
        return None
    scale = _robust_scale(logs)
    if not np.isfinite(scale):
        return None

    x = logs.to_numpy()
    total_sse = float(((x - x.mean()) ** 2).sum())

    best = None
    for t in range(MIN_SEGMENT, n - MIN_SEGMENT):
        if covid_mask.iloc[t]:
            continue                      # COVID was a shock, not a reclassification
        before, after = x[:t], x[t:]
        sse = float(((before - before.mean()) ** 2).sum()
                    + ((after - after.mean()) ** 2).sum())
        gain = total_sse - sse            # unique maximum at a true step
        if best is None or gain > best[0]:
            best = (gain, t)
    if best is None:
        return None
    t = best[1]

    # --- measure the shift robustly at the located point ---
    pre = logs.iloc[max(0, t - 24):t]
    post = logs.iloc[t:t + 24]
    if len(pre) < MIN_SEGMENT or len(post) < MIN_SEGMENT:
        return None
    shift = post.median() - pre.median()
    if abs(shift) < MIN_SHIFT_LOG:
        return None

    # Persistence: the new level must still hold at the end of the series,
    # otherwise this is a shock that recovered, not a break.
    tail = logs.iloc[max(t, n - MIN_PERSIST):]
    if len(tail) and abs(tail.median() - post.median()) > MIN_SHIFT_LOG:
        return None

    score = abs(shift) / scale
    return (t, score, shift) if score >= MIN_SCORE else None


def detect_breaks(series: pd.Series, max_breaks: int = 3) -> list[dict]:
    """Binary segmentation for persistent level shifts."""
    s = series.dropna()
    s = s[s > 0]
    if len(s) < 2 * MIN_SEGMENT + MIN_PERSIST:
        return []
    logs = np.log(s)
    covid = (s.index >= pd.Timestamp(cfg.COVID_START)) & \
            (s.index <= pd.Timestamp(cfg.COVID_END))
    covid = pd.Series(covid, index=s.index)

    found: list[dict] = []
    segments = [(0, len(logs))]
    while segments and len(found) < max_breaks:
        lo, hi = segments.pop(0)
        window, mask = logs.iloc[lo:hi], covid.iloc[lo:hi]
        hit = _best_break(window, mask)
        if hit is None:
            continue
        pos, score, shift = hit
        abs_pos = lo + pos
        found.append({
            "break_month": logs.index[abs_pos],
            "score": round(float(score), 2),
            "shift_log": round(float(shift), 4),
            "level_change_pct": round(float(np.exp(shift) - 1), 4),
            "pre_level": float(np.exp(window.iloc[max(0, pos - 24):pos].median())),
            "post_level": float(np.exp(window.iloc[pos:pos + 24].median())),
            "detected_by": "level_shift",
        })
        segments += [(lo, abs_pos), (abs_pos, hi)]
    return sorted(found, key=lambda d: d["break_month"])


def adjust(series: pd.Series, period: int = 12) -> pd.DataFrame:
    """STL decomposition. Returns trend, seasonal, resid, and the SA series."""
    s = series.astype(float)
    # STL cannot take gaps; interpolate internally but never write the filled
    # values back - suppressed months stay gaps in everything user-facing.
    filled = s.interpolate(limit_direction="both")
    if filled.isna().all() or len(filled) < 2 * period:
        nan = pd.Series(np.nan, index=s.index)
        return pd.DataFrame({"trend": nan, "seasonal": nan, "resid": nan, "sa": nan})
    res = STL(filled, period=period, robust=True).fit()
    sa = filled - res.seasonal
    out = pd.DataFrame({"trend": res.trend, "seasonal": res.seasonal,
                        "resid": res.resid, "sa": sa})
    return out.mask(s.isna())          # restore the gaps


def _continuity_factors(series: pd.Series, breaks: list[dict]) -> pd.Series:
    """Multiplicative factor bringing each segment onto the latest one's level.

    Reported levels are never altered. This is applied only when a chart is
    explicitly asked for a continuous view, because back-adjusting means
    choosing whether to rewrite the past or misstate the present - a
    presentation choice, not a measurement one.
    """
    factor = pd.Series(1.0, index=series.index)
    if not breaks:
        return factor
    edges = [series.index[0]] + [b["break_month"] for b in breaks] + \
            [series.index[-1] + pd.offsets.MonthBegin(1)]
    medians, spans = [], []
    for lo, hi in zip(edges[:-1], edges[1:]):
        seg = series[(series.index >= lo) & (series.index < hi)].dropna()
        spans.append((lo, hi))
        medians.append(seg.median() if len(seg) else np.nan)
    latest = medians[-1]
    if not np.isfinite(latest) or latest == 0:
        return factor
    for (lo, hi), med in zip(spans, medians):
        if np.isfinite(med) and med > 0:
            factor[(factor.index >= lo) & (factor.index < hi)] = latest / med
    return factor


CO_OCCUR_WINDOW_MONTHS = 2
CO_OCCUR_THRESHOLD = 3


def _classify(breaks: pd.DataFrame) -> pd.DataFrame:
    """Separate breaks that look macro from breaks that look idiosyncratic.

    A level-shift test finds PERSISTENT SHIFTS. It cannot see cause, so it
    finds genuine economic regime changes alongside data artefacts - the COVID
    collapse and recovery in travel and hospitality are real, and correctly
    detected, but they are not reclassifications.

    The cheapest discriminator available: a macro event moves many industries
    at once, a reclassification moves one. This is a triage aid, not a verdict;
    every break stays status='auto' until a human confirms or dismisses it.
    """
    out = breaks.copy()
    months = pd.to_datetime(out.break_month)
    co = []
    for i, m in enumerate(months):
        near = (months - m).abs() <= pd.Timedelta(days=31 * CO_OCCUR_WINDOW_MONTHS)
        same_dir = np.sign(out.shift_log) == np.sign(out.shift_log.iloc[i])
        co.append(int((near & same_dir).sum()) - 1)
    out["co_occurring"] = co
    out["likely"] = np.where(out.co_occurring >= CO_OCCUR_THRESHOLD,
                             "macro (many industries moved together)",
                             "idiosyncratic (this industry alone)")
    return out


def build(panel: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Condition the national panel. Returns (augmented panel, break register)."""
    out, registry = [], []
    for sic2, grp in panel.groupby("sic2", observed=True):
        grp = grp.sort_values("month").set_index("month")
        if grp.inflow.mean() < MIN_MONTHLY_VALUE:
            # Too small to condition meaningfully; pass through untouched.
            out.append(grp.reset_index())
            continue

        breaks = detect_breaks(grp.inflow)
        for b in breaks:
            registry.append({"sic2": sic2, "industry": grp["name"].iloc[0],
                             "section": grp["section"].iloc[0], **b,
                             "status": "auto"})

        for m in MEASURES:
            dec = adjust(grp[m])
            grp[f"{m}_sa"] = dec.sa
            if m == "inflow":
                grp["inflow_trend"] = dec.trend
                grp["expected"] = dec.trend + dec.seasonal
                grp["residual"] = dec.resid

        # Baselines are estimated on the post-break segment only.
        last_break = breaks[-1]["break_month"] if breaks else None
        grp["segment_start"] = last_break if last_break is not None else grp.index[0]
        grp["break_flag"] = False
        for b in breaks:
            grp.loc[grp.index == b["break_month"], "break_flag"] = True
        grp["continuity_factor"] = _continuity_factors(grp.inflow, breaks)
        out.append(grp.reset_index())

    panel_out = pd.concat(out, ignore_index=True)
    breaks_df = pd.DataFrame(registry)
    if len(breaks_df):
        breaks_df = _classify(breaks_df)
        breaks_df = breaks_df.sort_values(["score"], ascending=False).reset_index(drop=True)
        log.info("break register: %d breaks across %d industries",
                 len(breaks_df), breaks_df.sic2.nunique())
    else:
        log.info("break register: none detected")
        breaks_df = pd.DataFrame(columns=[
            "sic2", "industry", "section", "break_month", "score", "shift_log",
            "level_change_pct", "pre_level", "post_level", "detected_by", "status",
            "co_occurring", "likely"])
    return panel_out, breaks_df
