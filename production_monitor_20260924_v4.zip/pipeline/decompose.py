"""Three-way change attribution: why did an industry move?

A naive decomposition differences the counterparties present in both months.
Tested against real data, that silently fails:

    SIC 29, June 2026 vs June 2025. Actual change -£178m.
    Matched counterparties explain -£1m. 99% of the move is invisible.

The missing £177m was one cell - payments from SIC 84 Public administration -
which ran at £81-186m for six months and then vanished from the data. The same
pattern drives SIC 19, where £313m of a £342m year-on-year inflow fall is a
single retail counterparty that disappears and then returns. (Measured on the
delivery of 16 July 2026; the user-facing copy is recomputed at render time by
app_pages.method.suppression_case().)

So every change splits into three exhaustive parts that sum to the actual
change with zero residual:

    continuing        present in both months          contribution = delta
    newly_present     absent before, present now      contribution = +value
    absent_suppressed present before, gone now        contribution = -value

The last two are DATA-PRESENCE effects, not economic ones, and are always
labelled as such.
"""
from __future__ import annotations

import logging

import pandas as pd

from . import config as cfg

log = logging.getLogger(__name__)

CONTINUING = "continuing"
NEWLY_PRESENT = "newly_present"
ABSENT = "absent_suppressed"


class EdgeIndex:
    """Edges grouped by month, so a decomposition slices instead of scanning.

    Filtering the full table per call costs 169 ms against 4 ms from a month
    index. Across the enrichment pass that is twelve minutes against twenty
    seconds, which is the difference between enriching the rows a user actually
    looks at and enriching an arbitrary global top-N.
    """

    __slots__ = ("_by_month", "_empty", "_filter", "_cache")

    def __init__(self, edges: pd.DataFrame):
        self._by_month = {m: g for m, g in edges.groupby("month", observed=True)}
        self._empty = edges.iloc[:0]
        self._filter = None
        self._cache: dict = {}

    def month(self, m: pd.Timestamp) -> pd.DataFrame:
        m = pd.Timestamp(m)
        if self._filter is None:
            return self._by_month.get(m, self._empty)
        if m not in self._cache:
            self._cache[m] = self._filter(self._by_month.get(m, self._empty))
        return self._cache[m]

    def filtered(self, mask_fn) -> "EdgeIndex":
        """A view with a row filter, applied lazily and memoised per month.

        A decomposition touches two months out of ninety. Filtering eagerly
        rebuilt the whole index on every call and dominated the runtime.
        """
        out = EdgeIndex.__new__(EdgeIndex)
        out._by_month = self._by_month
        out._empty = self._empty
        out._filter = mask_fn
        out._cache = {}
        return out

    @property
    def months(self):
        return self._by_month.keys()


def as_index(edges) -> EdgeIndex:
    """Accept either a DataFrame or an already-built index."""
    return edges if isinstance(edges, EdgeIndex) else EdgeIndex(edges)


def _counterparties(edges, code: str, month: pd.Timestamp,
                    side: str) -> pd.Series:
    """Value by counterparty for one industry-month.

    side='in'  -> who paid this industry (decomposing inflow)
    side='out' -> who this industry paid (decomposing outflow)
    """
    own, other = ("payee", "payer") if side == "in" else ("payer", "payee")
    frame = as_index(edges).month(month)
    sel = frame[frame[own] == code]
    return sel.set_index(other).value


def decompose(edges, code: str,
              month: pd.Timestamp, base_month: pd.Timestamp,
              side: str = "in") -> pd.DataFrame:
    """Attribute the change between two months to counterparties.

    Returns one row per counterparty with its contribution and category.
    The contributions sum exactly to the actual change.
    """
    edges = as_index(edges)
    now = _counterparties(edges, code, pd.Timestamp(month), side)
    base = _counterparties(edges, code, pd.Timestamp(base_month), side)
    idx = now.index.union(base.index)
    now, base = now.reindex(idx), base.reindex(idx)

    both = now.notna() & base.notna()
    only_now = now.notna() & base.isna()
    only_base = now.isna() & base.notna()

    rows = pd.concat([
        pd.DataFrame({"counterparty": idx[both],
                      "contribution": (now[both] - base[both]).to_numpy(),
                      "category": CONTINUING,
                      "value_now": now[both].to_numpy(),
                      "value_base": base[both].to_numpy()}),
        pd.DataFrame({"counterparty": idx[only_now],
                      "contribution": now[only_now].to_numpy(),
                      "category": NEWLY_PRESENT,
                      "value_now": now[only_now].to_numpy(),
                      "value_base": float("nan")}),
        pd.DataFrame({"counterparty": idx[only_base],
                      "contribution": -base[only_base].to_numpy(),
                      "category": ABSENT,
                      "value_now": float("nan"),
                      "value_base": base[only_base].to_numpy()}),
    ], ignore_index=True)

    rows["is_self"] = rows.counterparty == code
    rows["is_unclassified"] = rows.counterparty == cfg.UNCLASSIFIED_SIC
    return rows.sort_values("contribution", key=abs, ascending=False,
                            ignore_index=True)


def decompose_measure(edges, code: str,
                      month: pd.Timestamp, base_month: pd.Timestamp,
                      measure: str = "inflow",
                      include_unclassified: bool = True) -> pd.DataFrame:
    """Attribute a change in inflow, outflow or PFI to counterparties.

    PFI is inflow + outflow - self_flow, so a counterparty's contribution to it
    is its contribution on BOTH sides. Decomposing only the inflow side while
    the headline figure is PFI mixes two different quantities: an industry can
    be down £2.7bn on PFI while its largest inflow contributor is +£197m, and
    the resulting "63% of the move" is arithmetic on mismatched numerators.
    """
    src = as_index(edges)
    if not include_unclassified:
        # The classified measures exclude SIC 00 as a counterparty entirely, so
        # a decomposition that includes it cannot reconcile to them: for SIC 66
        # that gap is +£171m on inflows and -£45m on outflows. Both figures are
        # correct; they answer different questions, and mixing them silently
        # produced a "63% of the move" claim about the wrong denominator.
        src = src.filtered(lambda g: g[(g.payer != cfg.UNCLASSIFIED_SIC)
                                       & (g.payee != cfg.UNCLASSIFIED_SIC)])

    if measure in ("inflow", "outflow"):
        return decompose(src, code, month, base_month,
                         side="in" if measure == "inflow" else "out")

    ins = decompose(src, code, month, base_month, side="in")
    outs = decompose(src, code, month, base_month, side="out")
    both = pd.concat([ins, outs], ignore_index=True)
    if both.empty:
        return both

    agg = (both.groupby("counterparty", as_index=False)
               .agg(contribution=("contribution", "sum"),
                    value_now=("value_now", "sum"),
                    value_base=("value_base", "sum"),
                    category=("category", _dominant_category)))
    # The industry's own row appears on both sides; PFI counts self-flow once.
    self_mask = agg.counterparty == code
    agg.loc[self_mask, "contribution"] = agg.loc[self_mask, "contribution"] / 2.0

    agg["is_self"] = self_mask
    agg["is_unclassified"] = agg.counterparty == cfg.UNCLASSIFIED_SIC
    return agg.sort_values("contribution", key=abs, ascending=False,
                           ignore_index=True)


def _dominant_category(s: pd.Series) -> str:
    """When a counterparty differs across sides, the data-presence label wins."""
    vals = set(s)
    for c in (ABSENT, NEWLY_PRESENT):
        if c in vals:
            return c
    return CONTINUING


def summarise(rows: pd.DataFrame) -> dict:
    """Headline figures for one decomposition."""
    total = float(rows.contribution.sum())
    by_cat = rows.groupby("category").contribution.sum()
    presence = float(by_cat.get(NEWLY_PRESENT, 0.0) + by_cat.get(ABSENT, 0.0))
    top = rows.iloc[0] if len(rows) else None
    return {
        "total_change": total,
        "continuing": float(by_cat.get(CONTINUING, 0.0)),
        "newly_present": float(by_cat.get(NEWLY_PRESENT, 0.0)),
        "absent_suppressed": float(by_cat.get(ABSENT, 0.0)),
        # Share of the move that comes from cells appearing or disappearing
        # rather than changing. This is the presence flag (BUILD_SPEC 6.7).
        "presence_share": abs(presence) / abs(total) if total else 0.0,
        "top_counterparty": None if top is None else str(top.counterparty),
        "top_contribution": None if top is None else float(top.contribution),
        "top_category": None if top is None else str(top.category),
        "n_counterparties": int(len(rows)),
    }


def _sic00_shift(edges, code: str, month: pd.Timestamp,
                 base: pd.Timestamp, window: int = 5) -> float:
    """Change in the share of an industry's inflow arriving from SIC 00.

    A counterparty reclassification moves money between SIC 00 and a real
    industry while leaving the total untouched. That is what happened to SIC 85
    Education: classified inflow fell 58% and inflow from SIC 00 rose 218%,
    but total money in rose 6% - the payments never stopped, their payers
    simply stopped being classified.

    A level-shift test cannot see this. The share can.
    """
    idx = as_index(edges)

    def share(centre: pd.Timestamp) -> float:
        months = pd.date_range(centre - pd.DateOffset(months=window // 2),
                               centre + pd.DateOffset(months=window // 2),
                               freq="MS")
        parts = [idx.month(m) for m in months]
        sel = pd.concat([p[p.payee == code] for p in parts if len(p)]) \
            if any(len(p) for p in parts) else idx.month(centre).iloc[:0]
        total = sel.value.sum()
        if not total:
            return float("nan")
        return sel.loc[sel.payer == cfg.UNCLASSIFIED_SIC, "value"].sum() / total

    return float(share(month) - share(base))


def build_table(alerts: pd.DataFrame, edges,
                top_n: int = 200, max_rows: int = 20) -> pd.DataFrame:
    """Pre-compute decompositions for the alerts a user will actually open.

    A full decomposition for every scored row would be 21,000 alerts x 88
    counterparties. Only the highest-severity rows are materialised; the app
    computes anything else on demand, which is fast enough locally.
    """
    if alerts.empty:
        return pd.DataFrame(columns=[
            "month", "code", "measure", "basis", "counterparty",
            "contribution_gbp", "category", "is_self", "is_unclassified"])

    edges = as_index(edges)
    out = []
    for r in alerts.nlargest(top_n, "severity").itertuples():
        lag = 1 if r.basis == "MoM" else 12
        base = r.month - pd.DateOffset(months=lag)
        rows = decompose(edges, r.code, r.month, base, side="in")
        if rows.empty:
            continue
        # Keep the largest contributors plus everything structurally pinned,
        # so the self and unclassified bars are never dropped by a top-N cut.
        pinned = rows[rows.is_self | rows.is_unclassified]
        head = rows.head(max_rows)
        keep = pd.concat([head, pinned]).drop_duplicates(subset="counterparty")
        out.append(keep.assign(month=r.month, code=r.code,
                               measure=r.measure, basis=r.basis))
    if not out:
        return pd.DataFrame()
    table = pd.concat(out, ignore_index=True)
    return table.rename(columns={"contribution": "contribution_gbp"})[
        ["month", "code", "measure", "basis", "counterparty",
         "contribution_gbp", "category", "is_self", "is_unclassified",
         "value_now", "value_base"]]


def classify_break(edges, code: str,
                   break_month: pd.Timestamp) -> dict:
    """Why did this break happen: economics, a cell going dark, or relabelling?

    Three causes are separated, because they need completely different
    treatment and a level-shift test cannot tell them apart:

      suppression-driven  counterparties stopped being reported
      reclassification    counterparties were relabelled to/from SIC 00
      level shift         everything else, including genuine economic change
    """
    break_month = pd.Timestamp(break_month)
    base = break_month - pd.DateOffset(years=1)
    if base < edges.month.min():
        base = break_month - pd.DateOffset(months=1)
    rows = decompose(edges, code, break_month, base, side="in")
    s = summarise(rows)
    s["sic00_share_shift"] = _sic00_shift(edges, code, break_month, base)

    if s["presence_share"] >= 0.5:
        cause = "suppression-driven"
    elif abs(s["sic00_share_shift"]) >= 0.20:
        cause = "reclassification"
    else:
        cause = "level shift"
    s["break_cause"] = cause
    return s
