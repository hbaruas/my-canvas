"""Read a delivery and normalise it to one long edge table.

Files are identified by inspecting their structure, never by filename:
deliveries arrive as 2607_sic5.csv, industrybusinesspaymentssic2dataset16072026.xlsx,
2607_sic2region_2025_2026.csv and the naming is not stable between releases.

Enforces the five parsing rules in BUILD_SPEC 5.1. Each of them is a silent
failure if skipped - none of them raises an error when done wrong.
"""
from __future__ import annotations

import logging
import re
from datetime import datetime
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

from . import config as cfg

log = logging.getLogger(__name__)

# Columns of the normalised long table every source is mapped onto.
EDGE_COLUMNS = [
    "payer", "payee", "payer_region", "payee_region",
    "month", "value", "n_tx", "suppressed_type", "grain",
]


@dataclass(frozen=True)
class Source:
    """One identified input file."""
    path: Path
    kind: str          # sic2 | sic2_region | sic5 | lookup
    detail: str = ""

    def __str__(self) -> str:
        mb = self.path.stat().st_size / 1e6
        return f"{self.kind:<12} {self.path.name}  ({mb:,.0f} MB)"


# ----------------------------------------------------------------------
# file identification
# ----------------------------------------------------------------------
def identify(path: Path) -> Source | None:
    """Work out what a file is by looking inside it."""
    suffix = path.suffix.lower()

    if suffix in {".xlsx", ".xlsm"}:
        try:
            names = pd.ExcelFile(path).sheet_names
        except Exception as exc:                      # pragma: no cover
            log.warning("could not open %s: %s", path.name, exc)
            return None
        combined = [n for n in names if re.fullmatch(r"SIC2_\d{4}_\d{4}", n)]
        if combined:
            return Source(path, "sic2", detail=combined[0])
        yearly = [n for n in names if re.fullmatch(r"SIC2_\d{4}", n)]
        if yearly:
            return Source(path, "sic2", detail=",".join(sorted(yearly)))
        return None

    if suffix == ".csv":
        header = pd.read_csv(path, nrows=0).columns.str.lower().tolist()
        if any("5_digit" in c for c in header):
            return Source(path, "sic5")
        if any("region" in c for c in header):
            return Source(path, "sic2_region")
        if any("2_digit" in c for c in header):
            return Source(path, "sic2")
    return None


def discover(*, include_sic5: bool = False) -> list[Source]:
    """Find inputs in Data/incoming, falling back to the Data root.

    The fallback exists because the first delivery was dropped straight into
    Data/ before incoming/ existed.
    """
    seen: dict[Path, Source] = {}
    for folder in (cfg.INCOMING, cfg.DATA):
        if not folder.exists():
            continue
        for path in sorted(folder.iterdir()):
            if not path.is_file() or path.name.startswith("~$"):
                continue
            src = identify(path)
            if src is None:
                continue
            if src.kind == "sic5" and not include_sic5:
                log.info("skipping %s (SIC5 not requested)", path.name)
                continue
            # A file found in incoming/ wins over the same kind in Data/.
            if src.kind not in {s.kind for s in seen.values()}:
                seen[path] = src
    return list(seen.values())


# ----------------------------------------------------------------------
# parsing helpers - the five rules
# ----------------------------------------------------------------------
def _split_suppressed(raw: pd.Series) -> tuple[pd.Series, pd.Series]:
    """Rule 1: [c] and [-] become NULL, never zero, and we keep which was which."""
    as_text = raw.astype(str).str.strip()
    kind = as_text.map(cfg.SUPPRESSION_TOKENS)
    numeric = pd.to_numeric(raw, errors="coerce")
    # Anything non-numeric that is not a known token is also null, but flagged
    # so it shows up in the quality report rather than passing silently.
    unknown = numeric.isna() & kind.isna() & as_text.ne("") & as_text.ne("nan")
    if unknown.any():
        log.warning("%d values were neither numeric nor a known suppression token: %s",
                    int(unknown.sum()), sorted(as_text[unknown].unique())[:5])
        kind = kind.mask(unknown, "unparsed")
    return numeric, kind


def _pad_sic(s: pd.Series, width: int) -> pd.Series:
    """Rule 2: SIC codes are zero-padded strings.

    The lookup sheet mixes types - '00' and '01' arrive as text but 97, 98, 99
    arrive as integers. Unpadded codes fail to join with no error at all.
    """
    return (s.astype(str)
             .str.strip()
             .str.replace(r"\.0$", "", regex=True)
             .str.zfill(width))


def _aggregate_repeats(df: pd.DataFrame, keys: list[str]) -> pd.DataFrame:
    """Combine rows that share a key by SUMMING them, not by discarding them.

    The two files repeat keys for different reasons, and only one of them is a
    duplicate:

    * The SIC2 workbook repeats a key when a cell carries both markers - once
      [c] and once [-]. Both are null, so summing gives null and one row, which
      is what we want.

    * The regional file repeats keys far more heavily - 90,344 rows across
      34,246 keys, in groups of up to nine - and those rows carry DIFFERENT
      real values. They are separate records reported at a finer grain than the
      columns expose, not duplicates. Keeping one and dropping the rest loses
      £3.39tn of £6.5tn.

    Summing is correct for both. min_count=1 keeps an all-null group null
    rather than turning it into a zero.
    """
    repeated = df.duplicated(subset=keys, keep=False)
    if not repeated.any():
        return df

    n_rows = int(repeated.sum())
    n_keys = int(df[repeated].groupby(keys, sort=False).ngroups)
    log.info("%d rows share %d keys; summing them (groups of up to %d)",
             n_rows, n_keys,
             int(df[repeated].groupby(keys, sort=False).size().max()))

    other = [c for c in df.columns if c not in keys]
    agg = {c: "first" for c in other}
    agg["value"] = lambda s: s.sum(min_count=1)
    agg["n_tx"] = lambda s: s.sum(min_count=1)
    # If any part of a group was suppressed, say so on the combined row.
    agg["suppressed_type"] = lambda s: next(
        (v for v in s if isinstance(v, str)), None)

    out = (df.groupby(keys, sort=False, dropna=False)
             .agg(agg)
             .reset_index())
    return out[df.columns]


MONTH_NAME = re.compile(r"^[A-Za-z]+\s+\d{4}$")
DAY_MON_YR = re.compile(r"^\d{1,2}-[A-Za-z]{3}-\d{2}$")


def _parse_month(s: pd.Series) -> pd.Series:
    """Normalise a date column to the first of its month.

    The column is not one type. The July 2026 workbook holds 667,356 rows as
    the text "January 2019" and 15,453 as real datetime cells - the same column,
    two types, split by when the row was written. Choosing a format from one
    sample row therefore works only while that sample happens to be text: a
    delivery that led with a datetime row would send every text date down the
    wrong parser.

    So each kind is handled explicitly and the result reassembled.
    """
    out = pd.Series(pd.NaT, index=s.index, dtype="datetime64[ns]")

    # Cells Excel already stored as dates need no parsing.
    already = pd.to_datetime(s, errors="coerce",
                             format="mixed", dayfirst=False) \
        if s.map(lambda v: isinstance(v, (pd.Timestamp, datetime))).any() else None
    if already is not None:
        native = s.map(lambda v: isinstance(v, (pd.Timestamp, datetime)))
        out[native] = pd.to_datetime(s[native])

    text = s[out.isna()].astype(str).str.strip()
    if len(text):
        month_name = text.str.match(MONTH_NAME)
        if month_name.any():
            out.loc[text[month_name].index] = pd.to_datetime(
                text[month_name], format="%B %Y")
        day_first = text.str.match(DAY_MON_YR)
        if day_first.any():
            out.loc[text[day_first].index] = pd.to_datetime(
                text[day_first], format="%d-%b-%y")
        unparsed = text[~month_name & ~day_first]
        if len(unparsed):
            raise ValueError(
                f"{len(unparsed)} dates in an unrecognised format, e.g. "
                f"{sorted(set(unparsed))[:3]}"
            )

    if out.isna().any():
        raise ValueError(f"{int(out.isna().sum())} dates could not be parsed")
    return out.dt.to_period("M").dt.to_timestamp()


# ----------------------------------------------------------------------
# readers
# ----------------------------------------------------------------------
def read_release_date(src: Source) -> pd.Timestamp | None:
    """The delivery's release date, from the workbook cover sheet.

    This is the vintage key. Falling back to the file mtime would make two
    copies of the same delivery look like different vintages.
    """
    try:
        cover = pd.read_excel(src.path, sheet_name="Cover sheet", header=None)
    except Exception:                                  # pragma: no cover
        return None
    for _, row in cover.iterrows():
        label = str(row.iloc[0]).strip().lower()
        if label.startswith("released"):
            val = row.iloc[1] if len(row) > 1 else None
            ts = pd.to_datetime(val, errors="coerce")
            if pd.notna(ts):
                return ts
    return None


def read_lookup(src: Source) -> pd.DataFrame:
    """Rule 5: keep_default_na=False, or SIC 00's 'N/A' section becomes NaN
    and Unclassified silently vanishes from every section aggregation."""
    df = pd.read_excel(src.path, sheet_name="SIC2 Lookup", skiprows=5,
                       keep_default_na=False)
    df.columns = ["sic2", "division", "section", "section_desc"]
    df = df[df.sic2.astype(str).str.strip().ne("")].copy()
    df["sic2"] = _pad_sic(df.sic2, 2)
    for c in ("division", "section", "section_desc"):
        df[c] = df[c].astype(str).str.strip()
    # Normalise the "N/A" section code before it can round-trip through a CSV
    # and come back as a missing value (see config.UNCLASSIFIED_SECTION).
    df["section"] = df.section.replace(cfg.UNCLASSIFIED_SECTION_RAW,
                                       cfg.UNCLASSIFIED_SECTION)
    df["gdp_grouping"] = df.section.map(cfg.GDP_GROUPING).fillna("Unclassified")

    n_sections = df.section.nunique()
    if n_sections < 22:
        raise ValueError(
            f"lookup has only {n_sections} sections, expected 22. "
            "This usually means keep_default_na swallowed SIC 00's 'N/A'."
        )
    log.info("lookup: %d divisions, %d sections", len(df), n_sections)
    return df


def read_sic2(src: Source) -> pd.DataFrame:
    """The combined SIC2_YYYY_YYYY sheet: payer x payee x month."""
    df = pd.read_excel(src.path, sheet_name=src.detail, skiprows=8,
                       dtype={0: str, 1: str})
    df.columns = ["payer", "payee", "date", "value", "n_tx"]
    out = pd.DataFrame({
        "payer": _pad_sic(df.payer, 2),
        "payee": _pad_sic(df.payee, 2),
        "payer_region": pd.NA,
        "payee_region": pd.NA,
        "month": _parse_month(df.date),
    })
    out["value"], kind = _split_suppressed(df.value)
    out["n_tx"] = pd.to_numeric(df.n_tx, errors="coerce")
    out["suppressed_type"] = kind
    out["grain"] = cfg.LEVEL_SIC2
    return _aggregate_repeats(out[EDGE_COLUMNS], ["payer", "payee", "month"])


def read_sic2_region(src: Source) -> pd.DataFrame:
    """Regional file: adds payer_region / payee_region (TLC-TLN plus 'unknown')."""
    df = pd.read_csv(src.path, dtype=str)
    df.columns = ["payer", "payer_region", "payee", "payee_region",
                  "date", "value", "n_tx"]
    out = pd.DataFrame({
        "payer": _pad_sic(df.payer, 2),
        "payee": _pad_sic(df.payee, 2),
        # Rule 3: 'unknown' is a category, not a missing value.
        "payer_region": df.payer_region.astype(str).str.strip(),
        "payee_region": df.payee_region.astype(str).str.strip(),
        "month": _parse_month(df.date),
    })
    out["value"], kind = _split_suppressed(df.value)
    out["n_tx"] = pd.to_numeric(df.n_tx, errors="coerce")
    out["suppressed_type"] = kind
    out["grain"] = cfg.LEVEL_SIC2_REGION
    return _aggregate_repeats(
        out[EDGE_COLUMNS],
        ["payer", "payer_region", "payee", "payee_region", "month"])


def read_sic5(src: Source) -> pd.DataFrame:
    """SIC5 file. Written for Phase 2; not read by default (BUILD_SPEC 10)."""
    frames = []
    for chunk in pd.read_csv(src.path, dtype=str, chunksize=2_000_000):
        chunk.columns = ["payer", "payee", "date", "value", "n_tx"]
        part = pd.DataFrame({
            "payer": _pad_sic(chunk.payer, 5),
            "payee": _pad_sic(chunk.payee, 5),
            "payer_region": pd.NA,
            "payee_region": pd.NA,
            "month": _parse_month(chunk.date),
        })
        part["value"], kind = _split_suppressed(chunk.value)
        part["n_tx"] = pd.to_numeric(chunk.n_tx, errors="coerce")
        part["suppressed_type"] = kind
        part["grain"] = cfg.LEVEL_SIC5
        frames.append(part[EDGE_COLUMNS])
    return pd.concat(frames, ignore_index=True)


def read_sic2_yearly(src: Source) -> pd.DataFrame | None:
    """The per-year sheets (SIC2_2019 ... SIC2_2026), stacked.

    The workbook carries the same data twice: once per year, and once combined
    in SIC2_2019_2026. They are not identical. The yearly sheets hold the full
    89 x 89 grid every month, including pairs with no data; the combined sheet
    omits those. That part is benign. But in the July 2026 release 78 cells are
    PUBLISHED in the combined sheet and WITHHELD as [c] in the yearly one -
    £299.6m, 75 of them in April 2026. The two sheets therefore need
    reconciling rather than one being assumed to be the other.
    """
    try:
        names = pd.ExcelFile(src.path).sheet_names
    except Exception:                                   # pragma: no cover
        return None
    yearly = sorted(n for n in names if re.fullmatch(r"SIC2_\d{4}", n))
    if not yearly:
        return None
    frames = []
    for name in yearly:
        df = pd.read_excel(src.path, sheet_name=name, skiprows=8,
                           dtype={0: str, 1: str}, usecols=range(5))
        df.columns = ["payer", "payee", "date", "value", "n_tx"]
        df = df.dropna(subset=["payer"])
        part = pd.DataFrame({
            "payer": _pad_sic(df.payer, 2),
            "payee": _pad_sic(df.payee, 2),
            "month": _parse_month(df.date),
        })
        part["value"], part["suppressed_type"] = _split_suppressed(df.value)
        part["n_tx"] = pd.to_numeric(df.n_tx, errors="coerce")
        part["sheet"] = name
        frames.append(part)
    return pd.concat(frames, ignore_index=True)


def cross_check_sheets(combined: pd.DataFrame,
                       yearly: pd.DataFrame | None) -> pd.DataFrame:
    """Cells on which the combined and yearly sheets disagree.

    Returns one row per disagreeing payer-payee-month, with each sheet's
    reading. An empty frame means the two agree completely.
    """
    cols = ["payer", "payee", "month", "combined_value", "yearly_value",
            "combined_state", "yearly_state", "yearly_sheet", "kind"]
    if yearly is None or yearly.empty:
        return pd.DataFrame(columns=cols)

    keys = ["payer", "payee", "month"]
    c = (combined.groupby(keys, observed=True)
                 .agg(combined_value=("value", lambda s: s.sum(min_count=1)),
                      combined_state=("suppressed_type",
                                      lambda s: next((v for v in s if isinstance(v, str)), None)))
                 .reset_index())
    y = (yearly.groupby(keys, observed=True)
               .agg(yearly_value=("value", lambda s: s.sum(min_count=1)),
                    yearly_state=("suppressed_type",
                                  lambda s: next((v for v in s if isinstance(v, str)), None)),
                    yearly_sheet=("sheet", "first"))
               .reset_index())
    m = c.merge(y, on=keys, how="left")

    has_c, has_y = m.combined_value.notna(), m.yearly_value.notna()
    published_only_combined = has_c & ~has_y
    published_only_yearly = ~has_c & has_y
    different = has_c & has_y & ((m.combined_value - m.yearly_value).abs() > 0.5)

    out = m[published_only_combined | published_only_yearly | different].copy()
    out["kind"] = np.select(
        [published_only_combined.loc[out.index],
         published_only_yearly.loc[out.index]],
        ["published in combined, withheld in yearly",
         "withheld in combined, published in yearly"],
        default="different values")
    return out[cols].reset_index(drop=True)


def apply_stricter_suppression(combined: pd.DataFrame,
                                disagreements: pd.DataFrame) -> pd.DataFrame:
    """Withhold any cell that either copy of the data withholds.

    Decision taken with the project owner: where the combined sheet publishes
    a value that the yearly sheet suppresses, the cell is treated as
    suppressed. The tool never builds on a figure that ONS withheld elsewhere
    in the same release - which matters for anything exported.
    """
    if disagreements is None or disagreements.empty:
        return combined
    withheld = disagreements[
        disagreements.kind == "published in combined, withheld in yearly"]
    if withheld.empty:
        return combined
    keys = set(zip(withheld.payer, withheld.payee, pd.to_datetime(withheld.month)))
    hit = pd.Series([k in keys for k in zip(combined.payer, combined.payee,
                                            combined.month)],
                    index=combined.index)
    out = combined.copy()
    out.loc[hit, "value"] = np.nan
    out.loc[hit, "n_tx"] = np.nan
    out.loc[hit, "suppressed_type"] = "withheld_in_yearly_sheet"
    log.warning("withheld %d cells published only in the combined sheet "
                "(£%.1fm)", int(hit.sum()),
                withheld.combined_value.fillna(0).sum() / 1e6)
    return out


_READERS = {
    "sic2": read_sic2,
    "sic2_region": read_sic2_region,
    "sic5": read_sic5,
}


def load(sources: list[Source]) -> tuple[dict[str, pd.DataFrame], pd.DataFrame,
                                         "pd.Timestamp | None"]:
    """Read every identified source. Returns (edges by grain, lookup, release date)."""
    lookup_src = next((s for s in sources if s.kind == "sic2"), None)
    if lookup_src is None:
        raise FileNotFoundError(
            "No SIC2 workbook found. The lookup sheet lives inside it and "
            "everything else depends on it."
        )
    lookup = read_lookup(lookup_src)
    release = read_release_date(lookup_src)
    log.info("delivery released %s",
             release.date() if release is not None else "unknown")

    edges: dict[str, pd.DataFrame] = {}
    for src in sources:
        reader = _READERS.get(src.kind)
        if reader is None:
            continue
        log.info("reading %s", src)
        df = reader(src)
        edges[df.grain.iloc[0]] = df
        log.info("  -> %s rows, %s to %s", f"{len(df):,}",
                 df.month.min().date(), df.month.max().date())
    return edges, lookup, release
