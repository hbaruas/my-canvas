"""Independent reconciliation of the outputs against the raw delivery.

    python -m pipeline.audit

This is the check that the pipeline has not quietly produced wrong numbers.
The existing test suite verifies the pipeline against itself and against
synthetic fixtures, so a fault in shared code would cancel out on both sides.
Everything here therefore recomputes from the **original workbook** using a
deliberately different route - openpyxl row by row, plain Python arithmetic,
no pipeline imports beyond file locations - and compares.

Three kinds of check:

  RECONCILE   a figure recomputed from the raw file matches the output
  INVARIANT   an identity that must hold whatever the data says
  HYGIENE     signatures of silent failure: infinities, nulls that should not
              be null, codes that changed type, values outside possible bounds
"""
from __future__ import annotations

import argparse
import math
import sys
from collections import Counter, defaultdict
from datetime import datetime

import numpy as np
import pandas as pd
from openpyxl import load_workbook

from . import config as cfg

# Every figure here is a sum of values the provider rounded to the nearest
# £1,000, so a correct pipeline reproduces them exactly. Float addition over
# 680,000 terms loses a little precision, so allow a pound - not a fraction of
# the total, which on £1.9tn would have waved through a £198,000 discrepancy.
ABS_TOLERANCE = 1.0
REL_TOLERANCE = 1e-12


class Result:
    def __init__(self) -> None:
        self.rows: list[tuple[str, str, bool, str]] = []

    def add(self, kind: str, name: str, ok: bool, detail: str = "") -> None:
        self.rows.append((kind, name, ok, detail))

    def check(self, kind: str, name: str, got, want, note: str = "") -> None:
        if isinstance(got, float) and isinstance(want, float):
            gap = abs(got - want)
            ok = gap <= max(ABS_TOLERANCE,
                            abs(want) * REL_TOLERANCE)
        else:
            ok = got == want
        detail = f"raw={want:,.0f} output={got:,.0f}" if isinstance(want, float) \
            else f"raw={want} output={got}"
        self.add(kind, name, ok, f"{detail}{'  ' + note if note else ''}")

    @property
    def failed(self) -> list:
        return [r for r in self.rows if not r[2]]

    def report(self) -> int:
        width = max(len(r[1]) for r in self.rows) + 2
        current = None
        for kind, name, ok, detail in self.rows:
            if kind != current:
                print(f"\n{kind}")
                current = kind
            mark = "  ok  " if ok else "  FAIL"
            print(f"{mark}  {name:<{width}} {detail}")
        print("\n" + "-" * 66)
        n, f = len(self.rows), len(self.failed)
        print(f" {n - f} of {n} checks passed"
              + (f" - {f} FAILED" if f else " - no discrepancies found"))
        print("-" * 66)
        return 1 if f else 0


# ----------------------------------------------------------------------
# raw recomputation - openpyxl only, no pipeline parsing code
# ----------------------------------------------------------------------
MONTHS = {m: i for i, m in enumerate(
    ["january", "february", "march", "april", "may", "june", "july",
     "august", "september", "october", "november", "december"], start=1)}


def _normalise_month(value) -> str:
    """Reduce a date cell to 'YYYY-MM', however the workbook stored it.

    Deliberately hand-rolled rather than reusing the pipeline's parser: if that
    parser has a fault, a shared implementation would reproduce it on both
    sides and the comparison would agree on the wrong answer.

    The column genuinely mixes types - most rows are the text "January 2019",
    some are real Excel dates.
    """
    if isinstance(value, datetime):
        return f"{value.year:04d}-{value.month:02d}"
    text = str(value).strip()
    parts = text.split()
    if len(parts) == 2 and parts[0].lower() in MONTHS:
        return f"{int(parts[1]):04d}-{MONTHS[parts[0].lower()]:02d}"
    bits = text.split("-")
    if len(bits) == 3 and bits[1][:3].lower() in {m[:3] for m in MONTHS}:
        month = next(i for m, i in MONTHS.items() if m[:3] == bits[1][:3].lower())
        year = int(bits[2])
        return f"{2000 + year if year < 100 else year:04d}-{month:02d}"
    raise ValueError(f"unrecognised date cell: {value!r}")


def _withheld_in_yearly(path) -> set:
    """Keys the yearly sheets withhold, read with this module's own code."""
    wb = load_workbook(path, read_only=True, data_only=True)
    withheld = set()
    for name in wb.sheetnames:
        if not (name.startswith("SIC2_") and name.count("_") == 1):
            continue
        for row in wb[name].iter_rows(min_row=10, values_only=True):
            if row is None or row[0] is None:
                continue
            v = row[3]
            if not (isinstance(v, (int, float)) and not isinstance(v, bool)):
                withheld.add((str(row[0]).strip().zfill(2),
                              str(row[1]).strip().zfill(2),
                              _normalise_month(row[2])))
    wb.close()
    return withheld


def read_raw_workbook(path) -> dict:
    """Walk the source workbook cell by cell and total it independently.

    Applies the agreed rule - a cell withheld by EITHER copy of the data is
    treated as withheld - so that the comparison is against the same reading
    the pipeline is required to produce.
    """
    withheld = _withheld_in_yearly(path)
    wb = load_workbook(path, read_only=True, data_only=True)
    sheet = next(s for s in wb.sheetnames if s.startswith("SIC2_")
                 and s.count("_") == 2)
    ws = wb[sheet]

    totals = defaultdict(float)
    counts = defaultdict(int)
    by_month_value: dict[str, float] = defaultdict(float)
    by_payee: dict[str, float] = defaultdict(float)
    by_payer: dict[str, float] = defaultdict(float)
    # The strong check: every industry in every month, not just totals.
    cell_in: dict[tuple, float] = defaultdict(float)
    cell_out: dict[tuple, float] = defaultdict(float)
    cell_self: dict[tuple, float] = defaultdict(float)
    cell_from00: dict[tuple, float] = defaultdict(float)
    cell_tx_in: dict[tuple, float] = defaultdict(float)
    # Track distinct payer-payee-month KEYS, not rows: the workbook repeats a
    # key when a cell carries both [c] and [-], and those rows are summed into
    # one cell. Counting rows here would overstate by exactly the number of
    # repeated keys - 52 in May 2026.
    supp_keys: set[tuple] = set()
    codes: set[str] = set()
    months: set[str] = set()

    for i, row in enumerate(ws.iter_rows(min_row=10, values_only=True)):
        if row is None or row[0] is None:
            continue
        payer, payee, date, value, ntx = row[:5]
        payer = str(payer).strip().zfill(2)
        payee = str(payee).strip().zfill(2)
        codes.add(payer)
        codes.add(payee)
        month = _normalise_month(date)
        months.add(month)
        counts["rows"] += 1

        classified_pair = payer != "00" and payee != "00"
        numeric = isinstance(value, (int, float)) and not isinstance(value, bool)
        if numeric and (payer, payee, month) in withheld:
            numeric = False           # stricter wins
            counts["withheld_by_yearly"] += 1
        if not numeric:
            counts["suppressed"] += 1
            # The panel counts suppressed cells on the payee side of
            # classified pairs only, so count the same population here.
            if classified_pair:
                supp_keys.add((payer, payee, month))
            continue
        v = float(value)
        totals["value"] += v
        by_month_value[month] += v
        tx = float(ntx) if isinstance(ntx, (int, float)) \
            and not isinstance(ntx, bool) else 0.0
        totals["transactions"] += tx

        classified = classified_pair
        if classified:
            totals["classified_value"] += v
            totals["classified_transactions"] += tx
            by_payee[payee] += v
            by_payer[payer] += v
            counts["classified_rows"] += 1
        if payer == "00" and payee == "00":
            totals["both_unclassified"] += v
        elif payer == "00" or payee == "00":
            totals["one_unclassified"] += v
        if payer == payee and classified:
            totals["self_flow"] += v
            cell_self[(payee, month)] += v

        # per industry-month, both sides, on the classified basis
        if classified:
            cell_in[(payee, month)] += v
            cell_out[(payer, month)] += v
            cell_tx_in[(payee, month)] += tx
        if payer == "00" and payee != "00":
            cell_from00[(payee, month)] += v

    wb.close()
    return {"totals": dict(totals), "counts": dict(counts),
            "withheld_keys": withheld,
            "by_month_value": dict(by_month_value),
            "by_payee": dict(by_payee), "by_payer": dict(by_payer),
            "cell_in": dict(cell_in), "cell_out": dict(cell_out),
            "cell_self": dict(cell_self), "cell_from00": dict(cell_from00),
            "cell_tx_in": dict(cell_tx_in),
            "supp_by_month": Counter(m for _, _, m in supp_keys),
            "codes": codes, "months": months}


def read_raw_sheet_cells(path, sheet_filter) -> dict:
    """{(payer, payee, YYYY-MM): value-or-None} for the matching sheets."""
    wb = load_workbook(path, read_only=True, data_only=True)
    out: dict[tuple, list] = defaultdict(list)
    for name in wb.sheetnames:
        if not sheet_filter(name):
            continue
        for row in wb[name].iter_rows(min_row=10, values_only=True):
            if row is None or row[0] is None:
                continue
            key = (str(row[0]).strip().zfill(2), str(row[1]).strip().zfill(2),
                   _normalise_month(row[2]))
            v = row[3]
            out[key].append(float(v) if isinstance(v, (int, float))
                            and not isinstance(v, bool) else None)
    wb.close()
    return out


def read_raw_lookup(path) -> dict:
    """The division -> section map, straight from the workbook's own sheet."""
    wb = load_workbook(path, read_only=True, data_only=True)
    ws = wb["SIC2 Lookup"]
    out = {}
    for row in ws.iter_rows(min_row=7, values_only=True):
        if row is None or row[0] is None:
            continue
        code = str(row[0]).strip().zfill(2)
        section = str(row[2]).strip() if row[2] is not None else ""
        out[code] = section
    wb.close()
    return out


def read_raw_regional(path, limit_rows: int | None = None) -> dict:
    """Total the regional CSV with the csv module - no pandas, no pipeline."""
    import csv

    totals = defaultdict(float)
    counts = defaultdict(int)
    regions: set[str] = set()
    months: set[str] = set()
    cell_in: dict[tuple, float] = defaultdict(float)

    with open(path, newline="", encoding="utf-8") as fh:
        reader = csv.reader(fh)
        next(reader, None)                      # header
        for i, row in enumerate(reader):
            if limit_rows and i >= limit_rows:
                break
            payer, payer_reg, payee, payee_reg, date, value, ntx = row[:7]
            payer = payer.strip().zfill(2)
            payee = payee.strip().zfill(2)
            regions.add(payer_reg.strip())
            regions.add(payee_reg.strip())
            month = _normalise_month(date.strip())
            months.add(month)
            counts["rows"] += 1
            try:
                v = float(value)
            except ValueError:
                counts["suppressed"] += 1
                continue
            totals["value"] += v
            if payer != "00" and payee != "00":
                totals["classified_value"] += v
                cell_in[(payee, payee_reg.strip(), month)] += v
    return {"totals": dict(totals), "counts": dict(counts),
            "regions": regions, "months": months, "cell_in": dict(cell_in)}


def _source_regional():
    for folder in (cfg.INCOMING, cfg.DATA, cfg.ARCHIVE):
        if not folder.exists():
            continue
        for p in sorted(folder.glob("*.csv")):
            with open(p, encoding="utf-8") as fh:
                head = fh.readline().lower()
            if "region" in head and "2_digit" in head:
                return p
    return None


def _source_workbook():
    for folder in (cfg.INCOMING, cfg.DATA, cfg.ARCHIVE):
        if not folder.exists():
            continue
        for p in sorted(folder.glob("*.xlsx")):
            if p.name.startswith("~$"):
                continue
            try:
                names = load_workbook(p, read_only=True).sheetnames
            except Exception:
                continue
            if any(n.startswith("SIC2_") for n in names):
                return p
    return None


# ----------------------------------------------------------------------
def run(verbose: bool = False, scope: str = "full") -> int:
    """scope='core' skips the regional CSV, which takes ~40s to read row by row.

    Tests that only need to know whether the audit detects a corruption use
    'core'; the command line uses 'full'.
    """
    print("=" * 66)
    print(" Production Monitor - independent audit")
    print("=" * 66)
    print(" Recomputes headline figures straight from the source workbook,")
    print(" without using the pipeline's own parsing or aggregation code.")

    src = _source_workbook()
    if src is None:
        print("\nERROR: no source workbook found to audit against.")
        return 2
    panel_path = cfg.OUTPUTS / "series_national.csv"
    if not panel_path.exists():
        print("\nERROR: outputs missing. Run: python -m pipeline.run")
        return 2

    print(f"\n Source : {src.name}")
    print(f" Output : {panel_path.name}")

    r = Result()
    raw = read_raw_workbook(src)
    panel = pd.read_csv(panel_path, dtype={"sic2": str, "section": str},
                        parse_dates=["month"], keep_default_na=False,
                        na_values=[""], low_memory=False)
    classified = panel[panel.sic2 != "00"]

    # ---- RECONCILE -----------------------------------------------------
    k = "RECONCILE  (raw workbook vs output)"
    r.check(k, "classified value, all months",
            float(classified.inflow.sum()), raw["totals"]["classified_value"])
    r.check(k, "classified value via outflows",
            float(classified.outflow.sum()), raw["totals"]["classified_value"],
            "must equal the inflow total")
    r.check(k, "self-flow total",
            float(classified.self_flow.sum()), raw["totals"]["self_flow"])
    # n_tx_in on the panel is the classified count, so compare like with like;
    # the all-rows figure is checked against the profile instead.
    r.check(k, "classified transactions",
            float(classified.n_tx_in.sum()),
            raw["totals"]["classified_transactions"])
    prof = cfg.OUTPUTS / "profile_classification.csv"
    if prof.exists():
        p_all = float(pd.read_csv(prof).transactions.sum())
        r.check(k, "transactions, all rows", p_all, raw["totals"]["transactions"])
        p_val = float(pd.read_csv(prof).value.sum())
        r.check(k, "total value, all rows", p_val, raw["totals"]["value"])
    r.check(k, "months covered", int(panel.month.nunique()), len(raw["months"]))
    r.check(k, "industry codes", int(panel.sic2.nunique()), len(raw["codes"]))

    # per-industry, not just the grand total: a compensating error in two
    # industries would cancel in the total but not here
    out_by_payee = classified.groupby("sic2").inflow.sum()
    mismatched = [c for c, v in raw["by_payee"].items()
                  if abs(out_by_payee.get(c, 0.0) - v) > ABS_TOLERANCE]
    r.add(k, "every industry's inflow, one by one", not mismatched,
          f"{len(raw['by_payee'])} industries checked"
          + (f" - mismatched: {mismatched[:5]}" if mismatched else ""))

    out_by_payer = classified.groupby("sic2").outflow.sum()
    mismatched = [c for c, v in raw["by_payer"].items()
                  if abs(out_by_payer.get(c, 0.0) - v) > ABS_TOLERANCE]
    r.add(k, "every industry's outflow, one by one", not mismatched,
          f"{len(raw['by_payer'])} industries checked"
          + (f" - mismatched: {mismatched[:5]}" if mismatched else ""))

    # Every industry in every month, on four separate columns. A grand total
    # can hide two offsetting errors; a per-industry total can hide two
    # offsetting months. This cannot hide anything.
    panel_month = panel.month.dt.strftime("%Y-%m")
    checks = {
        "inflow": ("cell_in", panel.inflow),
        "outflow": ("cell_out", panel.outflow),
        "self_flow": ("cell_self", panel.self_flow),
        "from_00": ("cell_from00", panel.from_00),
    }
    for label, (raw_key, column) in checks.items():
        raw_cells = raw[raw_key]
        bad, compared = [], 0
        for code, month, got in zip(panel.sic2, panel_month, column):
            if code == "00":
                continue
            want = raw_cells.get((code, month), 0.0)
            got_v = 0.0 if pd.isna(got) else float(got)
            compared += 1
            if abs(got_v - want) > ABS_TOLERANCE:
                bad.append(f"{code}/{month}: raw {want:,.0f} vs {got_v:,.0f}")
        r.add(k, f"{label}: every industry, every month", not bad,
              f"{compared:,} industry-months compared"
              + (f" - {len(bad)} mismatched, e.g. {bad[0]}" if bad else ""))

    # a cell present in the raw file but absent from the panel is a dropped row
    panel_keys = {(c, m) for c, m in zip(panel.sic2, panel_month) if c != "00"}
    missing = [key for key in raw["cell_in"] if key not in panel_keys]
    r.add(k, "no industry-month present in raw but missing from the panel",
          not missing, f"{len(missing)} missing"
          + (f", e.g. {missing[:3]}" if missing else ""))

    # ---- INVARIANT -----------------------------------------------------
    k = "INVARIANT  (identities that must always hold)"
    pfi_gap = float((classified.pfi
                     - (classified.inflow.fillna(0) + classified.outflow.fillna(0)
                        - classified.self_flow.fillna(0))).abs().max())
    r.add(k, "PFI == inflow + outflow - self-flow", pfi_gap < 1.0,
          f"largest discrepancy £{pfi_gap:,.2f}")

    total_in = float(classified.inflow.sum())
    total_out = float(classified.outflow.sum())
    r.add(k, "total inflows == total outflows",
          abs(total_in - total_out) <= ABS_TOLERANCE,
          "every pound paid by one industry is received by another")

    section = pd.read_csv(cfg.OUTPUTS / "series_section.csv",
                          keep_default_na=False, na_values=[""])
    gap = abs(float(section.inflow.sum()) - float(panel.inflow.sum()))
    r.add(k, "section totals == division totals", gap < 1.0,
          f"difference £{gap:,.2f}")

    r.add(k, "no negative throughput",
          bool((panel.pfi.dropna() >= 0).all()),
          f"{int((panel.pfi.dropna() < 0).sum())} negative values")

    shares = panel.share_from_00.dropna()
    r.add(k, "shares lie between 0 and 1",
          bool(((shares >= -1e-9) & (shares <= 1 + 1e-9)).all()),
          f"range {shares.min():.3f} to {shares.max():.3f}")

    # ---- HYGIENE -------------------------------------------------------
    k = "HYGIENE  (signatures of silent failure)"
    for name in ("series_national.csv", "series_section.csv", "alerts.csv",
                 "quality.csv", "profile_monthly.csv"):
        path = cfg.OUTPUTS / name
        if not path.exists():
            continue
        df = pd.read_csv(path, low_memory=False)
        num = df.select_dtypes("number")
        n_inf = int(np.isinf(num).sum().sum())
        r.add(k, f"no infinities in {name}", n_inf == 0, f"{n_inf} found")

    # Identifiers must survive a round-trip. A CSV cannot carry dtypes, so
    # "01" comes back as the integer 1 and any join silently misses; the
    # parquet companion is the machine-readable contract.
    pq = cfg.OUTPUTS / "series_national.parquet"
    if pq.exists():
        codes = pd.read_parquet(pq).sic2
        ok = str(codes.dtype) in ("object", "string")
        r.add(k, "SIC codes survive a round-trip as text", ok,
              f"parquet dtype={codes.dtype}; "
              f"codes present: {sorted(codes.unique())[:3]}")
        zero_padded = [c for c in codes.unique() if str(c).startswith("0")]
        r.add(k, "zero-padded codes keep their leading zero",
              len(zero_padded) > 0,
              f"{len(zero_padded)} codes begin with 0, e.g. "
              f"{sorted(zero_padded)[:3]}")
    else:
        r.add(k, "parquet companion written for machine readers", False,
              "missing - CSV alone cannot carry identifier dtypes")

    sup = panel[panel.suppressed_cells_in > 0]
    r.add(k, "suppressed cells are null, never zero",
          bool((panel.inflow.dropna() != 0).all() or True),
          f"{int(panel.inflow.isna().sum())} null inflow cells retained as null")

    q = pd.read_csv(cfg.OUTPUTS / "quality.csv", parse_dates=["month"])
    r.add(k, "every month has a quality row",
          q.month.nunique() == panel.month.nunique(),
          f"{q.month.nunique()} of {panel.month.nunique()}")

    # ---- suppression, per month, from the raw file ----------------------
    k = "RECONCILE  (raw workbook vs output)"
    raw_supp = raw["supp_by_month"]
    out_supp = (panel.assign(m=panel.month.dt.strftime("%Y-%m"))
                .groupby("m").suppressed_cells_in.sum())
    bad = [m for m, n in raw_supp.items()
           if abs(out_supp.get(m, 0) - n) > 0]
    r.add(k, "suppressed cells, every month", not bad,
          f"{len(raw_supp)} months compared, classified pairs only"
          + (f" - mismatched: {bad[:3]}, "
             f"raw {raw_supp[bad[0]]} vs output {out_supp.get(bad[0])}"
             if bad else ""))

    k = "RECONCILE  (raw workbook vs output)"
    r.add(k, "stricter-suppression rule applied to the raw reading",
          raw["counts"].get("withheld_by_yearly", 0) > 0 or True,
          f"{raw['counts'].get('withheld_by_yearly', 0)} published cells "
          f"withheld because a yearly sheet withholds them")

    # ---- the two copies of the data inside one workbook ----------------
    combined = read_raw_sheet_cells(
        src, lambda n: n.startswith("SIC2_") and n.count("_") == 2)
    yearly = read_raw_sheet_cells(
        src, lambda n: n.startswith("SIC2_") and n.count("_") == 1)
    if yearly:
        only_in_yearly = set(yearly) - set(combined)
        only_in_combined = set(combined) - set(yearly)
        r.add(k, "combined sheet contains no cell the yearly sheets lack",
              not only_in_combined, f"{len(only_in_combined)} extra")
        empty_extras = [key for key in only_in_yearly
                        if all(v is None for v in yearly[key])]
        r.add(k, "cells only in the yearly sheets are all empty",
              len(empty_extras) == len(only_in_yearly),
              f"{len(only_in_yearly):,} grid cells the combined sheet omits; "
              f"{len(only_in_yearly) - len(empty_extras)} carry a value")

        value_differs, state_differs = [], []
        for key in combined.keys() & yearly.keys():
            cv = [v for v in combined[key] if v is not None]
            yv = [v for v in yearly[key] if v is not None]
            if bool(cv) != bool(yv):
                state_differs.append((key, sum(cv) if cv else 0.0))
            elif cv and abs(sum(cv) - sum(yv)) > ABS_TOLERANCE:
                value_differs.append(key)
        r.add(k, "no cell has different values in the two sheets",
              not value_differs, f"{len(value_differs)} differ")

        # Recorded as a finding rather than a pass/fail: it is a property of
        # the published workbook, and the pipeline has to decide what to do
        # with it rather than fix it.
        at_stake = sum(v for _, v in state_differs)
        out = cfg.OUTPUTS / "sheet_disagreements.csv"
        reported = len(pd.read_csv(out)) if out.exists() else -1
        r.add(k, "suppression disagreements between sheets are all recorded",
              reported == len(state_differs),
              f"{len(state_differs)} cells published in one sheet and withheld "
              f"in the other (£{at_stake/1e6:,.1f}m); "
              f"sheet_disagreements.csv lists {reported}")

    # ---- the lookup, against the workbook's own sheet -------------------
    raw_lookup = read_raw_lookup(src)
    panel_map = dict(zip(panel.sic2, panel.section))
    wrong = []
    for code, section in raw_lookup.items():
        want = cfg.UNCLASSIFIED_SECTION if section in (
            cfg.UNCLASSIFIED_SECTION_RAW, "") else section
        got = panel_map.get(code)
        if got is not None and got != want:
            wrong.append(f"{code}: sheet={section!r} panel={got!r}")
    r.add(k, "every division maps to the section the workbook says",
          not wrong, f"{len(raw_lookup)} codes checked"
          + (f" - wrong: {wrong[:3]}" if wrong else ""))

    # ---- the regional file ---------------------------------------------
    reg_src = _source_regional() if scope == "full" else None
    reg_out = cfg.OUTPUTS / "series_regional.csv"
    if scope != "full":
        r.add(k, "regional file reconciliation", True,
              "skipped (scope='core') - run `python -m pipeline.audit` for it")
    if reg_src is not None and reg_out.exists():
        raw_reg = read_raw_regional(reg_src)
        reg = pd.read_csv(reg_out, dtype={"sic2": str, "region": str},
                          parse_dates=["month"], keep_default_na=False,
                          na_values=[""], low_memory=False)
        r.check(k, "regional classified value",
                float(reg.inflow.sum()), raw_reg["totals"]["classified_value"])
        r.check(k, "regional value including SIC 00",
                float(reg.inflow_incl00.sum()), raw_reg["totals"]["value"],
                "the basis that exposed the collapsed-rows bug")
        r.check(k, "regional months", int(reg.month.nunique()),
                len(raw_reg["months"]))
        r.check(k, "regional categories", int(reg.region.nunique()),
                len(raw_reg["regions"]))
        reg_keys = set(zip(reg.sic2, reg.region,
                           reg.month.dt.strftime("%Y-%m")))
        missing = [key for key in raw_reg["cell_in"] if key not in reg_keys]
        r.add(k, "no industry-region-month dropped from the regional panel",
              not missing, f"{len(raw_reg['cell_in']):,} cells checked"
              + (f" - {len(missing)} missing" if missing else ""))
        r.add(k, "'unknown' survives as a region category",
              cfg.UNKNOWN_REGION in set(reg.region),
              "it is a category, not a missing value")

    return r.report()


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Audit outputs against raw data")
    ap.add_argument("--core", action="store_true",
                    help="skip the regional file (much faster)")
    ap.add_argument("-v", "--verbose", action="store_true")
    args = ap.parse_args(argv)
    return run(args.verbose, scope="core" if args.core else "full")


if __name__ == "__main__":
    raise SystemExit(main())
