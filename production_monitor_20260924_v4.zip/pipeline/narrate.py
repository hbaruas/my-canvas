"""Plain-English driver lines.

Andrew should not have to read a waterfall to learn what the waterfall says.
Each line is assembled from the alert's own decomposition, so it states the
cause rather than restating the number.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from . import config as cfg
from . import decompose


def _money(x: float) -> str:
    """Format a signed amount with the sign OUTSIDE the currency symbol.

    f"£{-2.7}bn" renders as "£-2.7bn", which reads as a typo. A minus sign
    belongs in front of the whole quantity.
    """
    if not np.isfinite(x):
        return "n/a"
    a = abs(x)
    sign = "-" if x < 0 else ""
    if a >= 1e9:
        return f"{sign}£{a/1e9:,.1f}bn"
    return f"{sign}£{a/1e6:,.0f}m"


def _counterparty_label(code: str, lookup: dict[str, str]) -> str:
    if code == cfg.UNCLASSIFIED_SIC:
        return "unclassified businesses"
    return f"SIC {code} {lookup.get(code, '')}".strip()


def line(alert, edges: pd.DataFrame, lookup: dict[str, str]) -> str:
    """One sentence explaining a single alert.

    The shape of the sentence is fixed and never varies:

        <industry>: <measure> <up|down> <money> (<pct>) vs <period>.
        <cause clause naming the kind of cause, the partner, and the share>.

    Fixed on purpose. This line is regenerated every month for whichever
    industries move, so a reader has to be able to skim it in the same shape
    every time rather than re-parse a new turn of phrase. An earlier version
    ended "Largest contributor SIC 84 at £307m (69% of the move)", which left
    the reader to guess whether 84 was the largest, the closest or merely the
    one we happened to name, and whether 69% was of the move or of the total.
    Every clause below now states which quantity it is a share of, and says
    what kind of cause it is before naming any number.
    """
    lag = 1 if alert.basis == "MoM" else 12
    base = alert.month - pd.DateOffset(months=lag)
    when = f"{base:%B %Y}" if lag == 12 else f"the previous month ({base:%B %Y})"

    label = {"pfi": "PFI", "inflow": "inflows", "outflow": "outflows"}.get(
        alert.measure, alert.measure)
    direction = "up" if alert.gbp_delta > 0 else "down"
    head = (f"**SIC {alert.code} {alert.name}**: {label} "
            f"{direction} {_money(abs(alert.gbp_delta))}")
    if np.isfinite(alert.pct_delta):
        head += f" ({alert.pct_delta:+.0%})"
    head += f" vs {when}."

    # Alerts are scored on the classified basis, so the sentence must be too.
    rows = decompose.decompose_measure(edges, alert.code, alert.month, base,
                                       measure=alert.measure,
                                       include_unclassified=False)
    if rows.empty:
        return head
    s = decompose.summarise(rows)
    top, contrib = s["top_counterparty"], s["top_contribution"]
    if top is None or not s["total_change"]:
        return head

    total = abs(s["total_change"])
    share = abs(contrib) / total
    who = _counterparty_label(top, lookup)
    n_others = max(s["n_counterparties"] - 1, 0)
    rest = total - abs(contrib)

    # The cause matters more than the magnitude: a reporting change dressed as
    # an economic one is the failure this whole design guards against. So the
    # clause always opens by naming the KIND of cause, before any number.
    if s["top_category"] == decompose.ABSENT:
        return (f"{head} **Reporting change, not money changing hands:** "
                f"{_money(abs(contrib))} of the {_money(total)} move "
                f"({share:.0%}) is payments from {who} that have a figure in "
                f"{base:%B %Y} and no figure in {alert.month:%B %Y}. The "
                f"partner left the published data; it need not have stopped "
                f"trading.")
    if s["top_category"] == decompose.NEWLY_PRESENT:
        return (f"{head} **Coverage change, not new activity:** "
                f"{_money(abs(contrib))} of the {_money(total)} move "
                f"({share:.0%}) is payments from {who} that have a figure in "
                f"{alert.month:%B %Y} and no figure in {base:%B %Y}. The "
                f"partner entered the published data; it need not have started "
                f"trading.")
    if np.isfinite(getattr(alert, "sic00_share_shift", np.nan)) \
            and abs(alert.sic00_share_shift) >= 0.20:
        return (f"{head} **Most likely a classification change:** the share of "
                f"this industry's money arriving from payers with no industry "
                f"code moved {alert.sic00_share_shift:+.0%}. Money shifting "
                f"between the identified and unidentified buckets moves this "
                f"series without any change in trading.")
    if np.isfinite(getattr(alert, "breadth", np.nan)) and alert.breadth >= 0.6:
        return (f"{head} **Broad-based:** {alert.breadth:.0%} of its "
                f"{s['n_counterparties']} trading partners moved the same way, "
                f"so no single relationship explains it. The largest of them is "
                f"{who}, which paid {_money(abs(contrib))} "
                f"{'more' if contrib > 0 else 'less'} than in {base:%B %Y} — "
                f"{share:.0%} of the {_money(total)} move.")

    signed_total = float(s["total_change"])
    moved_word = "rise" if signed_total > 0 else "fall"
    paid_word = "more" if contrib > 0 else "less"

    # The largest partner by size can move AGAINST the total. Calling it "the
    # largest contributor to the move" then states the opposite of the truth:
    # SIC 68 fell £176m in June 2026 while its biggest single change, SIC 47,
    # paid £93m MORE. The sign has to be read before the sentence is written.
    if np.sign(contrib) != np.sign(signed_total):
        return (f"{head} **No single partner drove it — the largest one moved "
                f"the other way:** the biggest individual change was {who}, "
                f"which paid {_money(abs(contrib))} {paid_word}, *against* the "
                f"overall {moved_word}. The {moved_word} is therefore spread "
                f"across the other {n_others} partners rather than caused by "
                f"any one of them.")

    if share > 1.0:
        offset = abs(signed_total - contrib)
        return (f"{head} **More than accounted for by one partner:** {who} "
                f"alone paid {_money(abs(contrib))} {paid_word}, which is "
                f"{share:.0%} of the {_money(total)} net move. It is more than "
                f"the whole change because the other {n_others} partners moved "
                f"the opposite way and offset {_money(offset)} of it. Remove "
                f"this one relationship and the industry barely moved.")

    return (f"{head} **Concentrated in one partner:** {who} accounts for "
            f"{share:.0%} of the {_money(total)} move — it paid "
            f"{_money(abs(contrib))} {paid_word} than in {base:%B %Y}. It "
            f"traded with this industry in both months, so that part is money "
            f"genuinely changing hands. The other {n_others} partners account "
            f"for the remaining {_money(abs(signed_total - contrib))}.")


def add_lines(alerts: pd.DataFrame, edges: pd.DataFrame,
              lookup: pd.DataFrame, per_month: int = 5) -> pd.DataFrame:
    """Generate driver lines for the top alerts IN EACH MONTH.

    Per month, not globally: a global top-N is dominated by whichever months
    were most extreme - July 2022 carries severity 99 across many industries -
    so the current month, which is the one anyone actually opens, would get no
    lines at all.
    """
    alerts = alerts.copy()
    alerts["driver_line"] = ""
    if alerts.empty:
        return alerts

    div = alerts[alerts.level == "division"]
    names = dict(zip(lookup.sic2, lookup.division))
    picked = (div.sort_values("severity", ascending=False)
                 .groupby(["month", "measure", "basis"], observed=True)
                 .head(per_month))
    alerts.loc[picked.index, "driver_line"] = [line(r, edges, names)
                                               for r in picked.itertuples()]

    # Section and GDP rows inherit the sentence from the division they name,
    # so a reader at section level still sees the cause.
    lookup_line = dict(zip(
        zip(picked.month, picked.measure, picked.basis, picked.code),
        alerts.loc[picked.index, "driver_line"]))
    agg = alerts[alerts.level != "division"]
    if len(agg) and "driver_code" in agg:
        alerts.loc[agg.index, "driver_line"] = [
            lookup_line.get((m, me, b, d), "")
            for m, me, b, d in zip(agg.month, agg.measure, agg.basis,
                                   agg.driver_code)]
    return alerts
