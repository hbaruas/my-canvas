"""Network metrics over the payment graph.

Phase 2, chunk 2. Everything here is built on `graph.py`, which is the only
place edge direction is defined - money runs payer -> payee - so a single
tested convention underpins every metric.

Why PageRank rather than size. A sector's importance measured by its own
turnover ignores who it trades with. PageRank scores an industry by the money
flowing into it, weighted by how central its payers are, so an industry that
receives from other important industries outranks one of the same size that
receives from the periphery. The spec's validation for this is that it should
reproduce the hub structure in the ONS input-output tables.

Two decisions carried from the spec:

  * Run on CLASSIFIED flows only. With SIC 00 included, that single node takes
    0.341 of all PageRank - it is both the largest source and the largest sink -
    and every other score is deflated by it.
  * Betweenness IS computed and written, but is given no view. 83% of
    industries score exactly zero at SIC2 and 80% at SIC5, and the non-zero
    scores land on the same nodes PageRank already identifies. It is kept
    because the stress-testing use is real, and its zero-share is written
    beside it every month so nobody can read the column without seeing how
    much of it is zero (BUILD_SPEC 12.4, hook 8).
"""
from __future__ import annotations

import logging

import networkx as nx
import numpy as np
import pandas as pd

from . import config as cfg
from . import graph as g

log = logging.getLogger(__name__)

DAMPING = 0.85

# Metrics written for every node-month. Long format so adding a metric never
# changes the schema (BUILD_SPEC 12.6 hook 5).
METRICS = ("pagerank", "pagerank_volume", "betweenness", "in_strength",
           "out_strength", "in_degree", "out_degree", "top_counterparty_share")


def _month_metrics(graph: nx.DiGraph) -> pd.DataFrame:
    """Every node metric for one month's graph."""
    if graph.number_of_edges() == 0:
        return pd.DataFrame(columns=["node", "metric", "value"])
    frame = g.strengths(graph)
    frame["pagerank"] = g.pagerank(graph, alpha=DAMPING)
    # The same walk weighted by NUMBER of payments rather than their value.
    # Value-weighted influence follows the largest settlements; volume-weighted
    # follows the busiest relationships, and the two need not agree.
    if any("n_tx" in d for _, _, d in graph.edges(data=True)):
        frame["pagerank_volume"] = pd.Series(
            nx.pagerank(graph, alpha=DAMPING, weight="n_tx"))
    frame["top_counterparty_share"] = g.top_counterparty_share(graph)
    # No view is built on this (BUILD_SPEC 12.4) but it is written, because
    # "keep the computation for stress-testing" was the decision and an
    # unwritten computation is not kept. ~0.15s a month at SIC2.
    frame["betweenness"] = g.betweenness(graph)
    out = (frame.reset_index(names="node")
                .melt(id_vars="node", var_name="metric", value_name="value"))
    return out[out.metric.isin(METRICS)]


def build(edges: pd.DataFrame, level: str = cfg.LEVEL_SIC2,
          vintage: str = "") -> pd.DataFrame:
    """Node metrics for every month, long format."""
    months = sorted(edges.loc[edges.grain == level, "month"].unique())
    if not months:
        return pd.DataFrame(columns=["level", "node_id", "month", "metric",
                                     "value", "vintage"])
    index = g.as_index_for(edges, level)
    frames = []
    for month in months:
        graph = g.build_graph(index, level=level, month=month,
                              include_unclassified=False)
        part = _month_metrics(graph)
        if part.empty:
            continue
        part["month"] = month
        frames.append(part)

    out = pd.concat(frames, ignore_index=True)
    out["level"] = level
    out["node_id"] = [cfg.node_id(level, n) for n in out.node]
    out["vintage"] = vintage
    log.info("network metrics: %s nodes x %d months, %d rows",
             out.node.nunique(), len(months), len(out))
    return out[["level", "node_id", "month", "metric", "value", "vintage"]]


def diagnostics(edges: pd.DataFrame, level: str = cfg.LEVEL_SIC2,
                vintage: str = "") -> pd.DataFrame:
    """The per-month diagnostic that must travel with every network output.

    Hook 8 of BUILD_SPEC 12.6: each of these metrics has a regime where it
    stops meaning anything, and the diagnostic is what makes that visible on
    the chart rather than in a footnote.

      density            how close the network is to complete. Above ~70%
                         there is no intermediation left to detect.
      betweenness_zero   share of nodes scoring exactly zero.
      sic00_pagerank     PageRank taken by SIC 00 when it is included. This is
                         why the headline runs classified-only: one node
                         absorbing a third of the walk deflates every other
                         score.
    """
    months = sorted(edges.loc[edges.grain == level, "month"].unique())
    index = g.as_index_for(edges, level)
    rows = []
    for month in months:
        G = g.build_graph(index, level=level, month=month,
                          include_unclassified=False)
        if G.number_of_edges() == 0:
            continue
        G00 = g.build_graph(index, level=level, month=month,
                            include_unclassified=True)
        pr00 = g.pagerank(G00) if G00.number_of_edges() else pd.Series(dtype=float)
        rows.append({
            "level": level, "month": month,
            "n_nodes": G.number_of_nodes(), "n_edges": G.number_of_edges(),
            "density": g.density(G),
            "betweenness_zero_share": g.zero_share(g.betweenness(G)),
            "sic00_pagerank_share": float(pr00.get(cfg.UNCLASSIFIED_SIC,
                                                   float("nan"))),
            "vintage": vintage,
        })
    out = pd.DataFrame(rows)
    if len(out):
        log.info("network diagnostics: density %.1f%%, betweenness zeros "
                 "%.0f%%, SIC 00 takes %.3f of PageRank when included",
                 100 * out.density.mean(), 100 * out.betweenness_zero_share.mean(),
                 out.sic00_pagerank_share.mean())
    return out


def wide(metrics: pd.DataFrame, metric: str) -> pd.DataFrame:
    """One metric as month x node, for charting and for rank changes."""
    sel = metrics[metrics.metric == metric].copy()
    sel["code"] = sel.node_id.str.split(":").str[-1]
    return sel.pivot_table(index="month", columns="code", values="value")


def rank_changes(metrics: pd.DataFrame, metric: str = "pagerank",
                 window: int = 12) -> pd.DataFrame:
    """How far each industry has moved in the ranking over `window` months.

    Rank rather than level, because PageRank scores are shares that all move
    together when the network's total activity moves. The question worth asking
    is who has gained influence *relative to everyone else*.
    """
    w = wide(metrics, metric)
    if len(w) <= window:
        return pd.DataFrame()
    ranks = w.rank(axis=1, ascending=False, method="min")
    now, then = ranks.iloc[-1], ranks.iloc[-1 - window]
    out = pd.DataFrame({
        "rank_now": now, "rank_then": then,
        "rank_change": then - now,                  # positive = risen
        "score_now": w.iloc[-1], "score_then": w.iloc[-1 - window],
    })
    out["score_change"] = out.score_now / out.score_then - 1
    return out.sort_values("rank_change", ascending=False)
