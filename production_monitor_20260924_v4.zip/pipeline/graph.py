"""The single entry point for every graph built anywhere in the system.

This module exists so that edge direction, weighting and thresholds are
defined exactly once. PageRank inverts silently if payer and payee are
swapped - there is no error, just a wrong answer - so the orientation is
fixed here and asserted by tests/test_direction.py.

DIRECTION CONVENTION, fixed and tested:
    an edge runs  payer -> payee,  following the money.
    payer is the source, payee is the target, value is the edge weight.
"""
from __future__ import annotations

import logging

import networkx as nx
import pandas as pd

from . import config as cfg

log = logging.getLogger(__name__)


def as_index_for(edges: pd.DataFrame, level: str):
    """Month-indexed view of one grain, built once for a monthly loop.

    Filtering the whole edge table per month costs ~170 ms a call; slicing a
    month index costs ~4 ms. Over 90 months that is the difference between a
    fifteen-second pass and a quarter of a second.
    """
    from . import decompose
    return decompose.as_index(edges[edges.grain == level])


def build_graph(edges,
                *,
                level: str = cfg.LEVEL_SIC2,
                month: pd.Timestamp | str | None = None,
                region_scope: str | None = None,
                min_edge_value: float = 0.0,
                include_unclassified: bool = False,
                drop_self_loops: bool = False,
                directed: bool = True) -> nx.Graph | nx.DiGraph:
    """Construct one graph from the edge table.

    Args:
        edges: normalised edge table (from ingest).
        level: which grain to use.
        month: a single month, or None for every month summed.
        region_scope: an ITL1 code to restrict to, 'unknown' included, or
            None for no regional filter.
        min_edge_value: drop edges below this value. Sparsifying barely moves
            the metrics here (BUILD_SPEC 12.1) but the option is kept.
        include_unclassified: keep SIC 00. False by default because SIC 00
            takes 34% of all PageRank when included (BUILD_SPEC 12.2).
        drop_self_loops: drop payer == payee. Self-flows are real and are kept
            by default; some centrality measures want them gone.
        directed: DiGraph payer -> payee, else an undirected value-summed Graph.
    """
    from . import decompose
    if isinstance(edges, decompose.EdgeIndex):
        if month is None:
            raise ValueError("a month is required when passing an EdgeIndex")
        df = edges.month(month)
    else:
        df = edges[edges.grain == level]
        if month is not None:
            df = df[df.month == pd.Timestamp(month)]
    if region_scope is not None:
        df = df[(df.payer_region == region_scope) | (df.payee_region == region_scope)]
    if not include_unclassified:
        df = df[(df.payer != cfg.UNCLASSIFIED_SIC) & (df.payee != cfg.UNCLASSIFIED_SIC)]

    df = df[df.value.notna() & (df.value > min_edge_value)]
    if drop_self_loops:
        df = df[df.payer != df.payee]

    # Edges carry both the value and its reciprocal: shortest-path algorithms
    # need "distance", where a high-value link is a short one.
    agg = df.groupby(["payer", "payee"], observed=True).agg(
        value=("value", "sum"), n_tx=("n_tx", "sum"))

    G: nx.Graph | nx.DiGraph = nx.DiGraph() if directed else nx.Graph()
    G.graph.update(level=level, month=str(month), region_scope=region_scope,
                   include_unclassified=include_unclassified)

    for (payer, payee), row in agg.iterrows():
        #  --- the direction convention, in one place ---
        source, target = payer, payee
        value, n_tx = float(row.value), float(row.n_tx or 0)
        if not directed and G.has_edge(source, target):
            value += G[source][target]["value"]
            n_tx += G[source][target].get("n_tx", 0.0)
        G.add_edge(source, target, value=value, n_tx=n_tx,
                   distance=1.0 / value if value > 0 else float("inf"))
    return G


def pagerank(G: nx.DiGraph, alpha: float = 0.85) -> pd.Series:
    """PageRank weighted by transaction value.

    Runs on the classified graph by default: including SIC 00 gives that single
    node 0.341 of all PageRank, because Unclassified is both the largest source
    and the largest sink in the network (BUILD_SPEC 12.2).
    """
    return (pd.Series(nx.pagerank(G, alpha=alpha, weight="value"))
              .sort_values(ascending=False))


def strengths(G: nx.DiGraph) -> pd.DataFrame:
    """In/out strength and degree per node."""
    return pd.DataFrame({
        "in_strength": pd.Series(dict(G.in_degree(weight="value"))),
        "out_strength": pd.Series(dict(G.out_degree(weight="value"))),
        "in_degree": pd.Series(dict(G.in_degree())),
        "out_degree": pd.Series(dict(G.out_degree())),
    }).fillna(0)


def top_counterparty_share(G: nx.DiGraph) -> pd.Series:
    """Share of a node's inflow coming from its single largest counterparty.

    A concentration measure: high values mean the series is one relationship
    away from a step change.
    """
    out = {}
    for node in G.nodes:
        vals = [d["value"] for _, _, d in G.in_edges(node, data=True)]
        total = sum(vals)
        out[node] = max(vals) / total if total > 0 else float("nan")
    return pd.Series(out)


def betweenness(G: nx.DiGraph, *, weight: str = "distance",
                normalized: bool = True) -> pd.Series:
    """Share of shortest paths through each node, on value-distance.

    Computed, but deliberately given no view (BUILD_SPEC 12.4). Measured on
    this network, 83% of industries score exactly zero at SIC2 and 80% at
    SIC5, and the non-zero scores land on the same hubs PageRank already
    names. Sparsifying does not help: dropping the SIC2 graph from 77% to 19%
    density left the zero-share pinned at 82%. Density was never the cause -
    this economy is hub-and-spoke at every level of granularity.

    It is kept because the stress-testing use is real: if a hub is removed,
    betweenness is what says whose paths ran through it. Publish `zero_share`
    beside it, always, so a reader can see how much of the column is zero
    before drawing anything from it (hook 8).

    `weight="distance"` is 1/value, set in build_graph: a high-value link is a
    SHORT path. Passing "value" here would invert the meaning and, as with
    PageRank direction, would do so silently.
    """
    if G.number_of_edges() == 0:
        return pd.Series(dtype=float)
    return pd.Series(nx.betweenness_centrality(G, weight=weight,
                                               normalized=normalized))


def zero_share(values: pd.Series) -> float:
    """Fraction of nodes scoring exactly zero.

    The diagnostic that must accompany betweenness. A metric where four in
    five nodes score zero is not ranking those nodes - it is separating a
    handful of hubs from everyone else, and saying so is the difference
    between a diagnostic and a league table.
    """
    v = pd.Series(values).dropna()
    return float((v == 0).mean()) if len(v) else float("nan")


def density(G: nx.Graph | nx.DiGraph) -> float:
    return nx.density(G)
