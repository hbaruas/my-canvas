"""Pipeline orchestrator.

    python -m pipeline.run                 read Data/incoming, run everything
    python -m pipeline.run --use-cache     re-run from the last vintage (fast)
    python -m pipeline.run --with-sic5     also ingest the 782MB SIC5 file
"""
from __future__ import annotations

import argparse
import logging
import sys
import time

import pandas as pd

from . import config as cfg
from . import (communities, condition, decompose, detect, ingest, narrate,
               network, profile, quality, series, structural, vintage)

log = logging.getLogger("pipeline")


def _setup_logging(verbose: bool) -> None:
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(message)s",
        stream=sys.stdout,
    )


class DataNotFound(Exception):
    """Raised with an actionable message when no delivery is present."""


def _load(use_cache: bool, with_sic5: bool):
    """Return (edges, lookup, release). Cache means the last written vintage."""
    if use_cache:
        vintages = vintage.list_vintages()
        if not vintages:
            log.warning("--use-cache requested but no vintage exists yet; reading source files")
        else:
            v = vintages[-1]
            log.info("loading cached vintage %s", v.name)
            edges = {}
            for grain in (cfg.LEVEL_SIC2, cfg.LEVEL_SIC2_REGION, cfg.LEVEL_SIC5):
                df = vintage.load_snapshot(v, grain)
                if df is not None:
                    edges[grain] = df
            lookup = pd.read_parquet(v / "lookup.parquet")
            return edges, lookup, pd.Timestamp(v.name)

    sources = ingest.discover(include_sic5=with_sic5)
    if not sources:
        raise DataNotFound(
            f"No payment data found.\n\n"
            f"Expected one or both of these in {cfg.INCOMING} "
            f"(or directly in {cfg.DATA}):\n"
            f"  - the SIC2 workbook  (.xlsx, sheet SIC2_YYYY_YYYY)   [required]\n"
            f"  - the regional file  (.csv with payer_region column) [optional]\n\n"
            f"Files are identified by their structure, so the filename does not matter."
        )
    if not any(s.kind == "sic2" for s in sources):
        raise DataNotFound(
            "Found input files, but none is the SIC2 workbook.\n"
            "The workbook is required: it holds the lookup sheet that "
            "everything else joins to."
        )
    log.info("found %d input file(s):", len(sources))
    for s in sources:
        log.info("   %s", s)
    return ingest.load(sources)


# Columns that are identifiers, not numbers. Written to CSV they come back as
# integers - "01" becomes 1, "00" becomes 0 - which silently breaks any join a
# downstream reader attempts. The CSV stays, because people open it; a parquet
# companion carries the dtypes exactly.
ID_COLUMNS = ("sic2", "code", "driver_code", "payer", "payee", "section",
              "counterparty", "top_counterparty", "region", "node_id", "level",
              "metric")


def _write(df: pd.DataFrame, name: str) -> None:
    """Write a CSV for people and a parquet for machines."""
    out = df.copy()
    for c in ID_COLUMNS:
        if c in out.columns:
            out[c] = out[c].astype("string")
    out.to_csv(cfg.OUTPUTS / f"{name}.csv", index=False)
    out.to_parquet(cfg.OUTPUTS / f"{name}.parquet", index=False)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Production Monitor pipeline")
    ap.add_argument("--use-cache", action="store_true",
                    help="re-run from the last saved vintage instead of re-parsing")
    ap.add_argument("--with-sic5", action="store_true",
                    help="also ingest the SIC5 file (slow; not used by Phase 1)")
    ap.add_argument("--no-audit", action="store_true",
                    help="skip the reconciliation against the raw file")
    ap.add_argument("-v", "--verbose", action="store_true")
    args = ap.parse_args(argv)

    _setup_logging(args.verbose)
    cfg.ensure_dirs()
    t0 = time.time()

    print("=" * 62)
    print(" Production Monitor - pipeline")
    print("=" * 62)

    try:
        edges, lookup, release = _load(args.use_cache, args.with_sic5)
    except DataNotFound as exc:
        print(f"\nERROR: {exc}\n")
        return 2

    # --- vintage + revisions -------------------------------------------
    if not args.use_cache:
        vdir, revisions = vintage.reconcile(edges, lookup, release)
        vintage_key = vdir.name
    else:
        vintage_key = release.strftime("%Y-%m-%d")
        revisions = pd.DataFrame()

    all_edges = pd.concat(edges.values(), ignore_index=True)

    # --- the workbook carries the data twice; check the copies agree -----
    if not args.use_cache:
        src = next((x for x in ingest.discover() if x.kind == "sic2"), None)
        yearly = ingest.read_sic2_yearly(src) if src else None
        disagreements = ingest.cross_check_sheets(edges[cfg.LEVEL_SIC2], yearly)
        disagreements.to_csv(cfg.OUTPUTS / "sheet_disagreements.csv", index=False)
        # Stricter wins: withhold anything either sheet withholds, then rebuild
        # the combined edge table the rest of the pipeline reads.
        edges[cfg.LEVEL_SIC2] = ingest.apply_stricter_suppression(
            edges[cfg.LEVEL_SIC2], disagreements)
        all_edges = pd.concat(edges.values(), ignore_index=True)
        vintage.write_snapshot(edges, lookup, release)
        if len(disagreements):
            log.warning(
                "%d cells differ between SIC2_2019_2026 and the yearly sheets "
                "(%s of value) - see outputs/sheet_disagreements.csv",
                len(disagreements),
                f"£{disagreements.combined_value.fillna(0).sum()/1e6:,.1f}m")

    # --- panels ---------------------------------------------------------
    national = series.build_national(all_edges, lookup)

    # --- conditioning: seasonal adjustment + break register ---------------
    national, breaks = condition.build(national)
    _write(national, "series_national")

    # Ask of each registered break: is this a real level shift, or a
    # counterparty cell that stopped being reported? A level-shift test cannot
    # tell the difference, but the edge list can.
    if len(breaks):
        sic2_edges = edges[cfg.LEVEL_SIC2]
        cause = [decompose.classify_break(sic2_edges, r.sic2, r.break_month)
                 for r in breaks.itertuples()]
        cause = pd.DataFrame(cause, index=breaks.index)
        breaks = pd.concat(
            [breaks, cause[["presence_share", "sic00_share_shift",
                            "top_counterparty", "top_category",
                            "break_cause"]]], axis=1)
    _write(breaks, "breaks")

    section = series.build_section(national)
    _write(section, "series_section")

    regional = series.build_regional(all_edges, lookup)
    if regional is not None:
        _write(regional, "series_regional")

    # --- detection ------------------------------------------------------
    alerts = detect.build(national, edges[cfg.LEVEL_SIC2], breaks)
    alerts = detect.enrich(alerts, edges[cfg.LEVEL_SIC2])
    alerts = detect.roll_up(alerts, national)
    alerts = detect.add_revision_flags(alerts, revisions)
    alerts = narrate.add_lines(alerts, edges[cfg.LEVEL_SIC2], lookup)
    _write(alerts, "alerts")

    decomposition = decompose.build_table(alerts, edges[cfg.LEVEL_SIC2])
    _write(decomposition, "decomposition")

    # --- quality --------------------------------------------------------
    q = quality.build(all_edges)
    _write(q, "quality")
    qr = quality.build_regional(all_edges)
    if qr is not None:
        qr.to_csv(cfg.OUTPUTS / "quality_regional.csv", index=False)
    stability = quality.cell_stability(all_edges)
    _write(stability, "cell_stability")

    # --- dataset profile (what is in the delivery) ------------------------
    profile.write(profile.build(edges))

    # --- network metrics (Phase 2) ----------------------------------------
    node_metrics = network.build(all_edges, cfg.LEVEL_SIC2, vintage_key)
    _write(node_metrics, "node_metrics")

    # Hook 8: the diagnostic travels with the output it qualifies, so a reader
    # cannot see a network metric without also seeing the regime it is in.
    _write(network.diagnostics(all_edges, cfg.LEVEL_SIC2, vintage_key),
           "network_diagnostics")

    # Communities need SIC5, which Phase 1 does not ingest: at SIC2 the network
    # is 86% dense and modularity is 0.163, too dense to cluster meaningfully.
    if args.with_sic5:
        sic5_path = next((x.path for x in ingest.discover(include_sic5=True)
                          if x.kind == "sic5"), None)
        if sic5_path is not None:
            yearly = communities.stream_sic5_edges(sic5_path)
            members, summary = communities.build(yearly)
            stability = communities.stability(members)
            # Hook 7: network outputs are recomputed per delivery like
            # everything else, so revisions have to be visible here too.
            for frame in (members, summary, stability):
                frame["vintage"] = vintage_key
            _write(members, "communities")
            _write(summary, "community_summary")
            _write(stability, "community_stability")
        else:
            log.warning("--with-sic5 given but no SIC5 file found")

    struct = structural.build(all_edges, node_metrics)
    struct["vintage"] = vintage_key          # hook 7
    keep = ["sic2", "month", "vintage", "structural_score", "structural_flag",
            "structural_reason", *structural.FEATURES,
            *[f"z_{c}" for c in structural.FEATURES]]
    _write(struct[[c for c in keep if c in struct]], "structural")

    # --- edge store (Phase 2 hook) ---------------------------------------
    series.write_edge_store(edges, vintage_key)

    # --- summary ---------------------------------------------------------
    latest = national.month.max()
    cur = q[q.month == latest].iloc[0]
    print()
    print("-" * 62)
    print(f" Vintage          {vintage_key}")
    print(f" Data ends        {latest:%B %Y}   ({national.month.nunique()} months)")
    print(f" Industries       {national.sic2.nunique()}   Sections {section.section.nunique()}")
    if regional is not None:
        print(f" Regions          {regional.region.nunique()}   "
              f"({regional.month.nunique()} months)")
    print(f" Latest month     £{cur.classified_value/1e9:,.1f}bn classified "
          f"of £{cur.total_value/1e9:,.1f}bn total")
    print(f" Unclassified     {cur.share_unclassified:.1%} of value")
    print(f" Cells suppressed {cur.share_cells_suppressed:.1%}")
    if len(breaks):
        idio = int(breaks.likely.str.startswith("idio").sum())
        causes = breaks.break_cause.value_counts().to_dict()
        print(f" Breaks           {len(breaks)} registered "
              f"({idio} idiosyncratic)")
        for c, k in causes.items():
            print(f"                  {k:>3}  {c}")
    head = alerts[(alerts.measure == "pfi") & (alerts.basis == "YoY")
                  & (alerts.month == latest)
                  & (alerts.level == "division")].nlargest(5, "severity")
    if len(head):
        print("-" * 62)
        print(f" Top movers, {latest:%B %Y} (PFI, year-on-year)")
        for r in head.itertuples():
            print(f"   {r.severity:>5.1f}  {r.confidence:<6}  SIC {r.code} "
                  f"{r.name[:34]:<34} {r.pct_delta:+.0%}")
    if len(revisions):
        print(f" REVISIONS        {len(revisions):,} industry-months changed "
              f"since the previous delivery")
    print("-" * 62)
    print(f" Outputs written to {cfg.OUTPUTS.relative_to(cfg.ROOT)}/  "
          f"in {time.time()-t0:,.0f}s")
    print("=" * 62)

    if args.no_audit:
        print(" Audit skipped (--no-audit). Run it with: python -m pipeline.audit")
        return 0

    # Reconcile against the raw workbook before anyone reads the outputs. A
    # silent fault - a division by zero, a dtype change, a dropped category -
    # produces plausible numbers rather than an error, so this runs by default.
    from . import audit as audit_mod
    print()
    status = audit_mod.run()
    if status:
        print("\n AUDIT FAILED - the outputs do not reconcile to the source "
              "data.\n Treat the dashboard as unreliable until this is resolved.")
    return status


if __name__ == "__main__":
    raise SystemExit(main())
