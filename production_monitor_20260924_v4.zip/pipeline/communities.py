"""Economic clusters: groups of industries that trade more with each other.

Phase 2, chunk 4. Louvain community detection over the SIC5 payment network,
run per year so the clustering can be followed through time.

Read the modularity before the picture. Modularity measures how much denser
the links inside communities are than chance would give; roughly 0.3 is the
conventional floor for structure worth interpreting. Measured here:

    SIC2, all months   0.163    - too dense to cluster (86% of pairs trade)
    SIC5, one month    0.249    - better, still below the floor

So this is built at SIC5, and it is **exploratory**. The communities are a
hypothesis generator for an analyst, not a finding for a bulletin, and the view
states the modularity on its own face so nobody reads more into the picture
than the number supports.

SIC5 is not ingested by the Phase 1 pipeline - 65% of its cells are suppressed
and no Phase 1 view reads it. Rather than materialise 27 million rows to build
eight graphs, the file is streamed and aggregated to the periods needed.
"""
from __future__ import annotations

import logging
from pathlib import Path

import networkx as nx
import numpy as np
import pandas as pd
from networkx.algorithms.community import louvain_communities, modularity

from . import config as cfg

log = logging.getLogger(__name__)

SEED = 0                    # fixed: the same data must cluster the same way
CHUNK = 2_000_000
MIN_EDGE_VALUE = 0.0
MIN_COMMUNITY = 3           # smaller groups are noise, reported as "unclustered"


def stream_sic5_edges(path: Path, freq: str = "YS") -> pd.DataFrame:
    """Aggregate the SIC5 file to payer/payee/period without holding it all.

    Returns classified pairs only: SIC 00 is both the largest source and the
    largest sink, and including it produces one giant community around it.
    """
    totals: dict[tuple, float] = {}
    rows_read = 0
    for chunk in pd.read_csv(path, dtype=str, chunksize=CHUNK):
        chunk.columns = ["payer", "payee", "date", "value", "n_tx"]
        rows_read += len(chunk)
        value = pd.to_numeric(chunk.value, errors="coerce")
        keep = value.notna() & (value > MIN_EDGE_VALUE)
        keep &= ~chunk.payer.str.startswith("00") & ~chunk.payee.str.startswith("00")
        if not keep.any():
            continue
        sub = chunk[keep].copy()
        sub["value"] = value[keep]
        period = (pd.to_datetime(sub.date, format="%d-%b-%y")
                    .dt.to_period(freq[0]).dt.to_timestamp())
        grouped = sub.groupby([sub.payer, sub.payee, period],
                              sort=False).value.sum()
        for key, v in grouped.items():
            totals[key] = totals.get(key, 0.0) + float(v)

    out = (pd.Series(totals).rename("value").reset_index()
           if totals else pd.DataFrame(columns=["payer", "payee", "period", "value"]))
    if len(out):
        out.columns = ["payer", "payee", "period", "value"]
    log.info("SIC5 streamed: %s rows read, %s payer-payee-period edges",
             f"{rows_read:,}", f"{len(out):,}")
    return out


def _graph(edges: pd.DataFrame) -> nx.Graph:
    """Undirected, value-weighted. Community detection has no direction:
    two industries trading heavily either way belong together."""
    g = nx.Graph()
    for payer, payee, value in zip(edges.payer, edges.payee, edges.value):
        if payer == payee:
            continue                       # a self-loop joins nothing
        if g.has_edge(payer, payee):
            g[payer][payee]["weight"] += float(value)
        else:
            g.add_edge(payer, payee, weight=float(value))
    return g


def detect(edges: pd.DataFrame, seed: int = SEED) -> tuple[list[set], float, nx.Graph]:
    graph = _graph(edges)
    if graph.number_of_edges() == 0:
        return [], float("nan"), graph
    parts = louvain_communities(graph, weight="weight", seed=seed)
    return parts, float(modularity(graph, parts, weight="weight")), graph


def _match(previous: dict[str, set], current: list[set]) -> dict[int, str]:
    """Give a community the same key as the one it most overlaps with.

    Louvain numbers communities arbitrarily each run, so community 3 in 2019
    has nothing to do with community 3 in 2020. Without matching, following a
    cluster through time is meaningless (BUILD_SPEC 12.6 hook 6).
    """
    assigned: dict[int, str] = {}
    taken: set[str] = set()
    for i, comm in enumerate(current):
        best_key, best_overlap = None, 0.0
        for key, prev in previous.items():
            if key in taken or not (comm | prev):
                continue
            jaccard = len(comm & prev) / len(comm | prev)
            if jaccard > best_overlap:
                best_key, best_overlap = key, jaccard
        if best_key is not None and best_overlap >= 0.25:
            assigned[i] = best_key
            taken.add(best_key)
        else:
            assigned[i] = f"C{len(previous) + len(assigned) + 1:02d}"
    return assigned


def build(edges: pd.DataFrame, level: str = cfg.LEVEL_SIC5
          ) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Communities for every period, with keys that survive across periods.

    Returns (members, summary). The summary travels as its own frame rather
    than on `.attrs`, which pandas tries to serialise as JSON on the way to
    parquet and cannot.
    """
    records, summary = [], []
    previous: dict[str, set] = {}

    for period in sorted(edges.period.unique()):
        part = edges[edges.period == period]
        communities, mod, graph = detect(part)
        if not communities:
            continue
        keys = _match(previous, communities)
        carried = {}
        for i, members in enumerate(communities):
            key = keys[i]
            carried[key] = members
            if len(members) < MIN_COMMUNITY:
                key = "unclustered"
            for node in members:
                records.append({"period": period, "level": level,
                                "node": node,
                                "node_id": cfg.node_id(level, node),
                                "community_key": key,
                                "community_size": len(members)})
        previous = carried
        summary.append({"period": period, "modularity": round(mod, 4),
                        "communities": len(communities),
                        "nodes": graph.number_of_nodes(),
                        "edges": graph.number_of_edges(),
                        "density": round(nx.density(graph), 4),
                        "largest": max(len(c) for c in communities)})
        log.info("%s: %d communities, modularity %.3f, %d nodes",
                 pd.Timestamp(period).year, len(communities), mod,
                 graph.number_of_nodes())

    return pd.DataFrame(records), pd.DataFrame(summary)


def stability(members: pd.DataFrame) -> pd.DataFrame:
    """How much each community's membership changes from period to period."""
    rows = []
    periods = sorted(members.period.unique())
    for a, b in zip(periods, periods[1:]):
        before = members[members.period == a].groupby("community_key").node.apply(set)
        after = members[members.period == b].groupby("community_key").node.apply(set)
        for key in set(before.index) & set(after.index):
            x, y = before[key], after[key]
            rows.append({"period": b, "community_key": key,
                         "retained": len(x & y) / len(x | y),
                         "joined": len(y - x), "left": len(x - y),
                         "size": len(y)})
    return pd.DataFrame(rows)
