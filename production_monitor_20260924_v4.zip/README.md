# Production Monitor

Monthly monitoring of UK business-to-business payment flows (Pay.UK / Vocalink),
flagging industries whose activity has moved unusually.

Runs locally on macOS and Windows. Nothing is hosted, nothing is published.

---

> **Returning to this project after a break?** Read `PROJECT_STATE.md` first.
> It explains what this is, the decisions that look odd without context, and
> what to do next — without re-reading the code.

For what each number on a page means, where it comes from and how to
reproduce it, see **`CHANGELOG.md`** — every term, threshold and worked example
is traced to its source there.

## Quick start

**macOS** — double-click, in order:

1. `install.command` — builds an isolated environment inside this folder (once, ~3 min)
2. `run.command` — quick run: rebuilds from cache and opens the dashboard
3. `run-full.command` — full run: rebuilds from the delivery, reconciles every
   figure against the raw files, runs the tests, then opens the dashboard.
   Use this whenever a new delivery arrives.

**Windows** — double-click, in order:

1. `install.bat`
2. `run-full.bat` — first time: full rebuild, audit and tests (~15 min)
3. `run.bat` — every day after: quick, audit skipped

### If Python is not on PATH

Managed and work builds usually install Python at a fixed location and do
**not** add it to PATH, so automatic detection finds nothing. Two ways to point
the scripts at it:

- **Once, then forget it.** Create `python_path.txt` beside `install.bat`
  containing one line — the full path to `python.exe`, for example
  `C:\ONSapps\My_Python\Python_3_10\python.exe`. Everything then works by
  double-click. This file is not in the zip, so it stays specific to the
  machine it is on.
- **Or pass it in once:** open the folder in a terminal and run
  `install.bat "C:\ONSapps\My_Python\Python_3_10\python.exe"`.

`_env.bat` resolves this for all three scripts, so the rule is written once. It
also checks: the interpreter must report **3.10, 3.11 or 3.12**.

To keep the environment somewhere other than the project folder — some sites
keep them centrally — set `PRODMON_VENV`, or put the path in `venv_path.txt`.

### If the dashboard will not start: `WinError 10013`

```
PermissionError: [WinError 10013] An attempt was made to access a socket
in a way forbidden by its access permissions
```

This is **not** "the port is already in use". Windows reserves whole TCP
ranges for Hyper-V, WSL and Docker and refuses any bind inside them, even
when nothing is listening. Managed machines reserve ranges by policy too.

Run **`find-port.bat`**. It prints the reserved ranges, then tries fourteen
candidate ports by actually binding each one — the same operation the server
performs — and writes the first that works to `port.txt`. Both run scripts
read that file, on Windows and macOS alike.

If nothing binds, the restriction is the machine rather than this tool, and
the reserved-range table it prints is what to show IT.

> The first time you double-click a `.command` file on macOS, right-click it and
> choose **Open** instead — Gatekeeper blocks double-clicks on unsigned scripts
> until you have opened one once.

---

## Where the data goes

Put each monthly delivery into **`Data/incoming/`**. Filenames do not matter —
files are identified by their internal structure, because the naming changes
between releases.

| File | Needed | Notes |
|---|---|---|
| SIC2 workbook (`.xlsx`) | **Required** | Also holds the lookup sheet everything joins to |
| Regional file (`.csv`, has `payer_region`) | Optional | Enables the regional views |
| SIC5 file (`.csv`, 782 MB) | Not used yet | Ignored unless you pass `--with-sic5` |

If no data is present, `run` stops with a message telling you exactly what is
missing and where to put it.

---

## Moving this to another machine

1. Run `package.command` (macOS) or `package.bat` (Windows).
2. Copy the resulting `.zip` across.
3. Unzip, then `install` and `run` on the new machine.

The environment is **not** included in the zip — it contains platform-specific
binaries and is rebuilt by `install`. The zip carries code, data and outputs only.

---

## Requirements

- Python 3.10, 3.11 or 3.12 on PATH (or a conda environment active)
- Internet access for the one-off install
- ~2 GB disk: environment ~840 MB, data ~370 MB, outputs ~100 MB

---

## What it produces

Written to `outputs/`:

| File | Contents |
|---|---|
| `series_national.csv` | Industry × month: inflow, outflow, PFI, on classified and including-SIC-00 bases |
| `series_section.csv` | The same, aggregated to section and GDP grouping |
| `series_regional.csv` | Industry × region × month |
| `quality.csv` | Coverage, suppression and unclassified shares per month |
| `cell_stability.csv` | Counterparty relationships that move in and out of suppression |
| `revisions.csv` | What changed since the previous delivery |
| `edges/` | Edge list partitioned by level and month |
| `vintages/` | One full snapshot per delivery |

---

## Running from the command line

```bash
.venv/bin/python -m pipeline.run                # macOS
.venv\Scripts\python -m pipeline.run            # Windows

    --use-cache     re-run from the last snapshot instead of re-parsing (fast)
    --with-sic5     also ingest the 782 MB SIC5 file
    -v              verbose
```

Tests: `.venv/bin/python -m pytest tests/ -q`

---

## Documentation

- `BUILD_SPEC.md` — what is being built, and why each decision was made
- `PROJECT_PLAN.md` — findings from the data and the reasoning behind the approach
