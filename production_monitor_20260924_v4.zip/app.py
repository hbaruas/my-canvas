"""Production Monitor - local dashboard.

Reads outputs/ and contains no analytical logic. Everything shown here is
reproducible by running the pipeline, which is what makes an exported briefing
defensible.

    streamlit run app.py
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import streamlit as st

from app_pages import data, theme
from export import briefing, report

st.set_page_config(page_title="Production Monitor", page_icon="📊",
                   layout="wide", initial_sidebar_state="expanded")

# Phase 1 is the monitor as commissioned. Phase 2 is network analysis over the
# same data, kept separate and collapsed so the working tool is not cluttered
# by things that are not built yet.
# Ordered as an investigation runs: what moved, which of it is unusual, why,
# whether it persists, and how it looks over a longer window. No order suits
# everyone - people arrive with different questions and skip freely - but a
# reader going top to bottom should find each view answers the question the
# one above it raises.
PHASE_1 = ["Overview", "Movers", "Outliers", "Why did it move?", "Trends",
           "Gainers & losers"]
REFERENCE = ["Playbook", "The dataset", "Data quality", "Glossary"]
PHASE_2_BUILT = ["Structural shifts", "Influence", "Economic clusters"]
PHASE_2 = {
    "Structural anomalies":
        "Industries whose *pattern* of counterparties changes even when their "
        "totals do not.",
    "Economic clusters":
        "Groups of industries that trade more with each other than with the "
        "rest of the economy.",
}


def _export_controls() -> None:
    """Two buttons over one renderer (BUILD_SPEC 8.7)."""
    panel = data.national()
    month = panel.month.max()
    vintage = data.vintage_label()

    st.caption("**Export**")
    blocks = report.collected()
    st.download_button(
        "This view",
        data=report.render(
            f"Production Monitor - {month:%B %Y}", blocks,
            {"Source": "Pay.UK / Vocalink industry-to-industry payments",
             "Data release": vintage, "Latest month": f"{month:%B %Y}",
             "Sensitivity": "Internal - see handling note"}),
        file_name=f"production-monitor-view-{month:%Y-%m}.html",
        mime="text/html", use_container_width=True, disabled=not blocks,
        help="What is on screen now, as a single self-contained file.")
    st.download_button(
        "Monthly briefing",
        data=briefing.build(panel, data.alerts(), data.quality(), data.breaks(),
                            data.cell_stability(), month, vintage),
        file_name=f"production-monitor-briefing-{month:%Y-%m}.html",
        mime="text/html", use_container_width=True, type="primary",
        help="Headline, what changed, movers and the data-quality caveats.")
    st.caption("Self-contained: charts stay interactive with no internet "
               "connection. About 5 MB.")


def main() -> None:
    theme.install()
    report.clear()

    try:
        data.national()
    except data.OutputsMissing as exc:
        st.title("Production Monitor")
        st.error(str(exc))
        st.stop()

    # One selection across both groups. Streamlit has no single radio that can
    # carry group headings, so there are two - kept mutually exclusive by
    # clearing the other when either changes. index=None renders a group with
    # nothing selected, which is what makes that possible without a dummy
    # "none of these" option.
    st.session_state.setdefault("nav_phase1", PHASE_1[0])
    st.session_state.setdefault("nav_reference", None)
    st.session_state.setdefault("nav_phase2", None)

    def _chose_phase1() -> None:
        st.session_state.nav_reference = None
        st.session_state.nav_phase2 = None

    def _chose_reference() -> None:
        st.session_state.nav_phase1 = None
        st.session_state.nav_phase2 = None

    def _chose_phase2() -> None:
        st.session_state.nav_phase1 = None
        st.session_state.nav_reference = None

    with st.sidebar:
        st.title("Production Monitor")
        st.caption(f"Data release {data.vintage_label()}")

        st.markdown("**Phase 1 — industry shock monitor**")
        st.radio("Phase 1", PHASE_1, key="nav_phase1",
                 on_change=_chose_phase1, label_visibility="collapsed")

        st.markdown("**Reference**")
        st.radio("Reference", REFERENCE, key="nav_reference", index=None,
                 on_change=_chose_reference, label_visibility="collapsed")

        view = (st.session_state.nav_phase1 or st.session_state.nav_phase2
                or st.session_state.nav_reference)
        if view is None:                     # both cleared: fall back sensibly
            view = PHASE_1[0]
            st.session_state.nav_phase1 = view

        st.markdown("**Phase 2 — network analysis**")
        st.radio("Phase 2", PHASE_2_BUILT, key="nav_phase2", index=None,
                 on_change=_chose_phase2, label_visibility="collapsed")

        with st.expander("Phase 2 — still to build"):
            st.caption("These work on the same data, but look at the **shape** "
                       "of the payment network rather than the size of each "
                       "industry.")
            for name, blurb in PHASE_2.items():
                st.markdown(f"**{name}** — {blurb}")
            st.caption("Chokepoint analysis was tested and dropped: 80% of "
                       "industries score exactly zero at every granularity.")

        export_slot = st.container()
        st.divider()
        st.caption("UK business-to-business payment flows, Pay.UK / Vocalink. "
                   "Official statistics in development — not official "
                   "statistics, and not a measure of GDP.")

    st.title("Production Monitor")
    st.caption(f"UK business-to-business payment flows · data release "
               f"{data.vintage_label()}")
    st.divider()

    if view == "Overview":
        from app_pages import overview
        overview.render()
    elif view == "Movers":
        from app_pages import movers
        movers.render()
    elif view == "Outliers":
        from app_pages import outliers
        outliers.render()
    elif view == "Gainers & losers":
        from app_pages import leaderboard
        leaderboard.render()
    elif view == "Trends":
        from app_pages import trends
        trends.render()
    elif view == "Why did it move?":
        from app_pages import decomposition
        decomposition.render()
    elif view == "Structural shifts":
        from app_pages import shifts
        shifts.render()
    elif view == "Economic clusters":
        from app_pages import clusters
        clusters.render()
    elif view == "Influence":
        from app_pages import influence
        influence.render()
    elif view == "Playbook":
        from app_pages import playbook
        playbook.render()
    elif view == "The dataset":
        from app_pages import dataset
        dataset.render()
    elif view == "Glossary":
        from app_pages import glossary
        glossary.render()
    else:
        from app_pages import quality
        quality.render()

    with export_slot:
        _export_controls()


if __name__ == "__main__":
    main()
