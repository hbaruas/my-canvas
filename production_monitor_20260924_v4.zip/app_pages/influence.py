"""Influence — where an industry sits in the payment network.

Phase 2. The honest framing matters here, because the obvious version of this
view would mislead.

PageRank scores an industry by the money reaching it, weighted by how central
its payers are. The intuition is that importance and size should differ. On
this data they barely do: **the rank correlation between PageRank and simple
inflow is 0.992**. A PageRank league table would be a size league table with a
different name, and is not built.

What is informative is the **gap** between the two rankings. An industry ranked
well below its size is one whose money arrives from payers that are themselves
peripheral — and on this data those industries have one thing in common.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from pipeline import config as cfg

from . import data, method, theme
from export import report

def _scatter(df: pd.DataFrame, names: dict) -> go.Figure:
    p = theme.palette()
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=df.size_rank, y=df.pr_rank, mode="markers",
        marker=dict(size=9, color=p["s1"], opacity=0.55,
                    line=dict(width=1, color=p["surface"])),
        customdata=[[c, names.get(c, ""), g] for c, g in zip(df.index, df.gap)],
        hovertemplate="<b>%{customdata[0]} %{customdata[1]}</b><br>"
                      "size rank %{x:.0f} · influence rank %{y:.0f}"
                      "<br>gap %{customdata[2]:+.0f}<extra></extra>",
        showlegend=False))
    lim = max(df.size_rank.max(), df.pr_rank.max()) + 2
    fig.add_trace(go.Scatter(x=[0, lim], y=[0, lim], mode="lines",
                             line=dict(color=p["axis"], width=1, dash="dot"),
                             hoverinfo="skip", showlegend=False))
    # Name only the industries that sit furthest from the diagonal.
    for code in list(df.nsmallest(4, "gap").index) + list(df.nlargest(3, "gap").index):
        r = df.loc[code]
        fig.add_annotation(x=r.size_rank, y=r.pr_rank,
                           text=f"{code} {names.get(code,'')[:20]}",
                           showarrow=True, arrowhead=0, arrowwidth=1,
                           arrowcolor=p["axis"], ax=26, ay=-16,
                           font=dict(size=11, color=p["ink2"]))
    theme.style(fig, height=470, legend=False,
                x_title="rank by size (inflow)", y_title="rank by influence")
    fig.update_yaxes(autorange="reversed")
    fig.update_xaxes(autorange="reversed")
    return fig


def _sic00_note(month: pd.Timestamp) -> None:
    """What including SIC 00 does to this ranking, measured on this month.

    BUILD_SPEC 12.2 specified that PageRank runs classified-only, "with
    including-00 available as a diagnostic view and never as the headline".
    The classified-only half was built; the diagnostic was not, which left a
    reader with no way to see the size of the thing being excluded - and
    excluding a third of the money silently is exactly what this project is
    not supposed to do.
    """
    diag = data.network_diagnostics()
    if diag is None or diag.empty:
        return
    row = diag[diag.month == month]
    if row.empty:
        return
    r = row.iloc[0]
    share = float(r.sic00_pagerank_share)
    if not np.isfinite(share):
        return
    with st.expander("Why this ranking excludes SIC 00 Unclassified, and what "
                     "including it would do"):
        st.markdown(f"""
**This ranking is computed on classified payments only** — both ends carrying
an industry code. That is a deliberate choice, and this is the size of it.

**Add SIC 00 back and that single node takes {share:.1%} of all the influence
in the network**, in {month:%B %Y}. Not {share:.1%} of the money —
{share:.1%} of the *ranking*.

**Why it does that.** PageRank imagines somebody following payments from
industry to industry at random, and scores each industry by how often the walk
lands there. SIC 00 is both the largest source of payments and the largest
destination, so the walk falls into it and struggles to get out. One node
absorbing a third of the walk deflates every other score, and it does so
without any error or warning.

**So the two are not comparable and neither is wrong.** Classified-only asks
*"among the industries we can name, who is most central?"*. Including SIC 00
asks *"where does money go?"* and answers *"a great deal of it goes somewhere
we cannot identify"* — which is true, and is reported on the **Overview** and
**The dataset**, but it is not a ranking of industries.

**The unclassified money is never hidden.** It is {share:.0%} of the influence
and roughly two-thirds of the value, it is stated here and on every money view
via the **Basis** control, and it is excluded from *this one calculation* for
the stated reason above — not dropped.

| Diagnostic for {month:%B %Y} | |
|---|---|
| Nodes / edges | {int(r.n_nodes)} / {int(r.n_edges):,} |
| Network density | {r.density:.1%} — the median industry pays most of the others |
| SIC 00 share of PageRank if included | **{share:.1%}** |

*Recomputed from `outputs/network_diagnostics.csv` when this page opens.*
""")


def render() -> None:
    st.subheader("Influence")
    method.page_guide("influence")

    metrics = data.node_metrics()
    if metrics is None or metrics.empty:
        st.warning("No network metrics yet. Run the pipeline.")
        return

    panel = data.national()
    names = dict(zip(panel.sic2, panel["name"]))
    edges = data.edges()

    months = sorted(metrics.month.unique(), reverse=True)
    c1, c2 = st.columns([1.2, 2])
    with c1:
        month = pd.Timestamp(st.selectbox(
            "Month", months, index=0,
            format_func=lambda m: pd.Timestamp(m).strftime("%b %Y")))

    cur = metrics[metrics.month == month]
    wide = cur.pivot_table(index=cur.node_id.str.split(":").str[-1],
                           columns="metric", values="value")
    df = wide.dropna(subset=["pagerank", "in_strength"]).copy()
    df["pr_rank"] = df.pagerank.rank(ascending=False, method="min")
    df["size_rank"] = df.in_strength.rank(ascending=False, method="min")
    df["gap"] = df.size_rank - df.pr_rank      # negative = below its size

    rho = df.pr_rank.corr(df.size_rank, method="spearman")
    a, b, c = st.columns(3)
    a.metric("Industries", f"{len(df)}")
    b.metric("Influence vs size", f"ρ = {rho:.3f}",
             help="Spearman rank correlation. Near 1 means influence is "
                  "almost entirely explained by size, which is why this page "
                  "shows the gap rather than the ranking.")
    c.metric("Ranked 5+ places apart", f"{int(df.gap.abs().ge(5).sum())}")

    # Hook 8 of BUILD_SPEC 12.6: the diagnostic travels with the output it
    # qualifies. For PageRank that diagnostic is what SIC 00 does to the walk.
    _sic00_note(month)

    st.info(
        f"**PageRank and size rank industries almost identically here "
        f"(ρ = {rho:.3f}).** The ranking on its own adds nothing to a size "
        f"ranking. What follows is about the {int(df.gap.abs().ge(5).sum())} "
        f"industries where the two disagree."
    )

    # --- value against volume --------------------------------------------
    if "pagerank_volume" in wide.columns:
        vol = wide.dropna(subset=["pagerank", "pagerank_volume"]).copy()
        vol["by_value"] = vol.pagerank.rank(ascending=False, method="min")
        vol["by_volume"] = vol.pagerank_volume.rank(ascending=False, method="min")
        vol["vgap"] = vol.by_volume - vol.by_value
        rho_v = vol.by_value.corr(vol.by_volume, method="spearman")
        st.markdown("### Influence by value, or by number of payments")
        st.markdown(
            f"PageRank can follow the **money** or the **count of payments**. "
            f"They agree less than you might expect (ρ = {rho_v:.3f}), and the "
            f"disagreement separates sectors that settle in a few large "
            f"payments from those that bill constantly in small ones."
        )
        cL, cR = st.columns(2)
        with cL:
            st.markdown("**More central by value** — few, large settlements")
            t = vol.nlargest(5, "vgap")
            st.dataframe(pd.DataFrame({
                "Industry": [f"{c} {names.get(c, '')}" for c in t.index],
                "Places higher by value": t.vgap.astype(int),
            }), use_container_width=True, hide_index=True)
        with cR:
            st.markdown("**More central by volume** — many, small payments")
            t = vol.nsmallest(5, "vgap")
            st.dataframe(pd.DataFrame({
                "Industry": [f"{c} {names.get(c, '')}" for c in t.index],
                "Places higher by volume": (-t.vgap).astype(int),
            }), use_container_width=True, hide_index=True)
        st.caption(
            "Construction and civil engineering sit far higher by value: large, "
            "infrequent settlements. Water, telecoms and postal sit higher by "
            "volume: constant small billing. Neither is more important — but a "
            "disruption affects them differently, and a payment-count measure "
            "notices things a value measure cannot."
        )
        st.divider()

    fig = _scatter(df, names)
    st.plotly_chart(fig, use_container_width=True,
                    config={"displayModeBar": False})
    st.caption("Points on the dotted line rank the same way by size and by "
               "influence. Points below it punch above their weight; points "
               "above it are large but peripheral.")
    report.heading(f"Influence vs size — {month:%B %Y}")
    report.figure(fig, "Rank by size against rank by network influence.")

    # ---- the interesting half: who funds the outliers -------------------
    st.markdown("### Large, but outside the business-to-business network")
    st.markdown(
        "These industries receive substantially less influence than their size "
        "implies. The reason is visible in who pays them."
    )
    rows = []
    for code, r in df.nsmallest(8, "gap").iterrows():
        sel = edges[(edges.payee == code) & (edges.month == month)
                    & (edges.payer != cfg.UNCLASSIFIED_SIC)]
        top = sel.nlargest(1, "value")
        payer = top.payer.iloc[0] if len(top) else "—"
        share = (top.value.iloc[0] / sel.value.sum()) if len(top) and sel.value.sum() else np.nan
        rows.append({
            "Industry": f"{code} {names.get(code, '')}",
            "Size rank": f"{r.size_rank:.0f}",
            "Influence rank": f"{r.pr_rank:.0f}",
            "Gap": f"{r.gap:+.0f}",
            "Largest payer": f"{payer} {names.get(payer, '')}"[:34],
            "Its share": f"{share:.0%}" if np.isfinite(share) else "—",
        })
    table = pd.DataFrame(rows)
    st.dataframe(table, use_container_width=True, hide_index=True)
    report.table(table, "Industries ranked below their size by network influence.")

    top_payers = [r["Largest payer"].split()[0] for r in rows]
    common = pd.Series(top_payers).value_counts()
    if len(common) and common.iloc[0] >= 3:
        code = common.index[0]
        st.success(
            f"**{common.iloc[0]} of the {len(rows)} are funded principally by "
            f"SIC {code} {names.get(code, '')}.** That is what the gap is "
            f"detecting: money from a payer that itself receives little passes "
            f"on little influence. These industries are large, but they sit "
            f"outside the circulation of business-to-business payments — which "
            f"is not visible in any size ranking."
        )

    # ---- drift over time ------------------------------------------------
    st.markdown("### Has an industry's position moved?")
    codes = sorted(df.index)
    pick = st.selectbox("Industry", codes,
                        index=codes.index("64") if "64" in codes else 0,
                        format_func=lambda c: f"{c} {names.get(c, '')}")
    series = metrics[(metrics.metric == "pagerank")
                     & (metrics.node_id.str.endswith(f":{pick}"))] \
        .sort_values("month")
    p = theme.palette()
    line = go.Figure()
    line.add_trace(go.Scatter(
        x=series.month, y=series.value * 100, mode="lines",
        line=dict(color=p["s1"], width=2), connectgaps=False,
        hovertemplate="%{x|%b %Y}<br>%{y:.2f}% of network influence<extra></extra>"))
    theme.style(line, height=280, legend=False, y_title="% of total influence")
    st.plotly_chart(line, use_container_width=True,
                    config={"displayModeBar": False})
    st.caption(
        "PageRank is a share of the whole network, so every industry's score "
        "moves when the network's composition moves. A month-to-month wobble is "
        "usually that; a sustained drift is the industry."
    )
    report.figure(line, f"Network influence over time — {pick} {names.get(pick,'')}.")
