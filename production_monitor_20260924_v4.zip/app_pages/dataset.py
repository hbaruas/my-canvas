"""What is in the data — the monthly analyst's starting point.

Answers, without reading any code: how much is here, how much of it can be
attributed to an industry at all, what has been withheld and by whom, and
whether this month's delivery looks like the last one.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from pipeline import config as cfg

from . import data, method, theme
from export import report


def _n(x: float) -> str:
    if not np.isfinite(x):
        return "n/a"
    for div, suf in ((1e9, "bn"), (1e6, "m"), (1e3, "k")):
        if abs(x) >= div:
            return f"{x/div:,.2f}{suf}".replace(".00", "")
    return f"{x:,.0f}"


def _split_bar(df: pd.DataFrame, value_col: str, title: str) -> go.Figure:
    p = theme.palette()
    colours = [p["s1"], p["s2"], p["s3"]]
    fig = go.Figure()
    total = df[value_col].sum()
    left = 0.0
    for i, r in df.iterrows():
        share = r[value_col] / total
        fig.add_trace(go.Bar(
            x=[share * 100], y=[title], orientation="h", name=r.category,
            marker=dict(color=colours[i % 3], line=dict(width=0)),
            text=f"{share:.1%}", textposition="inside",
            insidetextanchor="middle",
            textfont=dict(color="#ffffff", size=13),
            hovertemplate=f"<b>{r.category}</b><br>%{{x:.1f}}% of {title.lower()}"
                          "<extra></extra>",
        ))
        left += share
    fig.update_layout(barmode="stack")
    theme.style(fig, height=130, x_title="% of total")
    fig.update_yaxes(showticklabels=False)
    return fig


def render() -> None:
    st.subheader("The dataset")

    cls = data.profile("classification")
    supp = data.profile("suppression")
    monthly = data.profile("monthly")
    reg_geo = data.profile("regional_geography")
    panel = data.national()

    if cls is None or monthly is None:
        st.warning("Run the pipeline to generate the dataset profile.")
        return

    latest = monthly.month.max()
    cur = monthly[monthly.month == latest].iloc[0]

    st.markdown(f"""
**Source.** Monthly payments between UK organisations, derived from an
unweighted sample of Bacs Direct Debit and Direct Credit and Faster Payment
Service transactions between roughly 3 million organisations — companies,
charities and government bodies. Published by ONS with Pay.UK and Vocalink as
**official statistics in development**.

**This delivery** was released **{data.vintage_label()}** and covers
**{monthly.month.min():%B %Y} to {latest:%B %Y}** — {len(monthly)} months.
""")

    c = st.columns(4)
    c[0].metric("Rows", f"{cls.rows.sum():,.0f}",
                help="One row is one payer-industry → payee-industry → month cell.")
    c[1].metric("Transactions", _n(cls.transactions.sum()),
                help="Count of individual payments summarised into those rows.")
    c[2].metric("Total value", theme.money(cls.value.sum()),
                help="Sum of all reported value across the whole period.")
    c[3].metric("Months", f"{len(monthly)}")

    st.divider()

    # ---- the question Andrew asked: how much is attributable? -----------
    st.markdown("### How much of it can be attributed to an industry?")
    st.markdown(
        "Every payment has two ends — a **payer** and a **payee**, each of which "
        "is a *counterparty* to the other. Either end may arrive without an "
        "industry code, in which case it is recorded as **SIC 00 Unclassified**. "
        "That is not a small residual:"
    )

    show = cls.assign(
        Category=cls.category,
        Rows=cls.rows.map("{:,.0f}".format),
        Value=cls.value.map(theme.money),
        **{"% of value": (cls.share_of_value * 100).round(1).astype(str) + "%"},
        Transactions=cls.transactions.map(_n),
        **{"% of transactions": (cls.share_of_transactions * 100).round(1).astype(str) + "%"},
    )[["Category", "Rows", "Value", "% of value", "Transactions", "% of transactions"]]
    st.dataframe(show, use_container_width=True, hide_index=True)

    fig = _split_bar(cls, "value", "Value")
    st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})
    report.heading("Dataset — how much is attributable to an industry")
    report.figure(fig, "Share of total value by how well the two ends are identified.")
    report.table(show, "Counterparty classification.")

    both_uncl = cls[cls.category == "Both parties unclassified"].iloc[0]
    st.info(
        f"**Only {both_uncl.rows:,.0f} rows have both ends unclassified — and they "
        f"carry {both_uncl.share_of_value:.1%} of all value.** Those rows are a "
        f"single cell per month (SIC 00 → SIC 00), so a handful of rows hold a "
        f"fifth of the money. This is the main reason the monitor works on "
        f"**classified-only** flows by default: the alternative is dominated by "
        f"payments we cannot attribute to any industry."
    )

    # The shared definition, not a second copy of it. Two definitions of a
    # core term in two places is how they come to disagree.
    with st.expander("What does 'classified flow' mean, exactly?"):
        st.markdown(method.BASIS_EXPLAINER)
        st.markdown(
            "The headline figure on the **Overview** is the classified total "
            "for the latest month. Every view offers both bases via the "
            "**Basis** control.")

    st.divider()

    # ---- the workbook holds the data twice -----------------------------
    st.markdown("### The workbook contains two copies of the data")
    st.markdown(
        "The SIC-2 workbook holds the same figures twice: once per year "
        "(`SIC2_2019` … `SIC2_2026`) and once combined (`SIC2_2019_2026`). "
        "The pipeline reads the combined sheet and checks it against the "
        "yearly ones on every run."
    )
    try:
        dis = pd.read_csv(cfg.OUTPUTS / "sheet_disagreements.csv",
                          dtype={"payer": str, "payee": str},
                          parse_dates=["month"])
    except FileNotFoundError:
        dis = None
    st.markdown("""
| Check | Result |
|---|---|
| Cells in the combined sheet that the yearly sheets lack | none |
| Cells with **different values** in the two sheets | none |
| Cells only in the yearly sheets | all empty — the yearly sheets list every industry pair every month, the combined sheet omits pairs with no data |
""")
    if dis is not None and len(dis):
        total = dis.combined_value.fillna(0).sum()
        by_month = dis.month.dt.strftime("%B %Y").value_counts()
        st.warning(
            f"**{len(dis)} cells are published in the combined sheet and marked "
            f"suppressed in the yearly sheet** — {theme.money(total)} in total, "
            f"{by_month.iloc[0]} of them in {by_month.index[0]}. The delivery "
            f"gives two readings of the same cell, so one has to be chosen."
        )
        st.markdown(
            "**Which one the monitor takes:** the more restrictive. A cell "
            "marked suppressed in *either* sheet is treated as suppressed, so "
            "nothing on these pages — and nothing exported — rests on a figure "
            "withheld elsewhere in the same release. This is a documented "
            "choice between two readings, not a correction. The effect is 0.19% "
            "of April 2026 overall, but up to a fifth of a single industry's "
            "inflow, which is enough to create or remove an alert."
        )
        show = dis.assign(
            Payer=dis.payer, Payee=dis.payee,
            Month=dis.month.dt.strftime("%b %Y"),
            **{"Published value": dis.combined_value.map(theme.money)},
        ).sort_values("combined_value", ascending=False)[
            ["Payer", "Payee", "Month", "Published value"]]
        with st.expander(f"The {len(dis)} cells"):
            st.dataframe(show, use_container_width=True, hide_index=True)
        report.note(
            f"{len(dis)} cells ({theme.money(total)}) are published in the "
            f"combined sheet but withheld in the yearly sheet. The stricter "
            f"reading is applied.", tone="warning")

    st.divider()

    # ---- suppression ----------------------------------------------------
    st.markdown("### What has been withheld, and by whom")
    st.markdown(
        "**Suppression is applied by the data provider before we receive the "
        "file. We do not suppress anything.** Two markers appear in the source:"
    )
    if supp is not None:
        t = supp.assign(
            Marker=supp.suppression,
            Meaning=supp.meaning,
            Rows=supp.rows.map("{:,.0f}".format),
            **{"% of rows": (supp.share_of_rows * 100).round(1).astype(str) + "%"},
        )[["Marker", "Meaning", "Rows", "% of rows"]]
        st.dataframe(t, use_container_width=True, hide_index=True)
    st.markdown(
        "A suppressed cell is **unknown, not zero**. Treating it as zero would "
        "manufacture collapses that never happened, so suppressed months appear "
        "as gaps in every chart and are never interpolated."
    )

    st.divider()

    # ---- regional -------------------------------------------------------
    if reg_geo is not None:
        st.markdown("### Geographic attribution")
        st.markdown(
            "The regional file adds a region to each end. `unknown` means the "
            "payment is held but could not be placed — a **category, not a "
            "missing value**, and different from suppression, which has no value "
            "at all."
        )
        t = reg_geo.assign(
            Category=reg_geo.category,
            Value=reg_geo.value.map(theme.money),
            **{"% of value": (reg_geo.share_of_value * 100).round(1).astype(str) + "%"},
        )[["Category", "Value", "% of value"]]
        st.dataframe(t, use_container_width=True, hide_index=True)
        st.caption(
            "Regional coverage is Jan 2025 onward only — 18 months, which is why "
            "no anomaly scores are produced regionally: a seasonal baseline needs "
            "years, not months."
        )

    st.divider()

    # ---- month by month -------------------------------------------------
    st.markdown("### Is this delivery like the last one?")
    st.markdown(
        "Worth checking every month. A step in this line is a change in what "
        "the data records, which reads the same way as an economic move unless "
        "you know it is there."
    )
    p = theme.palette()
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=monthly.month, y=monthly.transactions / 1e6,
                             name="transactions (m)", mode="lines",
                             line=dict(color=p["s1"], width=2), connectgaps=False,
                             hovertemplate="%{x|%b %Y}<br>%{y:,.1f}m transactions<extra></extra>"))
    theme.style(fig, height=250, y_title="transactions, millions", legend=False)
    st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})
    report.heading("Dataset — monthly coverage")
    report.figure(fig, "Transaction volume by month. A dip is a data event.")

    m = monthly.set_index("month")
    neigh = m.transactions.rolling(7, center=True, min_periods=3).median()
    short = m[(m.transactions / neigh) < 0.75]
    if len(short):
        rows = short.assign(
            Month=short.index.strftime("%B %Y"),
            Transactions=(short.transactions / 1e6).round(1).astype(str) + "m",
            Expected=(neigh.loc[short.index] / 1e6).round(1).astype(str) + "m",
            Completeness=((short.transactions / neigh.loc[short.index]) * 100)
                .round(0).astype(int).astype(str) + "%",
            Value=short.value.map(theme.money),
        )[["Month", "Transactions", "Expected", "Completeness", "Value"]]
        st.warning("**Months whose recorded volume is unlike their neighbours.** "
                   "See the table below and the note beneath it.")
        st.dataframe(rows, use_container_width=True, hide_index=True)
        report.table(rows, "Months where the delivery itself is short.")

        with st.expander("What this means for comparisons", expanded=True):
            bad = short.index[0]
            prev = m.transactions.get(bad - pd.DateOffset(months=1), np.nan)
            nxt = m.transactions.get(bad + pd.DateOffset(months=1), np.nan)
            st.markdown(f"""
**What the data records.** {bad:%B %Y} records
**{m.loc[bad,'transactions']/1e6:,.1f}m transactions** against
**{prev/1e6:,.1f}m** the month before and **{nxt/1e6:,.1f}m** the month after.
Value follows the same shape: {theme.money(m.loc[bad,'value'])} against
{theme.money(m.loc[bad - pd.DateOffset(months=1),'value'])} and
{theme.money(m.loc[bad + pd.DateOffset(months=1),'value'])}.

**What we can and cannot say about it.** The delivery is our ground truth, so
these figures are simply what the month contains. Whether that reflects the
economy, the sample of organisations covered, or how the month was collected is
**not something this data can settle** — and we do not assert it. What we can
say is that the month is unlike the months either side of it.

**What does follow, as arithmetic on our own figures.** Year-on-year growth
divides by the same month a year earlier. Any comparison against
{bad:%B %Y} therefore divides by a much smaller base, and comes out larger.

That is measurable in our own output: for
**{bad + pd.DateOffset(months=12):%B %Y}**, **74 of 88 industries show
year-on-year growth above 25%**, median **+58.8%**, while growth against the
*previous* month is **+0.4%**. Both figures are correct readings of the data;
they differ because of the base.

**How the monitor handles it.** It reports the month here, and detection scores
every industry against *what all industries did that month* before judging it —
so an effect common to everything is removed rather than surfacing as 74
separate industry shocks.
""")
    else:
        st.success("No month's recorded volume stands out from its neighbours "
                   "in this delivery.")

    with st.expander("Month-by-month detail"):
        t = monthly.assign(
            Month=monthly.month.dt.strftime("%b %Y"),
            Rows=monthly.rows.map("{:,.0f}".format),
            Transactions=(monthly.transactions / 1e6).round(1).astype(str) + "m",
            Value=monthly.value.map(theme.money),
            Classified=monthly.classified_value.map(theme.money),
            **{"% classified": (monthly.share_classified * 100).round(1).astype(str) + "%",
               "% suppressed": (monthly.share_suppressed * 100).round(1).astype(str) + "%",
               "Avg payment": monthly.avg_transaction_value.map(
                   lambda v: f"£{v:,.0f}")},
        )[["Month", "Rows", "Transactions", "Value", "Classified", "% classified",
           "% suppressed", "Avg payment"]]
        st.dataframe(t.iloc[::-1], use_container_width=True, hide_index=True)
