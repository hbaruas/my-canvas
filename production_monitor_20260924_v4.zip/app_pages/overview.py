"""Overview — the month at a glance.

Its own view rather than a banner on every page. Shows the same total on both
bases, because a payment to a counterparty we cannot identify still moved real
money, and both month-on-month and year-on-year, because the two answer
different questions.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from . import data, method, theme
from export import report

def _delta(series: pd.Series, month: pd.Timestamp, months_back: int) -> float:
    prior = month - pd.DateOffset(months=months_back)
    if prior not in series.index or month not in series.index:
        return np.nan
    base = series.loc[prior]
    return (series.loc[month] / base - 1) if base else np.nan


def _trend(q: pd.DataFrame, latest: pd.Timestamp) -> go.Figure:
    p = theme.palette()
    fig = go.Figure()
    for col, name, colour in (("total_value", "All flow", p["s2"]),
                              ("classified_value", "Classified only", p["s1"])):
        fig.add_trace(go.Scatter(
            x=q.month, y=q[col] / 1e9, name=name, mode="lines",
            line=dict(color=colour, width=2), connectgaps=False,
            hovertemplate="%{x|%b %Y}<br><b>" + name + "</b> £%{y:,.1f}bn"
                          "<extra></extra>"))
    theme.style(fig, height=300, y_title="£bn per month")
    return fig


def render() -> None:
    st.subheader("Overview")
    method.page_guide("overview")

    q = data.quality().sort_values("month")
    panel = data.national()
    alerts = data.alerts()
    latest = panel.month.max()
    series_all = q.set_index("month").total_value
    series_cls = q.set_index("month").classified_value
    cur = q[q.month == latest].iloc[0]

    st.markdown(f"#### {latest:%B %Y}")
    left, right = st.columns(2)
    with left:
        st.markdown("**All flow** — every payment, including SIC 00")
        a, b, c = st.columns(3)
        a.metric("Value", theme.money(cur.total_value))
        b.metric("Month on month", f"{_delta(series_all, latest, 1):+.1%}")
        c.metric("Year on year", f"{_delta(series_all, latest, 12):+.1%}")
    with right:
        st.markdown("**Classified only** — both ends identified")
        a, b, c = st.columns(3)
        a.metric("Value", theme.money(cur.classified_value))
        b.metric("Month on month", f"{_delta(series_cls, latest, 1):+.1%}")
        c.metric("Year on year", f"{_delta(series_cls, latest, 12):+.1%}")

    st.caption(
        f"Payments with at least one unidentified end — **SIC 00 "
        f"Unclassified** — account for "
        f"**{cur.share_unclassified:.0%}** of all value this month. That money "
        f"moved; we simply cannot attribute one end of it to an industry. Every "
        f"view offers both bases."
    )

    st.divider()
    fig = _trend(q, latest)
    st.plotly_chart(fig, use_container_width=True,
                    config={"displayModeBar": False})
    report.heading(f"Overview — {latest:%B %Y}")
    report.figure(fig, "Monthly payment value on both bases.")

    st.divider()
    d, e, f = st.columns(3)
    d.metric("Data ends", f"{latest:%b %Y}",
             help=f"{panel.month.nunique()} months. "
                  f"Delivery released {data.vintage_label()}.")
    e.metric("Cells suppressed", f"{cur.share_cells_suppressed:.0%}",
             help="Withheld by the data provider for disclosure control. "
                  "We suppress nothing. A suppressed cell is unknown, not zero.")
    fired = alerts[(alerts.month == latest) & (alerts.level == "division")
                   & (alerts.measure == "pfi") & (alerts.basis == "YoY")
                   & (alerts.severity >= 63)]
    f.metric("Industries flagged", f"{fired.code.nunique()}",
             help="Moved unusually against their own history this month. "
                  "See Movers and Outliers.")

    if bool(cur.get("volume_outlier", False)):
        st.warning(
            f"**{latest:%B %Y} records {cur.n_tx/1e6:,.0f}m transactions**, "
            f"against a median of {cur.n_tx/cur.volume_vs_neighbours/1e6:,.0f}m "
            f"in the months around it. Comparisons against this month divide by "
            f"that smaller base — see **The dataset**.")

    if len(fired):
        st.markdown("**What changed this month**")
        st.caption(
            "The three industries that moved most unusually against their own "
            "history, year on year, on the classified basis. Each line has the "
            "same shape every month: **what moved**, then **what kind of cause "
            "it was**, then **the largest single contributor and what share of "
            "the move it accounts for**."
        )
        for r in fired.nlargest(3, "severity").itertuples():
            if isinstance(r.driver_line, str) and len(r.driver_line) > 3:
                st.markdown(f"- {r.driver_line}")
        st.caption("Full detail in **Movers**, and the cause in "
                   "**Why did it move?**")
