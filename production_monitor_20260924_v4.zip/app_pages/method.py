"""Method explanations, with the arithmetic shown.

Every number a reader sees on this dashboard has to be traceable to a
calculation they could repeat on a calculator. This module is the single place
those calculations are written down, so the same words appear on every view
that uses the same term.

Two rules govern everything in here.

1. **No claim without its arithmetic.** Where a threshold is used, this module
   states the formula, the number that comes out of it, and where the
   convention came from.
2. **No example that expires.** Illustrations of a *method* use round invented
   numbers so they read the same in five years. Illustrations of *this
   dataset* are recomputed from the current outputs every time the page opens,
   so they can never describe a month that is no longer there.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import streamlit as st

from pipeline import decompose, detect

from . import data, explain

# ---------------------------------------------------------------------------
# Basis: which payments are counted
# ---------------------------------------------------------------------------

BASIS_EXPLAINER = """
**"Basis" means: which payments are counted.** It is a choice about coverage,
not about arithmetic. The same industry, the same month, can be summed two
ways.

| Basis | Counts a payment when | 
|---|---|
| **Classified only** | **Both** ends carry a real industry code |
| **Including SIC 00** | **Either** end may be unidentified — those payments are counted too, under the label **SIC 00 Unclassified** |

**Why two answers, not one.** About a third of the money in this data has an
end we cannot name. That money moved. A business really did pay it and another
really did receive it. We simply do not know which industry one of them belongs
to. Leaving it out gives a clean, stable series; putting it in gives the full
amount but moves whenever the identification improves or worsens.

#### Worked example — invented, round numbers

An industry receives payments from two kinds of partner.

| | Month 1 | Month 2 | Change |
|---|---|---|---|
| From partners we can identify | £100m | £110m | **+£10m, +10%** |
| From partners we cannot identify (SIC 00) | £200m | £90m | −£110m, −55% |
| **All flow** (the two added) | £300m | £200m | **−£100m, −33%** |

On the **classified** basis this industry **rose 10%**.
On the **all flow** basis the same industry **fell 33%**.

Neither figure is wrong and neither is the "real" one. They answer different
questions. Classified asks *"among the partners we can name, did more money
move?"*. All flow asks *"did more money move in total?"*.

**So always say which one you quoted.** A rise on one basis beside a fall on
the other is the normal state of affairs whenever identification changes, and
it is not a contradiction.

#### Three things the classified total is not

- **It is not a growth rate.** It is a value, in pounds.
- **It is not different depending on whether you call it inflow or outflow** —
  at whole-economy level. Every pound paid by one industry is received by
  another, so summing either side across all industries gives the identical
  total. The distinction only matters for an individual industry.
- **It does not treat a withheld cell as zero.** A withheld cell has no value
  to add. It is unknown, not nil, and nothing is invented to fill it.
"""




# ---------------------------------------------------------------------------
# Severity
# ---------------------------------------------------------------------------

SEVERITY_FIRES = 63

SEVERITY_METHOD = """
**Severity answers one question: how far is this month's move from what this
industry normally does?** It is not a measure of size. A £50m move in a small,
steady industry can score higher than a £2bn move in a large, erratic one, and
that is the intention.

It is built in six steps. Every step is arithmetic you can repeat.

| Step | What happens | Why |
|---|---|---|
| 1 | Take the industry's monthly series | The comparison is always against itself, never against other industries |
| 2 | Take the **log change** against the same month a year earlier | Logs make a +50% and a −33% move the same size, so a rise and a fall are treated even-handedly |
| 3 | Subtract the **common component** — the middle value of that same log change across all industries this month | An industry that moved because *everything* moved has not had an industry shock |
| 4 | Compare what is left against the **middle of this industry's own past**, measured with the median and the MAD rather than the mean and standard deviation | One past spike would stretch a standard deviation and hide everything after it. The median and MAD cannot be dragged by a single point |
| 5 | **Discount for a short history** using the t distribution on the number of months actually observed | A yardstick measured from 15 months is itself uncertain. Without this, a thin baseline produces an undeservedly high score |
| 6 | Map the result onto **0–100** with a saturating curve | So the number has a floor and a ceiling and can be sorted and filtered |

Only history **before** the month being scored is used. A shock never
contributes to the yardstick it is measured against.
"""

SEVERITY_SCALE_METHOD = """
#### Where 63 comes from

Step 6 is this formula, and nothing else:

$$\\text{severity} = 100 \\times \\left(1 - e^{-|z| / 3}\\right)$$

Put |z| = 3 into it:

    severity = 100 × (1 − e^(−3/3))
             = 100 × (1 − e^(−1))
             = 100 × (1 − 0.3679)
             = 63.2

So **63 is not a tuned number. It is what the formula returns at |z| = 3**,
and you can check it on any calculator. The whole curve:

| \\|z\\| | 1 | 2 | **3** | 4 | 4.5 | 6 | 9 |
|---|---|---|---|---|---|---|---|
| severity | 28 | 49 | **63** | 74 | 78 | 86 | 95 |

#### Why |z| = 3, and not some other number

|z| = 3 is the **three-sigma rule**, the oldest convention in statistical
process control — it is the control limit Walter Shewhart set in 1931 and it
is still the default in quality and outlier work. Under a normal bell curve, a
point three or more standard deviations from the middle happens about
**0.27% of the time — roughly 1 observation in 370**.

We did not invent the threshold, and we are not asking anyone to take it on
trust: the arithmetic above shows how 3 becomes 63, and the check below shows
what it actually does to *this* data.
"""


@st.cache_data(ttl=600, show_spinner=False)
def _severity_empirics() -> dict:
    """What the 63 threshold does on this dataset, measured not assumed."""
    a = data.alerts()
    d = a[(a.level == "division") & (a.basis == "YoY")]
    if d.empty:
        return {}
    fired = d[d.severity >= SEVERITY_FIRES]
    per_month = (d[(d.measure == "pfi") & (d.severity >= SEVERITY_FIRES)]
                 .groupby("month").code.nunique())
    scored = d[d.measure == "pfi"]
    return {
        "n_scored": int(len(d)),
        "share_fired": float((d.severity >= SEVERITY_FIRES).mean()),
        "per_month_mean": float(per_month.mean()) if len(per_month) else float("nan"),
        "per_month_median": float(per_month.median()) if len(per_month) else float("nan"),
        "per_month_max": int(per_month.max()) if len(per_month) else 0,
        "n_months": int(scored.month.nunique()),
        "n_codes": int(scored.code.nunique()),
        "conf_mix": fired.confidence.value_counts(normalize=True).to_dict(),
    }


def severity_reality_check() -> str:
    """The honest paragraph: what the threshold does here, not in a textbook."""
    e = _severity_empirics()
    if not e:
        return ""
    normal_rate = 0.0027
    ratio = e["share_fired"] / normal_rate if e["share_fired"] else float("nan")
    return f"""
#### What 63 actually does to this data — measured, not assumed

If payment flows followed a normal bell curve, 63 would flag about **0.27%** of
industry-months. On the {e['n_scored']:,} industry-months scored here it flags
**{e['share_fired']:.1%}** — about **{ratio:.0f} times more often**.

**That is not a fault in the threshold and it is not a fault in the data.**
It is what payment flows look like. Business-to-business payment series have
much fatter tails than a bell curve: large one-off settlements, contract
renewals and year-end payments are ordinary events, not rare ones. A
normal-curve probability was never going to survive contact with this series.

**So read 63 for what it is: a dial, not a verdict.** It means *"about as far
from normal as a three-sigma move"*, which in this data puts roughly
{e['per_month_median']:.0f} industries on the page in a typical month (mean
{e['per_month_mean']:.1f}, most ever {e['per_month_max']}, across
{e['n_months']} months and {e['n_codes']} industries). That is a readable
shortlist, which is the job it has to do. Move the slider down to browse more
and up to see only extremes — nothing breaks either way, because the score
underneath is continuous.

**Never write "significant" on the strength of this number alone.** It is a
distance from an industry's own recent history. It is not a hypothesis test, it
carries no p-value that would survive these tails, and it says nothing about
whether the cause was economic — that is what confidence is for.
"""


SEVERITY_BASIS_NOTE = """
#### One thing that surprises people

**Severity does not change when you switch between MoM and YoY.** The score is
computed once per industry-month from three signals, none of which is a
month-on-month comparison. Switching the comparison changes the **£ change**,
the **% change** and the **common component** shown beside the score — it does
not change the score. This is deliberate, and it is stated here rather than
left for someone to discover.
"""


@st.cache_data(ttl=600, show_spinner=False)
def _severity_worked(measure: str = "pfi") -> dict | None:
    """Recompute one real alert end to end, exposing every intermediate.

    Chosen live rather than hard-coded so the example can never refer to a
    month that has dropped out of the data. The preference order is: latest
    month, highest severity, full (non-provisional) baseline, high confidence —
    because a worked example should not also need a caveat.
    """
    try:
        panel = data.national()
        alerts = data.alerts()
    except Exception:
        return None
    d = alerts[(alerts.level == "division") & (alerts.measure == measure)
               & (alerts.basis == "YoY")]
    if d.empty:
        return None
    latest = d.month.max()
    here = d[d.month == latest].copy()
    # A clean example: scored on the year-on-year signal, on a full baseline.
    prefer = here[(here.confidence == "high")
                  & (~here.provisional.astype(bool))
                  & (here.z_yoy.abs() >= 3)]
    pick = prefer if len(prefer) else here
    row = pick.sort_values("severity", ascending=False).iloc[0]
    code = str(row.code)

    common = detect.common_component(panel, measure, 12)
    g = panel[panel.sic2 == code].sort_values("month").set_index("month")
    if latest not in g.index:
        return None
    logs = np.log(g[measure].where(g[measure] > 0))
    yoy_raw = logs.diff(12)
    yoy = yoy_raw - common.reindex(yoy_raw.index)
    seg = (g["segment_start"].iloc[0] if "segment_start" in g else pd.NaT)
    usable = detect._baseline_mask(g.index, seg)
    i = list(g.index).index(latest)
    hist = yoy.iloc[:i][usable.iloc[:i]].dropna()
    if len(hist) < detect.MIN_HISTORY:
        return None
    med, mad = float(hist.median()), detect._mad(hist)
    if not np.isfinite(mad):
        return None
    base_month = latest - pd.DateOffset(months=12)
    ratio = (float(yoy.loc[latest]) - med) / mad
    z = detect._finite_sample_z(ratio, len(hist))
    return {
        "signals": {"z_level": float(row.z_level), "z_yoy": float(row.z_yoy),
                    "cusum": float(row.cusum)},
        "code": code, "name": str(row["name"]), "month": latest,
        "base_month": base_month, "measure": measure,
        "now": float(g.loc[latest, measure]),
        "base": float(g.loc[base_month, measure])
        if base_month in g.index else float("nan"),
        "log_change": float(yoy_raw.loc[latest]),
        "common": float(common.loc[latest]),
        "excess": float(yoy.loc[latest]),
        "n_hist": int(len(hist)), "median": med, "mad": mad,
        "ratio": ratio, "z": z,
        "severity_uncorrected": 100 * (1 - np.exp(-abs(ratio) / 3)),
        "severity": float(row.severity),
        "stored_z": float(row.z_yoy),
    }


def _which_signal_won(w: dict) -> str:
    """Reconcile the recomputed figure against the published one, on screen.

    Severity is the strongest of three signals, so a worked example of one
    signal need not equal the published score. Saying which signal won, and
    checking the two agree when it is the one shown, is the difference between
    a demonstration and an assertion.
    """
    sig = w["signals"]
    winner = max(sig, key=lambda k: abs(sig[k]) if np.isfinite(sig[k]) else -1)
    recomputed = 100 * (1 - np.exp(-abs(w["z"]) / 3))
    names = {"z_level": "single-month deviation",
             "z_yoy": "year-on-year deviation",
             "cusum": "six-month drift"}
    lines = [f"The published severity for this row is "
             f"**{w['severity']:.1f}**. Severity is the **strongest of three "
             f"signals**, and for this industry-month the winner was the "
             f"**{names[winner]}** (z = {sig[winner]:+.3f})."]
    if winner == "z_yoy":
        gap = abs(recomputed - w["severity"])
        lines.append(
            f"That is the signal worked through above, so the two figures "
            f"should match — recomputed **{recomputed:.1f}** against published "
            f"**{w['severity']:.1f}**"
            + (", and they do. This check runs every time the page opens."
               if gap <= 0.1 else
               f", a gap of {gap:.1f}. They should agree to within 0.1. "
               f"A gap means `outputs/` was built by different code from the "
               f"code running now — rebuild with `./run-full.command` before "
               f"quoting anything on this page."))
    else:
        lines.append(
            f"The year-on-year signal worked through above scores "
            f"**{recomputed:.1f}** on its own. The published score is higher "
            f"because a different signal was stronger this month. The other "
            f"two are built the same way, on different inputs: the "
            f"single-month deviation compares the seasonally adjusted level "
            f"with its own rolling median, and the six-month drift is the "
            f"average of the year-on-year z over the last six months.")
    return "\n".join(lines)


def severity_worked_example(measure: str = "pfi") -> str:
    w = _severity_worked(measure)
    if w is None:
        return ""
    label = {"pfi": "PFI", "inflow": "inflows", "outflow": "outflows"}[measure]
    return f"""
#### The whole calculation on one real industry

**SIC {w['code']} {w['name']}, {w['month']:%B %Y}, {label}, year on year.**
Every figure below comes from `outputs/series_national.csv`. You can redo it in
a spreadsheet.

| # | Step | Arithmetic | Result |
|---|---|---|---|
| 1 | This month | — | £{w['now']/1e9:,.3f}bn |
| 1 | Same month a year earlier | — | £{w['base']/1e9:,.3f}bn |
| 2 | Log change | ln({w['now']/1e9:,.3f} ÷ {w['base']/1e9:,.3f}) | **{w['log_change']:+.4f}** |
| 3 | Common component — the middle log change across all {len(data.national().sic2.unique())-1} industries this month | median of every industry's log change | {w['common']:+.4f} |
| 3 | Excess — this industry's move *beyond* the common one | {w['log_change']:+.4f} − ({w['common']:+.4f}) | **{w['excess']:+.4f}** |
| 4 | Middle of this industry's own past excesses ({w['n_hist']} usable months before {w['month']:%b %Y}) | median | {w['median']:+.4f} |
| 4 | Typical spread of those past excesses | MAD × 1.4826 | {w['mad']:.4f} |
| 4 | Raw ratio | ({w['excess']:+.4f} − {w['median']:+.4f}) ÷ {w['mad']:.4f} | **{w['ratio']:+.3f}** |
| 5 | Discounted for a {w['n_hist']}-month baseline | t on {w['n_hist']-1} d.f. → equivalent z | **{w['z']:+.3f}** |
| 6 | Severity | 100 × (1 − e^(−{abs(w['z']):.3f} ÷ 3)) | **{100*(1-np.exp(-abs(w['z'])/3)):.1f}** |

{_which_signal_won(w)}

**Reading the middle rows.** The excess of {w['excess']:+.4f} in log terms is
about **{np.expm1(w['excess']):+.1%}** in plain percentage terms — that is how
much this industry moved *after* setting aside what every industry did. Its own
usual excess is about {np.expm1(w['median']):+.1%}, and its usual month-to-month
wobble around that is about {w['mad']*100:.1f} percentage points. So this month
sits roughly **{abs(w['ratio']):.1f} of its own typical wobbles** away from its
own normal. That sentence *is* the z-score, in English.

**What step 5 did.** {"The baseline is long, so the discount is small: the ratio " + f"{w['ratio']:+.3f} became {w['z']:+.3f}." if w['n_hist'] >= 48 else "The baseline is short, so the discount bites: the ratio " + f"{w['ratio']:+.3f} was pulled back to {w['z']:+.3f}, and severity fell from {w['severity_uncorrected']:.1f} to {100*(1-np.exp(-abs(w['z'])/3)):.1f} as a result."}
"""




# ---------------------------------------------------------------------------
# The common component
# ---------------------------------------------------------------------------

COMMON_COMPONENT = """
**"After removing what every industry did that month" — what that means and
why we do it.**

#### The plain version

Suppose every industry in the country shows payments up 40% against the same
month last year. Has something happened to all 88 industries at once? Almost
never. Far more often something happened to the *comparison* — the month a year
ago was short of data, or a reporting change moved everyone at once.

If we scored each industry only against its own history, we would report 88
separate industry shocks on a month like that. So before scoring, we work out
what the **middle industry** did that month and subtract it from everyone. What
is left is the part that is specific to that industry.

#### How it is calculated

1. For every industry, take the log change against the same month a year ago.
2. Take the **median** across industries — the middle value, so no single huge
   industry can set it.
3. Subtract that one number from every industry's change.

The median, not the mean, so one enormous industry cannot define "normal" for
everybody.

#### The case it was built for, and it is a real one

**July 2021** recorded **£90.1bn** across **52.2m transactions**. June 2021
recorded **£120.1bn** across **81.7m**. Whatever the reason, July 2021 holds far
less than the months either side of it.

Twelve months later, every year-on-year comparison divides by that smaller
base. In **July 2022**, **74 of 88 industries** rose more than 25% year on year,
with a median of **+58.8%** — while the same month measured against *June 2022*
grew **+0.4%**.

Without this correction the detector would have reported 74 economic shocks in
one month. None of them happened. With it, the common +58.8% is removed and
only industries that moved differently from the rest are flagged.

#### What it costs

An industry that genuinely moves *with* the whole economy will score low. That
is a deliberate trade. This tool exists to find industries moving
**differently** from the rest — the economy-wide picture is the job of GDP, not
of this dashboard. When the common component is large, every page says so in a
banner rather than leaving it implicit.
"""




# ---------------------------------------------------------------------------
# Confidence
# ---------------------------------------------------------------------------

CONFIDENCE_METHOD = """
**Confidence does not judge economics. It runs a checklist.**

The honest description of this column is: *how many known ways of producing a
fake move did we fail to rule out?* We cannot see inside a business, so we never
claim to know that a move "was economic". What we can do is test for the
specific, measurable conditions that are known to move these numbers **without
any money changing hands differently**. If one of them is present, we say so.

Every rule below is a fixed threshold applied in a fixed order. The **first**
rule that matches decides the label, and the reason you see in the *Why* column
is that rule. Nothing is weighted, averaged or tuned.

#### The checklist, in the order it runs

| Order | Test | Threshold | Label | Why this is a warning sign |
|---|---|---|---|---|
| 1 | The whole economy moved this month | median industry change ≥ **±20%** | **low** | On a month like that, one industry's move mostly reflects the common movement, not itself |
| 2 | The month sits on a known structural break for this industry | break register | **low** | The level before a break does not describe the series after it, so the comparison is between two different things |
| 3 | Counterparties appearing or disappearing carry most of the move | presence share ≥ **50%** | **low** | Over half the change comes from trading partners in one month's data and not the other's. Nobody changed what they paid |
| 4 | The share arriving from unidentified payers jumped | change in SIC 00 share ≥ **±20 percentage points** | **low** | Payments moved between the "identified" and "unidentified" buckets. The industry's real total may not have moved at all |
| 5 | Most of this industry's cells are withheld | suppressed share > **50%** | **low** | More than half the counterparty cells are withheld for disclosure control, so we are measuring a minority of the industry |
| 6 | One counterparty carries most of the move | top counterparty ≥ **70%** of the change | **medium** | It may be entirely genuine, but it is one relationship, not an industry trend — and one relationship can be a single contract or a single settlement date |
| 7 | The move is concentrated in a few counterparties | fewer than **40%** moved the same way | **medium** | Most trading partners did not do this. Worth knowing before calling it an industry-wide shift |
| 8 | Partly driven by presence | presence share ≥ **25%** | **medium** | A quarter or more of the move is cells entering or leaving |
| 9 | The baseline is thin | fewer than **24** months | **medium** | The yardstick itself is uncertain. The score is already discounted for this — the label is so you know it happened |
| — | None of the above matched | — | **high** | Broad-based, on a full baseline, with no artefact test triggered |

#### Where the thresholds come from

They are **stated conventions, not fitted parameters.**
None was chosen by looking at which alerts it produced.

- **50%** (rules 3 and 5) and **70%** (rule 6) are the plain meanings of
  "most of it" and "nearly all of it". Above 50%, *more than half* of the move
  is one thing; that is arithmetic, not opinion.
- **20 percentage points** (rules 1 and 4) is a fifth of the whole. A move of
  that size in a share is an order of magnitude larger than this data's normal
  month-to-month drift in the same share.
- **24 months** (rule 9) is two full years — the minimum needed to see each
  calendar month twice, which is what a seasonal comparison requires.
- **40%** (rule 7) is "fewer than two in five", the point below which "most
  counterparties did this" stops being a true sentence.

**Change one and everything downstream changes.** They are therefore constants
at the top of `pipeline/detect.py`, not numbers buried in the code, and they
are listed in the changelog whenever they move.

#### Why confidence is never blended into severity

A single combined score would average away exactly the case this tool exists to
catch: **a very large move that is entirely a recording change.** If that move
scored 90 for size and 10 for believability, a blended 50 would file it beside
a modest, genuine, well-evidenced move — and the reader would have no way to
tell the two apart.

So they stay in two columns. **Severity says how far from normal. Confidence
says what we could not rule out.** Read them in that order and never quote the
first without the second.
"""




@st.cache_data(ttl=600, show_spinner=False)
def _confidence_case() -> str:
    """A live example of each label, so the words attach to real rows."""
    try:
        a = data.alerts()
    except Exception:
        return ""
    d = a[(a.level == "division") & (a.measure == "pfi") & (a.basis == "YoY")]
    if d.empty:
        return ""
    latest = d.month.max()
    here = d[(d.month == latest) & (d.severity >= 40)]
    out = [f"#### How this reads on the current month ({latest:%B %Y})\n",
           "| Industry | Severity | Confidence | The rule that fired |",
           "|---|---|---|---|"]
    shown = 0
    for label in ("high", "medium", "low"):
        sub = here[here.confidence == label].nlargest(1, "severity")
        for r in sub.itertuples():
            out.append(f"| {r.code} {r.name} | {r.severity:.0f} | "
                       f"**{label}** | {r.confidence_reason} |")
            shown += 1
    if shown == 0:
        return ""
    out.append("")
    out.append("These rows are read from `outputs/alerts.csv` when the page "
               "opens, so this table describes the delivery you are looking "
               "at, not a month we happened to write about once.")
    return "\n".join(out)


# ---------------------------------------------------------------------------
# Baseline / provisional
# ---------------------------------------------------------------------------

BASELINE_METHOD = """
**"Baseline" is the number of past months the score was measured against.**
Nothing more.

Severity works by comparing this month with this industry's own past. The
baseline is how much past there was. It is shown because a score measured
against 60 months and a score measured against 14 are not equally trustworthy,
and the number itself is the cheapest possible way to say so.

#### What counts, and what does not

A month goes into the baseline only if **all** of these hold:

| Rule | Reason |
|---|---|
| It comes **before** the month being scored | Otherwise the shock would help set the yardstick it is measured against, and nothing would ever look unusual |
| It is **outside March 2020 – June 2021** | The COVID period is so wide that including it makes everything after it look normal by comparison |
| It is **after this industry's last structural break** | Before a break the series sat at a different level. Those months describe a different thing |
| It actually **has a value** | A withheld cell, or a month before the year-on-year comparison can start, contributes nothing |

#### What "provisional" means

**`provisional` = fewer than 24 months in the baseline.** 24 is two full years,
the minimum that sees each calendar month twice.

It does **not** mean the score is wrong, and it does not mean ignore the row.
It means two specific things:

1. **The score has already been reduced to account for it.** Step 5 of the
   severity calculation references the ratio to a t distribution on the months
   actually observed, so a thin baseline has to produce a larger move to reach
   the same severity. The discount is applied before you see the number — the
   label is not a second penalty, it is a disclosure.
2. **It will change as history accumulates.** The same move rescored in a
   year's time, with a fuller baseline, may score differently. That is the
   correct behaviour, and it is why the word is on the row.

#### Why an industry can have a short baseline at all

Almost always because it had a **structural break**. A break resets the
baseline: months before it are no longer usable, so the count restarts and
climbs back towards 24 one month at a time. An industry can therefore sit at
`provisional` for up to two years after a genuine change in its series, and
that is the intended behaviour, not a gap in the data.
"""




# ---------------------------------------------------------------------------
# The three decomposition categories
# ---------------------------------------------------------------------------

PRESENCE_METHOD = """
**First, one word.** *Counterparty* and *trading partner* mean the same thing
throughout this tool: **another industry that paid this one, or was paid by
it.** The column headings say "counterparty" because that is the term in the
source data; the explanations say "trading partner" because it is plainer.
There is no difference between them.

**Every trading partner falls into exactly one of three boxes**, decided only
by whether that partner has a figure in each of the two months being compared.

| | In the **earlier** month? | In the **later** month? | What it means |
|---|---|---|---|
| **Continuing** | yes | yes | The relationship exists in both. Any change is a change in **how much was paid** |
| **Newly present** | no | yes | The relationship has a figure now and did not before |
| **Absent or suppressed** | yes | no | The relationship had a figure before and does not now |

#### The same three, as everyday situations

Picture one industry — say **bakeries** — and the businesses that pay them.

- **Continuing.** A supermarket chain paid bakeries £10m last June and £12m this
  June. It is in both months. It paid **£2m more**. *This is the economic part:
  real money genuinely changed hands differently.*

- **Newly present.** A hotel group shows £3m paid to bakeries this June and
  nothing at all last June. Two quite different things look identical here:
  either the hotel group really did start buying bread this year, **or** it was
  buying all along and last June's figure was withheld. *The total goes up by
  £3m either way, and from the numbers alone we cannot tell which happened.*

- **Absent or suppressed.** A restaurant chain paid bakeries £4m last June and
  has no figure this June. Again two possibilities: it stopped paying, **or**
  the figure exists but was withheld this month. *The total drops £4m, and the
  restaurant chain may still be buying exactly as much bread as before.*

#### Why a figure disappears without anything happening

The data provider **withholds** a cell whenever publishing it might identify an
individual organisation. That test is applied **separately every single month**.
A long-standing, perfectly stable trading relationship can therefore be
published in June, withheld in July, and published again in August — with
nothing whatever having changed except what we are allowed to see.

This is the single most important thing to understand about this dataset. A
figure vanishing is not evidence that a business stopped trading.

#### Presence share — and why above 50% we stop calling it economic

    presence share = | newly present + absent | ÷ | total change |

**This is a definition, not a finding.** If it comes out above 50%, then by
plain arithmetic **more than half** of the change is attributable to partners
that appear in only one of the two months. Whether those partners really started
or stopped trading, or were simply published in one month and withheld in the
other, cannot be told apart from these numbers. So the honest statement is: *at
least half of this move is about what was published, and we cannot show it was
about money.*

Practical reading:

| Presence share | Read it as |
|---|---|
| under 25% | Substantially an economic move. Continuing relationships did the work |
| 25% – 50% | Mixed. Quote the continuing part, and say the rest was presence |
| over 50% | **Mostly a data-presence effect.** Do not report it as an economic change without separate evidence |

It can exceed 100%, and that is not an error. If continuing partners pushed the
total **up** while a vanished partner pulled it **down**, the vanishing part can
be larger than the net change that survived.
"""




# ---------------------------------------------------------------------------
# The typical-range band on Trends
# ---------------------------------------------------------------------------

BAND_METHOD = """
**The shaded band is the middle 80% of this industry's own recent months.**

#### How it is drawn, in four steps

1. Take every month of this industry's series **since its last structural
   break** — or the whole series, if it has never had one.
2. Sort those monthly values from smallest to largest.
3. Find the value **10% of the way up** the sorted list and the value **90% of
   the way up**. These are the 10th and 90th percentiles.
4. Shade between them.

So if an industry has 60 usable months, the band runs from roughly the 6th
smallest to roughly the 54th smallest. **Six months sat below the band and six
sat above it** — by construction.

#### What it is for

It turns "is £7.2bn a lot?" into a question you can answer by looking. £7.2bn
means nothing on its own. *Below where this industry has sat in 9 months out of
every 10* means something immediately.

#### How to read a point outside it

A point outside the band is **unusual for this industry** — not unusual in
pounds, and not unusual compared with other industries. A small industry has a
narrow band, so a modest move leaves it. A volatile one has a wide band and can
swing a long way while staying inside.

#### What it is not

- **It is not a confidence interval and it is not a forecast.** It describes
  months that have already happened. It makes no statement about what comes
  next and has no probability attached.
- **It is not the severity score.** The band uses the raw level; severity uses
  the change, with the common component removed and the industry's own spread
  as the yardstick. A point can sit just outside the band and score low, or sit
  inside it and score high. When the two disagree,
  **severity is the measured one** — the band is a reading aid.
- **It does not move with the basis you choose.** It is recomputed from
  whichever series is on screen, so it always matches the line it sits behind.

#### Why it starts at the last break

Before a structural break the series sat at a different level. Including those
months would widen the band to span both levels, and then almost nothing would
ever fall outside it — the band would still be drawn, and it would have stopped
meaning anything.
"""




# ---------------------------------------------------------------------------
# Diagnostics
# ---------------------------------------------------------------------------

DIAGNOSTICS_METHOD = """
**Diagnostics are the counts and shares behind the money.**

The **Measures** mode answers *how much money moved*. Diagnostics answer *what
the money was made of* — and they are often the faster route to why a total
moved, because a total can move for reasons that have nothing to do with trading
more.

Each one is taken directly from the source file. None is modelled.

| Diagnostic | Exactly what it is | The question it settles |
|---|---|---|
| **Payments received (count)** | The number of payments where this industry was the payee, summed across all its trading partners | Did the total rise because **more payments** were made? |
| **Payments made (count)** | The same on the paying side | Same question, on purchases |
| **Average payment received** | Money received ÷ payments received | Did the total rise because **each payment was bigger**? |
| **Self-flow (within industry)** | Money paid by this industry **to itself** — one firm in the industry paying another | Is the industry trading more internally, e.g. more subcontracting? |
| **Share from unclassified payers** | The proportion of money received that came from payers with no industry code | Is a move real, or is it identification improving or worsening? |

#### The one comparison that earns its place

**A total can rise two completely different ways**, and the money series alone
cannot tell them apart:

- **More payments, same size each.** More orders, more customers, more
  activity.
- **Same number of payments, each one bigger.** Higher prices, larger contracts,
  or several invoices being settled together.

Put *Payments received* and *Average payment received* on screen one after the
other and the answer is usually obvious in a glance. This is the closest this
dataset comes to separating **volume** from **value**, and neither the PFI, the
inflow nor the outflow series can do it.

#### Two cautions, both important

**Transaction counts are rounded by the provider.** A small industry can show a
count of 0 against a non-zero value in the same month. The average payment for
that month is therefore left **blank rather than infinite** — a division by zero
is never shown as a number here.

**A rising "share from unclassified payers" is not economic news.** It means
more of this industry's incoming money came from payers we could not identify.
That can shift because coverage changed, with no change in trading whatever.
When this line moves sharply, check it before believing any move in the money
series for the same month — and note that a jump of 20 points or more
automatically sets that month's confidence to **low**.
"""




# ---------------------------------------------------------------------------
# Reconciliation
# ---------------------------------------------------------------------------

RECONCILIATION_METHOD = """
**The reconciliation line is a self-check. It is there so you do not have to
take the chart on trust.**

The chart splits a total change into one bar per trading partner. If the split
is honest, adding the bars back up must return the number we started with.
The line under the chart does exactly that, and prints all three figures:

| | Where it comes from |
|---|---|
| **attributed** | The bars on the chart, added up |
| **actual change** | The industry's own published total this month minus its published total in the comparison month, read straight from `series_national.csv` |
| **residual** | actual − attributed |

**The residual should be zero** — and zero here means *every pound of the change
has been assigned to a named partner*.
It is not a statement about positive and negative bars cancelling out.
Positives and negatives cancelling out is what produces the **net change**; the
residual is about whether that net change has been fully **explained**.

#### What a non-zero residual would mean

Something reached the industry total that did not reach the partner-level
table — a row dropped in filtering, a mismatched month, a measure summed on one
basis and reconciled on another. It would be
**a bug in this tool, not a feature of the data**, which is precisely why the
figure is printed on screen every single time instead of being checked once and
assumed thereafter.

#### Why bars can be negative on a chart of inflows

This trips up almost everyone, so it is worth being blunt about.

**The bars are not inflows. They are contributions to the *change* in inflows.**

Worked through with invented, round numbers — one industry's inflows, this June
against last June:

| Partner | Last June | This June | Bar |
|---|---|---|---|
| A | £100m | £130m | **+£30m** |
| B | £80m | £50m | **−£30m** |
| C | £60m | £75m | **+£15m** |
| **Total inflows** | **£240m** | **£255m** | **+£15m** |

Inflows themselves are never negative — £100m, £80m, £60m are all positive, and
so are £130m, £50m, £75m. But partner **B paid £30m less than it did last year**,
so B's contribution to the change is **minus £30m**. Its bar points left.

Add the bars: +30 − 30 + 15 = **+£15m**, which is exactly the change in the
total. That is the reconciliation line doing its job.

**So a bar pointing left means "this partner held the total back", not "this
partner paid a negative amount".**
"""




# ---------------------------------------------------------------------------
# The two detectors
# ---------------------------------------------------------------------------

ANOMALY_KINDS = """
**There are two detectors running, and they look for different things.** The
*Kind of anomaly* control chooses which one's results you see.

| | **Level** | **Structural** |
|---|---|---|
| The question it asks | Did this industry's **money** move unusually? | Did the **shape of its trading** change? |
| What it looks at | One number a month: the industry's total | Nine features a month, describing who it trades with |
| Catches | A rise or fall that is large for this industry | A reorganisation, even when the total looks ordinary |
| Misses | A total that stays put while everything underneath changes | A straightforward rise or fall with no change in structure |
| The column it produces | **Severity** | **Structural score** |

#### Why two, rather than one better one

Because a total can stay completely still while the thing producing it changes
entirely.

Take an industry receiving **£100m** a month. Last year it came from a hundred
different customers. This year the same **£100m** arrives, but **40% of it**
comes from one. Nothing has happened to the money. A great deal has happened to
the industry — it is now exposed to a single customer in a way it was not
before. **The level detector sees nothing. The structural detector sees it.**

The reverse holds too: an industry can simply trade more with the same
customers in the same proportions. Its money moves and its shape does not. The
level detector catches that; the structural detector does not.

They overlap far less than people expect, and the exact figure is measured from
the current outputs rather than written in — see the line below this table.

#### What each setting shows you

- **Level — the money moved.** The Phase 1 detector on its own. Severity and
  confidence, as described in the boxes above. This is the default and it is
  what the bulletin process uses.
- **Structural — the shape changed.** The Phase 2 detector on its own, with a
  *structural score* and a plain sentence naming which features moved. The
  table also says whether each row was **also** a level alert, so you can see
  the overlap directly.
- **Both together.** Only industry-months that fired on **both**. These are the
  strongest signals available here — the money moved unusually *and* the
  trading reorganised at the same time — and in most months there are very few
  of them, or none.

#### What the structural score is measured on

Nine features of an industry's trading, each **standardised against that
industry's own history** so the question is always *"is this month unusual for
it?"*:

| Feature | What it measures |
|---|---|
| Number of counterparties | How many industries it trades with |
| Concentration (by value) | Whether its money comes from few or many |
| Concentration (by volume) | The same, counting payments rather than pounds |
| Largest single relationship | How much rests on one partner |
| Self-share | How much of its activity is internal |
| Unclassified share | How much arrives from payers with no industry code |
| Churn | How much its set of partners turned over |
| Average payment size | Whether payments got bigger or smaller |
| Network position | Its PageRank — how central it is to the flow |

An Isolation Forest scores how unusual the **combination** is. It is unusual
combinations that matter: any one feature moving can be ordinary, while several
moving together rarely is.

#### The case it was built for

**Retail, April 2020.** Its PFI moved **−1% year on year** — invisible to the
level detector, and correctly so, because the money barely moved. At the same
time public administration went from **18% to 40%** of its entire inflow. Same
money, completely different shape. **measured**, from `outputs/structural.csv`.
"""


@st.cache_data(ttl=600, show_spinner=False)
def _detector_overlap() -> str:
    """How much the two detectors actually disagree, on this delivery.

    Measured, never written in. An earlier draft quoted 79% from the build
    that first introduced the structural detector; adding the two
    volume-weighted features moved it, and the number sat stale in four files
    until it was checked. Anything that can go stale is computed here instead.
    """
    try:
        struct = data.structural()
        alerts = data.alerts()
    except Exception:
        return ""
    if struct is None or alerts is None or struct.empty or alerts.empty:
        return ""
    d = alerts[(alerts.level == "division") & (alerts.measure == "pfi")
               & (alerts.basis == "YoY") & (alerts.severity >= SEVERITY_FIRES)]
    level = set(zip(d.code, d.month))
    flagged = struct[struct.structural_flag.eq(True)]
    sk = set(zip(flagged.sic2, flagged.month))
    if not sk:
        return ""
    only = len(sk - level)
    return (
        f"**How much they overlap, measured on this delivery:** of the "
        f"**{len(sk)}** industry-months the structural detector flags, "
        f"**{only}** — **{only/len(sk):.0%}** — are **not** also level alerts "
        f"at severity {SEVERITY_FIRES}. The two are largely finding different "
        f"months in different industries, which is why both are kept. This "
        f"figure is recomputed from `outputs/structural.csv` and "
        f"`outputs/alerts.csv` each time this box is opened, so it describes "
        f"the delivery in front of you.")




# ---------------------------------------------------------------------------
# The driver lines
# ---------------------------------------------------------------------------

DRIVER_LINES = """
**"What changed this month" is generated, not written.** The same calculation
runs every month on whichever industries moved, so the sentence always has the
same two parts:

1. **What moved** — industry, measure, direction, £, %, and against which
   period.
2. **A cause clause that opens by naming the kind of cause in bold**, before
   any number appears.

There are exactly **seven** endings. The bold phrase tells you which one you
are reading before you read a figure.

| The line says | It means | What to do |
|---|---|---|
| **Concentrated in one partner** | One trading partner accounts for most of the move. It traded with this industry in **both** months, so that part is money genuinely changing hands | Real, but it is one relationship — not an industry trend. Check whether a single contract or settlement date explains it |
| **More than accounted for by one partner** | One partner moved by **more than the industry's net change**, because others moved the opposite way and offset part of it | Remove that one relationship and the industry barely moved. Never describe it as an industry-wide shift |
| **No single partner drove it — the largest one moved the other way** | The biggest individual change pushed **against** the direction of the total | The move is spread across the remaining partners. Do not name the largest partner as the cause — it was working against it |
| **Broad-based** | Most of this industry's partners moved the same way. No single relationship explains it | The strongest kind of signal in this data. Worth investigating |
| **Reporting change, not money changing hands** | The largest part of the move is a partner with a figure in one month and none in the other, having **disappeared** | Do not report as economic. The partner may be trading exactly as before, with its figure withheld |
| **Coverage change, not new activity** | The same, with a partner **appearing** | Do not report as economic |
| **Most likely a classification change** | Money moved between the identified and unidentified buckets, which moves the series without any change in trading | Check *Share from unclassified payers* on **Trends** |

#### Two things the wording guarantees

**Where a partner is named, it is the one whose payments changed the most** —
never the closest, the newest, or an example picked out to illustrate a point.

**Every percentage states what it is a share of.** It is always the share of
**that industry's total move**, never of the industry's total money. Three of
the seven endings exist purely so the **direction** of the largest change is
never glossed over: a partner that paid *more* while the industry *fell* is not
the cause of the fall, and the line says so rather than leaving the reader to
notice the signs do not agree.

**They cannot disagree with the chart.** Every line is regenerated from the
same counterparty decomposition that draws **Why did it move?**, so the
sentence and the waterfall are two renderings of one calculation.
"""




# ---------------------------------------------------------------------------
# One box per page
# ---------------------------------------------------------------------------
#
# Every page used to open a separate expander for each term it showed: nine on
# Outliers, eight on Movers. A reader with no knowledge of the project met the
# boxes before they met a number, which is the opposite of helpful however
# good the contents were.
#
# So each page now renders exactly one box. Inside it, the page's own sections
# sit on tabs, in reading order: what the page shows, then each term it uses.
# One click to open, one click to move between topics, and nothing has been
# removed - the same words are still there for anyone who wants them.

WHAT_OVERVIEW = """
**What this page shows.** The latest month's total payment value, counted two
ways, compared two ways, with the three industries that moved most unusually.

**Start here if you have never opened this before.** Every other page is a
detail of this one.

**Two totals, and both are real.**

- **Classified flow** counts only payments where *both* ends carry an industry
  code. It is the stable series, and every anomaly score is computed on it.
- **All flow** adds payments where one or both ends could not be identified —
  recorded as **SIC 00 Unclassified**. Roughly three times larger.
  **The money is just as real**; we simply cannot say which industry was at
  one end of it.

Whichever one you quote, **say which one it was**. The *Which payments are
counted* tab explains why, with an example.

**Two comparisons, and they answer different questions.**

- **Month on month** is the most timely reading, and the one to use when a
  year-earlier month is unreliable. It carries seasonal noise.
- **Year on year** compares like with like across the calendar, so it is
  seasonally self-controlling. But it inherits any problem in the month twelve
  back.
"""

WHAT_MOVERS = """
**What this page shows.** How much each industry's payments changed between the
month you chose and either the previous month or the same month a year earlier.
Gainers extend right, losers left; the longest bar is the biggest move in
pounds.

**How the table is ordered.** By how *unusual* a move is first, then by size —
so a strange move in a mid-sized industry outranks a routine move in a huge
one. Sorting by pounds alone would show the same handful of very large
industries every month.

**The two columns that matter, and they are deliberately separate.**

- **Unusual?** is severity, 0–100: how far this month sits from **this
  industry's own** history. It says nothing about whether the cause was
  economic.
- **Confidence** is a checklist of known ways the numbers can move **without
  any money changing hands differently**. Read it before believing the score.

Each has its own tab above, with the full arithmetic and a worked example on a
real industry.

**Unclassified (SIC 00)** is money with one end we could not identify. It is
shown — on the chart when you pick a basis that includes it, and beneath the
table always — but never ranked against industries, because it is not an
industry.
"""

WHAT_OUTLIERS = """
**What this page shows.** Every industry-month the detector flagged, browsable
across time rather than one month at a time. Use it to ask *"what has been
unusual lately"* rather than *"what happened in June"*.

**Three columns, three separate questions.**

- **Severity, 0–100** — how far the move sits from that industry's own
  history. Arithmetic, not judgement.
- **Confidence** — which of nine known artefact tests fired, if any. The *Why*
  column names the one that did.
- **Baseline** — how many past months the score rests on. `provisional` means
  fewer than 24; the score is real and has **already** been discounted for the
  thin history.

Each has a tab above.

**Two detectors run here**, and the *Kind of anomaly* control chooses which
you see: one asks whether the **money** moved unusually, the other whether the
**shape of the trading** changed. The *Two detectors* tab explains the
difference and why both are kept.
"""

WHAT_DECOMPOSITION = """
**What this page shows.** Which trading partners caused one industry's change.

**The bars are contributions to the *change*, not amounts of money received.**
A bar pointing left means that partner **held the total back** — it paid less
than in the comparison month. It does not mean a negative payment. This is the
single most common misreading of this chart, and the *Reconciliation* tab works
it through with round numbers.

**Every bar added together equals the total change, exactly.** The line under
the chart proves it on screen each time rather than asking you to assume it.

**Three kinds of bar, and only one is money changing hands:** *continuing*,
*newly present*, and *absent or suppressed*. The *Three kinds of bar* tab gives
each one as an everyday situation.

**Two bars are always drawn regardless of rank** — *within-industry* and
*SIC 00 Unclassified* — because each is structurally large and hiding either
would mislead.
"""

WHAT_TRENDS = """
**What this page shows.** One industry's series over time, on the measure(s),
diagnostic or region(s) you select.

**The three modes answer different questions.**

- **Measures** is the money: how much flowed.
- **Diagnostics** is what the money was made of — how many payments, how big
  each one was, how much stayed inside the industry, how much arrived from
  payers we could not identify. Often the faster route to *why* a total moved.
- **Regions** compares the same measure across places.

They are mutually exclusive by design: three measures across five regions is
fifteen lines and reads as noise.

**The shaded band** is the middle 80% of this industry's own recent months. It
is there so *"is £7.2bn a lot?"* becomes a question you can answer by looking.
It is not a forecast. Its own tab explains how it is drawn.

**Dotted vertical lines** mark structural breaks, labelled with their cause. A
break resets the baseline, because the level before it no longer describes the
series.

**Gaps are suppressed months.** They are left as gaps and never interpolated —
joining them would draw a line through data that does not exist. A gap is a
figure we are not allowed to see, never a zero.
"""


def _severity_tab() -> str:
    """Severity, and the two things that are part of it.

    The common component and the baseline are steps 3 and 5 of the severity
    calculation, so they belong with it rather than in boxes of their own.
    Splitting them out was a filing decision that made sense to whoever wrote
    the code and to nobody reading the page.
    """
    return "\n".join([
        SEVERITY_METHOD,
        severity_worked_example(),
        SEVERITY_SCALE_METHOD,
        severity_reality_check(),
        SEVERITY_BASIS_NOTE,
        "\n---\n",
        COMMON_COMPONENT,
        "\n---\n",
        BASELINE_METHOD,
    ])


@st.cache_data(ttl=600, show_spinner=False)
def _confidence_worked() -> str:
    """Walk the checklist on one real row, showing every measured value.

    The live summary table says WHICH rule fired. It does not show the numbers
    that made it fire, so the label still reads as a black box. This walks all
    nine tests in order, prints the measured value beside the threshold, and
    marks the first match - which is the whole of the decision.

    The outcome is compared with the label stored in alerts.csv, so the walk
    cannot quietly disagree with the detector it is describing.
    """
    try:
        alerts = data.alerts()
    except Exception:
        return ""
    d = alerts[(alerts.level == "division") & (alerts.measure == "pfi")
               & (alerts.basis == "YoY")]
    if d.empty:
        return ""
    latest = d.month.max()
    # Prefer a row where a named test actually fired: a "high" row walks nine
    # lines of "no" and teaches nothing.
    here = d[(d.month == latest) & d.confidence.isin(["low", "medium"])]
    if here.empty:
        here = d[d.month == latest]
    if here.empty:
        return ""
    r = here.nlargest(1, "severity").iloc[0]

    def num(v, kind):
        if not np.isfinite(v):
            return "not measured"
        return f"{v:.0%}" if kind == "pct" else f"{v:.0f}"

    # Same order, same thresholds as pipeline/detect.py::_confidence.
    tests = [
        ("1", "Whole economy moved this month",
         f"median industry change = {num(r.common_pct, 'pct')}",
         "at least ±20%",
         np.isfinite(r.common_pct) and abs(r.common_pct) >= detect.SYSTEMIC_COMMON_PCT,
         "low"),
        ("2", "Sits on a known structural break",
         "in the break register" if r.break_flag else "not in the break register",
         "present", bool(r.break_flag), "low"),
        ("3", "Partners appearing/disappearing carry most of it",
         f"presence share = {num(r.presence_share, 'pct')}",
         "at least 50%",
         np.isfinite(r.presence_share) and r.presence_share >= 0.5, "low"),
        ("4", "Unidentified-payer share jumped",
         f"change in SIC 00 share = {num(r.sic00_share_shift, 'pct')}",
         "at least ±20 points",
         np.isfinite(r.sic00_share_shift) and abs(r.sic00_share_shift) >= 0.20,
         "low"),
        ("5", "Most of this industry's cells withheld",
         f"suppressed share = {num(r.suppressed_share, 'pct')}",
         "more than 50%",
         np.isfinite(r.suppressed_share) and r.suppressed_share > 0.5, "low"),
        ("6", "One partner carries most of the move",
         f"largest partner = {num(r.top_counterparty_share, 'pct')} of the move",
         "at least 70%",
         np.isfinite(r.top_counterparty_share)
         and r.top_counterparty_share >= detect.CONCENTRATION_LIMIT, "medium"),
        ("7", "Concentrated in a few partners",
         f"{num(r.breadth, 'pct')} of partners moved the same way",
         "fewer than 40%",
         np.isfinite(r.breadth) and r.breadth < 0.4, "medium"),
        ("8", "Partly presence-driven",
         f"presence share = {num(r.presence_share, 'pct')}",
         "at least 25%",
         np.isfinite(r.presence_share) and r.presence_share >= 0.25, "medium"),
        ("9", "Baseline is thin",
         f"baseline = {num(r.baseline_months, 'n')} months",
         f"fewer than {detect.FULL_BASELINE}",
         np.isfinite(r.baseline_months)
         and r.baseline_months < detect.FULL_BASELINE, "medium"),
    ]

    rows, decided, verdict = [], False, "high"
    for n, name, measured, threshold, fired, label in tests:
        if decided:
            mark = "not reached"
        elif fired:
            mark = f"**FIRES → {label}**"
            decided, verdict = True, label
        else:
            mark = "no"
        rows.append(f"| {n} | {name} | {measured} | {threshold} | {mark} |")

    agree = (verdict == r.confidence)
    return f"""
#### The same checklist, walked on one real row

**SIC {r.code} {r["name"]}, {latest:%B %Y}, PFI, year on year.** Every value in
the third column is a column of `outputs/alerts.csv`. The tests run top to
bottom and **stop at the first one that fires**.

| # | Test | What this row measures | Fires when | Result |
|---|---|---|---|---|
{chr(10).join(rows)}

**Verdict: {verdict}.** {"The label stored for this row is **" + str(r.confidence) + "**, so the walk agrees with the detector." if agree else "The stored label is **" + str(r.confidence) + "**, which does not match. That is a fault in this tool - do not rely on this row until it is resolved."}

**The reason shown in the *Why* column is the test that fired**, in words:
*"{r.confidence_reason}"*.

Read it as: *we could not rule this one out*. It is not a claim that the move
was fake, and a **high** label is not a claim that the move was real — it means
none of the nine tests found anything. This row is recomputed when the page
opens, so it always describes the delivery in front of you.
"""


def _confidence_tab() -> str:
    return "\n".join([CONFIDENCE_METHOD, _confidence_worked(), _confidence_case()])


def _detectors_tab() -> str:
    return ANOMALY_KINDS + "\n" + _detector_overlap()


# Reading order, per page. The first tab is always "what this page shows", so
# somebody who opens the box and reads nothing else still learns the point of
# the page they are on.
PAGE_TABS: dict[str, list[tuple[str, object]]] = {
    "overview": [
        ("What this shows", lambda: WHAT_OVERVIEW),
        ("Which payments are counted", lambda: BASIS_EXPLAINER),
        ("The lines under 'What changed'", lambda: DRIVER_LINES),
    ],
    "movers": [
        ("What this shows", lambda: WHAT_MOVERS),
        ("The three measures", explain.measures_markdown),
        ("Which payments are counted", lambda: BASIS_EXPLAINER),
        ("'Unusual?' — severity", _severity_tab),
        ("Confidence", _confidence_tab),
        ("The lines under 'What changed'", lambda: DRIVER_LINES),
    ],
    "outliers": [
        ("What this shows", lambda: WHAT_OUTLIERS),
        ("The three measures", explain.measures_markdown),
        ("Which payments are counted", lambda: BASIS_EXPLAINER),
        ("Severity", _severity_tab),
        ("Confidence", _confidence_tab),
        ("The two detectors", _detectors_tab),
    ],
    "decomposition": [
        ("What this shows", lambda: WHAT_DECOMPOSITION),
        ("The three measures", explain.measures_markdown),
        ("Which payments are counted", lambda: BASIS_EXPLAINER),
        ("The three kinds of bar", lambda: PRESENCE_METHOD),
        ("Reconciliation", lambda: RECONCILIATION_METHOD),
    ],
    "trends": [
        ("What this shows", lambda: WHAT_TRENDS),
        ("The three measures", explain.measures_markdown),
        ("Which payments are counted", lambda: BASIS_EXPLAINER),
        ("The diagnostics", lambda: DIAGNOSTICS_METHOD),
        ("The shaded band", lambda: BAND_METHOD),
    ],
    "leaderboard": [
        ("What this shows", lambda: WHAT_LEADERBOARD),
        ("The three measures", explain.measures_markdown),
        ("Which payments are counted", lambda: BASIS_EXPLAINER),
    ],
    # Phase 2. Same treatment as Phase 1: what the method is, how it is
    # calculated, where every setting comes from, and a live example. These
    # pages carried 114-249 words and no derivation until this was written.
    "influence": [
        ("What this shows", lambda: WHAT_INFLUENCE),
        ("How PageRank works", lambda: PAGERANK_METHOD),
        ("On this delivery", lambda: _pagerank_worked()),
        ("Which payments are counted", lambda: BASIS_EXPLAINER),
    ],
    "clusters": [
        ("What this shows", lambda: WHAT_CLUSTERS),
        ("How Louvain works", lambda: LOUVAIN_METHOD),
        ("On this delivery", lambda: _louvain_live()),
        ("Which payments are counted", lambda: BASIS_EXPLAINER),
    ],
    "shifts": [
        ("What this shows", lambda: WHAT_SHIFTS),
        ("How the score is built", lambda: STRUCTURAL_METHOD),
        ("A real flagged month", lambda: _structural_worked()),
        ("Which payments are counted", lambda: BASIS_EXPLAINER),
    ],
}

GUIDE_TITLE = "How to read this page, and how every number on it is calculated"


def simple_guide(what_this_shows: str, *extra: tuple[str, object]) -> None:
    """The same one box, for a page whose guide is mostly its own text.

    Structural shifts, Influence, Economic clusters and Gainers & losers each
    had a box titled "How to read this". Same purpose, different title, in a
    different place on the page. Somebody moving between views had to notice
    that twice. One door, one title, everywhere.
    """
    sections = [("What this shows", lambda: what_this_shows), *extra]
    with st.expander(GUIDE_TITLE):
        st.caption(
            "Written for someone opening this for the first time. No "
            "statistics assumed.")
        if len(sections) == 1:
            st.markdown(what_this_shows)
            return
        for tab, (_, body) in zip(st.tabs([s[0] for s in sections]), sections):
            with tab:
                st.markdown(body())


def page_guide(page: str) -> None:
    """The one explanation box a page is allowed to open."""
    sections = PAGE_TABS[page]
    with st.expander(GUIDE_TITLE):
        st.caption(
            "Written for someone opening this for the first time. No "
            "statistics assumed. Every threshold shows where it comes from, "
            "and every example is either invented round numbers or recomputed "
            "from the current data, so nothing here goes out of date.")
        for tab, (_, body) in zip(st.tabs([s[0] for s in sections]), sections):
            with tab:
                st.markdown(body())


# ---------------------------------------------------------------------------
# The case that proves the point, recomputed every time
# ---------------------------------------------------------------------------

@st.cache_data(ttl=600, show_spinner=False)
def suppression_case() -> dict | None:
    """The largest fall in the data that is a reporting change, measured live.

    This example is quoted on four pages as the reason severity and confidence
    are never blended. It was written down once and then drifted: the text said
    "66% - £330m of a £348m fall" while the data said a 65.5% break and £313m
    of a £342m fall, and it named the case "the largest anomaly in this
    dataset" after the case had stopped being scored at all.

    It drifted because it was prose. So it is now computed: find the largest
    suppression-driven break in the break register, decompose that industry's
    inflow across it, and report what comes back. A future delivery with a
    bigger case will update this text by itself.
    """
    try:
        breaks = data.breaks()
        panel = data.national()
        edges = decompose.as_index(data.edges())
    except Exception:
        return None
    if breaks is None or breaks.empty:
        return None
    sup = breaks[breaks.break_cause.astype(str).str.contains("suppression",
                                                             case=False)]
    if sup.empty:
        return None
    r = sup.loc[sup.level_change_pct.abs().idxmax()]
    code = str(r.sic2)
    month = pd.Timestamp(r.break_month)
    base = month - pd.DateOffset(months=12)
    rows = decompose.decompose_measure(edges, code, month, base,
                                       measure="inflow",
                                       include_unclassified=False)
    if rows.empty:
        return None
    sm = decompose.summarise(rows)
    if not sm["total_change"] or sm["top_counterparty"] is None:
        return None
    names = dict(zip(panel.sic2, panel["name"]))
    scored = code in set(data.alerts().code.astype(str))
    return {
        "code": code, "name": names.get(code, ""), "month": month,
        "base": base,
        "break_pct": float(r.level_change_pct),
        "total": float(sm["total_change"]),
        "top_code": str(sm["top_counterparty"]),
        "top_name": names.get(str(sm["top_counterparty"]), ""),
        "top": float(sm["top_contribution"]),
        "top_share": abs(sm["top_contribution"]) / abs(sm["total_change"]),
        "presence": float(sm["presence_share"]),
        "category": str(sm["top_category"]),
        "scored": scored,
    }


def suppression_case_markdown(heading: bool = True) -> str:
    """The same case, in words, with every figure traceable to a file."""
    c = suppression_case()
    if c is None:
        return ""
    head = ("#### The clearest example in this data\n\n" if heading else "")
    scored_note = (
        "It is **not currently scored at all.** Its own break resets its "
        "baseline, and fewer than 12 usable months have accumulated since, so "
        "the detector has nothing to measure it against. That is the intended "
        "behaviour and the **Movers** page lists it among the industries it "
        "could not score."
        if not c["scored"] else
        "It is still scored, and its severity is among the highest in the "
        "series.")
    return f"""{head}**SIC {c['code']} {c['name']}, {c['month']:%B %Y}.**

The break detector records a level shift of **{c['break_pct']:.1%}** for this
industry in this month, and labels its cause **suppression-driven**
(`outputs/breaks.csv`).

Decomposing its inflow against {c['base']:%B %Y}:

| | |
|---|---|
| Total change | **{c['total']/1e6:,.0f}** £m |
| Largest single partner | SIC {c['top_code']} {c['top_name']} |
| That partner's contribution | **{c['top']/1e6:,.0f}** £m — **{c['top_share']:.0%}** of the move |
| What kind of change it is | **{c['category'].replace('_', ' ')}** — it has a figure in {c['base']:%B %Y} and none in {c['month']:%B %Y} |
| Presence share | **{c['presence']:.0%}** |

**What that means in plain terms.** Almost the whole of this fall is one
trading partner that has a published figure in one month and no published
figure in the other. **That is not the same as the partner having stopped
paying.** A cell is withheld whenever publishing it might identify an
individual organisation, and that test is applied separately every month.

**Why this example is quoted so often.** A single blended score would have
filed this beside a genuine industry collapse. Severity and confidence stay in
two columns precisely so that a very large move which is entirely a recording
change cannot be mistaken for news. {scored_note}

*Every figure above is recomputed from `outputs/breaks.csv` and the current
edge table when this page opens, so it describes the delivery in front of you
rather than a month somebody once wrote about.*
"""


# ---------------------------------------------------------------------------
# Phase 2: PageRank
# ---------------------------------------------------------------------------

PAGERANK_METHOD = """
**PageRank measures influence rather than size.** Size asks *how much money
does this industry receive?* Influence asks *how much money does it receive,
and does that money come from industries that are themselves important?*

#### The idea, without any mathematics

Imagine somebody with an unlimited amount of time following payments around the
economy. They start at a random industry, look at the payments it made, pick
one at random — **weighted by size, so a big payment is more likely to be
followed** — and move to whoever received it. Then they do it again. Millions
of times.

**PageRank is simply the proportion of time that wanderer spends in each
industry.** An industry that receives a lot, from industries that themselves
receive a lot, is visited often. One that receives the same amount from a
backwater is visited less.

That is the whole idea. It is the algorithm Google was originally built on, and
the same logic applies: a link from an important page counts for more.

#### Worked example — invented, round numbers

Two industries, each receiving exactly **£100m**, so they are the same size.

| | Industry **X** | Industry **Y** |
|---|---|---|
| Receives | £100m | £100m |
| All of it from | **Finance**, which is itself one of the most-visited industries | **A small niche industry** that almost nobody pays |
| How often the wanderer arrives | Often — it keeps passing through Finance, and some of those trips continue to X | Rarely — it seldom reaches the niche industry in the first place |
| **PageRank** | **Higher** | **Lower** |

**Same size. Different influence.** That difference is the only thing this page
is for. Neither is "better" — X sits inside the circulation of
business-to-business payments and Y sits at the edge of it, and that is a real
and useful distinction.

#### The one number you have to set: damping, 0.85

At every step the wanderer does one of two things:

- with probability **0.85**, follow a payment to wherever it went;
- with probability **0.15**, get bored and **jump to a random industry**.

**Why the jump exists.** Without it the wanderer gets stuck. Any industry that
receives payments but makes few is a trap — the walk falls in and never leaves,
and its score inflates while everyone else's collapses. The random jump is the
escape hatch.

**Where 0.85 comes from.** It is the value Brin and Page used in the original
1998 PageRank paper and it has been the standard default ever since.
**We did not choose it by looking at what it did to our rankings**, and it is a
constant
at the top of `pipeline/network.py` rather than a number buried in the code.
Between about 0.8 and 0.9 the ordering here barely moves.

#### What this page deliberately does not show

**A PageRank league table**, because on this data it would be a size league
table wearing a different hat. See the *Influence vs size* figure above: the
rank correlation between PageRank and inflow is around **0.99**, and only about
one industry in seven moves five places or more.

So the ranking adds nothing. **The divergence does**, and that is what the
chart plots: industries sitting well below their size are ones whose money
arrives from payers that are themselves outside the circulation — typically
public administration. That identifies industries that are large but funded
from outside business-to-business payment flows, which no size ranking can
show.
"""


@st.cache_data(ttl=600, show_spinner=False)
def _pagerank_worked() -> str:
    """The size-versus-influence gap on the real data, recomputed."""
    try:
        metrics = data.node_metrics()
        panel = data.national()
    except Exception:
        return ""
    if metrics is None or metrics.empty:
        return ""
    latest = metrics.month.max()
    cur = metrics[metrics.month == latest]
    wide = cur.pivot_table(index=cur.node_id.str.split(":").str[-1],
                           columns="metric", values="value")
    if not {"pagerank", "in_strength"} <= set(wide.columns):
        return ""
    df = wide.dropna(subset=["pagerank", "in_strength"]).copy()
    df["pr_rank"] = df.pagerank.rank(ascending=False, method="min")
    df["size_rank"] = df.in_strength.rank(ascending=False, method="min")
    df["gap"] = df.size_rank - df.pr_rank
    rho = df.pr_rank.corr(df.size_rank, method="spearman")
    names = dict(zip(panel.sic2, panel["name"]))
    top = df.nsmallest(4, "gap")
    def short(text: str, limit: int = 34) -> str:
        """Truncate on a word boundary. '...refined pe' reads as a bug."""
        if len(text) <= limit:
            return text
        return text[:limit].rsplit(" ", 1)[0] + "\u2026"

    rows = "\n".join(
        f"| {c} {short(names.get(c, ''))} | {int(r.size_rank)} | "
        f"{int(r.pr_rank)} | **{int(r.gap):+d}** |"
        for c, r in top.iterrows())
    moved = int(df.gap.abs().ge(5).sum())
    return f"""
#### On this delivery — {latest:%B %Y}, recomputed when the page opens

Rank correlation between influence and size: **ρ = {rho:.3f}**, with
**{moved} of {len(df)}** industries moving five or more places. That is why
there is no league table here.

The industries ranked furthest **below** their size — the ones this page
exists to find:

| Industry | Rank by size | Rank by influence | Gap |
|---|---|---|---|
{rows}

A negative gap means **less influential than its size implies**: the money
arrives, but from payers who themselves sit outside the main circulation, so
little influence travels with it. Check the largest payer of each of these on
**Why did it move?** — it is usually public administration.
"""


# ---------------------------------------------------------------------------
# Phase 2: Louvain communities
# ---------------------------------------------------------------------------

LOUVAIN_METHOD = """
**Louvain finds groups of industries that trade more with each other than with
everyone else.** Nobody tells it what a supply chain looks like. It is handed
the payments and asked to find the grouping that best separates dense pockets
of trade from the background.

#### The idea, without any mathematics

Start with every industry in a group of its own. Repeatedly ask: *if I moved
this industry into its neighbour's group, would the grouping get better?* If
yes, move it. Keep going until no single move improves anything. Then treat
each group as one node and do it all again, so small groups merge into larger
ones.

"Better" has one specific meaning, below.

#### Modularity — the score that says whether any of it is real

**Modularity compares the trade inside the groups with the trade you would
expect if the same industries were wired up at random.**

- **0** means the groups are no denser inside than chance would produce — they
  are not communities, just a partition.
- **Towards 1** means trade is heavily concentrated inside groups.

**The 0.3 rule of thumb.** Newman and Girvan, who defined the measure in 2004,
reported that values above roughly **0.3** indicate structure worth
interpreting. It is a
**convention from the network-science literature, not a test** — there is no
p-value behind it, and we did not derive it from this data.

**This network sits below 0.3 at both levels tested.** That is reported on the
chart rather than tucked into a footnote, because it changes what the output
can be used for.

#### Why SIC5 and not SIC2

At **SIC2** the payment network is about **86% dense** after symmetrising:
almost every industry pays almost every other. There is nothing to cluster —
modularity comes out at **0.163**, and one of the four groups found is a
32-division catch-all spanning tobacco, electricity, accommodation and computer
manufacturing, which is not an economic cluster by any reading.

At **SIC5** — 706 nodes, ~21% density — modularity improves to roughly
**0.25**. Better, and still below the threshold.

#### Three settings, and why each is what it is

| Setting | Value | Why |
|---|---|---|
| **Seed** | **0**, fixed | Louvain is randomised: the same data could otherwise produce different groups on different runs. A fixed seed means the same delivery always clusters the same way. At this size the partition is nearly deterministic anyway — 94.9% agreement across 10 seeds, same community count every time — but the run must be reproducible regardless |
| **Smallest group reported** | **3** | A group of one or two industries is not a community, it is a pair of trading partners. Smaller groups are reported as *unclustered* rather than dressed up as findings |
| **Matching across years** | **25%** overlap | Louvain numbers its groups arbitrarily on each run, so group "3" in 2019 has nothing to do with group "3" in 2020. Groups are matched year to year by **Jaccard overlap** — shared members divided by total distinct members — and a match is accepted at 25% or above. Below that, it is reported as a **new** community rather than forced onto an old label. Without this step, tracking a cluster through time would be meaningless |

#### How to use this, and how not to

**Use it as a hypothesis generator.** Communities fracturing and reforming
through 2020 is the most informative thing here, and that pattern does not
depend on the modularity being high.

**Do not put it in a bulletin as a finding.** While modularity stays near 0.25,
these groups are real but weak. Say so alongside any picture of them.
"""


@st.cache_data(ttl=600, show_spinner=False)
def _louvain_live() -> str:
    try:
        summary = data.communities("community_summary")
    except Exception:
        return ""
    if summary is None or summary.empty:
        return ""
    s = summary.copy()
    per = "\n".join(
        f"| {pd.Timestamp(r.period):%Y} | {r.modularity:.3f} | "
        f"{int(r.communities)} | {int(r.nodes)} | {r.density:.1%} | "
        f"{int(r.largest)} |"
        for r in s.itertuples())
    lo, hi = s.modularity.min(), s.modularity.max()
    return f"""
#### On this delivery — recomputed when the page opens

| Year | Modularity | Communities | Nodes | Density | Largest group |
|---|---|---|---|---|---|
{per}

**Modularity ranges {lo:.3f} to {hi:.3f}** — below the 0.3 convention in every
year measured. The groups are real but weak, and every chart on this page
prints the score so that is visible rather than implied.

Note the **largest group** column. Where one group holds a large share of all
nodes, that group is a residual — "everything that did not cluster" — and
should not be read as an economic sector.
"""


# ---------------------------------------------------------------------------
# Phase 2: structural anomalies
# ---------------------------------------------------------------------------

STRUCTURAL_METHOD = """
**This detector asks a different question from everything else in the tool:
not "did the money move?" but "did the shape of the trading change?"**

An industry can receive exactly the same amount two years running while the set
of businesses paying it changes completely. The money says nothing happened.
Something did.

#### The nine things it watches

Each is a plain fact about an industry's month, taken from the data. None is
modelled.

| Feature | In plain terms |
|---|---|
| Number of counterparties | How many industries pay it |
| Concentration by value | Whether its money comes from few payers or many |
| Concentration by volume | The same, counting payments rather than pounds |
| Largest single relationship | How much rests on one payer |
| Self-share | How much of its activity is with itself |
| Unclassified share | How much arrives from payers with no industry code |
| Churn | How much its set of payers turned over since last month |
| Average payment size | Whether payments got bigger or smaller |
| Network position | Its PageRank — how central it is |

#### Each feature is measured against that industry's own history

Before anything is scored, every feature is standardised **within the
industry**. So the question is always *"is this unusual for this industry?"*,
never *"is this industry unusual?"* — otherwise the model would simply
rediscover that industries differ in size, which we knew.

#### How the score is produced — an Isolation Forest, in plain terms

Imagine trying to separate one month from all the others by asking random
yes/no questions about those nine numbers. *Is churn above 0.2? Is self-share
below 0.1?*

**An ordinary month takes many questions to pin down**, because it sits in the
crowd and looks like its neighbours. **An unusual month is isolated in very
few**, because it sits out on its own and one or two questions already single
it out.

The algorithm builds **300 such question-trees** at random and measures how few
questions each month needed on average. Fewer questions = stranger month. That
is the whole method — it is looking for points that are *easy to separate*, not
for points far from an average.

**Why this rather than a rule per feature.** It is the *combination* that
matters. Churn rising is ordinary. Concentration rising is ordinary. Both
rising while the unclassified share jumps is not, and no single-feature rule
would catch it.

#### The settings, and where they come from

| Setting | Value | Why |
|---|---|---|
| **Trees** | **300** | Enough that the average stops moving between runs. More costs time and changes nothing |
| **Seed** | **0**, fixed | The same delivery must score the same way twice |
| **Expected share of anomalies** | **3%** | This is the one genuine judgement here. It sets how many months get flagged — roughly two or three a month across all industries, which is a shortlist somebody can actually read. **It does not decide what is unusual**; it decides where to draw the line on a continuous score. Move it and you get a longer or shorter list of the same ranking |
| **Minimum history** | **12 months** | Below that there is not enough of the industry's own past to standardise against |
| **Score scale** | **0–100** | The raw output is rescaled between its 1st and 99th percentile so it reads like the Phase 1 severity — higher is stranger. The 1st/99th trim stops one extreme month compressing everything else into the bottom of the range |

#### What it is not

**It is not a severity score and the two are not comparable.** Phase 1 severity
is a distance measured in an industry's own typical variation, and 63 has an
arithmetic meaning. This score is a **rank within this dataset**, rescaled to
0–100. A structural score of 80 and a severity of 80 do not mean the same
thing.

**It does not say what changed** — the *What changed* column does that, by
naming which of the nine features moved furthest.

**It has no p-value.** It is an ordering, and the 3% cut is where the list was
drawn, not a statement about probability.
"""


@st.cache_data(ttl=600, show_spinner=False)
def _structural_worked() -> str:
    """One flagged industry-month, with the nine features that produced it."""
    try:
        struct = data.structural()
        panel = data.national()
    except Exception:
        return ""
    if struct is None or struct.empty:
        return ""
    flagged = struct[struct.structural_flag.eq(True)]
    if flagged.empty:
        return ""
    r = flagged.nlargest(1, "structural_score").iloc[0]
    names = dict(zip(panel.sic2, panel["name"]))
    labels = {
        "n_counterparties": "Number of counterparties",
        "hhi": "Concentration by value",
        "hhi_volume": "Concentration by volume",
        "top_share": "Largest single relationship",
        "self_share": "Self-share",
        "unclassified_share": "Unclassified share",
        "churn": "Counterparty churn",
        "avg_payment": "Average payment size",
        "pagerank": "Network position",
    }
    rows = []
    for col, label in labels.items():
        z = r.get(f"z_{col}")
        if z is None or not np.isfinite(z):
            continue
        rows.append((abs(z), label, z))
    rows.sort(reverse=True)
    body = "\n".join(
        f"| {label} | {z:+.2f} | "
        + ("**largest mover**" if i == 0 else
           "unusual for this industry" if abs(z) >= 2 else "within its normal range")
        + " |"
        for i, (_, label, z) in enumerate(rows))
    biggest = rows[0][0] if rows else 0.0
    n_unusual = sum(1 for a, _, _ in rows if a >= 2)
    return f"""
#### A real flagged month, with the numbers behind it

**SIC {r.sic2} {names.get(str(r.sic2), '')}, {pd.Timestamp(r.month):%B %Y}** —
structural score **{r.structural_score:.0f}** out of 100.

Each figure below is that feature measured **in standard deviations from this
industry's own normal**. Zero means perfectly typical for it; ±2 means
unusually far from its own history.

| Feature | Distance from its own normal | |
|---|---|---|
{body}

**What the detector said about it:** *"{r.structural_reason}"*

**Read it this way.** {"The largest mover here is extreme on its own (" + f"{biggest:.1f}" + " standard deviations), so this month would stand out on that feature alone. What the detector adds is that " + f"**{n_unusual} of the nine features**" + " moved together." if biggest >= 5 else "No single one of these numbers is extreme on its own. The score is high because " + f"**{n_unusual} of the nine features**" + " moved at once."} A rule
per feature would either miss that or fire constantly; looking for months that
are **easy to isolate across all nine at once** is what an Isolation Forest is
for.

Recomputed from `outputs/structural.csv` when this page opens.
"""


# ---------------------------------------------------------------------------
# Phase 2 and Gainers & losers: what each page shows
# ---------------------------------------------------------------------------
#
# Lifted out of the page files so every guide is assembled from one place.

WHAT_INFLUENCE = """
**What this shows.** Every industry's position in the payment network, measured
by PageRank — money received, weighted by how central the payers sending it are.

**Read the gap, not the ranking.** PageRank and size rank industries almost
identically (correlation 0.992), so the league table on its own tells you
nothing new. The **divergence** does: an industry ranked far below its size is
one funded from outside the business-to-business network.

**Why an industry can be large but not central.** Money arriving from a payer
that receives little itself passes on little influence. Public administration
is the clearest case — it pays out heavily and receives comparatively little,
so industries it funds score below their size.
"""


WHAT_CLUSTERS = """
**What this shows.** Louvain community detection over the SIC-5 payment network,
run once per year. It groups industries that trade more heavily with each other
than with the rest of the economy — organically, from the transactions, with no
pre-set idea of what a supply chain looks like.

**Read the modularity first.** It scores how much denser the trade inside these
groups is than chance would produce, from 0 to 1. **This network sits below the
0.3 convention in every year measured**, so the groups are real but weak. Treat
them as a place to look, not as a result, and do not describe them as
"communities" in anything published without saying so.

Where 0.3 comes from, why the level is SIC-5 rather than SIC-2, and what the
three settings do are all on the **How Louvain works** tab.

**Community keys survive across years.** Louvain numbers its groups arbitrarily
each run, so the keys are matched year to year by membership overlap. Without
that, following a cluster through time would be meaningless.
"""


WHAT_SHIFTS = """
**What this shows.** Seven measures of the *shape* of an industry's inflows —
none of them a measure of size. Each is scored against that industry's own
history, so the question is whether a month is unusual **for it**.

**Why it matters.** An industry can keep its total steady while its funding base
changes underneath. Retail in April 2020 moved −0.6% year-on-year — invisible to
the level detector — while public administration went from 18% to 40% of
everything it received.

**How to read a flagged month.** The bar chart shows how far each feature sat
from that industry's normal, in standard units. The bars furthest from zero are
what isolated it. Then look at the payer composition beneath to see what
actually moved.

**A structural shift is not automatically bad, or even economic.** A
reclassification changes shape too. Read the features before drawing a
conclusion.
"""


WHAT_LEADERBOARD = """
**What this shows.** The biggest risers and fallers over a chosen window —
1, 3, 6 or 12 months, or year-to-date — with the two ends side by side.

**Ranking by % and by £ give different answers, and both are right.**
Percentage favours small industries; pounds favours large ones. Public
administration's £2.3bn rise over the year does not appear in the percentage
view at all. Switch between them rather than trusting one.

**The size floor.** Industries below £50m a month are excluded, because a 60%
move on a £40m base is noise next to a 3% move on £14bn. The caption says how
many were excluded.

**Anomaly scores** carry through where they exist. They read `-` for a single
region: 18 months of regional history cannot support a seasonal baseline.
"""
