"""Chart palette and Plotly defaults.

Both modes are selected, not flipped: the dark values are the same hues stepped
for a dark surface. Every categorical set here has been run through the palette
validator for colour-vision separation and contrast in both modes.
"""
from __future__ import annotations

import plotly.graph_objects as go
import plotly.io as pio
import streamlit as st

LIGHT = {
    "surface": "#fcfcfb", "plane": "#f9f9f7",
    "ink": "#0b0b0b", "ink2": "#52514e", "muted": "#898781",
    "grid": "#e1e0d9", "axis": "#c3c2b7",
    # categorical slots 1-3, validated light: worst adjacent CVD dE 9.2
    "s1": "#2a78d6", "s2": "#eb6834", "s3": "#1baf7a",
    # diverging poles, gray midpoint
    "pos": "#2a78d6", "neg": "#d03b3b", "mid": "#f0efec",
    "good": "#0ca30c", "warn": "#fab219", "serious": "#ec835a", "critical": "#d03b3b",
}

DARK = {
    "surface": "#1a1a19", "plane": "#0d0d0d",
    "ink": "#ffffff", "ink2": "#c3c2b7", "muted": "#898781",
    "grid": "#2c2c2a", "axis": "#383835",
    "s1": "#3987e5", "s2": "#d95926", "s3": "#199e70",
    "pos": "#3987e5", "neg": "#e66767", "mid": "#383835",
    "good": "#0ca30c", "warn": "#fab219", "serious": "#ec835a", "critical": "#d03b3b",
}

# Categories in the change decomposition. Continuing flows are the baseline
# story and take slot 1; the two data-presence categories are deliberately a
# different hue because they are not economic effects (BUILD_SPEC 6.7).
CATEGORY_COLOURS = {
    "continuing": "s1",
    "newly_present": "s3",
    "absent_suppressed": "s2",
}

CONFIDENCE_COLOURS = {"high": "good", "medium": "warn", "low": "critical"}


def palette() -> dict[str, str]:
    """Colours for the viewer's current theme."""
    try:
        base = st.get_option("theme.base") or "light"
    except Exception:                                    # pragma: no cover
        base = "light"
    return DARK if str(base).lower() == "dark" else LIGHT


def style(fig: go.Figure, *, height: int = 420, legend: bool = True,
          x_title: str = "", y_title: str = "") -> go.Figure:
    """Apply chart chrome: recessive axes, no chart junk, readable ink."""
    p = palette()
    fig.update_layout(
        height=height,
        margin=dict(l=8, r=8, t=8, b=8),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(family="system-ui, -apple-system, Segoe UI, sans-serif",
                  size=13, color=p["ink2"]),
        hoverlabel=dict(font_size=13, bgcolor=p["surface"],
                        bordercolor=p["axis"], font_color=p["ink"]),
        showlegend=legend,
        legend=dict(orientation="h", yanchor="bottom", y=1.02,
                    xanchor="left", x=0, title_text=""),
    )
    fig.update_xaxes(title_text=x_title, showgrid=False, zeroline=False,
                     linecolor=p["axis"], tickcolor=p["axis"],
                     tickfont=dict(color=p["muted"]))
    fig.update_yaxes(title_text=y_title, gridcolor=p["grid"], zeroline=False,
                     linecolor="rgba(0,0,0,0)", tickfont=dict(color=p["muted"]))
    return fig


MAX_LABEL = 38


def short(text: str) -> str:
    """Trim a long SIC description so the axis does not eat the plot.

    Several run past 70 characters ("Manufacture of computer, electronic and
    optical products"), which at 12px leaves almost no width for the bars.
    The full name stays in the hover.
    """
    return text if len(text) <= MAX_LABEL else text[:MAX_LABEL - 1].rstrip(" ,") + "\u2026"


def money(x: float, decimals: int | None = None) -> str:
    """Format a value in pounds at a sensible magnitude."""
    if x is None or x != x:
        return "n/a"
    a = abs(x)
    if a >= 1e12:
        return f"£{x/1e12:,.{2 if decimals is None else decimals}f}tn"
    if a >= 1e9:
        return f"£{x/1e9:,.{1 if decimals is None else decimals}f}bn"
    if a >= 1e6:
        return f"£{x/1e6:,.{0 if decimals is None else decimals}f}m"
    return f"£{x:,.0f}"


def install() -> None:
    """Register the default Plotly template once per session."""
    p = palette()
    pio.templates["pm"] = go.layout.Template(
        layout=dict(colorway=[p["s1"], p["s2"], p["s3"]])
    )
    pio.templates.default = "plotly_white+pm"
