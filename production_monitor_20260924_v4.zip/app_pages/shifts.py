"""Structural shifts — when an industry's trading changes shape.

Phase 2. The Phase 1 detector watches an industry's money. This watches its
relationships: who pays it, how many, how concentrated, how much is internal.
An industry can hold its total steady while a fifth of its funding base changes
hands, and only this sees it.

Most of what this flags is invisible to the level detector; the
exact share is measured from the current outputs and shown on the page.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from pipeline import config as cfg
from pipeline.structural import FEATURES

from . import data, method, theme
from export import report

FEATURE_LABEL = {
    "n_counterparties": "Industries paying it",
    "hhi": "Concentration (HHI)",
    "top_share": "Largest payer's share",
    "self_share": "Paid by itself",
    "unclassified_share": "From unclassified payers",
    "churn": "Counterparty turnover",
    "pagerank": "Position in the network",
}

def _deviation_chart(row: pd.Series) -> go.Figure:
    p = theme.palette()
    vals, labels = [], []
    for f in FEATURES:
        z = row.get(f"z_{f}")
        if pd.notna(z):
            vals.append(float(z))
            labels.append(FEATURE_LABEL.get(f, f))
    order = np.argsort(np.abs(vals))
    vals = [vals[i] for i in order]
    labels = [labels[i] for i in order]
    fig = go.Figure(go.Bar(
        x=vals, y=labels, orientation="h",
        marker=dict(color=[p["pos"] if v > 0 else p["neg"] for v in vals],
                    line=dict(width=0)),
        text=[f"{v:+.1f}" for v in vals], textposition="outside",
        textfont=dict(size=12, color=p["ink2"]),
        hovertemplate="<b>%{y}</b><br>%{x:+.1f} vs this industry's normal"
                      "<extra></extra>"))
    fig.add_vline(x=0, line_width=1, line_color=p["axis"])
    theme.style(fig, height=300, legend=False,
                x_title="distance from this industry's normal (robust z)")
    span = max(abs(min(vals)), abs(max(vals))) if vals else 1
    fig.update_xaxes(range=[-span * 1.35, span * 1.35])
    return fig


def _composition_chart(edges, code: str, month: pd.Timestamp,
                       names: dict, top_n: int = 6) -> tuple[go.Figure, pd.DataFrame]:
    """Who paid this industry, this month against the same month a year back."""
    p = theme.palette()
    base = month - pd.DateOffset(months=12)

    def shares(m):
        sel = edges[(edges.payee == code) & (edges.month == m)
                    & (edges.payer != cfg.UNCLASSIFIED_SIC)]
        total = sel.value.sum()
        if not total:
            return pd.Series(dtype=float)
        return sel.groupby("payer").value.sum().sort_values(ascending=False) / total

    now, then = shares(month), shares(base)
    if now.empty:
        return None, pd.DataFrame()
    keep = list(now.head(top_n).index)
    rows = pd.DataFrame({
        "payer": keep,
        "then": [then.get(k, 0.0) for k in keep],
        "now": [now.get(k, 0.0) for k in keep],
    })
    rows["label"] = [f"{k} {names.get(k, '')}"[:34] for k in keep]
    # Not "shift": that name resolves to DataFrame.shift() on attribute
    # access and returns the method rather than the column.
    rows["change"] = rows.now - rows.then

    fig = go.Figure()
    fig.add_trace(go.Bar(y=rows.label, x=rows.then * 100, orientation="h",
                         name=f"{base:%b %Y}", marker=dict(color=p["s3"],
                         line=dict(width=0)),
                         hovertemplate="%{y}<br>%{x:.1f}%<extra>"
                                       + f"{base:%b %Y}</extra>"))
    fig.add_trace(go.Bar(y=rows.label, x=rows.now * 100, orientation="h",
                         name=f"{month:%b %Y}", marker=dict(color=p["s1"],
                         line=dict(width=0)),
                         hovertemplate="%{y}<br>%{x:.1f}%<extra>"
                                       + f"{month:%b %Y}</extra>"))
    fig.update_layout(barmode="group", bargap=0.3)
    theme.style(fig, height=max(260, 42 * len(rows) + 90),
                x_title="share of this industry's inflow, %")
    return fig, rows


def render() -> None:
    st.subheader("Structural shifts")
    method.page_guide("shifts")

    struct = data.structural()
    if struct is None or struct.empty:
        st.warning("No structural metrics yet. Run the pipeline.")
        return

    panel = data.national()
    names = dict(zip(panel.sic2, panel["name"]))
    alerts = data.alerts()
    edges = data.edges()

    flagged = struct[struct.structural_flag.eq(True)].copy()
    latest = struct.month.max()

    c1, c2, c3 = st.columns([1.3, 1.2, 1.4])
    with c1:
        scope = st.selectbox("Period", ["Last 12 months", "Last 24 months",
                                        "All history"], index=0)
    windows = {"Last 12 months": latest - pd.DateOffset(months=11),
               "Last 24 months": latest - pd.DateOffset(months=23),
               "All history": struct.month.min()}
    # .copy(): a column is added below, and assigning into a slice raises
    # SettingWithCopyWarning and is not guaranteed to reach the caller.
    window = flagged[flagged.month >= windows[scope]].copy()

    lvl = alerts[(alerts.level == "division") & (alerts.measure == "pfi")
                 & (alerts.basis == "YoY") & (alerts.severity >= 63)]
    level_keys = set(zip(lvl.code, lvl.month))
    window["also_level"] = [(c, m) in level_keys
                            for c, m in zip(window.sic2, window.month)]

    a, b, c = st.columns(3)
    a.metric("Structural shifts", f"{len(window)}")
    b.metric("Also flagged on level", f"{int(window.also_level.sum())}")
    quiet = int((~window.also_level).sum())
    c.metric("Invisible to the level detector", f"{quiet}",
             help="Industries whose shape changed while their totals looked "
                  "ordinary. This is the group the measure exists for.")

    # ---- timeline -------------------------------------------------------
    counts = (flagged.groupby("month").size()
              .reindex(sorted(struct.month.unique()), fill_value=0))
    p = theme.palette()
    tl = go.Figure(go.Bar(
        x=counts.index, y=counts.values,
        marker=dict(color=p["s1"], line=dict(width=0)),
        hovertemplate="%{x|%b %Y}<br>%{y} industries<extra></extra>"))
    theme.style(tl, height=220, legend=False, y_title="industries flagged")
    st.plotly_chart(tl, use_container_width=True,
                    config={"displayModeBar": False})
    report.heading("Structural shifts over time")
    report.figure(tl, "Industries whose trading changed shape, per month.")

    if window.empty:
        st.success("No structural shifts in this window.")
        return

    # ---- the list -------------------------------------------------------
    listing = window.sort_values(["month", "structural_score"],
                                 ascending=[False, False])
    table = pd.DataFrame({
        "Month": listing.month.dt.strftime("%b %Y"),
        "Industry": listing.sic2 + " " + listing.sic2.map(names).fillna(""),
        "Score": listing.structural_score.round(0).astype(int),
        "Level alert too?": np.where(listing.also_level, "yes", "no"),
        "What changed": listing.structural_reason,
    })
    st.dataframe(table, use_container_width=True, hide_index=True)
    report.table(table, "Structural shifts in this window.")

    # ---- inspect one ----------------------------------------------------
    st.markdown("### Inspect one")
    # Plain string options with a lookup, rather than tuples plus a
    # format_func: a format_func that indexes into its argument breaks the
    # moment it is handed anything but the expected tuple.
    choices = {
        f"{pd.Timestamp(m):%b %Y} · {c} {names.get(c, '')}": (c, pd.Timestamp(m))
        for c, m in zip(listing.sic2, listing.month)
    }
    pick = st.selectbox("Flagged industry-month", list(choices))
    code, month = choices[pick]
    row = struct[(struct.sic2 == code) & (struct.month == month)].iloc[0]

    wide = panel.pivot_table(index="month", columns="sic2", values="pfi")
    try:
        yoy = wide.loc[month, code] / wide.loc[month - pd.DateOffset(months=12), code] - 1
    except Exception:
        yoy = np.nan

    m1, m2 = st.columns(2)
    m1.metric("Structural score", f"{row.structural_score:.0f}")
    m2.metric("PFI year-on-year", f"{yoy:+.1%}" if np.isfinite(yoy) else "n/a",
              help="If this is small, the level detector saw nothing here.")

    if np.isfinite(yoy) and abs(yoy) < 0.05:
        st.info(
            f"**The money barely moved ({yoy:+.1%}) but the shape did.** This is "
            f"exactly the case the measure exists for — nothing in the Phase 1 "
            f"views would have surfaced this industry-month.")

    st.markdown("**Which features were unusual**")
    dev = _deviation_chart(row)
    st.plotly_chart(dev, use_container_width=True,
                    config={"displayModeBar": False})
    st.caption(
        "Distance from this industry's own median, in robust standard units. "
        "Bars furthest from zero are what isolated the month. Computed against "
        "the industry's own history, so a large bar means unusual *for it*.")
    report.heading(f"{code} {names.get(code,'')} — {month:%B %Y}")
    report.figure(dev, "How far each structural feature sat from normal.")

    st.markdown("**Who was paying it, and how that changed**")
    comp, rows = _composition_chart(edges, code, month, names)
    if comp is None:
        st.caption("No counterparty detail available for that month.")
        return
    st.plotly_chart(comp, use_container_width=True,
                    config={"displayModeBar": False})
    report.figure(comp, "Share of inflow by payer, against the same month a "
                        "year earlier.")

    biggest = rows.reindex(rows["change"].abs().sort_values(ascending=False).index).iloc[0]
    if abs(biggest["change"]) > 0.05:
        direction = "rose" if biggest["change"] > 0 else "fell"
        st.success(
            f"**{biggest.label}** {direction} from {biggest.then:.0%} to "
            f"{biggest.now:.0%} of everything this industry received — a shift "
            f"of {abs(biggest['change']):.0%} of its funding base in twelve months."
        )
