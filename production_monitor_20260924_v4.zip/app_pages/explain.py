"""Shared definitions, rendered at the point of use.

A definition that lives only in a glossary is a definition nobody reads. These
appear on every view where the term can be selected.
"""
from __future__ import annotations

import pandas as pd
import streamlit as st

from . import data

# Shown on the Measure control everywhere.
MEASURE_HELP = (
    "PFI = inflow + outflow − self-flow, the total value of payments flowing "
    "through an industry in a month. Inflow is money it received; outflow is "
    "money it paid. Open 'How PFI is calculated' below the controls for the "
    "full definition."
)


def _worked_example() -> str:
    """A real industry-month, so the arithmetic is checkable."""
    try:
        panel = data.national()
        month = panel.month.max()
        row = panel[(panel.sic2 == "41") & (panel.month == month)]
        if not len(row):
            return ""
        r = row.iloc[0]
        if not all(pd.notna(r[c]) for c in ("inflow", "outflow", "self_flow", "pfi")):
            return ""
        return f"""
#### Worked example — SIC 41 Construction of buildings, {month:%B %Y}

| | £m | |
|---|---|---|
| Inflow | {r.inflow/1e6:,.0f} | received from other industries, including from itself |
| Outflow | {r.outflow/1e6:,.0f} | paid to other industries, including to itself |
| Self-flow | {r.self_flow/1e6:,.0f} | construction firms paying other construction firms |
| **PFI** | **{r.pfi/1e6:,.0f}** | {r.inflow/1e6:,.0f} + {r.outflow/1e6:,.0f} − {r.self_flow/1e6:,.0f} |

Every figure on this page can be reproduced from `outputs/series_national.csv`.
"""
    except Exception:
        return ""


def measures_markdown() -> str:
    """The three measures and exactly how each is computed.

    Returned as text rather than rendered, so a page can place it inside its
    single "How to read this page" box instead of opening a box of its own.
    Pages used to render five to nine separate expanders; a reader met the
    boxes before they met a number.
    """
    return ("""
Every row of the source data is one **payer industry → payee industry → month →
value**. Each industry therefore has two sides, and a third measure combines
them.

#### The three measures

| Measure | Calculation | Reads as |
|---|---|---|
| **Inflow** | Sum of `value` on every row where this industry is the **payee** | Money received — a proxy for sales |
| **Outflow** | Sum of `value` on every row where this industry is the **payer** | Money paid out — a proxy for input purchases |
| **PFI** | `inflow + outflow − self-flow` | Total payment throughput |

**PFI** stands for **Payment Flow Index**, but it is **not an index**:
it is a value in pounds, never rebased to 100 or to any reference period.
The name carries over from the original ONS framing and we kept it for
continuity — read it as *payment throughput*.

#### Why self-flow is subtracted

A payment from one construction firm to another appears **twice** in the
underlying data from construction's point of view: once as an inflow (it was
received by construction) and once as an outflow (it was paid by construction).
Both are genuine, so both belong in their own measure — but adding the two
together to get throughput would count that payment twice.

Subtracting self-flow once corrects it. This is not a rounding concern:
**intra-industry payments are 14.3% of all classified value** over the whole
period, and for an individual industry they run from 1% to 32% of its inflow —
31% for financial services in the latest month.
""" + _worked_example() + """
#### Which basis

Each measure is available two ways, via the **Basis** control:

- **Classified only** — counts only rows where **both** ends have a real
  industry code. This is the stable series and is what every anomaly score is
  computed on.
- **Including SIC 00** — also counts rows where one or both ends are
  unclassified. Roughly three times larger, but it moves whenever
  classification coverage moves.

#### Which to use

**PFI** is the default because inflows and outflows correlate 0.74 with neither
leading the other, so combining them averages out payment-timing noise without
losing signal. Use **inflow** alone when you specifically want a sales proxy, and
**outflow** when you want input purchases.

#### What none of them are

A payment is not production. The data records that money moved between two
industries in a month — not what it bought, nor when the underlying work was
done. Payment terms mean a payment can lag the activity it pays for by weeks or
months, and that lag differs by industry.
""")


def measures() -> None:
    """Standalone box. Kept for any surface with no page guide to fold into."""
    with st.expander("How PFI is calculated, and what the three measures mean"):
        st.markdown(measures_markdown())
