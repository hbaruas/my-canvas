"""How to use this as an investigative instrument.

Answers two questions the tool cannot answer by existing: in what order should
someone look at things, and what can be asked of this data that is not obvious
from the front page.

Every route here is executable today with the views as built. Nothing needs
developing first.
"""
from __future__ import annotations

import streamlit as st

from . import data


def render() -> None:
    st.subheader("Playbook")
    st.markdown(
        "The dashboard shows what moved. This page is about **what to ask of "
        "it** — the routes that are not obvious from any single screen, and the "
        "order to take them in."
    )

    tabs = st.tabs(["Writing the monthly bulletin", "Investigations",
                    "Plain-English guide", "What the data can and cannot answer"])

    # ------------------------------------------------------------------
    with tabs[0]:
        st.markdown("""
### A new delivery has landed. You have to write the bulletin.

Each step says exactly which view to open, which controls to set, and what to
do with what you see. About forty minutes the first time.

---

#### 1 · Check the delivery before looking at a single number
**Open:** Reference → **The dataset**

**Do this:**
1. Read the four figures at the top — rows, transactions, total value, months.
2. Scroll to **"Is this delivery like the last one?"** and look at the
   transaction line. You are looking for a *step*, not a wobble.
3. If a red or amber box appears listing months, open the note beneath it.
4. Scroll to **"How much of it can be attributed to an industry?"** and note the
   unclassified share. If it has moved several points since last month, say so
   in the bulletin's notes.

**What you are deciding:** whether this month's numbers sit on the same base as
last month's.

> **Stop condition.** If the latest month is flagged for low volume, do not
> write a year-on-year story about it. Use month-on-month and say why.

---

#### 2 · See what moved
**Open:** Phase 1 → **Movers**

**Set:** Month = latest · Compare with = **YoY** · Measure = **PFI** ·
Level = **Division (SIC2)** · Basis = **Classified only** · Region = All UK

**Do this:**
1. Read the three sentences under **"What changed this month"** first. They are
   generated from each industry's own counterparty breakdown and usually tell
   you the story before you look at anything else.
2. Read the table. It is ranked by *how unusual* a move is, then by size.
3. Now read the **Confidence** column, not the Change column. Anything marked
   `low` is probably a reporting change — note it for the data-quality section
   rather than the economic one.
4. Switch **Basis** to **Including SIC 00** and glance at the ranking. If an
   industry moves a long way between the two bases, its classified series is
   being driven by classification coverage, not activity.

**Write down:** the three or four industries with high severity *and* medium or
high confidence.

---

#### 3 · Narrow to what is genuinely unusual
**Open:** Phase 1 → **Outliers**

**Set:** Measure = PFI · Compare with = YoY · Period = **Latest month** ·
Confidence = **high** and **medium** · Severity slider = **63**

**Do this:** read the list. 63 is what the severity formula returns at
|z| = 3 — the three-sigma convention — and nothing more: 100 × (1 − e^(−3/3))
= 63.2. It is a browsing dial, not a test of significance. Usually three to six
industries remain. Open **How "Unusual?" is calculated** on that page for the
full derivation and a worked example.

**Why bother when Movers already ranked them:** Movers ranks partly by size.
This asks only whether a move is unusual *for that industry*. An industry that
routinely swings 20% is not news at 20%.

---

#### 4 · Find out what caused each one
**Open:** Phase 1 → **Why did it move?**

**Set:** SIC = your candidate · Month = latest · Compare with = YoY ·
Measure = PFI · Basis = Including SIC 00

**Do this:**
1. Look at **Presence share** first, top right.
   - **Above 50%** — the move is counterparties entering or leaving the data.
     Stop. This belongs in the data-quality notes, not the economic commentary.
   - **Below 25%** — carry on.
2. Read the waterfall. Each bar is one counterparty industry. Blue bars are
   relationships that continued and changed; the other colours are
   relationships that appeared or vanished.
3. Ask: **one big bar, or many small ones?** A move carried by a single
   counterparty is a story about one relationship. A broad-based move is a
   story about an industry. They need different sentences even at identical
   size.

---

#### 5 · Check whether it is new
**Open:** Phase 1 → **Trends**

**Set:** Industry = your candidate · Compare = **Measures** · pick PFI

**Do this:** find the latest point against the shaded band, which is that
industry's normal range.
- **Just outside it for the first time** — a genuine turning point.
- **Outside it for several months** — you are late; the story is the
  persistence, not this month.
- **Inside it** — a large move for the economy, a normal one for this industry.
  Say so.

Look for dotted vertical lines: those are structural breaks, and a recent one
means the baseline is short and the score provisional.

---

#### 6 · Get the longer view for the framing sentence
**Open:** Phase 1 → **Gainers & losers**

**Set:** Period = **12 months** · Measure = PFI · Rank by = **£ change**, then
switch to **% change**.

**Do this:** note the top two or three from each ranking. They barely overlap.
Pounds tell you what moved the economy; percentages tell you what moved an
industry. A bulletin usually wants one sentence of each.

---

#### 7 · Export the evidence
**Sidebar → Export → Monthly briefing**

A single self-contained file with the headline, the driver sentences, the
ranked table and the data-quality caveats. It opens with no internet
connection. Treat it as the evidence base for the bulletin, not the bulletin.
""")
        st.info(
            "**The two steps people skip under time pressure are 1 and 4** — "
            "checking the delivery, and checking presence share before writing. "
            "They are the two that stop a reporting change being published as "
            "an economic finding."
        )

    # ------------------------------------------------------------------
    with tabs[1]:
        st.markdown("""
### Investigations

Each of these is a hypothesis the data can actually test, with the route to
test it. None of them is visible on the front page.

---

#### A · Is this recovery real, or is it one customer?
**Who asks:** sector analyst, credit risk.
**Hypothesis:** an industry's growth is concentrated in a single counterparty
relationship, and is therefore fragile.

**Route.** Movers → find the riser → *Why did it move?* → read
**top counterparty share** and the waterfall.

**What tells you:** a 70%+ share from one counterparty alongside high breadth
is the interesting case — many counterparties moved, but one carried the
money. That industry's next month depends on one relationship. SIC 66 in June
2026 is 102% of its move from a single counterparty.

---

#### B · Price or volume?
**Who asks:** inflation analyst.
**Hypothesis:** an industry's value growth is prices, not activity.

**Route.** Trends → **Diagnostics** → plot *Payments received (count)*, then
*Average payment received*, for the same industry.

**What tells you:** value up with flat transaction counts and a rising average
payment is a price story. Value up with rising counts and a flat average is a
volume story. The two have opposite implications for output, and the headline
series cannot separate them.

> A caution: average payment size also moves when the *mix* of payers changes,
> so treat a single month as suggestive and a sustained divergence as evidence.

---

#### C · Who is paying their suppliers more slowly?
**Who asks:** credit risk, early-warning.
**Hypothesis:** an industry under working-capital pressure slows its outgoing
payments before its incoming payments fall.

**Route.** Trends → **Compare measures** → plot *Inflows* and *Outflows*
together for one industry.

**What tells you:** the two normally move together — correlation 0.74, with
neither leading. **A sustained divergence is the signal**, because it is
against type. Outflows falling while inflows hold is the shape to look for.

---

#### D · Is this industry becoming more self-contained?
**Who asks:** structural economist, competition analyst.
**Hypothesis:** consolidation or vertical integration shows up as an industry
trading more with itself.

**Route.** Trends → **Diagnostics** → *Self-flow (within industry)*, against
the same industry's inflow.

**What tells you:** a rising self-flow share means more of the industry's
activity is internal — consolidation, or work moving inside firm boundaries.
It runs from 1% to 32% across industries, so the level says little; the
**trend** is the finding.

---

#### E · Which relationships is an industry's output hostage to?
**Who asks:** supply-chain risk, resilience planning.
**Hypothesis:** an industry depends on a small number of counterparties whose
loss would be material.

**Route.** *Why did it move?* → pick any recent month → read the waterfall's
largest bars, then **Data quality → Unstable cells**.

**What tells you:** the waterfall names the relationships that matter. The
cell-stability table names the ones that are **intermittently reported** — and
a relationship that vanishes from the data for months at a time is one you
cannot monitor even though it exists. Those are the blind spots in any
resilience assessment built on this data.

---

#### F · Did something happen to an industry, or to the economy?
**Who asks:** anyone about to write a sentence beginning "manufacturing fell".
**Hypothesis:** an apparent industry shock is a common movement.

**Route.** Movers → look at the systemic banner → Outliers → compare an
industry's `%` change with the typical industry that month.

**What tells you:** the detection already subtracts what every industry did, so
a high severity score means the industry moved **differently** from the rest.
But the raw percentage does not. Quoting the raw percentage in a month when
everything moved is the single easiest way to publish a wrong number.

---

#### G · Is an industry's classification changing under us?
**Who asks:** methodologist, anyone quoting a level.
**Hypothesis:** a change in the series reflects how counterparties are coded,
not what they did.

**Route.** Trends → **Diagnostics** → *Share from unclassified payers*.

**What tells you:** a step in this line is a classification change. Education's
share went from 23% to 70% in March 2025 while total money in rose 6% — the
classified series fell 58% and nothing economic happened. Any industry with a
moving unclassified share should be quoted on the including-SIC-00 basis, or
not quoted.

---

#### H · Is the regional picture real, or is attribution improving?
**Who asks:** regional analyst.
**Hypothesis:** a region's apparent growth is previously-unattributed value
becoming attributable.

**Route.** Trends → **Compare regions** → add the region **and**
`Unknown / unattributed` to the same chart.

**What tells you:** if unknown is falling while your region rises, you are
watching attribution improve, not the region grow. Payer-side unknown has
already fallen from 19.3% to 16.0% across the 18 months available. Never read a
regional trend without this line beside it.

---

#### J · Is an industry settling differently — fewer, larger payments?
**Who asks:** credit risk, sector analyst.
**Hypothesis:** the commercial relationship has changed character even though
the money is the same — consolidated invoicing, longer terms, fewer larger
settlements.

**Route.** Trends → **Diagnostics** → *Payments received (count)* and
*Average payment received* · then Phase 2 → **Influence** → the value-versus-volume
tables.

**What tells you:** value flat, count falling, average payment rising means the
same money arriving in fewer, bigger transfers. At network level, construction
and civil engineering sit about 30 places higher by value than by volume;
water, telecoms and postal sit higher by volume. A sector moving *between* those
patterns is changing how it does business.

---

#### K · Which industries would notice first if a sector stopped paying?
**Who asks:** resilience planning, contingency.
**Hypothesis:** an industry's failure propagates first to those most dependent
on it as a payer.

**Route.** Phase 1 → *Why did it move?* → set **Side = Outflows** for the
industry in question, any recent month.

**What tells you:** the outflow waterfall names who it pays and how much. Those
with the largest bars lose the most if it stops. Cross-check each in
**Structural shifts** — an industry already showing high top-payer
concentration is the one least able to absorb it.

---

#### L · Has an industry quietly changed who funds it?
**Who asks:** policy, sector desk.
**Hypothesis:** the composition of an industry's funding has shifted without
its total changing.

**Route.** Phase 2 → **Structural shifts** → pick a flagged industry-month →
read the payer composition chart.

**What tells you:** this is the single clearest case in the data. Retail in
April 2020 moved −0.6% year-on-year while public administration went from 18%
to 40% of everything it received. Nothing in Phase 1 would have surfaced it.

---

#### I · What is this industry's normal, and who decides?
**Who asks:** anyone setting expectations for a sector.
**Hypothesis:** an industry's volatility, not its size, determines whether a
move is newsworthy.

**Route.** Outliers → set severity low (about 40) → sort by industry.

**What tells you:** which industries generate alerts constantly and which
almost never do. A 30% move means something very different in each. This is
also the fastest way to learn which industries in this data are simply noisy —
useful before promising anyone a monthly story about them.
""")

    # ------------------------------------------------------------------
    with tabs[2]:
        st.markdown("""
### Plain-English guide

For anyone opening this for the first time. No statistics assumed.

---

#### The data, in one paragraph
Every row says: **this industry paid that industry, this much, this month, in
this many separate payments.** Nothing else. Not what was bought, not when the
work happened, not who the individual firms were. Roughly 3 million UK
organisations, via Bacs and Faster Payments.

---

#### Inflow, outflow, PFI
Each industry has two sides.

- **Inflow** — money it received. Closest thing here to its sales.
- **Outflow** — money it paid out. Closest thing to its costs.
- **PFI** — inflow + outflow, minus what it paid itself. Total money flowing
  through it. *PFI is a value in pounds, despite the name — it is not an index
  and is not rebased to 100.*

We subtract the industry's payments to itself because they appear on both
sides, and counting them twice would inflate the total. They matter: 14.3% of
all classified value is an industry paying itself.

---

#### Classified, unclassified, suppressed — three different things
These get confused, and they mean different things.

| Term | Meaning | Is there a number? |
|---|---|---|
| **Classified** | Both ends have an industry code | Yes |
| **Unclassified (SIC 00)** | The payment happened, but one end has no industry code | **Yes** — the money is real |
| **Suppressed `[c]`** | The provider withheld the figure to protect an identifiable organisation | **No** — unknown, and never treated as zero |

Unclassified is not missing data. It is a real payment to an unidentified
counterparty, and it is roughly two thirds of all value. Every view lets you
include or exclude it.

---

#### Severity — "how unusual is this?"
A number from 0 to 100. It answers: **how far is this month from what this
industry normally does?**

It is built in four steps:
1. Take the industry's monthly series.
2. Subtract what *every* industry did that month, so a nationwide movement does
   not count as an industry shock.
3. Compare the remainder against the industry's **own** past — using the middle
   value and typical spread, so one past crisis cannot stretch the ruler.
4. Convert to 0–100.

**Where 63 comes from.** The last step is the formula
`severity = 100 × (1 − e^(−|z| / 3))`. Put |z| = 3 in and you get 63.2. That is
the whole story — it is not a tuned number, and you can check it on a
calculator. |z| = 3 is the three-sigma rule, the control limit Walter Shewhart
set in 1931, still the standard convention in outlier work.

**But do not read it as a probability.** Under a bell curve, |z| ≥ 3 happens
about 0.27% of the time. On *this* data it happens far more often, because
payment flows have much fatter tails than a bell curve — large one-off
settlements and contract renewals are ordinary events here, not rare ones. The
exact share is **measured from the current outputs and printed** in *How
"Unusual?" is calculated* on the **Outliers** page, rather than written into
this text where it would go stale.

So 63 means *"about as far from normal as a three-sigma move"*, which gives a
readable shortlist. **Never write "significant" on the strength of this number
alone.**

Important: severity is relative to *that industry*. A 30% move might score 90
for a stable industry and 40 for a volatile one. That is deliberate.

---

#### Confidence — "should I believe it?"
A completely separate column, and **not a judgement about economics** — we
cannot see inside a business. It is a **checklist**: nine specific, measurable
conditions, each known to move these numbers **without any money changing hands
differently**. The tests run in a fixed order and the first one that matches
sets the label. The *Why* column names the test that fired.

| | What it means | What to do |
|---|---|---|
| **high** | Broad-based, on a full history | Treat as a real move |
| **medium** | Concentrated in one counterparty, or resting on a short history | Check the cause before writing |
| **low** | One of the artefact tests fired — see *Why* | Do not publish as economics |

**Why they are never combined into one score.** The clearest case in this data
is an industry whose inflow fell by hundreds of millions, where over 90% of the
fall is a single trading partner that has a published figure in one month and
none in the next. The partner need not have stopped paying — a cell is withheld
whenever publishing it might identify an individual organisation. One blended
number would have filed that beside a genuine collapse, and somebody would have
published a collapse that never happened.

The industry, the month and every figure are worked through in **Glossary →
What the data is like**, recomputed from the current delivery rather than
written down.

**Read confidence before size. Every time.**

---

#### Why "low confidence" appears
Five reasons, each shown in the *Why* column:

- **the whole economy moved** — everything shifted that month, so this is not
  an industry story.
- **counterparties appearing or disappearing** — a relationship entered or left
  the data. Nobody changed what they paid.
- **classification shifted** — counterparties were re-coded between SIC 00 and
  a real industry.
- **inside a structural break** — the series has a step change, so the baseline
  does not describe it.
- **over half the cells are suppressed** — too little is visible to judge.

---

#### Presence share
On *Why did it move?*: **how much of a change comes from counterparties
entering or leaving the data**, rather than paying differently.

Above 50%, it is a recording change. The provider withholds a cell whenever
publishing it could identify an organisation, and that test is applied fresh
each month — so a real, continuing trading relationship can be visible one
month and hidden the next. Nothing about the relationship changed; only what we
are allowed to see.

---

#### Structural score — a different question entirely
Severity asks whether the **money** moved unusually. Structural score asks
whether the **shape** changed: who pays it, how many, how concentrated, how
much is internal.

An industry can hold its total perfectly steady while a fifth of its funding
base changes hands. **Most structural alerts are invisible to the severity
measure** — the exact share is measured from the current outputs and printed in
*The two detectors* box on the **Outliers** page, rather than written into this
text where it would go stale.

---

#### Provisional
A score resting on fewer than 24 months of history — usually because the
industry had a structural break recently, which resets the baseline. The score
is real but less certain, and has already been discounted for that.
""")

    # ------------------------------------------------------------------
    with tabs[3]:
        st.markdown("""
### What this data can and cannot answer

Worth knowing before promising an answer to anyone.

#### It can
- Say what moved between industries, monthly, within days of month end.
- Separate an industry-specific move from a common one.
- Attribute a change to the counterparties that caused it, exactly.
- Distinguish a change in activity from a change in what was reported.
- Show how concentrated an industry's trade is, and on whom.

#### It cannot
- **Tell you what a payment bought.** A payment is not production. There is no
  distinction here between paying for finished goods, materials, rent or a
  settlement.
- **Tell you when the activity happened.** Payment terms put weeks or months
  between work and payment, and the lag differs by industry.
- **Be read as GDP.** It is an unweighted sample of Bacs and Faster Payments
  between roughly 3 million organisations, not a weighted measure of output.
- **Support regional anomaly detection.** Eighteen months cannot establish a
  seasonal baseline.
- **Explain a cause.** It shows that classified inflow fell while unclassified
  rose. That a reclassification happened is an inference, and should be
  labelled as one.

#### Three habits worth keeping
1. **Check the delivery before the numbers.** Coverage changes look exactly
   like economic changes.
2. **Read confidence before size.** The clearest large move in this data is a
   counterparty that stopped being reported.
3. **Say which basis you are quoting.** Classified-only and including-SIC-00
   differ by roughly three times, and an industry can fall on one while rising
   on the other.
""")
