"""Gainers and losers over a chosen period.

The screener view: biggest risers and fallers side by side, over 1, 3, 6 or 12
months, year-to-date, or against the same month a year earlier.

One departure from a stock screener is deliberate. Ranking purely on percentage
puts the smallest industries permanently at both ends - a 60% move in a £40m
industry is noise next to a 3% move in a £14bn one. So a size floor applies,
and the £ ranking is one click away.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from pipeline import config as cfg

from . import data, explain, method, theme


def _region_label(code: str) -> str:
    """Show the region name, not the ITL1 code."""
    return code if code == "All UK" else cfg.ITL1_NAMES.get(code, code)
from export import report

# Periods, as a stock platform would offer them.
PERIODS = {
    "1 month": 1,
    "3 months": 3,
    "6 months": 6,
    "12 months": 12,
    "Year to date": "ytd",
}

MEASURES = {"PFI (throughput)": "pfi", "Inflows": "inflow", "Outflows": "outflow"}

# Below this an industry is too small for a percentage to mean much.
SIZE_FLOOR = 50e6


def _window(panel: pd.DataFrame, key: str, measure: str,
            month: pd.Timestamp, period) -> pd.DataFrame:
    """Value now against the start of the period."""
    base = (pd.Timestamp(year=month.year, month=1, day=1)
            if period == "ytd" else month - pd.DateOffset(months=period))

    def at(m):
        return (panel[panel.month == m].groupby(key, observed=True)[measure]
                .sum(min_count=1))

    now, then = at(month), at(base)
    idx = now.index.union(then.index)
    out = pd.DataFrame({"now": now.reindex(idx), "base": then.reindex(idx)})
    out["delta"] = out.now - out.base
    out["pct"] = out.now / out.base - 1
    out.attrs["base_month"] = base
    return out.dropna(subset=["delta", "pct"])


def _panel_chart(gain: pd.DataFrame, lose: pd.DataFrame,
                 labels: dict, by_pct: bool) -> go.Figure:
    """Risers and fallers on one axis, largest move outward."""
    p = theme.palette()
    d = pd.concat([lose.iloc[::-1], gain])
    col = "pct" if by_pct else "delta"
    x = d[col] * (100 if by_pct else 1 / 1e6)
    text = [f"{v:+.1%}" if by_pct else theme.money(v) for v in d[col]]
    fig = go.Figure(go.Bar(
        x=x, y=[theme.short(labels.get(i, i)) for i in d.index],
        orientation="h",
        marker=dict(color=[p["pos"] if v > 0 else p["neg"] for v in d[col]],
                    line=dict(width=0)),
        text=text, textposition="outside",
        textfont=dict(size=12, color=p["ink2"]),
        customdata=[labels.get(i, i) for i in d.index],
        hovertemplate="<b>%{customdata}</b><br>%{text}<extra></extra>",
    ))
    fig.add_vline(x=0, line_width=1, line_color=p["axis"])
    theme.style(fig, height=max(340, 26 * len(d) + 90), legend=False,
                x_title="% change" if by_pct else "change, £m")
    fig.update_yaxes(tickfont=dict(size=12))
    span = float(abs(x).max()) if len(x) else 1.0
    fig.update_xaxes(range=[-span * 1.4, span * 1.4])
    return fig


def _table(df: pd.DataFrame, labels: dict, scored) -> pd.DataFrame:
    rows = []
    for code, r in df.iterrows():
        sev = conf = None
        if scored is not None and code in scored.index:
            a = scored.loc[code]
            a = a.iloc[0] if isinstance(a, pd.DataFrame) else a
            sev, conf = a.severity, a.confidence
        rows.append({
            "Industry": labels.get(code, code),
            "%": f"{r.pct:+.1%}",
            "Change": theme.money(r.delta),
            "Latest": theme.money(r.now),
            "Unusual?": "-" if sev is None or not np.isfinite(sev) else f"{sev:.0f}",
            "Confidence": "-" if not isinstance(conf, str) else conf,
        })
    return pd.DataFrame(rows)


def render() -> None:
    st.subheader("Gainers and losers")
    method.page_guide("leaderboard")

    panel = data.national()
    alerts = data.alerts()
    regional = data.regional()

    c1, c2, c3, c4, c5 = st.columns([1.1, 1.1, 1.2, 1.2, 1])
    months = sorted(panel.month.unique(), reverse=True)
    with c1:
        month = st.selectbox("As at", months, index=0,
                             format_func=lambda m: pd.Timestamp(m).strftime("%b %Y"))
    with c2:
        period_label = st.selectbox("Period", list(PERIODS), index=3)
    with c3:
        measure_label = st.selectbox("Measure", list(MEASURES), key="lb_measure",
                                     help=explain.MEASURE_HELP)
    with c4:
        rank_by = st.radio("Rank by", ["% change", "£ change"], horizontal=True)
        money_basis = st.radio("Basis", ["Classified only", "Including SIC 00"],
                               key="lb_basis", help="Classified counts only payments where both ends have an industry code. Including SIC 00 adds payments with an unidentified end - real money, roughly three times the total.")
    with c5:
        regions = ["All UK"] + (sorted(regional.region.unique())
                                if regional is not None else [])
        region = st.selectbox("Region", regions, key="lb_region",
                              format_func=_region_label)

    month = pd.Timestamp(month)
    period = PERIODS[period_label]
    measure = MEASURES[measure_label]
    if money_basis == "Including SIC 00":
        measure += "_incl00"
    by_pct = rank_by == "% change"

    if region != "All UK":
        src = regional[regional.region == region]
        scored = None
        if month not in set(src.month):
            st.warning(f"The regional file covers {src.month.min():%b %Y} to "
                       f"{src.month.max():%b %Y}. {month:%b %Y} is not in it.")
            return
    else:
        src = panel
        scored = alerts[(alerts.month == month) & (alerts.measure == measure)
                        & (alerts.basis == ("MoM" if period == 1 else "YoY"))
                        & (alerts.level == "division")] \
            .drop_duplicates(subset="code").set_index("code")


    changes = _window(src, "sic2", measure, month, period)
    base_month = changes.attrs.get("base_month")
    if changes.empty:
        st.info(f"No data for the {period_label.lower()} to {month:%b %Y}.")
        return

    changes = changes[changes.index != cfg.UNCLASSIFIED_SIC]
    sizeable = changes[changes.now.abs() >= SIZE_FLOOR]
    excluded = len(changes) - len(sizeable)

    labels = {k: f"{k} {v}" for k, v in dict(zip(panel.sic2, panel["name"])).items()}
    n = st.slider("How many each way", 3, 15, 8, key="lb_n")
    col = "pct" if by_pct else "delta"
    ranked = sizeable.sort_values(col, ascending=False)
    gain, lose = ranked.head(n), ranked.tail(n)

    st.caption(
        f"**{measure_label}**, {month:%B %Y} against {base_month:%B %Y} "
        f"({period_label.lower()}). "
        + (f"Industries below {theme.money(SIZE_FLOOR)} a month are excluded "
           f"({excluded} of {len(changes)}): a large percentage move in a very "
           f"small industry is noise. " if excluded else "")
        + ("Regional data has no anomaly scores - 18 months cannot support a "
           "seasonal baseline." if region != "All UK" else "")
    )

    fig = _panel_chart(gain, lose, labels, by_pct)
    st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})
    report.heading(f"Gainers and losers - {measure_label}, {period_label.lower()} "
                   f"to {month:%B %Y}")
    report.figure(fig, f"Ranked by {rank_by.lower()}.")

    left, right = st.columns(2)
    with left:
        st.markdown("**Top gainers**")
        t = _table(gain, labels, scored)
        st.dataframe(t, use_container_width=True, hide_index=True)
        report.table(t, "Top gainers")
    with right:
        st.markdown("**Top losers**")
        t = _table(lose.iloc[::-1], labels, scored)
        st.dataframe(t, use_container_width=True, hide_index=True)
        report.table(t, "Top losers")

    if by_pct:
        st.caption("Ranked on percentage, as a screener would. Switch to "
                   "**£ change** to rank on economic size instead - the two "
                   "orders differ a lot, because the largest percentage moves "
                   "are usually the smallest industries.")
