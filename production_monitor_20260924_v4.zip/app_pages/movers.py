"""Movers - gainers and losers for one month.

The landing view. Ranked by how far each industry moved, with a separate,
always-visible checklist of the known ways these numbers move without money
changing hands differently.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from pipeline import config as cfg

from types import SimpleNamespace

from pipeline import narrate

from . import data, explain, method, theme


def _region_label(code: str) -> str:
    """Show the region name, not the ITL1 code."""
    return code if code == "All UK" else cfg.ITL1_NAMES.get(code, code)
from export import report

MEASURES = {"PFI (throughput)": "pfi", "Inflows": "inflow", "Outflows": "outflow"}


@st.cache_resource(show_spinner=False)
def _edges_for(region: str):
    """Month-indexed edges, built once per region and reused."""
    from pipeline import decompose
    return decompose.as_index(data.edges())
CONF_ICON = {"high": "●", "medium": "◐", "low": "○"}


def _changes(panel: pd.DataFrame, key: str, measure: str,
             month: pd.Timestamp, lag: int) -> pd.DataFrame:
    """Change in `measure` between month and month-lag, per unit of `key`.

    The key is aggregated rather than indexed directly: a level can be coarser
    than the panel it is built from. The section panel holds one row per
    section, so grouping it by GDP grouping puts sections B, C, D and E all
    under "Production" - four rows sharing one label.
    """
    base = month - pd.DateOffset(months=lag)

    def at(m: pd.Timestamp) -> pd.Series:
        return (panel[panel.month == m]
                .groupby(key, observed=True)[measure]
                .sum(min_count=1))

    now, then = at(month), at(base)
    idx = now.index.union(then.index)
    now, then = now.reindex(idx), then.reindex(idx)
    out = pd.DataFrame({"now": now, "base": then})
    out["delta"] = out.now - out.base
    out["pct"] = out.now / out.base - 1
    # A change needs a figure in BOTH months. Where either is withheld there is
    # no change to state, so the row leaves - but it is counted rather than
    # silently dropped, because "88 industries exist and 86 are listed" is a
    # question a reader will ask and is entitled to an answer to.
    kept = out.dropna(subset=["delta"])
    kept.attrs["dropped"] = [
        (str(k),
         "no figure this month" if pd.isna(out.now.get(k))
         else f"no figure in {base:%b %Y}")
        for k in out.index if k not in kept.index]
    return kept


def _bar(df: pd.DataFrame, labels: dict[str, str], top: int) -> go.Figure:
    """Diverging bar: gainers right, losers left, ordered by size."""
    p = theme.palette()
    d = df.reindex(df.delta.abs().sort_values(ascending=False).index).head(top)
    d = d.sort_values("delta")
    colours = [p["pos"] if v > 0 else p["neg"] for v in d.delta]
    text = [f"{theme.money(v)}" for v in d.delta]
    fig = go.Figure(go.Bar(
        x=d.delta / 1e6, y=[theme.short(labels.get(i, i)) for i in d.index],
        orientation="h", marker=dict(color=colours, line=dict(width=0)),
        text=text, textposition="outside",
        textfont=dict(size=12, color=p["ink2"]),
        # The hover carries the untruncated name.
        customdata=[labels.get(i, i) for i in d.index],
        hovertemplate="<b>%{customdata}</b><br>change %{text}<extra></extra>",
    ))
    fig.add_vline(x=0, line_width=1, line_color=p["axis"])
    theme.style(fig, height=max(320, 26 * len(d) + 80), legend=False,
                x_title="change, £m")
    fig.update_yaxes(tickfont=dict(size=12))
    # Headroom so the outside labels are not clipped.
    span = float(d.delta.abs().max() / 1e6) if len(d) else 1.0
    fig.update_xaxes(range=[-span * 1.35, span * 1.35])
    return fig


def _coverage_note(shown: int, labels: dict, dropped: list,
                   month: pd.Timestamp, lag: int, charted_uncl: bool,
                   has_uncl: bool) -> str:
    """Account for every industry code, every time.

    The SIC-2 list holds 88 real industries plus SIC 00 Unclassified, 89 rows
    in all. Any smaller number on screen has a reason, and the reason is always
    the same one: a change needs a figure in both months, and the provider
    withholds cells that could identify an organisation.

    The counts come from the label set in front of the reader rather than from
    a written-in 88, so the sentence stays true on the regional file and on any
    future delivery that adds or drops a code.
    """
    base = month - pd.DateOffset(months=lag)
    real = [d for d in dropped if d[0] != cfg.UNCLASSIFIED_SIC]
    n_industries = len([k for k in labels if k != cfg.UNCLASSIFIED_SIC])
    bits = [f"**{shown} of the {n_industries} industries** have a figure in "
            f"both {base:%b %Y} and {month:%b %Y}, so a change can be stated "
            f"for them."]
    if real:
        named = ", ".join(f"{labels.get(c, c)} ({why})" for c, why in real[:4])
        bits.append(
            f"{len(real)} cannot be shown: {named}"
            f"{' and others' if len(real) > 4 else ''}. "
            f"A withheld cell is unknown, not zero, so there is no change to "
            f"state - we do not treat it as nil.")
    else:
        bits.append("None are missing this month.")
    if has_uncl:
        bits.append(
            f"**SIC 00 Unclassified** is the remaining row, "
            f"{n_industries + 1} in all. It is money with one end we could not "
            f"identify, not an industry, so it is never ranked against them"
            + (" - it is drawn on the chart above and excluded from the table."
               if charted_uncl else
               ", and it is reported on its own line beneath the table."))
    else:
        bits.append(
            f"**SIC 00 Unclassified** — the {n_industries + 1}th row — is "
            f"absent on this basis **by definition**, not by omission: "
            f"*Classified only* counts a payment when both ends carry an "
            f"industry code, and SIC 00 is the label for an end that does "
            f"not. Switch the **Basis** control to *Including SIC 00* to see "
            f"it, and expect the totals to roughly triple.")
    return " ".join(bits)


def render() -> None:
    st.subheader("Movers")
    method.page_guide("movers")

    panel = data.national()
    alerts = data.alerts()
    regional = data.regional()

    # ---- controls -----------------------------------------------------
    c1, c2, c3, c4, c5, c6 = st.columns([1.1, 1, 1.2, 1.3, 1.2, 1])
    # Newest first: the latest month is what anyone opens this for.
    months = sorted(panel.month.unique(), reverse=True)
    with c1:
        month = st.selectbox("Month", months, index=0,
                             format_func=lambda m: pd.Timestamp(m).strftime("%b %Y"))
    with c2:
        basis = st.radio("Compare with", ["YoY", "MoM"], horizontal=True,
                         help="Year-on-year is seasonally controlled; "
                              "month-on-month is more timely but noisier.")
    with c3:
        measure_label = st.selectbox("Measure", list(MEASURES),
                                     help=explain.MEASURE_HELP)
    with c4:
        level = st.selectbox("Level", ["Division (SIC2)", "Section", "GDP grouping"],
                             help="Division is the default: aggregating to section "
                                  "loses 52% of detectable shocks.")
    with c5:
        money_basis = st.selectbox(
            "Basis", ["Classified only", "Including SIC 00"],
            help="SIC 00 is 32-68% of an industry's inflows. The classified "
                 "series is the stable one; including it is all the money.")
    with c6:
        regions = ["All UK"]
        if regional is not None:
            regions += sorted(regional.region.unique())
        region = st.selectbox("Region", regions,
                              format_func=_region_label)

    measure = MEASURES[measure_label]
    if money_basis == "Including SIC 00":
        measure = measure + "_incl00"
    month = pd.Timestamp(month)
    lag = 12 if basis == "YoY" else 1

    # ---- assemble the table -------------------------------------------
    use_regional = region != "All UK"
    if use_regional:
        src = regional[regional.region == region]
        if month not in set(src.month):
            st.warning(f"The regional file covers "
                       f"{src.month.min():%b %Y} to {src.month.max():%b %Y} "
                       f"(18 months). {month:%b %Y} is not in it.")
            return
        st.caption(
            f"**{cfg.ITL1_NAMES.get(region, region)}** — from the regional file, "
            "which is more heavily suppressed than the national one and carries "
            "~30% less value. Not comparable with All UK on the same axis. "
            "Anomaly scores are national-only: 18 months cannot support a "
            "seasonal baseline."
        )
        changes = _changes(src, "sic2", measure, month, lag)
        labels = {k: f"{k} {v}" for k, v in
                  dict(zip(src.sic2, src["name"])).items()}
        scored = None
        key_is_aggregate = False
    else:
        key = {"Division (SIC2)": "sic2", "Section": "section",
               "GDP grouping": "gdp_grouping"}[level]
        key_is_aggregate = key != "sic2"
        src = panel if key == "sic2" else data.section()
        if key == "sic2":
            labels = {k: f"{k} {v}" for k, v in dict(zip(panel.sic2, panel["name"])).items()}
        elif key == "section":
            labels = dict(zip(src.section, src.section + " " + src.section_desc.str.title()))
        else:
            labels = {v: v for v in src.gdp_grouping}
        changes = _changes(src, key, measure, month, lag)
        # Section and GDP rows inherit their most anomalous division's score
        # rather than being re-estimated on the aggregate, which would lose
        # more than half the signal (BUILD_SPEC 6.3).
        want_level = {"sic2": "division", "section": "section",
                      "gdp_grouping": "gdp_grouping"}[key]
        base_measure = measure.replace("_incl00", "")
        scored = alerts[(alerts.month == month) & (alerts.measure == base_measure)
                        & (alerts.basis == basis)
                        & (alerts.level == want_level)]
        scored = scored.drop_duplicates(subset="code").set_index("code")

    if changes.empty:
        st.info("No data for that combination.")
        return

    # Unclassified is shown, but never ranked as if it were an industry.
    dropped = changes.attrs.get("dropped", [])
    uncl = changes[changes.index == cfg.UNCLASSIFIED_SIC]
    changes = changes[changes.index != cfg.UNCLASSIFIED_SIC]

    # ---- systemic-month banner ----------------------------------------
    if scored is not None and len(scored) and "common_pct" in scored:
        common = scored.common_pct.dropna()
        if len(common) and abs(common.iloc[0]) >= 0.20:
            st.error(
                f"**Every industry moved together this month** "
                f"({common.iloc[0]:+.0%} typical change). That usually means a "
                f"common movement rather than {len(changes)} separate industry "
                f"shocks. A month whose recorded volume differs sharply from "
                f"its neighbours produces this in every comparison against it. "
                f"Rankings below are measured against the typical industry."
            )

    # Severity first, then size: the genuinely unusual should outrank the
    # merely large, which is what Andrew asked for. Rows with no score (a
    # single region, or an industry too small to condition) fall to the end
    # but stay ordered by money.
    order = pd.DataFrame({"delta": changes.delta.abs()})
    order["severity"] = (scored.severity.reindex(order.index)
                         if scored is not None and "severity" in scored
                         else np.nan)
    tbl = changes.loc[order.sort_values(["severity", "delta"], ascending=False,
                                        na_position="last").index]

    # --- what changed this month, in words ------------------------------
    # Generated live for the selection on screen, not read from the pipeline.
    # The pipeline pre-computes lines for the top 5 per month/measure/basis at
    # All-UK, classified, division level - which is stale the moment a region
    # or the SIC-00 basis is changed. A decomposition is ~8 ms, so three of
    # them cost nothing and always describe what is actually displayed.
    if scored is not None and len(tbl):
        st.markdown("**What changed this month**")
        st.caption(
            "The three highest-ranked industries in the selection above. Each "
            "line has the same shape every month: **what moved**, then **what "
            "kind of cause it was**, then **the largest single contributor and "
            "what share of the move it accounts for**.")
        edge_idx = _edges_for(region)
        names_for_lines = dict(zip(panel.sic2, panel["name"]))
        shown = 0
        for code, r in tbl.head(8).iterrows():
            if shown >= 3:
                break
            if code not in scored.index or key_is_aggregate:
                continue
            a = scored.loc[code]
            a = a.iloc[0] if isinstance(a, pd.DataFrame) else a
            try:
                sentence = narrate.line(
                    SimpleNamespace(code=code, name=names_for_lines.get(code, ""),
                                    measure=measure.replace("_incl00", ""),
                                    basis=basis, month=month,
                                    gbp_delta=r.delta, pct_delta=r.pct,
                                    breadth=a.get("breadth", np.nan),
                                    sic00_share_shift=a.get("sic00_share_shift", np.nan)),
                    edge_idx, names_for_lines)
            except Exception:
                sentence = str(a.get("driver_line", "")) or None
            if not sentence:
                continue
            icon = {"high": "", "medium": ":large_orange_circle: ",
                    "low": ":red_circle: "}.get(a.confidence, "")
            st.markdown(f"{icon}{sentence}")
            report.text(sentence)
            shown += 1
        if shown == 0:
            st.caption("No counterparty detail available for this selection.")
        st.markdown("")

    n_available = len(changes)
    show_uncl = False
    if len(uncl) and money_basis == "Including SIC 00":
        show_uncl = st.checkbox(
            "Show SIC 00 Unclassified on the chart", value=True,
            key="movers_show_uncl",
            help="On this basis, money with one unidentified end is counted, "
                 "and it is usually the single largest bar. It is drawn here "
                 "so the chart adds up to what the Overview reports - but it "
                 "is never given a rank in the table, because it is not an "
                 "industry.")

    chart_src = pd.concat([changes, uncl]) if show_uncl else changes
    top = st.slider("Industries shown", 5, max(n_available, 6),
                    min(12, n_available), key="movers_top",
                    help=f"{n_available} available at this level. "
                         f"Drag to the end to show them all.")
    fig = _bar(chart_src, labels, top + (1 if show_uncl else 0))
    st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})

    # "Why 86 and not 89?" - answered on the page rather than left to be asked.
    if not key_is_aggregate:
        st.caption(_coverage_note(n_available, labels, dropped,
                                  month, lag, show_uncl, bool(len(uncl))))
    report.heading(f"Movers - {measure_label}, {basis}, {month:%B %Y}")
    report.figure(fig, f"Change against "
                       f"{'the previous month' if lag == 1 else 'the same month a year earlier'}"
                       f"{'' if region == 'All UK' else ' - ' + cfg.ITL1_NAMES.get(region, region)}.")

    # ---- the table -----------------------------------------------------
    rows = []
    for code, r in tbl.head(top).iterrows():
        sev = conf = reason = driver = None
        if scored is not None and code in scored.index:
            a = scored.loc[code]
            a = a.iloc[0] if isinstance(a, pd.DataFrame) else a
            sev, conf, reason = a.severity, a.confidence, a.confidence_reason
            dc, dn = a.get("driver_code"), a.get("driver_name")
            if isinstance(dc, str) and dc != code:
                driver = f"{dc} {str(dn)[:24]}"
        row = {
            "Industry": labels.get(code, code),
            "Change": theme.money(r.delta),
            "%": f"{r.pct:+.1%}" if np.isfinite(r.pct) else "n/a",
            "Unusual?": "n/a" if sev is None or not np.isfinite(sev)
                        else f"{sev:.0f}",
            "Confidence": "—" if conf is None or not isinstance(conf, str)
                          else f"{CONF_ICON.get(conf, '')} {conf}",
        }
        if key_is_aggregate:
            row["Driven by"] = driver or ""
        row["Why"] = "" if not isinstance(reason, str) else reason
        rows.append(row)
    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
    report.table(pd.DataFrame(rows),
                 "Ranked by how unusual the move is, then by size.")

    if key_is_aggregate:
        st.caption(
            "**Unusual?** at this level is inherited from the most anomalous "
            "division inside the group, not re-estimated on the total. "
            "Re-estimating loses 52% of alerts: SIC 51 Air transport scored "
            "-4.9 while its whole section showed -0.3. The money is summed; "
            "the signal is not diluted."
        )

    if scored is None:
        st.caption("**Unusual?** is n/a for a single region — 18 months of "
                   "history cannot support a seasonal baseline.")
    else:
        st.caption(
            "**Unusual?** and **Confidence** are never combined into one "
            "number. Severity says how far from normal; confidence says what "
            "we could not rule out. A single blended score would file a very "
            "large move that is entirely a recording change beside a modest "
            "genuine one. The full arithmetic for both, with a worked example, "
            "is above the chart.")

    # Industries we could not score at all. A recent break resets the
    # baseline, so an industry stays unscoreable until 24 usable months
    # accumulate after it - which is right, but silent unless it is said.
    if scored is not None and not key_is_aggregate:
        sizeable = set(changes[changes.now.abs() > 50e6].index)
        unscored = sorted(sizeable - set(scored.index))
        if unscored:
            brk = data.breaks()
            with_break = [c for c in unscored if c in set(brk.sic2)] if len(brk) else []
            detail = ", ".join(labels.get(c, c).split(" ")[0] + " "
                               + " ".join(labels.get(c, c).split(" ")[1:])[:22]
                               for c in unscored[:4])
            st.caption(
                f"**{len(unscored)} industries could not be scored this month** "
                f"({detail}{'…' if len(unscored) > 4 else ''}). "
                + (f"{len(with_break)} of them have a recent structural break, "
                   f"which resets the baseline until 24 usable months build up "
                   f"after it. They remain in the break register. "
                   if with_break else "")
                + "Their change is still shown above; only the score is absent."
            )

    if len(uncl):
        u = uncl.iloc[0]
        st.caption(f"Unclassified (SIC 00), shown for reconciliation but not "
                   f"ranked: {theme.money(u.delta)} ({u.pct:+.1%}).")
