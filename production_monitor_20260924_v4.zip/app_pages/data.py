"""Cached loaders for the pipeline's outputs.

The app reads outputs/ and contains no analytical logic of its own: everything
it shows is reproducible by running the pipeline, which is what makes an export
defensible.
"""
from __future__ import annotations

from pathlib import Path

import pandas as pd
import streamlit as st

from pipeline import config as cfg

TTL = 300


class OutputsMissing(Exception):
    pass


def _read(name: str, **kw) -> pd.DataFrame:
    path = cfg.OUTPUTS / name
    if not path.exists():
        raise OutputsMissing(
            f"{name} not found in outputs/.\n\n"
            "Run the pipeline first:  python -m pipeline.run"
        )
    # keep_default_na=False on the section column: SIC 00's section would
    # otherwise be read back as a missing value (BUILD_SPEC 5.1 rule 5).
    return pd.read_csv(path, **kw)


@st.cache_data(ttl=TTL)
def national() -> pd.DataFrame:
    return _read("series_national.csv", dtype={"sic2": str, "section": str},
                 parse_dates=["month"], keep_default_na=False,
                 na_values=[""])


@st.cache_data(ttl=TTL)
def section() -> pd.DataFrame:
    return _read("series_section.csv", dtype={"section": str},
                 parse_dates=["month"], keep_default_na=False, na_values=[""])


@st.cache_data(ttl=TTL)
def regional() -> pd.DataFrame | None:
    try:
        return _read("series_regional.csv", dtype={"sic2": str, "region": str},
                     parse_dates=["month"], keep_default_na=False, na_values=[""])
    except OutputsMissing:
        return None


@st.cache_data(ttl=TTL)
def alerts() -> pd.DataFrame:
    return _read("alerts.csv",
                 dtype={"code": str, "section": str, "driver_code": str,
                        "driver_name": str, "top_counterparty": str},
                 parse_dates=["month"], keep_default_na=False, na_values=[""],
                 low_memory=False)


@st.cache_data(ttl=TTL)
def breaks() -> pd.DataFrame:
    return _read("breaks.csv", dtype={"sic2": str, "top_counterparty": str},
                 parse_dates=["break_month"], keep_default_na=False, na_values=[""])


@st.cache_data(ttl=TTL)
def quality() -> pd.DataFrame:
    return _read("quality.csv", parse_dates=["month"])


@st.cache_data(ttl=TTL)
def quality_regional() -> pd.DataFrame | None:
    try:
        return _read("quality_regional.csv", parse_dates=["month"])
    except OutputsMissing:
        return None


@st.cache_data(ttl=TTL)
def cell_stability() -> pd.DataFrame:
    return _read("cell_stability.csv", dtype={"payer": str, "payee": str})


@st.cache_data(ttl=TTL)
def revisions() -> pd.DataFrame:
    return _read("revisions.csv")


@st.cache_data(ttl=TTL)
def edges(grain: str = cfg.LEVEL_SIC2) -> pd.DataFrame:
    """The edge list, from the most recent vintage."""
    vintages = sorted(p for p in cfg.VINTAGES.iterdir() if p.is_dir()) \
        if cfg.VINTAGES.exists() else []
    if not vintages:
        raise OutputsMissing("No vintage found. Run: python -m pipeline.run")
    return pd.read_parquet(vintages[-1] / f"{grain}.parquet")


@st.cache_data(ttl=TTL)
def vintage_label() -> str:
    vintages = sorted(p.name for p in cfg.VINTAGES.iterdir() if p.is_dir()) \
        if cfg.VINTAGES.exists() else []
    return vintages[-1] if vintages else "unknown"


@st.cache_data(ttl=TTL)
def profile(name: str) -> pd.DataFrame | None:
    try:
        return _read(f"profile_{name}.csv", keep_default_na=False, na_values=[""],
                     parse_dates=["month"] if name == "monthly" else None)
    except OutputsMissing:
        return None


@st.cache_data(ttl=TTL)
def node_metrics() -> pd.DataFrame | None:
    try:
        return _read("node_metrics.csv", parse_dates=["month"],
                     keep_default_na=False, na_values=[""])
    except OutputsMissing:
        return None


@st.cache_data(ttl=TTL)
def network_diagnostics() -> pd.DataFrame | None:
    """Density, betweenness zero-share and the SIC 00 PageRank share."""
    try:
        return _read("network_diagnostics.csv", parse_dates=["month"],
                     keep_default_na=False, na_values=[""])
    except OutputsMissing:
        return None


@st.cache_data(ttl=TTL)
def structural() -> pd.DataFrame | None:
    try:
        return _read("structural.csv", dtype={"sic2": str}, parse_dates=["month"],
                     keep_default_na=False, na_values=[""])
    except OutputsMissing:
        return None


@st.cache_data(ttl=TTL)
def communities(name: str = "communities") -> pd.DataFrame | None:
    try:
        return _read(f"{name}.csv", dtype={"node": str}, parse_dates=["period"],
                     keep_default_na=False, na_values=[""])
    except OutputsMissing:
        return None


def industry_names() -> dict[str, str]:
    n = national()
    return dict(zip(n.sic2, n["name"]))
