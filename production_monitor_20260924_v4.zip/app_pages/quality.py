"""Data quality - how far the numbers can be trusted.

Not a diagnostics page. The findings that shape the whole design come from
here: the unclassified share, the intermittently suppressed cells, the
the month whose recorded volume is unlike its neighbours, the break
register.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from pipeline import config as cfg

from . import data, theme
from export import report


def _series(fig, x, y, name, colour, pct=True):
    fig.add_trace(go.Scatter(
        x=x, y=np.asarray(y, dtype=float) * (100 if pct else 1), name=name,
        mode="lines", line=dict(color=colour, width=2), connectgaps=False,
        hovertemplate="%{x|%b %Y}<br><b>" + name + "</b>  %{y:.1f}"
                      + ("%" if pct else "") + "<extra></extra>"))


def render() -> None:
    st.subheader("Data quality")
    q = data.quality()
    qr = data.quality_regional()
    p = theme.palette()

    tabs = st.tabs(["Reconciliation", "Coverage", "Regional attribution",
                    "Structural breaks", "Unstable cells", "Revisions"])

    with tabs[0]:
        st.markdown("""
Every figure in this dashboard is recomputed from the **original workbook** by
a separate route — reading it cell by cell with no pipeline code — and compared.
This catches the failures that do not raise an error: a division by zero
becoming infinity, an identifier silently changing type, a category quietly
dropped.

Run it yourself:
""")
        st.code("python -m pipeline.audit", language="bash")
        st.markdown("""
It runs automatically at the end of every pipeline run, and the run exits with
an error if anything fails to reconcile.

**What it checks**

| Kind | Example |
|---|---|
| **Reconcile** | Total classified value, every industry's inflow and outflow one by one, transaction counts and month coverage — recomputed from the raw file |
| **Invariant** | PFI equals inflow + outflow − self-flow; total inflows equal total outflows; section totals equal division totals; no negative throughput; shares between 0 and 1 |
| **Hygiene** | No infinities in any output; identifiers keep their leading zeros; suppressed cells stay null rather than becoming zero; every month has a quality row |

**Checked per industry, not just in total.** A compensating error across two
industries would cancel out in a grand total, so each industry's inflow and
outflow is reconciled separately.

**The audit is itself tested against deliberate corruption** — a £1m shift, a
broken identity, an injected infinity — to confirm it can actually fail. A
reconciliation that cannot detect a discrepancy is worse than none.
""")
        st.info("This is the answer to “how do we know the tool is not quietly "
                "producing wrong numbers?”. It found a real one: 96 infinite "
                "values from dividing by a transaction count that the source "
                "rounds down to zero.")

    # ---- coverage ------------------------------------------------------
    with tabs[1]:
        fig = go.Figure()
        _series(fig, q.month, q.share_unclassified, "Involving SIC 00", p["s1"])
        _series(fig, q.month, q.share_cells_suppressed, "Cells suppressed", p["s2"])
        theme.style(fig, height=330, y_title="% of value / cells")
        st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})
        report.heading("Data quality - coverage")
        report.figure(fig, "A shift in either line looks exactly like an "
                           "economic move.")
        st.caption(
            "A shift in either line looks exactly like an economic move. SIC 00 "
            "is the largest single counterparty for most industries — 68% of "
            "Education's inflows, 47% of construction's."
        )

        # A missing column must not become `q[False]`, which raises a KeyError
        # that reads like a data problem rather than a stale output file.
        bad = (q[q.volume_outlier.fillna(False).astype(bool)]
               if "volume_outlier" in q.columns else q.iloc[:0])
        st.markdown("**Months where the data itself is short**")
        if len(bad):
            st.warning(
                f"{len(bad)} month(s) record a transaction volume well below "
                f"the months around them. Any year-on-year comparison against "
                f"one of them divides by that smaller base — for July 2022, "
                f"74 of 88 industries show growth above 25% on that basis."
            )
            st.dataframe(
                bad.assign(Month=bad.month.dt.strftime("%b %Y"),
                           Transactions=(bad.n_tx / 1e6).round(1).astype(str) + "m",
                           Completeness=(bad.volume_vs_neighbours * 100).round(0).astype(int).astype(str) + "%",
                           Value=bad.classified_value.map(theme.money))
                   [["Month", "Transactions", "Completeness", "Value"]],
                use_container_width=True, hide_index=True)
        else:
            st.success("No month's recorded volume stands out from its "
                       "neighbours.")

    # ---- regional ------------------------------------------------------
    with tabs[2]:
        if qr is None:
            st.info("The regional file was not ingested.")
        else:
            fig = go.Figure()
            _series(fig, qr.month, qr.unknown_payer_share, "Unknown payer region", p["s1"])
            _series(fig, qr.month, qr.unknown_payee_share, "Unknown payee region", p["s2"])
            _series(fig, qr.month, qr.both_known_share, "Both regions known", p["s3"])
            theme.style(fig, height=330, y_title="% of classified value")
            st.plotly_chart(fig, use_container_width=True,
                            config={"displayModeBar": False})
            first, last = qr.iloc[0], qr.iloc[-1]
            st.caption(
                f"Payer-side unknown has moved from {first.unknown_payer_share:.1%} "
                f"({first.month:%b %Y}) to {last.unknown_payer_share:.1%} "
                f"({last.month:%b %Y}). **As attribution improves, named regions "
                f"gain value that was previously unknown — which is "
                f"indistinguishable from regional growth.** Always read a "
                f"regional trend against this line."
            )

    # ---- breaks --------------------------------------------------------
    with tabs[3]:
        b = data.breaks()
        if not len(b):
            st.info("No structural breaks detected.")
        else:
            st.caption(
                "A break is a permanent level shift. The cause matters more "
                "than the size: a **reclassification** moves money between SIC 00 "
                "and a real industry without anything economic happening; a "
                "**suppression-driven** break is a counterparty that stopped being "
                "reported. Both are detected as level shifts and neither is one."
            )
            show = b.assign(
                Industry=b.sic2 + " " + b["industry"],
                Month=b.break_month.dt.strftime("%b %Y"),
                Change=(b.level_change_pct * 100).round(0).astype(int).astype(str) + "%",
                Score=b.score.round(1),
                Presence=(b.presence_share * 100).round(0).astype(int).astype(str) + "%",
            )[["Industry", "Month", "Change", "Score", "break_cause",
               "Presence", "likely", "status"]]
            show.columns = ["Industry", "Month", "Change", "Score", "Cause",
                            "Presence", "Pattern", "Status"]
            st.dataframe(show, use_container_width=True, hide_index=True)

    # ---- unstable cells -------------------------------------------------
    with tabs[4]:
        cs = data.cell_stability()
        names = data.industry_names()
        st.caption(
            "Counterparty relationships that move in and out of suppression. "
            "This is the table that turns “this industry collapsed” into "
            "“one trading partner stopped being published”. A relationship "
            "listed here has a figure in some months and none in others; that "
            "is a disclosure decision by the provider, not evidence about "
            "whether the two businesses were still trading."
        )
        show = cs.head(25).assign(
            Payer=cs.payer + " " + cs.payer.map(names).fillna(""),
            Payee=cs.payee + " " + cs.payee.map(names).fillna(""),
            Present=cs.months_present.astype(int),
            Absent=cs.months_absent.astype(int),
            Typical=cs.mean_value_when_present.map(theme.money),
        ).head(25)[["Payer", "Payee", "Present", "Absent", "Typical"]]
        st.dataframe(show, use_container_width=True, hide_index=True)
        st.caption("Present / absent are months out of the 90 in the series.")

    # ---- revisions ------------------------------------------------------
    with tabs[5]:
        rev = data.revisions()
        if not len(rev):
            st.info(
                "No revisions to report. Each delivery restates the whole "
                "history, so this table fills in once a second delivery has "
                "been ingested — it is how a restated month is caught before "
                "it reads as an economic change."
            )
        else:
            st.dataframe(rev.head(200), use_container_width=True, hide_index=True)
