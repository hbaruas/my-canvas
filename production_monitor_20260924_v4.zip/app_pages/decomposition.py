"""Why did it move? - horizontal waterfall of counterparty contributions.

The three-way split is the point. A decomposition that differences only the
counterparties present in both months misses everything that appeared or
disappeared - which on this data was 99% of one industry's movement.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from pipeline import config as cfg, decompose

from . import data, method, theme
from export import report

CATEGORY_LABEL = {
    decompose.CONTINUING: "Continuing counterparty",
    decompose.NEWLY_PRESENT: "Newly present in the data",
    decompose.ABSENT: "Absent or suppressed now",
}


def _label(code: str, names: dict[str, str]) -> str:
    if code == cfg.UNCLASSIFIED_SIC:
        return "SIC 00 Unclassified"
    return f"{code} {names.get(code, '')}"[:44]


def render() -> None:
    st.subheader("Why did it move?")
    method.page_guide("decomposition")

    panel = data.national()
    names = dict(zip(panel.sic2, panel["name"]))
    p = theme.palette()
    codes = sorted(c for c in panel.sic2.unique() if c != cfg.UNCLASSIFIED_SIC)

    c1, c2, c3, c4 = st.columns([1.7, 1, 1, 1.1])
    with c1:
        code = st.selectbox("Industry", codes,
                            index=codes.index("19") if "19" in codes else 0,
                            format_func=lambda c: f"{c} {names.get(c, '')}")
    with c2:
        # Newest first: the latest month is what anyone opens this for.
        months = sorted(panel.month.unique(), reverse=True)
        month = st.selectbox("Month", months, index=0,
                             format_func=lambda m: pd.Timestamp(m).strftime("%b %Y"))
    with c3:
        basis = st.radio("Compare with", ["YoY", "MoM"], horizontal=True)
    with c4:
        side = st.radio("Measure", ["PFI (throughput)", "Inflows", "Outflows"],
                        help="Inflows decomposes who paid this industry, "
                             "outflows who it paid. PFI combines both.")

    money_basis = st.radio(
        "Basis", ["Including SIC 00", "Classified only"], horizontal=True,
        help="SIC 00 is 32-68% of an industry's inflows, so it is shown by "
             "default. The classified basis is what the alert scores use.")
    include_uncl = money_basis == "Including SIC 00"


    month = pd.Timestamp(month)
    lag = 12 if basis == "YoY" else 1
    base = month - pd.DateOffset(months=lag)
    edges = data.edges()

    measure_key = {"Inflows": "inflow", "Outflows": "outflow",
                   "PFI (throughput)": "pfi"}[side]
    rows = decompose.decompose_measure(edges, code, month, base,
                                       measure=measure_key,
                                       include_unclassified=include_uncl)
    if rows.empty:
        st.info("No counterparty data for that combination.")
        return
    summary = decompose.summarise(rows)

    # ---- headline ------------------------------------------------------
    c = st.columns(4)
    c[0].metric(f"Change vs {base:%b %Y}", theme.money(summary["total_change"]),
                help="The total movement being explained. Every bar below adds "
                     "up to exactly this figure.")
    c[1].metric("From continuing flows", theme.money(summary["continuing"]),
                help="The part contributed by counterparties present in BOTH "
                     "months, which simply paid more or less. This is the "
                     "economic part.")
    c[2].metric("From cells appearing / vanishing",
                theme.money(summary["newly_present"] + summary["absent_suppressed"]),
                help="The part contributed by counterparties that are in one "
                     "month's data but not the other's. Nobody changed what "
                     "they paid - a relationship entered or left the dataset.")
    c[3].metric("Presence share", f"{summary['presence_share']:.0%}",
                help="'From cells appearing / vanishing' divided by 'Change', "
                     "ignoring signs. Above 50%, more than half the move comes "
                     "from partners with a figure in only one of the two "
                     "months, so it cannot be reported as an economic change.")

    # The live reading of the four figures, as a sentence rather than a box.
    # What each figure IS belongs in the page guide with everything else; what
    # they SAY about the selection on screen belongs here, next to them.
    cont = summary["continuing"]
    pres = summary["newly_present"] + summary["absent_suppressed"]
    tot = summary["total_change"]
    st.caption(
        f"**In words:** this industry's {side.lower()} changed by "
        f"**{theme.money(tot)}** between {base:%B %Y} and {month:%B %Y}. "
        f"**{theme.money(cont)}** of that is trading partners present in both "
        f"months paying a different amount — money genuinely changing hands. "
        f"**{theme.money(pres)}** is partners present in only one of the two "
        f"months, where nobody need have changed what they paid. The two add "
        f"back to the total exactly. *Three kinds of bar* in the guide above "
        f"explains why a partner can vanish without anything happening.")

    # The generated sentence for this exact industry-month, if it was scored.
    alerts = data.alerts()
    match = alerts[(alerts.code == code) & (alerts.month == month)
                   & (alerts.basis == basis) & (alerts.level == "division")
                   & (alerts.driver_line.astype(str).str.len() > 0)]
    if len(match):
        st.info(match.nlargest(1, "severity").iloc[0].driver_line)

    if summary["presence_share"] >= 0.5:
        st.error(
            f"**{summary['presence_share']:.0%} of this move is counterparties "
            f"appearing or disappearing from the data**, not changing what they "
            f"pay. Treat it as a reporting change unless you can confirm "
            f"otherwise."
        )

    # ---- waterfall -----------------------------------------------------
    # The cap is the number of partners this industry actually has, not a
    # round number. It used to stop at 24, which silently hid the tail on any
    # industry that trades with more than that - and most of them do.
    n_total = int(len(rows))
    if n_total > 6:
        n_bars = st.slider(
            "Counterparties shown", 6, n_total, min(12, n_total), key="wf_bars",
            help=f"This industry has {n_total} trading partners with a figure "
                 f"in one or both months. Drag to the end to show every one of "
                 f"them; whatever you choose, the rest are gathered into a "
                 f"single 'All other counterparties' bar so the chart still "
                 f"adds up to the total change.")
    else:
        n_bars = n_total

    # Pin self and unclassified: each is structurally large (8-20% and 32-68%
    # of inflows) and dropping either from a top-N cut misleads.
    pinned = rows[rows.is_self | rows.is_unclassified]
    head = rows.head(n_bars)
    keep = pd.concat([head, pinned]).drop_duplicates(subset="counterparty")
    rest = rows[~rows.counterparty.isin(keep.counterparty)]

    keep = keep.sort_values("contribution")
    labels = [_label(c, names) for c in keep.counterparty]
    values = list(keep.contribution / 1e6)
    cats = list(keep.category)

    if len(rest):
        labels.insert(0, f"All other counterparties ({len(rest)})")
        values.insert(0, float(rest.contribution.sum() / 1e6))
        cats.insert(0, decompose.CONTINUING)

    colour_for = {decompose.CONTINUING: p["s1"],
                  decompose.NEWLY_PRESENT: p["s3"],
                  decompose.ABSENT: p["s2"]}

    fig = go.Figure()
    for cat in (decompose.CONTINUING, decompose.NEWLY_PRESENT, decompose.ABSENT):
        mask = [c == cat for c in cats]
        if not any(mask):
            continue
        fig.add_trace(go.Bar(
            x=[v if m else None for v, m in zip(values, mask)],
            y=labels, orientation="h", name=CATEGORY_LABEL[cat],
            marker=dict(color=colour_for[cat], line=dict(width=0)),
            hovertemplate="<b>%{y}</b><br>%{x:,.0f} £m<br>"
                          + CATEGORY_LABEL[cat] + "<extra></extra>",
        ))
    fig.add_vline(x=0, line_width=1, line_color=p["axis"])
    theme.style(fig, height=max(340, 26 * len(labels) + 110), x_title="contribution, £m")
    fig.update_layout(barmode="relative", bargap=0.25)
    fig.update_yaxes(tickfont=dict(size=12))
    st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})
    report.heading(f"Why {code} {names.get(code, '')} moved - {month:%B %Y}")
    if len(match):
        report.text(match.nlargest(1, "severity").iloc[0].driver_line)
    report.figure(fig,
                  "Contributions sum exactly to the total change. "
                  "<b>Newly present</b> and <b>absent or suppressed</b> are "
                  "data-presence effects, not economic ones.")

    st.caption(
        "Contributions sum exactly to the total change. **Newly present** and "
        "**absent or suppressed** are data-presence effects, not economic ones. "
        "Within-industry and SIC 00 bars are always shown, however they rank."
    )

    # ---- the table -----------------------------------------------------
    with st.expander("Table"):
        t = rows.assign(
            Counterparty=[_label(c, names) for c in rows.counterparty],
            Contribution=rows.contribution.map(theme.money),
            Category=rows.category.map(CATEGORY_LABEL),
            Now=rows.value_now.map(theme.money),
            Base=rows.value_base.map(theme.money),
        )[["Counterparty", "Contribution", "Category", "Base", "Now"]]
        st.dataframe(t, use_container_width=True, hide_index=True)

    # reconciliation, stated rather than assumed
    panel_col = measure_key if include_uncl is False else measure_key + "_incl00"
    row_now = panel[(panel.sic2 == code) & (panel.month == month)]
    row_base = panel[(panel.sic2 == code) & (panel.month == base)]
    if panel_col in panel.columns and len(row_now) and len(row_base):
        actual = float(row_now[panel_col].iloc[0]) - float(row_base[panel_col].iloc[0])
        residual = actual - summary["total_change"]
        ok = abs(residual) < 1.0
        st.caption(
            f"**Reconciliation.** The bars above add to "
            f"**{theme.money(summary['total_change'])}**. This industry's own "
            f"published total moved **{theme.money(actual)}** between "
            f"{base:%b %Y} and {month:%b %Y} (column `{panel_col}` of "
            f"`series_national.csv`). **Residual "
            f"{theme.money(residual)}**"
            + (" — every pound of the change has been assigned to a named "
               "partner." if ok else
               " — this should be zero. A non-zero residual is a fault in this "
               "tool, not a feature of the data. Do not quote this chart until "
               "it is resolved.")
            + " This is checked and printed on screen every time rather than "
              "verified once and assumed thereafter.")
