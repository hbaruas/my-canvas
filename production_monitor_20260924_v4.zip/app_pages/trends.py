"""Trends - one industry over time.

Two modes, mutually exclusive: compare measures for one region, or compare
regions for one measure. Three measures across five regions is fifteen lines
and reads as noise.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from pipeline import config as cfg

from . import data, method, theme
from export import report

MEASURES = {"PFI (throughput)": "pfi", "Inflows": "inflow", "Outflows": "outflow"}

# Diagnostics: computed for every industry-month but not money, so they need
# their own units and their own basis rules. These are where the less obvious
# questions live - whether a rise is price or volume, whether an industry is
# trading more with itself, whether its counterparties are being classified.
DIAGNOSTICS = {
    "Payments received (count)": ("n_tx_in", "payments", 1),
    "Payments made (count)": ("n_tx_out", "payments", 1),
    "Average payment received": ("avg_tx_value_in", "£", 1),
    "Self-flow (within industry)": ("self_flow", "£m", 1e6),
    "Share from unclassified payers": ("share_from_00", "%", 0.01),
}

# One line per diagnostic, shown with the chart. A definition sitting only in
# an expander is a definition nobody reads.
DIAGNOSTIC_NOTE = {
    "Payments received (count)":
        "**The number of payments this industry received**, added up across "
        "every industry that paid it. Rising here while the money rises means "
        "more transactions. Flat here while the money rises means the same "
        "number of payments, each one bigger. Counts are rounded by the "
        "provider, so a very small industry can show zero against a non-zero "
        "value.",
    "Payments made (count)":
        "**The number of payments this industry made.** The same reading as "
        "above, on the purchasing side.",
    "Average payment received":
        "**Money received divided by payments received.** This is the closest "
        "this dataset comes to separating price from volume: put this beside "
        "*Payments received* and a rise in one but not the other tells you "
        "which of the two moved. Blank where the payment count is zero — a "
        "division by zero is never shown as a number here.",
    "Self-flow (within industry)":
        "**Money this industry paid to itself** — one firm in the industry "
        "paying another. A rise can mean more subcontracting or more stages "
        "of production being settled separately. This is also the figure "
        "subtracted once when PFI is calculated, so that such a payment is "
        "not counted twice.",
    "Share from unclassified payers":
        "**The proportion of this industry's incoming money that came from "
        "payers with no industry code.** This is a data-coverage line, not an "
        "economic one: it moves when identification improves or worsens, with "
        "no change in trading whatever. A jump of 20 percentage points or more "
        "automatically sets that month's confidence to **low** on every other "
        "view — so check this line before believing any money move in the same "
        "month.",
}


def _line(fig: go.Figure, x, y, name: str, colour: str,
          divisor: float = 1e6, unit: str = "£m") -> None:
    values = np.asarray(y, dtype=float) / divisor
    if unit == "%":
        tip = "%{y:,.1f}%"
    elif unit == "£":
        tip = "£%{y:,.0f}"
    elif unit == "payments":
        tip = "%{y:,.0f} payments"
    else:
        tip = "£%{y:,.0f}m"
    fig.add_trace(go.Scatter(
        x=x, y=values, name=name, mode="lines",
        line=dict(color=colour, width=2),
        connectgaps=False,          # suppressed months stay gaps, never joined
        hovertemplate="%{x|%b %Y}<br><b>" + name + "</b>  " + tip + "<extra></extra>",
    ))


def render() -> None:
    st.subheader("Trends")
    method.page_guide("trends")

    panel = data.national()
    regional = data.regional()
    breaks = data.breaks()
    p = theme.palette()

    names = dict(zip(panel.sic2, panel["name"]))
    codes = sorted(c for c in panel.sic2.unique() if c != cfg.UNCLASSIFIED_SIC)

    c1, c2, c3 = st.columns([1.6, 1.2, 1.6])
    with c1:
        code = st.selectbox("Industry", codes,
                            index=codes.index("29") if "29" in codes else 0,
                            format_func=lambda c: f"{c} {names.get(c, '')}")
    with c2:
        mode = st.radio("Compare", ["Measures", "Diagnostics", "Regions"],
                        help="**Measures** are the money itself. "
                             "**Diagnostics** are the counts and shares behind "
                             "it: whether a rise came from more payments or "
                             "from bigger ones, how much of the industry's "
                             "trade is with itself, and how much of its money "
                             "arrived from payers with no industry code. "
                             "**Regions** compares places. See 'What the "
                             "diagnostics are' below the controls.")
    with c3:
        if mode == "Measures":
            chosen = st.multiselect("Measures", list(MEASURES),
                                    default=["PFI (throughput)", "Inflows"])
            region_sel = ["All UK"]
        elif mode == "Diagnostics":
            chosen = [st.selectbox("Diagnostic", list(DIAGNOSTICS))]
            region_sel = ["All UK"]
        else:
            chosen = [st.selectbox("Measure", list(MEASURES))]
            opts = sorted(regional.region.unique()) if regional is not None else []
            region_sel = st.multiselect(
                "Regions", opts,
                default=[o for o in ("TLI", cfg.UNKNOWN_REGION) if o in opts],
                format_func=lambda r: cfg.ITL1_NAMES.get(r, r))

    basis = st.radio("Basis", ["Classified only", "Including SIC 00"],
                     horizontal=True,
                     help="SIC 00 is 32–68% of an industry's inflows. The "
                          "classified series is more stable; the full series "
                          "is all the money.")
    suffix = "_incl00" if basis == "Including SIC 00" else ""


    fig = go.Figure()
    slots = [p["s1"], p["s2"], p["s3"]]
    band_note = ""

    if mode == "Measures":
        if not chosen:
            st.info("Select at least one measure.")
            return
        src = panel[panel.sic2 == code].sort_values("month")
        for i, label in enumerate(chosen):
            col = MEASURES[label] + suffix
            if col not in src:
                col = MEASURES[label]
            _line(fig, src.month, src[col], label, slots[i % 3])
        title = f"{code} {names.get(code, '')} — All UK"
    elif mode == "Diagnostics":
        src = panel[panel.sic2 == code].sort_values("month")
        col, unit, divisor = DIAGNOSTICS[chosen[0]]
        _line(fig, src.month, src[col], chosen[0], slots[0],
              divisor=divisor, unit=unit)
        theme.style(fig, height=430, y_title=unit)
        title = f"{code} {names.get(code, '')} — {chosen[0]}"
    else:
        if regional is None:
            st.warning("The regional file was not ingested.")
            return
        if not region_sel:
            st.info("Select at least one region.")
            return
        col = MEASURES[chosen[0]]
        src = regional[regional.sic2 == code].sort_values("month")
        for i, reg in enumerate(region_sel):
            r = src[src.region == reg]
            _line(fig, r.month, r[col], cfg.ITL1_NAMES.get(reg, reg), slots[i % 3])
        title = f"{code} {names.get(code, '')} — {chosen[0]}"
        st.caption(
            "Regional data covers Jan 2025 – Jun 2026 only and carries ~30% "
            "less value than the national file. `Unknown / unattributed` is "
            "shown by default: as attribution improves, named regions gain "
            "value that was previously unknown, which looks like growth."
        )

    # Baseline band: the industry's own typical range, so a reader can see
    # whether the latest point is unusual without reading a z-score. Drawn
    # from the post-break segment only, because a pre-break level no longer
    # describes this series.
    if mode == "Measures" and len(chosen) == 1:
        src_b = panel[panel.sic2 == code].sort_values("month")
        col = MEASURES[chosen[0]] + suffix
        col = col if col in src_b else MEASURES[chosen[0]]
        seg = src_b
        rel_b = breaks[breaks.sic2 == code] if len(breaks) else breaks
        if len(rel_b):
            last_break = pd.to_datetime(rel_b.break_month).max()
            seg = src_b[src_b.month >= last_break]
        vals = seg[col].dropna()
        if len(vals) >= 6:
            lo, hi = vals.quantile(0.1) / 1e6, vals.quantile(0.9) / 1e6
            fig.add_hrect(y0=lo, y1=hi, fillcolor=p["s1"], opacity=0.07,
                          line_width=0, layer="below")
            fig.add_annotation(
                xref="paper", x=0.005, y=hi, yanchor="bottom",
                text="typical range: 8 of every 10 months sat inside this band"
                     + (" (since the last break)" if len(rel_b) else ""),
                showarrow=False, font=dict(size=11, color=p["muted"]))
            band_note = (
                f"**The shaded band** runs from £{lo:,.0f}m to £{hi:,.0f}m. "
                f"That is the 10th to the 90th percentile of this industry's "
                f"own monthly values across the {len(vals)} usable months"
                + (" since its last structural break" if len(rel_b) else "")
                + ", so by construction one month in ten sat below it and one "
                  "in ten above. It describes months that have already "
                  "happened: it is **not** a forecast and **not** a confidence "
                  "interval, and it carries no probability.")

    # Structural breaks, marked rather than silently adjusted.
    if mode in ("Measures", "Diagnostics") and len(breaks):
        for b in breaks[breaks.sic2 == code].itertuples():
            fig.add_vline(x=b.break_month, line_width=1, line_dash="dot",
                          line_color=p["critical"])
            fig.add_annotation(x=b.break_month, yref="paper", y=1.0,
                               text=f"break · {b.break_cause}", showarrow=False,
                               font=dict(size=11, color=p["critical"]),
                               xanchor="left", yanchor="bottom")

    if mode != "Diagnostics":
        theme.style(fig, height=430, y_title="£m")
    st.markdown(f"**{title}**")
    if mode == "Diagnostics":
        st.caption(DIAGNOSTIC_NOTE.get(chosen[0], ""))
    st.plotly_chart(fig, use_container_width=True,
                    config={"displayModeBar": False})
    report.heading(title)
    report.figure(fig, "Gaps are months where the cell was suppressed; they are "
                       "left as gaps, never interpolated.")
    if band_note:
        st.caption(band_note)
    st.caption("Gaps are months where the cell was suppressed. They are left "
               "as gaps, never interpolated. A gap is a figure we are not "
               "allowed to see, never a zero.")

    rel = breaks[breaks.sic2 == code] if len(breaks) else breaks
    if len(rel):
        st.markdown("**Structural breaks in this series**")
        show = rel.assign(
            Month=rel.break_month.dt.strftime("%b %Y"),
            Change=(rel.level_change_pct * 100).round(0).astype(int).astype(str) + "%",
        )[["Month", "Change", "score", "break_cause", "likely"]]
        show.columns = ["Month", "Change", "Score", "Cause", "Pattern"]
        st.dataframe(show, use_container_width=True, hide_index=True)
