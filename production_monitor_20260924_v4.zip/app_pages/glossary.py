"""Glossary - what every term means and how each number is produced.

Written so that someone who did not build this can read any chart in it, and
so that a figure quoted in a bulletin can be traced back to its definition.
"""
from __future__ import annotations

import streamlit as st

from . import data, method


def _facts() -> dict:
    q, n = data.quality(), data.national()
    latest = n.month.max()
    cur = q[q.month == latest].iloc[0]
    return {"months": n.month.nunique(), "latest": f"{latest:%B %Y}",
            "vintage": data.vintage_label(),
            "uncl": f"{cur.share_unclassified:.0%}",
            "supp": f"{cur.share_cells_suppressed:.0%}"}


def render() -> None:
    st.subheader("Glossary and method")
    f = _facts()
    st.caption(f"Data release {f['vintage']} · {f['months']} months to "
               f"{f['latest']} · {f['uncl']} of value involves an unclassified "
               f"counterparty · {f['supp']} of cells suppressed")

    tabs = st.tabs(["How to read each view", "The measures", "The scores",
                    "Data caveats", "Definitions"])

    # ------------------------------------------------------------------
    with tabs[0]:
        st.markdown("""
#### Movers
**Question it answers:** what moved most in one month, and was that unusual?

The bar chart shows the change in the selected measure against either the
previous month or the same month a year earlier. Gainers extend right, losers
left, longest bar = biggest move in pounds.

The table beneath is ranked **by how unusual the move is first, then by size**,
so a genuinely strange move in a mid-sized industry outranks a routine move in
a huge one. Read the *Confidence* column before believing the *Unusual?* score.

#### Outliers
**Question it answers:** what has been unusual recently, across months?

The same detection, browsable. Lower the severity slider to see more, raise it
to see only extremes. Filtering to `high` confidence removes moves that look
like reporting changes.

#### Gainers and losers
**Question it answers:** who is up and down over a longer window?

A screener. Ranking by **%** favours small industries; ranking by **£** favours
large ones. The two orders differ substantially and both are meaningful —
Public administration's £2.3bn rise does not appear in the percentage view at
all. Industries below £50m a month are excluded because a percentage on a tiny
base is noise.

#### Trends
**Question it answers:** how has one industry behaved over time?

The shaded band is that industry's typical range (10th–90th percentile) since
its last structural break. Dotted vertical lines mark breaks. **Gaps are
months where the cell was suppressed** — they are left as gaps and never
interpolated, because joining them would draw a line through data that does
not exist.

#### Why did it move?
**Question it answers:** which counterparties caused a change?

A horizontal waterfall. Bars sum exactly to the total change. Two bars are
always shown regardless of rank — *within-industry* and *SIC 00 Unclassified* —
because each is structurally large and hiding either misleads.
""")

    # ------------------------------------------------------------------
    with tabs[1]:
        st.markdown("""
Every row of the source data is one **payer industry → payee industry → month →
value**. Each industry therefore has two sides.

| Term | Definition | Reads as |
|---|---|---|
| **Inflow** | Total value where the industry is the **payee** | Money received — a sales proxy |
| **Outflow** | Total value where the industry is the **payer** | Money paid out — an input-purchase proxy |
| **PFI** | inflow + outflow − self-flow | Total payment throughput |

**Why PFI subtracts self-flow.** Payments an industry makes to itself are
genuine receipts *and* genuine payments, so they appear in both legs. Counting
them twice would overstate throughput — intra-industry flows are 14.3% of all
classified value over the whole period, and reach 32% of a single industry's
inflow.

Inflows and outflows correlate 0.74 and **neither leads the other**, so PFI
averages out payment-timing noise without losing signal. That is why it is the
default.

#### The two bases
| Basis | What it includes |
|---|---|
| **Classified only** | Flows between two identified industries. The stable series, and what all scores are computed on. |
| **Including SIC 00** | Also flows to and from counterparties with no industry code. All the money, but it moves when classification coverage moves. |

SIC 00 is **32–68% of a typical industry's inflows** — 68% for Education — so
it is never hidden, only separated.
""")

    # ------------------------------------------------------------------
    with tabs[2]:
        st.markdown("""
#### Severity (0–100)
How far a move sits from that industry's **own** history.

1. Take the measure, seasonally adjusted where enough history exists.
2. Subtract the **common component** — the median change across all industries
   that month. An industry moving with the whole economy is not an industry
   shock, and without this step July 2022 alone produced 74 false alerts.
3. Score three ways: a single-month deviation, a year-on-year deviation, and a
   six-month average drift (CUSUM) that catches sustained moves no single month
   would flag.
4. Take the strongest of the three and map it onto 0–100 with
   `severity = 100 × (1 − e^(−|z| / 3))`. Put |z| = 3 into that and it returns
   **63.2** — which is the entire reason 63 is the default. |z| = 3 is the
   three-sigma rule (Shewhart, 1931), not a number we picked.

**Do not read it as a probability.** Under a bell curve |z| ≥ 3 happens 0.27%
of the time; on this data 63 fires far more often, because payment flows have
much fatter tails than a bell curve. The exact share is measured from the
current outputs and printed on the **Outliers** page. It is a browsing dial,
not a test of significance, and the word *significant* should never be written
on the strength of it.

Baselines use **median and MAD**, not mean and standard deviation, so a single
spike cannot inflate the yardstick. COVID (Mar 2020 – Jun 2021) is excluded
from baselines, and only history *before* the month being scored is used.

Scores are discounted for a thin baseline: a median estimated from 15 months is
itself uncertain, so the ratio is referenced to a t distribution on the
baseline's own degrees of freedom. A score resting on under 24 months is marked
**provisional**.

#### Confidence — deliberately separate
**Not a judgement about economics** — we cannot observe that. It is a
**checklist** of specific, measurable conditions, each known to move these
numbers without any money changing hands differently. The tests run in a fixed
order, the first match sets the label, and the *Why* column names the test that
fired. It is never blended into severity, because a blended score would file a
very large move that is entirely a recording change beside a modest genuine
one.

| Confidence | Set when |
|---|---|
| **low** | The whole economy moved >20% that month; or the move sits on a structural break; or over half of it comes from counterparties appearing/vanishing; or the SIC-00 share shifted more than 20 points; or over half the industry's cells are suppressed |
| **medium** | One counterparty carries 70%+ of the move; or it is concentrated in few counterparties; or the baseline is provisional |
| **high** | Broad-based, on a full baseline |

#### Breadth, presence, concentration
- **Breadth** — share of counterparties moving the same way as the total.
- **Presence share** — how much of a change comes from cells appearing or
  disappearing rather than changing value. Above 50% it is a reporting change.
- **Top counterparty share** — how much one counterparty carries. High breadth
  and high concentration can both be true: many moved, one dominated.
""")

    # ------------------------------------------------------------------
    with tabs[3]:
        st.markdown("""
#### What this tool can and cannot tell you

**The delivery is the ground truth.** Everything here is derived from the files
Pay.UK and ONS supply, and the only question we can test is whether our figures
faithfully represent them. That check runs on every pipeline run and is
described under **Data quality → Reconciliation**.

What follows from that:

- **We report what the data records**, and never assert that a figure in it is
  mistaken. Where a month or a cell is unlike its neighbours, we say so and
  show the numbers — we do not claim to know why.
- **We separate observation from inference.** "Classified inflow fell 58% while
  inflow from unclassified payers rose 218%, and the total moved 6%" is an
  observation. "This is a reclassification" is an inference from it, and is
  labelled as one.
- **Arithmetic on our own figures is ours to assert.** That a year-on-year
  comparison against a low month produces a large number is not a claim about
  the source; it is a property of the calculation, and we state it plainly.

Below are the properties of the data that most affect how it reads. Each one
produced a convincing-looking wrong number in this tool at some point, and each
is now handled explicitly.

#### Suppressed cells are null, never zero
`[c]` means withheld for disclosure; `[-]` means no interaction recorded.
Neither is zero, and treating them as zero manufactures collapses that never
happened. About 18% of cells are suppressed.

#### Cells appear and disappear between months
A counterparty can be reported for some months and suppressed in others. The
box below works the clearest case through with live figures. Two further
confirmed cases, both of which look like economic collapses and are not:

- **SIC 29** — an £81–186m public-administration cell present in only 15 of
  the 90 months.
- **SIC 51** — in June 2026, 79% of a 20% year-on-year fall is one
  counterparty no longer reported. (`top_counterparty_share` in
  `outputs/alerts.csv`.)

""")
        st.markdown(method.suppression_case_markdown())
        st.markdown("""


#### July 2021 records far fewer transactions than the months around it
52.2m against 81.7m in June and 76.7m in August. Whether that is the economy,
the sample, or the collection is not something the data settles. What follows
arithmetically is that comparisons against it divide by a smaller base: for
July 2022, 74 of 88 industries show year-on-year growth above 25%, while
month-on-month growth is 0.4%.

#### Education, March 2025 — what changed was the classification of its payers
**Observed:** SIC 85's classified inflow fell 58%, its inflow from SIC 00 rose
218%, and total money in rose 6%. The share arriving from unclassified payers
went from 23% to 70%.

**Inferred:** a change in how Education's counterparties are classified, rather
than a change in activity. The observation supports it — the money did not
leave — but the data does not name a cause, and we do not claim it does.

#### Regional data is thinner than national
18 months only (Jan 2025 onward), roughly 30% less value than the national
file, and **no anomaly scores** — a seasonal baseline needs years. Also:
payer-side *unknown* has fallen from 19.3% to 16.0%, so as attribution improves
named regions gain value that was previously unknown, which looks exactly like
growth.

#### The workbook contains the same data twice
`SIC2_2019_2026` repeats the yearly sheets. They agree on every value, but
**78 cells are published in one and marked suppressed in the other** (£299.6m,
mostly April 2026). Faced with two readings of the same cell, the monitor takes
the more restrictive: a cell withheld in either sheet is treated as withheld,
so nothing shown or exported rests on a figure withheld elsewhere in the same
release. That is a documented choice between two ground truths, not a
correction of one.

#### Each delivery restates the whole history
Figures for past months can change between releases. `revisions.csv` records
what moved, so a restatement is seen as a restatement rather than as news.
""")

    # ------------------------------------------------------------------
    with tabs[4]:
        st.markdown("""
| Term | Meaning |
|---|---|
| **SIC2 / division** | 2-digit Standard Industrial Classification. 88 industries plus `00 Unclassified`. The level everything is detected at. |
| **Section** | Letter grouping A–U (21) plus Unclassified. A reporting level only. |
| **GDP grouping** | Agriculture, Production, Construction, Services — how GDP bulletins report. |
| **SIC 00 Unclassified** | A counterparty with no industry code. Not an industry; never ranked as one. |
| **ITL1** | The 12 UK regions, `TLC`–`TLN`, plus `unknown`. |
| **unknown region** | A payment we hold but cannot attribute geographically. A category, not a missing value — distinct from suppression, which has no value at all. |
| **Self-flow** | Payments within the same industry (payer = payee). Normal and large — 14.3% of classified value overall, up to 32% of one industry's inflow. |
| **Structural break** | A permanent level shift, as opposed to a shock that recovers. Classified as *reclassification*, *suppression-driven*, or *level shift*. |
| **Vintage** | One delivery of the data, identified by its release date. |
| **MoM / YoY** | Against the previous month / the same month a year earlier. |
| **Provisional** | A score resting on fewer than 24 months of baseline. |
| **Common component** | The median change across all industries in a month — what everything did together, removed before judging any single industry. |

#### Why detection happens at division level
Running the same detector on section totals finds **1.0 alerts a month against
3.6** at division level. Only 48% of division alerts survive aggregation, and
the median alert loses 30% of its strength — SIC 51 Air transport scored −4.9
while its whole section showed −0.3. Sections are for reporting; divisions are
for detecting.

#### What this is not
Unweighted sample totals from Bacs and Faster Payments between roughly 3
million organisations. **Not** official statistics, not a complete census of
UK payments, and not a measure of GDP. A payment is not production: the timing
of a payment and what it buys are both unknown.
""")
