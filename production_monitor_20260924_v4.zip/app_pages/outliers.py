"""Outliers - the anomaly detector's output, on its own page.

Until now severity was only a column inside Movers, which made the detector
hard to find and impossible to browse: you could not ask "what has been
unusual lately" without stepping through months one at a time.

Severity and confidence stay separate here, as everywhere. Severity is how far
a move sits from that industry's own history; confidence is whether it looks
economic at all. The clearest large fall in this dataset is a reporting change,
not a collapse - see method.suppression_case(), which measures it live.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from pipeline import config as cfg

from . import data, explain, method, theme
from export import report

MEASURES = {"PFI (throughput)": "pfi", "Inflows": "inflow", "Outflows": "outflow"}
CONF_ICON = {"high": "●", "medium": "◐", "low": "○"}
SEVERITY_FIRES = 63          # equivalent to |z| > 3


def _timeline(counts: pd.Series, fired: pd.Series) -> go.Figure:
    p = theme.palette()
    fig = go.Figure()
    fig.add_trace(go.Bar(
        x=counts.index, y=counts.values, name="industries flagged",
        marker=dict(color=p["s1"], line=dict(width=0)),
        hovertemplate="%{x|%b %Y}<br>%{y} industries<extra></extra>"))
    theme.style(fig, height=230, legend=False, y_title="industries flagged")
    return fig


def render() -> None:
    st.subheader("Outliers")
    method.page_guide("outliers")

    alerts = data.alerts()
    panel = data.national()
    div = alerts[alerts.level == "division"]

    c1, c2, c3, c4 = st.columns([1.2, 1.1, 1.3, 1.3])
    with c1:
        measure_label = st.selectbox("Measure", list(MEASURES), key="out_measure",
                                     help=explain.MEASURE_HELP)
    with c2:
        basis = st.radio("Compare with", ["YoY", "MoM"], horizontal=True,
                         key="out_basis")
    with c3:
        months = sorted(div.month.unique(), reverse=True)
        scope = st.selectbox(
            "Period", ["Latest month", "Last 6 months", "Last 12 months",
                       "All scored history"], index=0)
    with c4:
        min_conf = st.multiselect(
            "Confidence", ["high", "medium", "low"], default=["high", "medium"],
            help="Low confidence means the move looks like a reporting change: "
                 "a counterparty appearing or vanishing, a reclassification, or "
                 "a month when the whole economy moved.")

    basis_note = st.radio(
        "Magnitudes shown", ["Classified only", "Including SIC 00"],
        horizontal=True, key="out_money_basis",
        help="Scores are always computed on the classified basis, which is the "
             "stable series. This switches the £ figures shown beside them.")

    kind = st.radio(
        "Kind of anomaly", ["Level — the money moved", "Structural — the shape changed",
                            "Both together"],
        horizontal=True, key="out_kind",
        help="Two detectors run on this data and look for different things. "
             "**Level** asks whether an industry's money moved unusually. "
             "**Structural** asks whether the shape of its trading changed - "
             "who pays it, how many of them, how concentrated - even when the "
             "total looks ordinary. **Both together** shows only the "
             "industry-months that fired on both. Full explanation in the box "
             "below.")

    measure = MEASURES[measure_label]
    sel = div[(div.measure == measure) & (div.basis == basis)]
    if sel.empty:
        st.info("Nothing scored for that combination.")
        return

    latest = sel.month.max()
    windows = {"Latest month": latest,
               "Last 6 months": latest - pd.DateOffset(months=5),
               "Last 12 months": latest - pd.DateOffset(months=11),
               "All scored history": sel.month.min()}
    sel = sel[sel.month >= windows[scope]]

    threshold = st.slider(
        "Severity at least", 0, 100, SEVERITY_FIRES, step=1,
        help="0-100. The default 63 is what the severity formula returns at "
             "|z| = 3, the three-sigma convention - 100 x (1 - e^(-3/3)) = "
             "63.2. It is a browsing dial, not a test: the score underneath "
             "is continuous, so lower it to see more and raise it for "
             "extremes only. See 'How Unusual? is calculated' above.")

    fired = sel[sel.severity >= threshold]
    if min_conf:
        fired = fired[fired.confidence.isin(min_conf)]

    # ---- structural layer ----------------------------------------------
    struct = data.structural()
    if struct is not None and kind != "Level — the money moved":
        flagged = struct[struct.structural_flag.eq(True)
                         & (struct.month >= windows[scope])]
        if kind == "Structural — the shape changed":
            keys = set(zip(flagged.sic2, flagged.month))
            names_map = dict(zip(panel.sic2, panel["name"]))
            reasons = dict(zip(zip(flagged.sic2, flagged.month),
                               flagged.structural_reason))
            scores = dict(zip(zip(flagged.sic2, flagged.month),
                              flagged.structural_score))
            rows = []
            for code, month in sorted(keys, key=lambda k: (-scores.get(k, 0),)):
                lvl = sel[(sel.code == code) & (sel.month == month)]
                rows.append({
                    "Month": f"{pd.Timestamp(month):%b %Y}",
                    "Industry": f"{code} {names_map.get(code, '')}",
                    "Structural score": f"{scores.get((code, month), float('nan')):.0f}",
                    "Also a level alert?":
                        "yes" if len(lvl) and lvl.severity.iloc[0] >= threshold else "no",
                    "What changed": reasons.get((code, month), ""),
                })
            st.markdown(f"**{len(rows)} structural anomalies** in this window.")
            if rows:
                table = pd.DataFrame(rows)
                st.dataframe(table, use_container_width=True, hide_index=True)
                report.heading("Structural anomalies")
                report.table(table, "Industries whose trading changed shape.")
                st.caption(
                    "**Structural score** is how far this month's shape sits "
                    "from the industry's own normal, across seven features: how "
                    "many industries pay it, how concentrated those payments "
                    "are, its largest single relationship, how much activity is "
                    "internal, how much arrives unclassified, counterparty "
                    "turnover, and its position in the network. Every feature "
                    "is standardised against that industry's own history, so "
                    "this asks whether the month is unusual *for it*.")
                st.info(
                    "**The case this exists for:** SIC 47 Retail in April 2020 "
                    "moved −1% year-on-year — invisible to the level detector — "
                    "while its payments became far more concentrated. Same "
                    "money, different shape.")
            else:
                st.success("No structural anomalies in this window.")
            return

        # "Both together": keep only level alerts that are also structural
        keys = set(zip(flagged.sic2, flagged.month))
        fired = fired[[(c, m) in keys for c, m in zip(fired.code, fired.month)]]
        st.markdown(
            f"**{len(fired)} industries moved *and* reorganised.** These are "
            f"the strongest signals available: the money moved unusually and "
            f"the shape of the trading changed at the same time.")

    # ---- how many, and when -------------------------------------------
    counts = (sel[sel.severity >= threshold]
              .groupby("month").code.nunique()
              .reindex(sorted(sel.month.unique()), fill_value=0))
    a, b, c = st.columns(3)
    a.metric("Outliers shown", f"{len(fired):,}")
    b.metric("Industries scored", f"{sel.code.nunique()}",
             help="Industries with enough history to score in this window.")
    c.metric("Typical per month", f"{counts.mean():.1f}")

    if len(counts) > 1:
        fig = _timeline(counts, fired)
        st.plotly_chart(fig, use_container_width=True,
                        config={"displayModeBar": False})
        report.heading(f"Outliers - {measure_label}, {basis}")
        report.figure(fig, "Industries flagged per month at the chosen severity.")

    if fired.empty:
        st.success("Nothing clears that threshold in this window.")
        return

    # ---- the list ------------------------------------------------------
    rows = []
    for r in fired.sort_values(["month", "severity"],
                               ascending=[False, False]).head(80).itertuples():
        rows.append({
            "Month": f"{r.month:%b %Y}",
            "Industry": f"{r.code} {r.name}",
            "Severity": f"{r.severity:.0f}",
            "Direction": "up" if r.direction == "up" else "down",
            "Change": theme.money(r.gbp_delta),
            "%": f"{r.pct_delta:+.1%}" if np.isfinite(r.pct_delta) else "n/a",
            "Confidence": f"{CONF_ICON.get(r.confidence, '')} {r.confidence}",
            "Why": r.confidence_reason,
            "Baseline": ("provisional" if bool(getattr(r, "provisional", False))
                         else f"{r.baseline_months:.0f}m"
                         if np.isfinite(getattr(r, "baseline_months", np.nan))
                         else "-"),
        })
    table = pd.DataFrame(rows)
    st.dataframe(table, use_container_width=True, hide_index=True)
    report.table(table, "Outliers at the chosen severity.")

    st.caption(
        "**Severity** is 0–100: how far the move sits from this industry's own "
        "history, after setting aside what every industry did that month. "
        "**Confidence** is a separate checklist of the known ways these "
        "numbers move without money changing hands differently; the *Why* "
        "column names the exact test that fired. **Baseline** is the number of "
        "past months the score rests on. The three are never blended into one "
        "figure — the full reasoning, with worked arithmetic, is in the method "
        "boxes above the chart."
    )

    # ---- the explanations ----------------------------------------------
    with st.expander("Why these moved", expanded=len(fired) <= 6):
        lines = fired[fired.driver_line.astype(str).str.len() > 3] \
            .nlargest(8, "severity")
        if not len(lines):
            st.caption("No counterparty detail generated for these rows.")
        for r in lines.itertuples():
            st.markdown(f"**{r.month:%b %Y} · {r.code} {r.name}** — {r.driver_line}")
