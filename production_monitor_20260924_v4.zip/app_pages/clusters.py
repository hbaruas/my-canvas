"""Economic clusters — groups of industries that trade more with each other.

Exploratory, and the page says so. Modularity sits at 0.24 against roughly 0.3
as the conventional floor for structure worth interpreting, so these clusters
are a hypothesis generator for an analyst rather than a finding for a bulletin.
The number is on the page, not in a footnote.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from . import data, method, theme
from export import report

MODULARITY_FLOOR = 0.30

def _modularity_chart(summary: pd.DataFrame) -> go.Figure:
    p = theme.palette()
    fig = go.Figure()
    fig.add_trace(go.Bar(
        x=summary.period, y=summary.modularity,
        marker=dict(color=p["s1"], line=dict(width=0)),
        text=[f"{m:.3f}" for m in summary.modularity], textposition="outside",
        textfont=dict(size=12, color=p["ink2"]),
        hovertemplate="%{x|%Y}<br>modularity %{y:.3f}<extra></extra>"))
    fig.add_hline(y=MODULARITY_FLOOR, line_width=1, line_dash="dash",
                  line_color=p["critical"])
    fig.add_annotation(xref="paper", x=0.01, y=MODULARITY_FLOOR, yanchor="bottom",
                       text="0.30 — conventional floor for meaningful structure",
                       showarrow=False, font=dict(size=11, color=p["critical"]))
    theme.style(fig, height=300, legend=False, y_title="modularity")
    fig.update_yaxes(range=[0, 0.42])
    return fig


def render() -> None:
    st.subheader("Economic clusters")
    method.page_guide("clusters")

    members = data.communities()
    summary = data.communities("community_summary")
    if members is None or summary is None or members.empty:
        st.warning(
            "Clusters are built from the SIC-5 file, which the standard run "
            "skips. Rebuild with:")
        st.code("python -m pipeline.run --with-sic5", language="bash")
        st.caption("Adds about five minutes: 27 million rows streamed down to "
                   "yearly edges.")
        return

    panel = data.national()
    section = dict(zip(panel.sic2, panel.section_desc))
    names = dict(zip(panel.sic2, panel["name"]))

    latest = summary.iloc[-1]
    a, b, c, d = st.columns(4)
    a.metric("Years covered", f"{len(summary)}")
    b.metric("Communities", f"{int(latest.communities)}",
             help="In the most recent year.")
    c.metric("Modularity", f"{latest.modularity:.3f}",
             help=f"Below {MODULARITY_FLOOR} means weak structure — real, but "
                  f"not strong enough to treat as a finding.")
    d.metric("Network density", f"{latest.density:.0%}",
             help="Share of possible industry pairs that actually trade.")

    st.warning(
        f"**Modularity is {summary.modularity.min():.3f}–"
        f"{summary.modularity.max():.3f} across all {len(summary)} years, below "
        f"the {MODULARITY_FLOOR} threshold.** These groups are real but weak. "
        f"Two of them correspond to recognisable parts of the economy; the "
        f"others are closer to a residual. Use this to generate a hypothesis "
        f"you then test in the Phase 1 views — not as a result in itself."
    )

    fig = _modularity_chart(summary)
    st.plotly_chart(fig, use_container_width=True,
                    config={"displayModeBar": False})
    report.heading("Economic clusters — modularity by year")
    report.figure(fig, "How strongly the network divides into communities. "
                       "Below 0.30 the structure is weak.")

    # ---- what is in each cluster ---------------------------------------
    periods = sorted(members.period.unique(), reverse=True)
    year = pd.Timestamp(st.selectbox(
        "Year", periods, index=0, format_func=lambda p: pd.Timestamp(p).strftime("%Y")))
    cur = members[members.period == year].copy()
    cur["sic2"] = cur.node.str[:2]
    cur["section"] = cur.sic2.map(section).fillna("Unclassified")

    st.markdown("### What each cluster contains")
    rows = []
    for key, grp in cur.groupby("community_key"):
        if key == "unclustered" or len(grp) < 5:
            continue
        top = grp.section.value_counts().head(3)
        rows.append({
            "Cluster": key,
            "SIC-5 codes": len(grp),
            "Dominant section": str(top.index[0]).title()[:44],
            "Its share": f"{top.iloc[0]/len(grp):.0%}",
            "Then": ", ".join(str(s).title()[:26] for s in top.index[1:3]),
        })
    table = pd.DataFrame(rows).sort_values("SIC-5 codes", ascending=False)
    st.dataframe(table, use_container_width=True, hide_index=True)
    report.table(table, f"Cluster composition, {year:%Y}.")
    st.caption(
        "A cluster whose dominant section is a large share is economically "
        "recognisable. One spread thinly across many sections is a residual — "
        "the algorithm putting somewhere the industries it could not group."
    )

    # ---- following one industry ----------------------------------------
    st.markdown("### Which cluster is an industry in, and has it moved?")
    codes = sorted(members.node.unique())
    pick = st.selectbox(
        "SIC-5 code", codes,
        format_func=lambda c: f"{c} — {names.get(c[:2], '')}"[:60])
    track = members[members.node == pick].sort_values("period")
    if track.empty:
        st.info("That code does not appear in the clustered network.")
        return
    show = track.assign(
        Year=track.period.dt.strftime("%Y"),
        Cluster=track.community_key,
        **{"Cluster size": track.community_size},
    )[["Year", "Cluster", "Cluster size"]]
    st.dataframe(show, use_container_width=True, hide_index=True)

    moves = int((track.community_key != track.community_key.shift()).sum()) - 1
    if moves <= 0:
        st.success(f"**{pick}** has stayed in the same cluster throughout. Its "
                   f"trading relationships have been stable in shape.")
    else:
        st.info(f"**{pick}** has changed cluster {moves} time(s). Worth checking "
                f"against the Trends and Outliers views for the same years — a "
                f"cluster move without a level move is exactly what the "
                f"structural detector looks for.")

    stab = data.communities("community_stability")
    if stab is not None and len(stab):
        st.markdown("### How stable are the clusters themselves?")
        s = stab.assign(
            Year=stab.period.dt.strftime("%Y"), Cluster=stab.community_key,
            Retained=(stab.retained * 100).round(0).astype(int).astype(str) + "%",
            Joined=stab.joined, Left=stab.left,
        )[["Year", "Cluster", "Retained", "Joined", "Left"]]
        st.dataframe(s, use_container_width=True, hide_index=True)
        st.caption(
            f"Membership retained from the previous year, median "
            f"{stab.retained.median():.0%}. A cluster that retains little of "
            f"its membership is being rebuilt by the algorithm rather than "
            f"persisting in the economy."
        )
