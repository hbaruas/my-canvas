#!/usr/bin/env bash
# Production Monitor - quick run (macOS)
# Rebuilds the outputs and opens the dashboard. Skips the reconciliation audit,
# which is the slow part. Use run-full.command before trusting a number.

cd "$(dirname "$0")" || exit 1
set -u
echo "==============================================="
echo " Production Monitor - quick run"
echo " (audit skipped - use run-full.command for that)"
echo "==============================================="
if [ ! -x ".venv/bin/python" ]; then
    echo; echo "ERROR: the environment is not installed."
    echo "Double-click  install.command  first."; echo
    read -r -p "Press Return to close."; exit 1
fi
PY="./.venv/bin/python"
"$PY" -m pipeline.run --use-cache --no-audit "$@"
STATUS=$?
if [ $STATUS -eq 2 ]; then
    echo "Place the delivery files in  Data/incoming/  and run this again."
    echo; read -r -p "Press Return to close."; exit 2
elif [ $STATUS -ne 0 ]; then
    echo; echo "ERROR: the pipeline failed (exit $STATUS). Nothing was launched."
    read -r -p "Press Return to close."; exit $STATUS
fi
echo; echo "Starting the dashboard - it will open in your browser."
echo "Close this window, or press Ctrl+C, to stop it."; echo
# --- which port -------------------------------------------------------
# Kept in step with run.bat: port.txt wins, then PRODMON_PORT, then 8501.
# macOS rarely refuses 8501, but the two platforms should not disagree about
# where the dashboard lives, and find-port writes the same file on both.
PORT=8501
[ -n "${PRODMON_PORT:-}" ] && PORT="$PRODMON_PORT"
[ -f "$(dirname "$0")/port.txt" ] && PORT="$(tr -d '[:space:]' < "$(dirname "$0")/port.txt")"
echo "Dashboard: http://localhost:$PORT"

"$PY" -m streamlit run app.py --browser.gatherUsageStats=false --server.port="$PORT"
