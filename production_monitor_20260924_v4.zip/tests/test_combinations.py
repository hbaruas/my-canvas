"""Every control combination, not one control at a time.

Two crashes reached the user because the suite parametrised a single control
while holding the rest at their defaults:

  * Movers at GDP-grouping level - duplicate index labels
  * Movers with a region AND the including-SIC-00 basis - the regional panel
    had no _incl00 columns at all

Both sit in the interaction, so both survived a green suite. There are two
layers here: a fast contract test that every column any view can ask for
exists in every panel it can ask from, and an exhaustive walk of the actual
control product.
"""
from __future__ import annotations

import itertools

import pandas as pd
import pytest
from streamlit.testing.v1 import AppTest

from pipeline import config as cfg

pytestmark = pytest.mark.skipif(
    not (cfg.OUTPUTS / "series_national.csv").exists(),
    reason="pipeline outputs not built; run python -m pipeline.run",
)

MEASURES = ("inflow", "outflow", "pfi")
BASES = ("", "_incl00")


def _read(name: str) -> pd.DataFrame:
    return pd.read_csv(cfg.OUTPUTS / name, nrows=1, keep_default_na=False,
                       na_values=[""])


# --- layer 1: the column contract (fast) --------------------------------

@pytest.mark.parametrize("panel", ["series_national.csv", "series_regional.csv",
                                   "series_section.csv"])
@pytest.mark.parametrize("measure", MEASURES)
@pytest.mark.parametrize("basis", BASES)
def test_every_panel_carries_every_measure_on_every_basis(panel, measure, basis):
    """A view lets the user pick measure x basis; the column must exist.

    This is the cheap guard. The regional panel shipped without _incl00
    columns and nothing failed until someone selected that pair in the UI.
    """
    cols = set(_read(panel).columns)
    assert measure + basis in cols, (
        f"{panel} has no column '{measure + basis}' - a user can select that "
        f"combination, so it must exist"
    )


@pytest.mark.parametrize("panel", ["series_national.csv", "series_regional.csv"])
def test_panels_agree_on_their_raw_measure_columns(panel):
    """Raw measures must match across panels; derived ones need not.

    Seasonally adjusted columns are national-only by design - 18 months of
    regional history cannot support seasonal adjustment - so they are excluded
    from the contract rather than faked.
    """
    wanted = {m + b for m in MEASURES for b in BASES}
    have = set(_read(panel).columns)
    assert not (wanted - have), f"{panel} is missing {sorted(wanted - have)}"


def test_seasonal_columns_are_national_only():
    regional = set(_read("series_regional.csv").columns)
    assert not [c for c in regional if c.endswith("_sa")], (
        "regional carries seasonally adjusted columns, but 18 months cannot "
        "support seasonal adjustment - they would be meaningless"
    )


# --- layer 2: the control product (thorough) ----------------------------

def _app(view: str) -> AppTest:
    at = AppTest.from_file("app.py", default_timeout=120).run()
    for radio in at.sidebar.radio:
        if view in list(radio.options):
            radio.set_value(view).run()
            return at
    raise AssertionError(f"view {view!r} not found in the sidebar")


def _options(at: AppTest, label: str) -> list:
    for group in (at.selectbox, at.radio):
        for w in group:
            if w.label == label:
                return list(w.options)
    return []


def _set(at: AppTest, label: str, value) -> None:
    for group in (at.selectbox, at.radio):
        for w in group:
            if w.label == label:
                w.set_value(value)
                return
    raise AssertionError(f"control {label!r} not found")


MOVERS_CONTROLS = ["Compare with", "Measure", "Level", "Basis", "Region"]


def _movers_product():
    at = _app("Movers")
    opts = {c: _options(at, c) for c in MOVERS_CONTROLS}
    # Keep the region axis to All UK plus one real region plus unknown: the
    # remaining regions exercise identical code paths.
    regions = opts["Region"]
    keep = [r for r in regions if r in ("All UK", "TLD", cfg.UNKNOWN_REGION)]
    opts["Region"] = keep or regions[:2]
    return [dict(zip(MOVERS_CONTROLS, combo))
            for combo in itertools.product(*(opts[c] for c in MOVERS_CONTROLS))]


@pytest.mark.parametrize("combo", _movers_product(),
                         ids=lambda c: "-".join(str(v)[:9] for v in c.values()))
def test_movers_every_control_combination(combo):
    at = _app("Movers")
    for label, value in combo.items():
        _set(at, label, value)
    at.run()
    assert not at.exception, f"{combo}: {[str(e) for e in at.exception]}"


OUTLIER_CONTROLS = ["Measure", "Compare with", "Period",
                    "Magnitudes shown", "Kind of anomaly"]


def _outlier_product():
    at = _app("Outliers")
    opts = {c: _options(at, c) for c in OUTLIER_CONTROLS}
    return [dict(zip(OUTLIER_CONTROLS, combo))
            for combo in itertools.product(*(opts[c] for c in OUTLIER_CONTROLS))]


@pytest.mark.parametrize("combo", _outlier_product(),
                         ids=lambda c: "-".join(str(v)[:9] for v in c.values()))
def test_outliers_every_control_combination(combo):
    at = _app("Outliers")
    for label, value in combo.items():
        _set(at, label, value)
    at.run()
    assert not at.exception, f"{combo}: {[str(e) for e in at.exception]}"


TREND_CONTROLS = ["Compare", "Basis"]


@pytest.mark.parametrize("diagnostic", [
    "Payments received (count)", "Payments made (count)",
    "Average payment received", "Self-flow (within industry)",
    "Share from unclassified payers"])
def test_trends_renders_every_diagnostic(diagnostic):
    """The diagnostics carry different units from the money measures."""
    at = _app("Trends")
    _set(at, "Compare", "Diagnostics")
    at.run()
    _set(at, "Diagnostic", diagnostic)
    at.run()
    assert not at.exception, f"{diagnostic}: {[str(e) for e in at.exception]}"


def _trend_product():
    at = _app("Trends")
    opts = {c: _options(at, c) for c in TREND_CONTROLS}
    return [dict(zip(TREND_CONTROLS, combo))
            for combo in itertools.product(*(opts[c] for c in TREND_CONTROLS))]


@pytest.mark.parametrize("combo", _trend_product(),
                         ids=lambda c: "-".join(str(v)[:9] for v in c.values()))
def test_trends_every_control_combination(combo):
    at = _app("Trends")
    for label, value in combo.items():
        _set(at, label, value)
    at.run()
    assert not at.exception, f"{combo}: {[str(e) for e in at.exception]}"


DECOMP_CONTROLS = ["Measure", "Compare with", "Basis"]


def _decomp_product():
    at = _app("Why did it move?")
    opts = {c: _options(at, c) for c in DECOMP_CONTROLS}
    return [dict(zip(DECOMP_CONTROLS, combo))
            for combo in itertools.product(*(opts[c] for c in DECOMP_CONTROLS))]


@pytest.mark.parametrize("combo", _decomp_product(),
                         ids=lambda c: "-".join(str(v)[:9] for v in c.values()))
def test_decomposition_every_control_combination(combo):
    at = _app("Why did it move?")
    for label, value in combo.items():
        _set(at, label, value)
    at.run()
    assert not at.exception, f"{combo}: {[str(e) for e in at.exception]}"


@pytest.mark.parametrize("view", ["Playbook", "Glossary", "The dataset",
                                  "Data quality", "Influence",
                                  "Economic clusters", "Structural shifts",
                                  "Overview"])
def test_reference_views_render(view):
    at = _app(view)
    assert not at.exception, f"{view}: {[str(e) for e in at.exception]}"


LEADERBOARD_CONTROLS = ["Period", "Measure", "Rank by", "Basis", "Region"]


def _leaderboard_product():
    at = _app("Gainers & losers")
    opts = {c: _options(at, c) for c in LEADERBOARD_CONTROLS}
    regions = opts["Region"]
    opts["Region"] = [r for r in regions if r in ("All UK", "TLD")] or regions[:1]
    return [dict(zip(LEADERBOARD_CONTROLS, combo))
            for combo in itertools.product(*(opts[c] for c in LEADERBOARD_CONTROLS))]


@pytest.mark.parametrize("combo", _leaderboard_product(),
                         ids=lambda c: "-".join(str(v)[:9] for v in c.values()))
def test_leaderboard_every_control_combination(combo):
    at = _app("Gainers & losers")
    for label, value in combo.items():
        _set(at, label, value)
    at.run()
    assert not at.exception, f"{combo}: {[str(e) for e in at.exception]}"
