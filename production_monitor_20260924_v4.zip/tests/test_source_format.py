"""What the source files actually look like, pinned.

Every assumption the ingest makes about the delivery is written down here and
checked against the real files. When a future release changes its layout,
these fail with a message saying which assumption broke - rather than the
pipeline carrying on and producing plausible wrong numbers.

Several of these were not assumptions at the start. They were found by reading
the files cell by cell after a naive read had already gone wrong.
"""
from __future__ import annotations

import csv
import re
from collections import Counter
from datetime import datetime

import pytest
from openpyxl import load_workbook

from pipeline import config as cfg, ingest

WORKBOOK = next(iter(sorted(cfg.DATA.glob("*sic2dataset*.xlsx"))), None)
REGIONAL = next(iter(sorted(cfg.DATA.glob("*sic2region*.csv"))), None)

needs_workbook = pytest.mark.skipif(WORKBOOK is None, reason="no SIC2 workbook")
needs_regional = pytest.mark.skipif(REGIONAL is None, reason="no regional file")


@pytest.fixture(scope="module")
def combined_rows():
    wb = load_workbook(WORKBOOK, read_only=True, data_only=True)
    rows = [r for r in wb["SIC2_2019_2026"].iter_rows(min_row=10, values_only=True)
            if r is not None and r[0] is not None]
    wb.close()
    return rows


# --- the workbook ------------------------------------------------------

@needs_workbook
def test_header_is_on_row_nine():
    wb = load_workbook(WORKBOOK, read_only=True, data_only=True)
    header = next(wb["SIC2_2019_2026"].iter_rows(min_row=9, max_row=9,
                                                  values_only=True))
    wb.close()
    assert header[:5] == ("Payer (2-digit SIC)", "Payee (2-digit SIC)", "Date",
                          "Value (£)", "Number of transactions")


@needs_workbook
def test_combined_sheet_has_nothing_beyond_column_five():
    wb = load_workbook(WORKBOOK, read_only=True, data_only=True)
    extra = [r for r in wb["SIC2_2019_2026"].iter_rows(values_only=True)
             if any(v not in (None, "") for v in r[5:])]
    wb.close()
    assert not extra, "content found beyond column 5 - notes or totals?"


@needs_workbook
def test_no_total_or_note_rows_at_the_foot(combined_rows):
    for r in combined_rows[-5:]:
        assert str(r[0]).strip().isdigit(), f"non-data row at the foot: {r[:5]}"


@needs_workbook
def test_date_column_mixes_text_and_real_dates(combined_rows):
    """The parser must handle both; a one-sample format guess does not."""
    kinds = Counter(type(r[2]).__name__ for r in combined_rows)
    assert kinds.get("str", 0) > 0 and kinds.get("datetime", 0) > 0, (
        f"date column types changed: {dict(kinds)} - re-check _parse_month"
    )


@needs_workbook
def test_code_columns_mix_text_and_integers(combined_rows):
    """Integer 5 must become "05"; there are ~2,900 such cells."""
    kinds = Counter(type(c).__name__ for r in combined_rows for c in r[:2])
    assert set(kinds) <= {"str", "int"}, f"unexpected code types {dict(kinds)}"
    small_ints = sum(1 for r in combined_rows for c in r[:2]
                     if isinstance(c, int) and c < 10)
    if small_ints:
        assert ingest._pad_sic(__import__("pandas").Series([5, "05", 99]), 2) \
            .tolist() == ["05", "05", "99"]


@needs_workbook
def test_values_are_whole_thousands_and_never_negative(combined_rows):
    nums = [r[3] for r in combined_rows
            if isinstance(r[3], (int, float)) and not isinstance(r[3], bool)]
    assert all(v >= 0 for v in nums), "negative values appeared - refunds?"
    assert all(v % 1000 == 0 for v in nums), (
        "values are no longer rounded to £1,000 - the audit tolerance assumes they are"
    )


@needs_workbook
def test_only_known_suppression_tokens_appear(combined_rows):
    tokens = {r[3] for r in combined_rows
              if not (isinstance(r[3], (int, float)) and not isinstance(r[3], bool))}
    unknown = tokens - set(cfg.SUPPRESSION_TOKENS)
    assert not unknown, f"new suppression tokens: {unknown}"


@needs_workbook
def test_lookup_section_for_unclassified_is_the_na_string():
    """The reason keep_default_na=False and the X normalisation exist."""
    wb = load_workbook(WORKBOOK, read_only=True, data_only=True)
    rows = {str(r[0]).strip().zfill(2): r[2]
            for r in wb["SIC2 Lookup"].iter_rows(min_row=7, values_only=True)
            if r and r[0] is not None}
    wb.close()
    assert rows["00"] == cfg.UNCLASSIFIED_SECTION_RAW
    assert len(rows) == 89


def _month_key(v):
    if isinstance(v, datetime):
        return (v.year, v.month)
    name, year = str(v).split()
    return (int(year), datetime.strptime(name, "%B").month)


@needs_workbook
def test_complete_years_are_the_full_grid():
    """89 x 89 x 12 = 95,052 rows for every complete year.

    The current partial year is not padded in its latest months - in the July
    2026 release, May is 66 cells short and June 375 - so it is checked
    separately below rather than held to the same rule.
    """
    wb = load_workbook(WORKBOOK, read_only=True, data_only=True)
    for name in wb.sheetnames:
        if not re.fullmatch(r"SIC2_\d{4}", name):
            continue
        rows = [r for r in wb[name].iter_rows(min_row=10, values_only=True)
                if r and r[0] is not None]
        months = {_month_key(r[2]) for r in rows}
        if len(months) == 12:
            assert len(rows) == 89 * 89 * 12, f"{name}: {len(rows)} rows"
    wb.close()


@needs_workbook
def test_grid_gaps_are_never_one_sided():
    """A cell missing from one sheet must be missing from the other too.

    A one-sided gap would mean one copy of the data knows about a relationship
    the other does not, which is a different problem from suppression and
    would need its own handling.
    """
    wb = load_workbook(WORKBOOK, read_only=True, data_only=True)

    def keys(filter_):
        out = set()
        for name in wb.sheetnames:
            if not filter_(name):
                continue
            for r in wb[name].iter_rows(min_row=10, values_only=True):
                if r and r[0] is not None:
                    out.add((str(r[0]).strip().zfill(2),
                             str(r[1]).strip().zfill(2), _month_key(r[2])))
        return out

    yearly = keys(lambda n: bool(re.fullmatch(r"SIC2_\d{4}", n)))
    combined = keys(lambda n: bool(re.fullmatch(r"SIC2_\d{4}_\d{4}", n)))
    wb.close()
    assert not (combined - yearly), (
        f"{len(combined - yearly)} cells exist only in the combined sheet"
    )
    # The reverse is expected: yearly sheets carry empty grid cells the
    # combined sheet omits. Those must all be empty, which the audit checks.


@needs_workbook
def test_sheet_disagreements_are_all_one_direction():
    """If the yearly sheets ever PUBLISH what the combined sheet withholds,
    the stricter-wins rule needs to handle that direction too."""
    path = cfg.OUTPUTS / "sheet_disagreements.csv"
    if not path.exists():
        pytest.skip("pipeline not run")
    import pandas as pd
    d = pd.read_csv(path)
    assert set(d.kind) <= {"published in combined, withheld in yearly"}, (
        f"new disagreement kinds: {set(d.kind)}"
    )


# --- the regional file -------------------------------------------------

@needs_regional
def test_regional_file_format():
    with open(REGIONAL, newline="", encoding="utf-8") as fh:
        rd = csv.reader(fh)
        header = next(rd)
        sample = [next(rd) for _ in range(200_000)]
    assert header == ["payer_2_digit_sic", "payer_region", "payee_2_digit_sic",
                      "payee_region", "date", "value_£",
                      "number_of_transactions"]
    assert all(re.fullmatch(r"\d{2}-[A-Z]{3}-\d{2}", r[4]) for r in sample)
    assert all(len(r[0]) == 2 and len(r[2]) == 2 for r in sample)


@needs_regional
def test_regional_suppression_token_is_uppercase():
    """The workbook writes [c]; this file writes [C]. Both must map."""
    with open(REGIONAL, newline="", encoding="utf-8") as fh:
        rd = csv.reader(fh)
        next(rd)
        tokens = set()
        for i, r in enumerate(rd):
            try:
                float(r[5])
            except ValueError:
                tokens.add(r[5])
            if i > 500_000:
                break
    assert tokens <= set(cfg.SUPPRESSION_TOKENS), f"unmapped tokens {tokens}"
    assert cfg.SUPPRESSION_TOKENS["[C]"] == cfg.SUPPRESSION_TOKENS["[c]"]


@needs_regional
def test_regional_keys_repeat_and_must_be_summed():
    """Up to nine rows per key, with different values. Not duplicates."""
    seen = Counter()
    with open(REGIONAL, newline="", encoding="utf-8") as fh:
        rd = csv.reader(fh)
        next(rd)
        for i, r in enumerate(rd):
            seen[tuple(r[:5])] += 1
            if i > 2_000_000:
                break
    assert max(seen.values()) > 1, (
        "keys no longer repeat - _aggregate_repeats may now be unnecessary, "
        "but it is harmless"
    )
