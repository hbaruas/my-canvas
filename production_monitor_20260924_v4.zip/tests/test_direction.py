"""Golden test for edge direction.

A flipped payer/payee axis produces no error at all - every downstream
ranking simply inverts. This is the cheapest possible guard against that,
and it is why graph.py is the only module allowed to build a graph.
"""
from __future__ import annotations

import pandas as pd
import pytest

from pipeline import config as cfg
from pipeline.graph import build_graph, pagerank, strengths


@pytest.fixture
def toy() -> pd.DataFrame:
    """A -> B -> C, plus a large A -> C link.

    Money flows towards C, so C must rank highest and A lowest.
    """
    rows = [
        ("A", "B", 100.0),
        ("B", "C", 100.0),
        ("A", "C", 900.0),
    ]
    return pd.DataFrame([
        {"payer": p, "payee": q, "payer_region": None, "payee_region": None,
         "month": pd.Timestamp("2026-06-01"), "value": v, "n_tx": 1.0,
         "suppressed_type": None, "grain": cfg.LEVEL_SIC2}
        for p, q, v in rows
    ])


def test_edges_run_payer_to_payee(toy):
    G = build_graph(toy)
    assert G.has_edge("A", "B"), "edge must run payer -> payee"
    assert not G.has_edge("B", "A"), "edge must NOT run payee -> payer"


def test_strength_follows_the_money(toy):
    s = strengths(build_graph(toy))
    # A only pays out; C only receives.
    assert s.loc["A", "out_strength"] == 1000.0
    assert s.loc["A", "in_strength"] == 0.0
    assert s.loc["C", "in_strength"] == 1000.0
    assert s.loc["C", "out_strength"] == 0.0


def test_pagerank_ranks_the_receiver_highest(toy):
    pr = pagerank(build_graph(toy))
    assert pr.index[0] == "C", f"money sinks into C, so C must lead: got {pr.to_dict()}"
    assert pr["C"] > pr["B"] > pr["A"], "ranking must follow the direction of flow"


def test_unclassified_excluded_by_default(toy):
    toy = pd.concat([toy, toy.assign(payer=cfg.UNCLASSIFIED_SIC, value=5000.0)])
    assert cfg.UNCLASSIFIED_SIC not in build_graph(toy).nodes
    assert cfg.UNCLASSIFIED_SIC in build_graph(toy, include_unclassified=True).nodes


def test_self_loops_kept_by_default(toy):
    toy = pd.concat([toy, toy.head(1).assign(payer="B", payee="B", value=50.0)])
    assert build_graph(toy).has_edge("B", "B")
    assert not build_graph(toy, drop_self_loops=True).has_edge("B", "B")
