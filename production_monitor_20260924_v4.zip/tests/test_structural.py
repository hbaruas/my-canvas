"""Structural anomaly detection.

The question this layer must answer differently from the Phase 1 detector: has
an industry's trading changed SHAPE, even when its totals look ordinary. If it
simply rediscovered level anomalies it would be redundant, so the overlap is
tested, not assumed.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from pipeline import config as cfg, structural

pytestmark = pytest.mark.skipif(
    not (cfg.OUTPUTS / "structural.csv").exists(),
    reason="structural metrics not built; run python -m pipeline.run",
)


@pytest.fixture(scope="module")
def struct() -> pd.DataFrame:
    return pd.read_csv(cfg.OUTPUTS / "structural.csv", dtype={"sic2": str},
                       parse_dates=["month"], keep_default_na=False,
                       na_values=[""])


@pytest.fixture(scope="module")
def alerts() -> pd.DataFrame:
    return pd.read_csv(cfg.OUTPUTS / "alerts.csv", dtype={"code": str},
                       parse_dates=["month"], low_memory=False)


# --- the reason it exists ----------------------------------------------

def test_structural_finds_what_the_level_detector_misses(struct, alerts):
    """If most structural alerts were also level alerts, this layer would be
    redundant. Measured: roughly a fifth overlap."""
    lvl = alerts[(alerts.level == "division") & (alerts.measure == "pfi")
                 & (alerts.basis == "YoY") & (alerts.severity >= 63)]
    level_keys = set(zip(lvl.code, lvl.month))
    flagged = struct[struct.structural_flag.eq(True)]
    struct_keys = set(zip(flagged.sic2, flagged.month))
    assert struct_keys, "no structural anomalies at all"
    overlap = len(struct_keys & level_keys) / len(struct_keys)
    assert overlap < 0.5, (
        f"{overlap:.0%} of structural alerts are also level alerts - this "
        f"layer would be rediscovering the Phase 1 detector"
    )


def test_a_flat_industry_can_still_be_structurally_flagged(struct, alerts):
    """The case the layer exists for: same money, different shape."""
    n = pd.read_csv(cfg.OUTPUTS / "series_national.csv", dtype={"sic2": str},
                    parse_dates=["month"], keep_default_na=False, na_values=[""])
    wide = n.pivot_table(index="month", columns="sic2", values="pfi")
    yoy = (wide / wide.shift(12) - 1).stack().rename("yoy").reset_index()
    yoy.columns = ["month", "sic2", "yoy"]
    flagged = struct[struct.structural_flag.eq(True)].merge(
        yoy, on=["sic2", "month"], how="left")
    quiet = flagged[flagged.yoy.abs() < 0.05]
    assert len(quiet) > 0, (
        "no industry was flagged structurally while its money barely moved - "
        "that is the whole point of the layer"
    )


# --- feature behaviour --------------------------------------------------

def test_every_industry_month_is_scored(struct):
    """A robust scale collapses on a feature that is usually constant, which
    once left only 360 of 7,783 rows scored."""
    scored = struct.structural_score.notna().mean()
    assert scored > 0.95, f"only {scored:.0%} of rows scored"


def test_alert_volume_is_usable(struct):
    per_month = struct.groupby("month").structural_flag.apply(
        lambda s: s.eq(True).sum())
    assert 1 <= per_month.mean() <= 8, (
        f"{per_month.mean():.1f} structural alerts a month is not reviewable"
    )


def test_first_month_has_no_churn(struct):
    """Nothing to compare against; scoring it as total turnover would flag
    every industry in the first month."""
    first = struct[struct.month == struct.month.min()]
    assert first.churn.isna().all()


def test_features_are_standardised_within_industry(struct):
    """The model must ask whether a month is unusual FOR an industry, not
    whether an industry is unusual."""
    for col in ("z_hhi", "z_top_share", "z_n_counterparties"):
        by_industry = struct.groupby("sic2")[col].median().abs()
        assert by_industry.median() < 1.0, (
            f"{col} has a non-zero median within industries - it is not "
            f"standardised against each industry's own history"
        )


def test_shares_stay_within_bounds(struct):
    for col in ("top_share", "self_share", "unclassified_share", "hhi", "churn"):
        v = struct[col].dropna()
        assert ((v >= -1e-9) & (v <= 1 + 1e-9)).all(), f"{col} out of range"


def test_scoring_is_reproducible():
    """A fixed seed: the same data must score identically every run."""
    assert structural.RANDOM_STATE is not None


def test_every_flagged_row_explains_itself(struct):
    flagged = struct[struct.structural_flag.eq(True)]
    assert (flagged.structural_reason.astype(str).str.len() > 10).all(), (
        "an isolation forest gives no coefficients, so each flag must carry "
        "the features that isolated it"
    )


def test_explanation_names_a_real_feature(struct):
    flagged = struct[struct.structural_flag.eq(True)]
    vocabulary = ("paying it", "concentrated", "payer", "within the industry",
                  "unclassified", "counterparties", "central")
    sample = flagged.structural_reason.head(30)
    assert all(any(v in r for v in vocabulary) for r in sample)


def test_the_gnn_was_deliberately_not_used():
    src = Path("pipeline/structural.py").read_text()
    assert "graph neural network" in src.lower()
    assert "7,920" in src or "7920" in src, (
        "the reason for rejecting a GNN - too few observations - should be "
        "recorded where someone would otherwise add one"
    )


# --- the dashboard view -------------------------------------------------

def test_structural_shifts_view_renders_with_charts():
    """The measure was a table with no visualisation until this view existed."""
    from streamlit.testing.v1 import AppTest
    at = AppTest.from_file("app.py", default_timeout=200).run()
    [r for r in at.sidebar.radio if r.label == "Phase 2"][0] \
        .set_value("Structural shifts").run()
    assert not at.exception, [str(e) for e in at.exception]
    assert len(at.get("plotly_chart")) >= 2, (
        "the view needs the feature-deviation chart and the payer composition, "
        "not just a table"
    )


def test_the_retail_case_is_reachable_and_explains_itself():
    """SIC 47 in April 2020: -0.6% on the level, a fifth of its funding base
    changed hands. The case the whole measure exists for."""
    from streamlit.testing.v1 import AppTest
    at = AppTest.from_file("app.py", default_timeout=200).run()
    [r for r in at.sidebar.radio if r.label == "Phase 2"][0] \
        .set_value("Structural shifts").run()
    [s for s in at.selectbox if s.label == "Period"][0] \
        .set_value("All history").run()
    box = [s for s in at.selectbox if s.label == "Flagged industry-month"][0]
    target = [o for o in box.options if o.startswith("Apr 2020 · 47")]
    assert target, "SIC 47 April 2020 is not offered for inspection"
    box.set_value(target[0]).run()
    assert not at.exception, [str(e) for e in at.exception]

    quiet = [i.value for i in at.info if "barely moved" in str(i.value)]
    assert quiet, "a flat-level, changed-shape month must say so"
    finding = [s.value for s in at.success if "of everything" in str(s.value)]
    assert finding, "the composition shift must be stated in words"
    assert "84" in finding[0], "public administration is the payer that moved"


def test_selectbox_options_are_plain_strings():
    """Tuple options with an indexing format_func break on any other input."""
    from pathlib import Path
    src = Path("app_pages/shifts.py").read_text()
    assert "choices[pick]" in src, "options should map back through a lookup"
    assert "format_func=lambda o: f\"{pd.Timestamp(o[1])" not in src
