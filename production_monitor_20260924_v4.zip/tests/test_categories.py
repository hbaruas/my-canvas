"""Categories that must never disappear.

SIC 00 is 32-68% of an industry's inflows and 63% of total value; the
'unknown' region is 16% of payer-side value. Both are labelled categories,
not missing values, and both have a history of vanishing silently:

  * the lookup sheet stores SIC 00's section as the literal string "N/A",
    which pandas nulls unless told otherwise - and does so again on every
    CSV round-trip.
"""
from __future__ import annotations

import pandas as pd

from pipeline import config as cfg


def test_unclassified_section_survives_a_csv_round_trip(tmp_path):
    df = pd.DataFrame({"section": [cfg.UNCLASSIFIED_SECTION, "A", "C"],
                       "value": [1.0, 2.0, 3.0]})
    path = tmp_path / "section.csv"
    df.to_csv(path, index=False)
    # Read with plain defaults, exactly as a downstream consumer would.
    back = pd.read_csv(path)
    assert back.section.nunique() == 3, (
        "a section code was read back as NaN - it must not be a pandas "
        "default NA string such as 'N/A', 'NA', 'None' or 'nan'"
    )
    assert cfg.UNCLASSIFIED_SECTION in set(back.section)


def test_unclassified_section_code_is_not_a_pandas_na_string():
    from pandas._libs.parsers import STR_NA_VALUES
    assert cfg.UNCLASSIFIED_SECTION not in STR_NA_VALUES
    assert cfg.UNCLASSIFIED_SECTION_RAW in STR_NA_VALUES, (
        "the raw workbook value is expected to be an NA string - that is "
        "precisely why it is normalised"
    )


def test_unknown_region_is_a_named_category():
    assert cfg.UNKNOWN_REGION in cfg.ITL1_NAMES
    assert len(cfg.ITL1_NAMES) == 13, "12 ITL1 regions plus 'unknown'"


def test_every_section_maps_to_a_gdp_grouping():
    for section in "ABCDEFGHIJKLMNOPQRSTU":
        assert section in cfg.GDP_GROUPING
    assert cfg.GDP_GROUPING[cfg.UNCLASSIFIED_SECTION] == "Unclassified"
