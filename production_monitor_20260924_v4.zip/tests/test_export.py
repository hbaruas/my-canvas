"""Export must produce a file that works on a machine with no network.

An ONS desktop may have no route to a CDN. A chart that renders as a blank box
on the recipient's screen is worse than a large attachment, so the whole
plotly bundle is inlined and this is the test that keeps it that way.
"""
from __future__ import annotations

import re

import pandas as pd
import plotly.graph_objects as go
import pytest

from export.report import Block, render

pytestmark = pytest.mark.filterwarnings("ignore::DeprecationWarning")

# Never assert directly on the document. It is ~4.6 MB, and when such an
# assertion fails pytest's rewriting builds an explanation from the whole
# string, which takes minutes and looks exactly like a hang. Reduce to a small
# fact first, then assert on that.

META = {"Source": "Pay.UK / Vocalink", "Data release": "2026-07-16",
        "Latest month": "June 2026", "Sensitivity": "Internal"}


def _doc(blocks) -> str:
    return render("Production Monitor - June 2026", blocks, META)


@pytest.fixture
def figure() -> go.Figure:
    return go.Figure(go.Bar(x=[1, -2, 3], y=["a", "b", "c"], orientation="h"))


def _page_shell(doc: str) -> str:
    """The document with embedded scripts removed.

    plotly's own bundle contains URLs of its own - map tile attributions and
    icon sets - so scanning the whole file for external references finds 16
    hits that no browser ever requests for our charts. What matters is that
    the PAGE does not link out, which is the 2.9 KB shell around the bundle.
    """
    return re.sub(r"<script\b[^>]*>.*?</script>", "", doc, flags=re.S)


def test_the_page_never_links_out(figure):
    """Opening the file must not fetch anything."""
    shell = _page_shell(_doc([Block("figure", figure, "caption")]))
    external = re.findall(r'(?:src|href)\s*=\s*["\'](?:https?:)?//[^"\']+', shell)
    assert not external, f"export references external resources: {external[:3]}"


def test_plotly_is_inlined_not_linked(figure):
    doc = _doc([Block("figure", figure)])
    scripts = re.findall(r"<script\b([^>]*)>", doc)
    linked = [a for a in scripts if "src=" in a]
    size_mb = round(len(doc) / 1e6, 2)
    assert not linked, f"a script tag loads externally: {linked[:2]}"
    assert size_mb > 1.0, f"bundle not inlined: document is only {size_mb} MB"


def test_geographic_charts_would_break_offline(figure):
    """A documented trap, pinned so it is noticed if anyone adds a map.

    plotly's bundle carries a default topojsonURL of https://cdn.plot.ly/.
    Nothing fetches it for bar, line or scatter charts, so exports are offline-
    safe today - but a choropleth or scattergeo would request it at render
    time and show an empty map on a machine with no outbound route.
    """
    doc = _doc([Block("figure", figure)])
    assert "topojsonURL" in doc, (
        "plotly no longer ships a default topojson URL - re-check whether "
        "geographic charts are safe to export offline"
    )


def test_bundle_is_included_only_once(figure):
    """Every extra chart should cost kilobytes, not another 4.6 MB."""
    one = _doc([Block("figure", figure)])
    three = _doc([Block("figure", figure) for _ in range(3)])
    assert len(three) - len(one) < 200_000, (
        "the plotly bundle looks like it was inlined more than once"
    )


def test_tables_render_and_escape_their_content():
    df = pd.DataFrame({"Industry": ["29 Motor <vehicles>"], "Change": ["-£178m"]})
    doc = _doc([Block("table", df, "cap")])
    assert "<td>29 Motor &lt;vehicles&gt;</td>" in doc
    assert "-£178m" in doc


def test_provenance_and_handling_note_are_present(figure):
    doc = _doc([Block("figure", figure)])
    for value in META.values():
        assert value in doc, f"missing provenance: {value}"
    assert "disclosure control" in doc, "handling note must survive into the file"
    assert "not official statistics" in doc


def test_notes_carry_their_tone():
    doc = _doc([Block("note", "incomplete month", extra={"tone": "error"})])
    assert 'class="note bad"' in doc


def test_document_is_well_formed(figure):
    doc = _doc([Block("heading", "Movers"), Block("figure", figure),
                Block("text", "something happened")])
    assert doc.startswith("<!doctype html>")
    assert doc.rstrip().endswith("</html>")
    assert doc.count("<body>") == 1 and doc.count("</body>") == 1


def test_briefing_builds_from_real_outputs():
    from pipeline import config as cfg
    if not (cfg.OUTPUTS / "alerts.csv").exists():
        pytest.skip("pipeline outputs not built")
    from export import briefing

    panel = pd.read_csv(cfg.OUTPUTS / "series_national.csv", dtype={"sic2": str},
                        parse_dates=["month"], keep_default_na=False, na_values=[""])
    alerts = pd.read_csv(cfg.OUTPUTS / "alerts.csv", dtype={"code": str},
                         parse_dates=["month"], low_memory=False)
    quality = pd.read_csv(cfg.OUTPUTS / "quality.csv", parse_dates=["month"])
    breaks = pd.read_csv(cfg.OUTPUTS / "breaks.csv", dtype={"sic2": str},
                         parse_dates=["break_month"])
    stability = pd.read_csv(cfg.OUTPUTS / "cell_stability.csv",
                            dtype={"payer": str, "payee": str})
    doc = briefing.build(panel, alerts, quality, breaks, stability,
                         panel.month.max(), "2026-07-16")
    assert "Headline" in doc and "Movers" in doc
    assert not re.findall(r'src\s*=\s*["\']https?://', _page_shell(doc))
