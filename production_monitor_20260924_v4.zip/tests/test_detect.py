"""Detection signals, severity and confidence.

Two failure modes drove this design, both observed on real data:

  * A system-wide move read as 88 industry-specific shocks. July 2021 is an
    incomplete month, so in July 2022 74 of 88 industries appeared to rise
    more than 25% year-on-year while month-on-month growth was +0.4%.

  * A CUSUM normalised by sqrt(n) inflating against autocorrelated inputs,
    firing 14.6 times a month where a single-month z fired 3.1 times.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from pipeline import config as cfg
from pipeline.detect import _confidence, _cusum, _severity, common_component


def _panel(frames: dict[str, list[float]], start="2019-01-01") -> pd.DataFrame:
    rows = []
    n = len(next(iter(frames.values())))
    months = pd.date_range(start, periods=n, freq="MS")
    for sic2, vals in frames.items():
        for m, v in zip(months, vals):
            rows.append({"sic2": sic2, "month": m, "pfi": v})
    return pd.DataFrame(rows)


def test_common_component_is_the_typical_industry():
    n = 30
    panel = _panel({
        "10": [100.0] * 12 + [200.0] * (n - 12),    # doubled
        "20": [100.0] * 12 + [200.0] * (n - 12),    # doubled
        "30": [100.0] * 12 + [200.0] * (n - 12),    # doubled
    })
    common = common_component(panel, "pfi", 12)
    # Every industry doubled, so the common component is log(2).
    assert common.iloc[12] == pytest.approx(np.log(2), abs=1e-9)


def test_an_industry_moving_with_everything_has_no_excess():
    n = 30
    panel = _panel({s: [100.0] * 12 + [200.0] * (n - 12) for s in ("10", "20", "30")})
    common = common_component(panel, "pfi", 12)
    series = panel[panel.sic2 == "10"].set_index("month").pfi
    yoy = np.log(series).diff(12)
    excess = yoy - common
    assert abs(excess.iloc[12]) < 1e-9, (
        "an industry that moved exactly like the rest of the economy "
        "must not register as an industry shock"
    )


def test_an_industry_moving_against_the_crowd_keeps_its_excess():
    n = 30
    panel = _panel({
        "10": [100.0] * 12 + [200.0] * (n - 12),
        "20": [100.0] * 12 + [200.0] * (n - 12),
        "30": [100.0] * 12 + [100.0] * (n - 12),   # flat while others doubled
    })
    common = common_component(panel, "pfi", 12)
    series = panel[panel.sic2 == "30"].set_index("month").pfi
    excess = np.log(series).diff(12) - common
    assert excess.iloc[12] == pytest.approx(-np.log(2), abs=1e-9)


def test_unclassified_is_excluded_from_the_common_component():
    n = 30
    panel = _panel({
        "10": [100.0] * n,
        "20": [100.0] * n,
        cfg.UNCLASSIFIED_SIC: [100.0] * 12 + [10000.0] * (n - 12),
    })
    common = common_component(panel, "pfi", 12)
    assert abs(common.iloc[12]) < 1e-9, "SIC 00 must not move the common component"


def test_cusum_is_a_mean_not_an_inflating_sum():
    """Six months at z = -2 should read about -2, not -2 * sqrt(6)."""
    z = pd.Series([-2.0] * 12, index=pd.date_range("2020-01-01", periods=12, freq="MS"))
    out = _cusum(z, window=6)
    assert out.iloc[-1] == pytest.approx(-2.0)


def test_cusum_ignores_a_single_spike():
    z = pd.Series([0.0] * 11 + [-6.0],
                  index=pd.date_range("2020-01-01", periods=12, freq="MS"))
    assert abs(_cusum(z, window=6).iloc[-1]) < 1.5


def test_severity_is_monotone_and_bounded():
    assert _severity(0.0) < _severity(2.0) < _severity(4.0) < _severity(9.0)
    assert 0 <= _severity(50.0) <= 100
    assert np.isnan(_severity(np.nan))


def test_severity_uses_the_strongest_signal():
    assert _severity(4.0, np.nan, 1.0) == _severity(4.0)


def test_a_systemic_month_is_never_high_confidence():
    label, reason = _confidence(presence=0.0, breadth=0.95, on_break=False,
                                sic00_shift=0.0, suppressed_share=0.1,
                                common_pct=0.588)
    assert label == "low"
    assert "whole economy" in reason


def test_presence_driven_moves_are_low_confidence():
    label, _ = _confidence(presence=0.92, breadth=0.5, on_break=False,
                           sic00_shift=0.0, suppressed_share=0.1, common_pct=0.02)
    assert label == "low"


def test_reclassification_is_low_confidence():
    label, reason = _confidence(presence=0.1, breadth=0.8, on_break=False,
                                sic00_shift=0.47, suppressed_share=0.1,
                                common_pct=0.02)
    assert label == "low"
    assert "classification" in reason


def test_a_broad_based_idiosyncratic_move_is_high_confidence():
    label, _ = _confidence(presence=0.05, breadth=0.85, on_break=False,
                           sic00_shift=0.01, suppressed_share=0.1, common_pct=0.02)
    assert label == "high"


def test_a_move_carried_by_one_counterparty_is_not_broad_based():
    """Breadth and concentration are different questions.

    SIC 66 had most of its counterparties falling AND a single counterparty
    carrying 102% of the fall. Reporting that as "broad-based" next to a driver
    line naming one counterparty left the reader to resolve a contradiction.
    """
    label, reason = _confidence(presence=0.05, breadth=0.9, on_break=False,
                                sic00_shift=0.0, suppressed_share=0.1,
                                common_pct=0.02, top_share=1.02)
    assert label == "medium"
    assert "single" in reason


def test_a_genuinely_spread_move_stays_high_confidence():
    label, reason = _confidence(presence=0.05, breadth=0.9, on_break=False,
                                sic00_shift=0.0, suppressed_share=0.1,
                                common_pct=0.02, top_share=0.25)
    assert label == "high"
    assert reason == "broad-based"
