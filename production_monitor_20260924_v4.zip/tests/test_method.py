"""The explanations must agree with the code they explain.

Every assertion here traces to a specific stakeholder question about a number
the dashboard prints. The theme of the feedback was that a threshold shown
without its derivation is a threshold the reader has to take on trust, and an
example pinned to one month stops being useful once that month is old.

Two classes of check:

  * **Arithmetic** - the numbers quoted in the prose are what the formulas
    return. These cannot drift, because the test recomputes them.
  * **Provenance** - a threshold quoted in the UI is the same constant the
    pipeline actually applies. Change the constant without the prose and this
    fails, which is the point.
"""
from __future__ import annotations

import re
from pathlib import Path

import numpy as np
import pytest

from pipeline import detect

METHOD = Path("app_pages/method.py").read_text()
NARRATE = Path("pipeline/narrate.py").read_text()
UI = {p.name: p.read_text() for p in Path("app_pages").glob("*.py")}
USER_FACING = "\n".join(UI.values())


# ---------------------------------------------------------------------------
# The severity scale
# ---------------------------------------------------------------------------

def _severity(z: float) -> float:
    return 100 * (1 - np.exp(-abs(z) / detect.SEVERITY_SCALE))


def test_63_is_what_the_formula_returns_at_z_equals_3():
    """The claim the whole Outliers page rests on.

    Andrew's question was "who told you that, why should we believe you". The
    answer has to be arithmetic, so it is checked as arithmetic.
    """
    assert round(_severity(3), 1) == 63.2
    assert round(_severity(3)) == 63


@pytest.mark.parametrize("z,expected", [(1, 28), (2, 49), (3, 63), (4, 74),
                                        (6, 86), (9, 95)])
def test_the_published_severity_curve_is_the_real_one(z, expected):
    """Every cell of the table printed in method.py, recomputed."""
    assert round(_severity(z)) == expected
    assert f"| {expected} |" in METHOD or str(expected) in METHOD


def test_the_severity_formula_is_shown_not_just_its_output():
    assert "1 - e^" in METHOD or "1 - e^{-" in METHOD or "e^{-|z|" in METHOD
    assert "Shewhart" in METHOD, (
        "the three-sigma convention must be attributed, not asserted")
    assert "1931" in METHOD
    assert "370" in METHOD, "the 0.27% tail has to be given in readable terms"


def test_the_normal_tail_quoted_for_z3_is_correct():
    from scipy import stats
    two_sided = 2 * stats.norm.sf(3)
    assert round(two_sided * 100, 2) == 0.27
    assert round(1 / two_sided) == 370
    assert "0.27" in METHOD


def test_the_fat_tail_caveat_is_present():
    """The honest half of the answer.

    On this data 63 fires far more often than a normal curve implies. Saying
    so is what stops the score being read as a probability.
    """
    assert "fatter tails" in METHOD or "fatter tail" in METHOD
    assert "not a hypothesis test" in METHOD
    assert "significant" in METHOD, (
        "the word has a specific meaning to an ONS reader; the page must say "
        "this score does not earn it")


def test_severity_is_disclosed_as_identical_across_mom_and_yoy():
    """It always was. It was never said."""
    assert "does not change when you switch between MoM and YoY" in METHOD


# ---------------------------------------------------------------------------
# Confidence thresholds: prose must match the constants
# ---------------------------------------------------------------------------

def test_confidence_thresholds_quoted_in_the_ui_match_the_code():
    assert f"{detect.SYSTEMIC_COMMON_PCT:.0%}".replace("%", "") == "20"
    assert f"{detect.CONCENTRATION_LIMIT:.0%}".replace("%", "") == "70"
    assert detect.FULL_BASELINE == 24
    for quoted in ("**±20%**", "**50%**", "**70%**", "**24**", "**40%**"):
        assert quoted in METHOD, f"{quoted} missing from the checklist table"


def test_every_confidence_threshold_has_a_stated_origin():
    """"Where the thresholds come from" is the section that answers
    "why should the stakeholder believe you"."""
    assert "Where the thresholds come from" in METHOD
    assert "not fitted parameters" in METHOD
    assert "None was chosen by looking at which alerts it produced" in METHOD


def test_confidence_is_framed_as_a_checklist_not_a_judgement():
    """The old wording claimed to know what was economic. We cannot."""
    assert "does not judge economics" in METHOD
    assert "checklist" in METHOD
    banned = re.findall(r"looks? genuinely economic", USER_FACING, re.I)
    assert not banned, (
        f"{banned[:2]}: we cannot observe whether a move is economic. Say "
        f"which artefact tests were run instead.")


def test_the_checklist_order_is_stated_because_first_match_wins():
    assert "first" in METHOD.lower() and "match" in METHOD.lower()
    assert "Nothing is weighted, averaged or tuned" in METHOD


def test_confidence_and_severity_are_never_blended():
    assert "never blended into severity" in METHOD or \
           "never blended" in METHOD
    assert "Why confidence is never blended into severity" in METHOD


# ---------------------------------------------------------------------------
# Baseline
# ---------------------------------------------------------------------------

def test_provisional_is_defined_as_the_constant_and_not_a_round_number():
    assert f"fewer than {detect.FULL_BASELINE} months" in METHOD
    assert "already been reduced" in METHOD or "already been discounted" in METHOD
    assert "disclosure" in METHOD, (
        "provisional must be described as a disclosure, not a second penalty")


def test_baseline_counts_only_months_that_hold_a_value():
    """The defect found while writing the worked example.

    Counting rows of the index rather than observations overstated both the
    published depth and the degrees of freedom of the t correction, in the
    direction of overconfidence.
    """
    import pandas as pd
    idx = pd.date_range("2022-01-01", periods=40, freq="MS")
    x = pd.Series(np.random.default_rng(0).normal(size=40), index=idx)
    x.iloc[5:15] = np.nan                      # ten withheld months
    usable = pd.Series(True, index=idx)
    _, depth = detect._rolling_robust_z(x, usable)
    last = depth.dropna().iloc[-1]
    assert last <= 30, (
        f"depth {last} counts withheld months; only {int(x.iloc[:-1].notna().sum())} "
        f"observations exist before the final point")


# ---------------------------------------------------------------------------
# Worked examples must be reproducible and must not expire
# ---------------------------------------------------------------------------

def test_the_basis_example_uses_invented_round_numbers():
    """An example of a *method* must not be pinned to a real month."""
    import app_pages.method as M
    block = M.BASIS_EXPLAINER
    assert "invented, round numbers" in block
    assert "£100m" in block and "£200m" in block
    assert not re.search(r"(January|February|March|April|May|June|July|August|"
                         r"September|October|November|December)\s+20\d\d", block), (
        "the basis example must not name a calendar month - it would expire")


def test_the_basis_example_arithmetic_is_right():
    """100 -> 110 is +10%; 300 -> 200 is -33%. Same industry, same month."""
    assert round((110 / 100 - 1) * 100) == 10
    assert round((200 / 300 - 1) * 100) == -33
    assert "rose 10%" in METHOD and "fell 33%" in METHOD


def test_the_negative_bar_example_reconciles():
    """The inflow waterfall example must add up, or it teaches the wrong thing."""
    bars = [130 - 100, 50 - 80, 75 - 60]
    assert sum(bars) == 255 - 240 == 15
    assert "+£15m" in METHOD and "−£30m" in METHOD


def test_education_march_2025_is_gone_from_the_overview():
    """Pinned to one month, and used 'basis' before defining it."""
    assert "Education did exactly that in March 2025" not in USER_FACING


def test_live_examples_are_recomputed_rather_than_written_in():
    """Anything describing *this* delivery must come from the outputs."""
    assert "@st.cache_data" in METHOD
    assert "_severity_worked" in METHOD and "data.national()" in METHOD


# ---------------------------------------------------------------------------
# The three decomposition categories and the reconciliation line
# ---------------------------------------------------------------------------

def test_the_three_categories_have_an_everyday_example_each():
    for phrase in ("supermarket", "hotel group", "restaurant chain"):
        assert phrase in METHOD, f"no concrete situation for one category ({phrase})"


def test_a_vanished_figure_is_not_claimed_to_be_a_stopped_business():
    assert "is not evidence that a business stopped trading" in METHOD
    assert "separately every single month" in METHOD


def test_presence_share_is_presented_as_a_definition():
    assert "This is a definition, not a finding" in METHOD
    assert "presence share = | newly present + absent | ÷ | total change |" in METHOD


def test_reconciliation_explains_what_zero_means():
    assert "It is not a statement about positive and negative bars cancelling" \
        in METHOD
    assert "a bug in this tool, not a feature of the data" in METHOD


def test_negative_bars_on_an_inflow_chart_are_explained():
    assert "The bars are not inflows. They are contributions to the *change*" \
        in METHOD
    assert "held the total back" in METHOD


# ---------------------------------------------------------------------------
# The band and the diagnostics
# ---------------------------------------------------------------------------

def test_the_band_says_what_it_is_not():
    assert "not a confidence interval" in METHOD
    assert "not a forecast" in METHOD
    assert "no probability" in METHOD


def test_the_band_says_what_happens_when_it_disagrees_with_severity():
    assert "severity is the measured one" in METHOD


def test_diagnostics_name_the_question_each_one_settles():
    assert "separating" in METHOD and "volume" in METHOD
    assert "blank rather than infinite" in METHOD, (
        "the rounded-transaction-count trap must be stated where it bites")


# ---------------------------------------------------------------------------
# Driver lines
# ---------------------------------------------------------------------------

CAUSE_PHRASES = [
    "Concentrated in one partner",
    "More than accounted for by one partner",
    "No single partner drove it",
    "Broad-based",
    "Reporting change, not money changing hands",
    "Coverage change, not new activity",
    "Most likely a classification change",
]


@pytest.mark.parametrize("phrase", CAUSE_PHRASES)
def test_every_driver_line_ending_exists_in_the_generator(phrase):
    assert f"**{phrase}" in NARRATE


@pytest.mark.parametrize("phrase", CAUSE_PHRASES)
def test_every_driver_line_ending_is_documented_for_the_reader(phrase):
    assert phrase in METHOD, (
        f"'{phrase}' can appear on a page but is not in the driver-line legend")


def test_the_driver_line_legend_is_rendered_wherever_the_lines_appear():
    """One legend, shared. Two copies would drift apart the first time a
    branch was added to the generator."""
    import app_pages.method as M
    for page in ("overview", "movers"):
        labels = [label for label, _ in M.PAGE_TABS[page]]
        assert any("What changed" in l for l in labels), (
            f"the {page} guide has no tab explaining the driver lines")


# ---------------------------------------------------------------------------
# Driver lines: exercised on synthetic edges, because the source text wraps
# and a wrapped phrase is one no grep and no reader can find.
# ---------------------------------------------------------------------------

def _edges(rows) -> "pd.DataFrame":
    import pandas as pd
    return pd.DataFrame(rows, columns=["month", "payer", "payee", "value",
                                       "n_tx"])


def _alert(**kw):
    import pandas as pd
    from types import SimpleNamespace
    base = dict(code="41", name="Construction", measure="inflow", basis="YoY",
                month=pd.Timestamp("2026-06-01"), breadth=np.nan,
                sic00_share_shift=np.nan)
    base.update(kw)
    return SimpleNamespace(**base)


def _line_for(rows, **alert_kw) -> str:
    from pipeline import narrate
    return narrate.line(_alert(**alert_kw), _edges(rows), {"64": "Finance",
                                                           "47": "Retail",
                                                           "84": "Public admin"})


NOW = "2026-06-01"
BASE = "2025-06-01"


def test_a_partner_moving_against_the_total_is_not_called_the_cause():
    """The defect this branch exists for.

    An industry falls overall while its single biggest change is a partner
    paying MORE. Calling that partner "the largest contributor to the move"
    states the opposite of the truth.
    """
    import pandas as pd
    rows = [
        # Retail paid £150m MORE - the largest single change of the three...
        (pd.Timestamp(BASE), "47", "41", 100e6, 10),
        (pd.Timestamp(NOW), "47", "41", 250e6, 10),
        # ...while two others each fell £100m, so the TOTAL falls £50m.
        (pd.Timestamp(BASE), "64", "41", 300e6, 10),
        (pd.Timestamp(NOW), "64", "41", 200e6, 10),
        (pd.Timestamp(BASE), "84", "41", 300e6, 10),
        (pd.Timestamp(NOW), "84", "41", 200e6, 10),
    ]
    out = _line_for(rows, gbp_delta=-50e6, pct_delta=-0.02)
    assert "moved the other way" in out, out
    assert "against" in out
    assert "largest contributor" not in out.lower()


def test_a_share_above_100_percent_is_explained_not_just_printed():
    """One partner can move by more than the industry's net change."""
    import pandas as pd
    rows = [
        (pd.Timestamp(BASE), "64", "41", 2800e6, 10),
        (pd.Timestamp(NOW), "64", "41", 100e6, 10),     # -2.7bn
        (pd.Timestamp(BASE), "47", "41", 40e6, 10),
        (pd.Timestamp(NOW), "47", "41", 100e6, 10),     # +60m, offsetting
    ]
    out = _line_for(rows, gbp_delta=-2.64e9, pct_delta=-0.36)
    assert "more than the whole change" in out, out
    assert "offset" in out
    assert "barely moved" in out


def test_the_ordinary_case_names_the_partner_the_share_and_the_remainder():
    import pandas as pd
    rows = [
        (pd.Timestamp(BASE), "84", "41", 100e6, 10),
        (pd.Timestamp(NOW), "84", "41", 407e6, 10),     # +307m
        (pd.Timestamp(BASE), "47", "41", 100e6, 10),
        (pd.Timestamp(NOW), "47", "41", 237e6, 10),     # +137m
    ]
    out = _line_for(rows, gbp_delta=444e6, pct_delta=0.12)
    assert "Concentrated in one partner" in out, out
    assert "accounts for" in out and "of the" in out
    assert "paid" in out and "more" in out
    assert "the remaining" in out.lower()


def test_a_vanished_partner_is_labelled_a_reporting_change():
    import pandas as pd
    rows = [
        (pd.Timestamp(BASE), "82", "41", 104e6, 10),   # present then, gone now
        (pd.Timestamp(BASE), "47", "41", 100e6, 10),
        (pd.Timestamp(NOW), "47", "41", 73e6, 10),
    ]
    out = _line_for(rows, gbp_delta=-131e6, pct_delta=-0.20)
    assert "Reporting change, not money changing hands" in out, out
    assert "need not have stopped trading" in out


def test_every_line_starts_with_the_industry_and_states_the_comparison():
    import pandas as pd
    rows = [(pd.Timestamp(BASE), "84", "41", 100e6, 10),
            (pd.Timestamp(NOW), "84", "41", 200e6, 10)]
    out = _line_for(rows, gbp_delta=100e6, pct_delta=0.5)
    assert out.startswith("**SIC 41 Construction**"), out
    assert "vs June 2025." in out


def test_money_puts_the_minus_outside_the_currency_symbol():
    from pipeline.narrate import _money
    assert _money(-2.7e9) == "-£2.7bn"
    assert _money(-6e7) == "-£60m"
    assert _money(4.44e8) == "£444m"


# ---------------------------------------------------------------------------
# Stored text must not go stale when the generator changes
# ---------------------------------------------------------------------------

def test_stored_driver_lines_match_what_the_generator_produces_now():
    """The Overview reads `driver_line` from alerts.csv rather than
    regenerating it, so a change to narrate.py leaves the page showing the old
    wording with nothing to indicate it. That happened once: the sign fix
    landed after the pipeline had already written its lines, and the Overview
    kept printing "the largest contributor is SIC 47 at £93m" for an industry
    that fell while SIC 47 paid more.

    Regenerating the latest month is a few hundred milliseconds against a
    month-indexed edge table, so there is no reason not to check it.
    """
    import pandas as pd
    from types import SimpleNamespace
    from pathlib import Path
    from pipeline import config as cfg, decompose, narrate

    if not (cfg.OUTPUTS / "alerts.parquet").exists():
        pytest.skip("no outputs; run the pipeline first")
    alerts = pd.read_parquet(cfg.OUTPUTS / "alerts.parquet")
    panel = pd.read_parquet(cfg.OUTPUTS / "series_national.parquet")
    vintages = sorted(p for p in cfg.VINTAGES.iterdir() if p.is_dir()) \
        if cfg.VINTAGES.exists() else []
    if not vintages:
        pytest.skip("no vintage")
    edges = decompose.as_index(
        pd.read_parquet(vintages[-1] / f"{cfg.LEVEL_SIC2}.parquet"))
    names = dict(zip(panel.sic2, panel["name"]))

    d = alerts[(alerts.level == "division")
               & alerts.driver_line.astype(str).str.len().gt(3)]
    latest = d.month.max()
    rows = d[d.month == latest].nlargest(4, "severity")
    stale = []
    for r in rows.itertuples():
        fresh = narrate.line(
            SimpleNamespace(code=r.code, name=r.name, measure=r.measure,
                            basis=r.basis, month=r.month,
                            gbp_delta=r.gbp_delta, pct_delta=r.pct_delta,
                            breadth=r.breadth,
                            sic00_share_shift=r.sic00_share_shift),
            edges, names)
        if fresh != r.driver_line:
            stale.append(f"{r.code} {r.basis}")
    assert not stale, (
        f"driver_line in outputs/alerts.csv was written by an older version of "
        f"narrate.py ({stale}). Rerun the pipeline - the Overview reads this "
        f"column directly and will show the old wording.")



# ---------------------------------------------------------------------------
# One box per page
# ---------------------------------------------------------------------------

GUIDED_PAGES = ["overview", "movers", "outliers", "decomposition", "trends"]
# These four moved onto the full tabbed guide once Phase 2 was given the same
# treatment as Phase 1; simple_guide remains for any view that needs it.
SIMPLE_GUIDE_PAGES = ["leaderboard", "shifts", "influence", "clusters"]


@pytest.mark.parametrize("page", GUIDED_PAGES)
def test_each_analysis_page_opens_exactly_one_explanation_box(page):
    """Outliers once opened nine, Movers eight.

    A reader with no knowledge of the project met the boxes before they met a
    number. Everything is still there - it is behind one door with tabs.
    """
    src = UI[f"{page}.py"]
    assert f'method.page_guide("{page}")' in src, (
        f"{page} does not render the shared guide")
    leftover = [line for line in src.splitlines()
                if "st.expander(" in line
                and not any(k in line for k in ("Table", "Why these moved"))]
    assert not leftover, (
        f"{page} still opens its own explanation box: {leftover}")


@pytest.mark.parametrize("page", SIMPLE_GUIDE_PAGES)
def test_the_other_views_use_the_same_door(page):
    """Same title, same place, so moving between views teaches nothing new."""
    src = UI[f"{page}.py"]
    assert ("method.simple_guide(" in src
            or f'method.page_guide("{page}")' in src), (
        f"{page} does not render a shared guide")
    assert 'st.expander("How to read this")' not in src, (
        f"{page} still uses its own box title")


def test_every_view_that_shows_a_number_has_a_guide():
    """Nine views, one door each, same title on all of them."""
    import app_pages.method as M
    expected = {"overview", "movers", "outliers", "decomposition", "trends",
                "leaderboard", "influence", "clusters", "shifts"}
    assert expected <= set(M.PAGE_TABS), (
        f"no guide for {sorted(expected - set(M.PAGE_TABS))}")


def test_every_guide_starts_by_saying_what_the_page_shows():
    import app_pages.method as M
    for page, sections in M.PAGE_TABS.items():
        assert sections[0][0] == "What this shows", (
            f"the {page} guide does not open by saying what the page is for")


def test_every_guide_tab_renders_without_error_and_is_not_empty():
    """A tab that raises would be invisible until somebody clicked it."""
    import app_pages.method as M
    for page, sections in M.PAGE_TABS.items():
        for label, body in sections:
            text = body()
            assert isinstance(text, str) and len(text.split()) > 40, (
                f"{page} / {label} rendered {len(text.split())} words")


def test_a_page_offering_a_measure_control_explains_the_measures():
    import app_pages.method as M
    for page in ("movers", "outliers", "decomposition", "trends"):
        labels = [label for label, _ in M.PAGE_TABS[page]]
        assert "The three measures" in labels, (
            f"{page} lets the user pick a measure but never defines it")


def test_a_page_offering_a_basis_control_explains_the_basis():
    import app_pages.method as M
    for page in M.PAGE_TABS:
        labels = [label for label, _ in M.PAGE_TABS[page]]
        assert "Which payments are counted" in labels, (
            f"{page} shows money on a basis it never explains")


def test_classified_flow_has_exactly_one_definition():
    """The dataset page used to define it a second time, in its own words."""
    import app_pages.method as M
    assert "Classified only" in M.BASIS_EXPLAINER
    assert "method.BASIS_EXPLAINER" in UI["dataset.py"], (
        "The dataset page should render the shared definition, not its own")
    own = UI["dataset.py"]
    assert "the sum of value on rows where" not in own, (
        "a second definition of classified flow has reappeared")


# ---------------------------------------------------------------------------
# The worked confidence example, and the case quoted across four pages
# ---------------------------------------------------------------------------

def test_confidence_has_a_worked_example_not_just_a_rule_table():
    """The stakeholder asked for a hand calculation for BOTH scores.

    The summary table said which rule fired. It did not show the numbers that
    made it fire, so the label still read as a black box.
    """
    import app_pages.method as M
    walk = M._confidence_worked()
    if not walk:
        pytest.skip("no outputs")
    assert "The same checklist, walked on one real row" in walk
    assert walk.count("| no |") + walk.count("| not reached |") >= 3, (
        "a walk that shows only the rule that fired teaches nothing")
    assert "FIRES" in walk, "the walk must mark the deciding test"
    assert "Verdict:" in walk


def test_the_confidence_walk_agrees_with_the_stored_label():
    """The walk re-applies the thresholds, so it could disagree with the
    detector. If it ever does, the page says so rather than printing both."""
    import app_pages.method as M
    walk = M._confidence_worked()
    if not walk:
        pytest.skip("no outputs")
    assert "so the walk agrees with the detector" in walk, (
        "the confidence walk disagrees with alerts.csv:\n" + walk)


def test_the_suppression_case_is_computed_not_written_down():
    """This example is quoted on four pages and had drifted on all of them.

    It said "66% - £330m of a £348m fall" while the data said a -65.5% break
    and £313m of £342m, and it called the case "the largest anomaly in this
    dataset" after the case had stopped being scored at all.
    """
    import app_pages.method as M
    c = M.suppression_case()
    if c is None:
        pytest.skip("no outputs")
    assert 0.5 <= c["top_share"] <= 1.5, c["top_share"]
    assert c["presence"] >= 0.5, (
        "the quoted case must actually be presence-driven")
    assert c["category"] in ("absent_suppressed", "newly_present")

    text = M.suppression_case_markdown()
    assert f"SIC {c['code']}" in text
    assert f"{c['top_share']:.0%}" in text
    assert "recomputed from" in text


@pytest.mark.parametrize("stale", ["£330m", "£348m", "fell 66%",
                                   "collapsed 66%", "falling 66%"])
def test_the_stale_figures_are_gone_from_every_user_facing_page(stale):
    from pathlib import Path
    pages = "\n".join(p.read_text() for p in Path("app_pages").glob("*.py")
                      if p.name != "method.py")
    assert stale not in pages, (
        f"{stale!r} is a figure that no longer matches the data")


def test_no_page_claims_the_case_is_the_largest_anomaly():
    """It is not scored at all: its own break resets its baseline."""
    from pathlib import Path
    pages = "\n".join(p.read_text() for p in Path("app_pages").glob("*.py"))
    assert "single largest anomaly" not in pages
    assert "largest anomaly in this dataset" not in pages


# ---------------------------------------------------------------------------
# Phase 2 gets the same treatment as Phase 1
# ---------------------------------------------------------------------------

PHASE_2_PAGES = ["influence", "clusters", "shifts"]


@pytest.mark.parametrize("page", PHASE_2_PAGES)
def test_phase_2_pages_use_the_same_guide_as_phase_1(page):
    """They had 114-249 words and no derivation, against 1,100-5,000 on the
    Phase 1 pages. Same tool, same reader, same standard."""
    import app_pages.method as M
    assert page in M.PAGE_TABS, f"{page} has no page guide"
    src = UI[f"{page}.py"]
    assert f'method.page_guide("{page}")' in src
    words = sum(len(body().split()) for _, body in M.PAGE_TABS[page])
    assert words >= 700, (
        f"{page} guide is {words} words; Phase 1 pages run 1,100-5,000")


@pytest.mark.parametrize("page", PHASE_2_PAGES)
def test_every_phase_2_page_explains_its_method_and_shows_a_live_example(page):
    import app_pages.method as M
    labels = [l for l, _ in M.PAGE_TABS[page]]
    assert any(l.startswith("How ") for l in labels), (
        f"{page} never explains how its number is produced")
    assert any(l in ("On this delivery", "A real flagged month")
               for l in labels), (
        f"{page} has no example computed from the current data")


def test_pagerank_explains_the_damping_factor_and_where_it_came_from():
    """0.85 is the one free parameter in PageRank and was never justified."""
    import app_pages.method as M
    t = M.PAGERANK_METHOD
    assert "0.85" in t and "0.15" in t
    assert "Brin and Page" in t and "1998" in t
    assert "did not choose it by looking at what it did to our rankings" in t
    assert "random jump is the escape hatch" in t or "escape hatch" in t


def test_pagerank_is_explained_without_mathematics_first():
    import app_pages.method as M
    assert "without any mathematics" in M.PAGERANK_METHOD
    assert "wanderer" in M.PAGERANK_METHOD
    # A method example must not be pinned to a real month.
    assert "invented, round numbers" in M.PAGERANK_METHOD


def test_pagerank_says_why_there_is_no_league_table():
    import app_pages.method as M
    assert "deliberately does not show" in M.PAGERANK_METHOD
    assert "0.99" in M.PAGERANK_METHOD


def test_louvain_justifies_all_three_of_its_settings():
    """Seed 0, minimum community 3, Jaccard 0.25 - none was justified."""
    import app_pages.method as M
    t = M.LOUVAIN_METHOD
    from pipeline import communities as C
    assert str(C.SEED) in t and str(C.MIN_COMMUNITY) in t
    assert "25%" in t and "Jaccard" in t
    assert "Newman and Girvan" in t and "2004" in t
    assert "not a test" in t, "0.3 is a rule of thumb and must be labelled one"


def test_louvain_says_what_the_output_may_not_be_used_for():
    import app_pages.method as M
    assert "hypothesis generator" in M.LOUVAIN_METHOD
    assert "Do not put it in a bulletin" in M.LOUVAIN_METHOD


def test_isolation_forest_is_explained_in_plain_terms():
    import app_pages.method as M
    t = M.STRUCTURAL_METHOD
    assert "yes/no questions" in t or "question-trees" in t
    assert "easy to separate" in t
    from pipeline import structural as S
    assert str(S.CONTAMINATION * 100).rstrip("0").rstrip(".") + "%" in t \
        or "3%" in t
    assert str(S.MIN_HISTORY) in t


def test_the_structural_score_is_not_confused_with_severity():
    """Both are 0-100 and they mean different things."""
    import app_pages.method as M
    t = M.STRUCTURAL_METHOD
    assert "not a severity score" in t and "not comparable" in t
    assert "no p-value" in t or "has no p-value" in t


def test_the_contamination_rate_is_labelled_a_judgement():
    """It is the one genuine judgement in the structural detector."""
    import app_pages.method as M
    assert "genuine judgement" in M.STRUCTURAL_METHOD
    assert "It does not decide what is unusual" in M.STRUCTURAL_METHOD


def test_the_structural_example_does_not_overclaim():
    """An earlier draft said "no single number is alarming on its own" beside
    a feature sitting 12.8 standard deviations out."""
    import app_pages.method as M
    t = M._structural_worked()
    if not t:
        pytest.skip("no outputs")
    assert not ("No single one of these numbers is extreme" in t
                and "standard deviations), so this month would stand out" in t)
    assert "largest mover" in t


def test_industry_names_are_not_truncated_mid_word():
    import app_pages.method as M
    t = M._pagerank_worked()
    if not t:
        pytest.skip("no outputs")
    import re
    for cell in re.findall(r"\| \d\d ([^|]+?) \|", t):
        assert not cell.endswith(" "), cell
        if "…" in cell:
            assert not cell.replace("…", "").endswith(" "), cell


def test_no_explanation_is_written_twice():
    """Two copies of a definition are two definitions that will disagree.

    The 0.3 modularity convention was briefly explained on both the "what this
    shows" tab and the "how Louvain works" tab after Phase 2 was given the
    full treatment.
    """
    import app_pages.method as M
    text = "\n".join(body() for secs in M.PAGE_TABS.values()
                      for _, body in secs)
    for phrase in ("Newman and Girvan",
                   "Brin and Page",
                   "means: which payments are counted",
                   "does not judge economics"):
        assert text.count(phrase) <= len(M.PAGE_TABS), (
            f"{phrase!r} appears {text.count(phrase)} times across the guides; "
            f"it should appear once per page that needs it, from one source")
