"""App smoke tests.

Streamlit renders client-side, so a 200 from the server proves only that it
started. AppTest actually executes the script and surfaces exceptions, which is
the only way a chart-building bug shows up before a user finds it.
"""
from __future__ import annotations

import pytest
from streamlit.testing.v1 import AppTest

from pipeline import config as cfg

pytestmark = pytest.mark.skipif(
    not (cfg.OUTPUTS / "series_national.csv").exists(),
    reason="pipeline outputs not built; run python -m pipeline.run",
)

TIMEOUT = 90


def _select_view(at, view: str):
    """Set the sidebar view, whichever group it lives in.

    The sidebar has separate Phase 1 and Reference radios, so a single index
    no longer identifies the control.
    """
    for radio in at.sidebar.radio:
        if view in list(radio.options):
            radio.set_value(view)
            return at.run()
    raise AssertionError(f"view {view!r} not found in the sidebar")


def _run(view: str | None = None) -> AppTest:
    at = AppTest.from_file("app.py", default_timeout=TIMEOUT).run()
    if view is not None:
        _select_view(at, view)
    return at


def test_app_starts_without_exception():
    at = _run()
    assert not at.exception, [str(e) for e in at.exception]


def test_overview_shows_both_bases_and_both_comparisons():
    """The headline used to sit on every page, show only the classified total,
    and give only a year-on-year change."""
    at = _run("Overview")
    assert not at.exception, [str(e) for e in at.exception]
    labels = [m.label for m in at.metric]
    assert labels.count("Value") == 2, "both bases must be shown"
    assert labels.count("Month on month") == 2
    assert labels.count("Year on year") == 2
    assert "Data ends" in labels


def test_the_headline_is_not_repeated_on_every_view():
    for view in ("Movers", "Trends", "Glossary"):
        at = _run(view)
        labels = [m.label for m in at.metric]
        assert labels.count("Month on month") == 0, (
            f"{view} still carries the overview banner"
        )


def test_region_controls_show_names_not_codes():
    for view, label in (("Movers", "Region"), ("Gainers & losers", "Region")):
        at = _run(view)
        box = [s for s in at.selectbox if s.label == label][0]
        codes = [o for o in box.options if str(o).startswith("TL")]
        assert not codes, f"{view} still offers raw ITL1 codes: {codes[:3]}"
        assert any("London" in str(o) or "Scotland" in str(o)
                   for o in box.options), f"{view} shows no region names"


@pytest.mark.parametrize("view", ["Overview", "Movers", "Outliers",
                                  "Gainers & losers", "Trends",
                                  "Why did it move?", "The dataset",
                                  "Glossary", "Data quality"])
def test_every_view_renders(view):
    at = _run(view)
    assert not at.exception, f"{view}: {[str(e) for e in at.exception]}"


def test_movers_responds_to_the_basis_control():
    at = _run("Movers")
    radios = [r for r in at.radio if r.label == "Compare with"]
    assert radios, "the MoM/YoY control is missing"
    radios[0].set_value("MoM").run()
    assert not at.exception, [str(e) for e in at.exception]


def test_trends_mode_switch_is_exclusive():
    """Compare-measures and compare-regions must not both be active."""
    at = _run("Trends")
    mode = [r for r in at.radio if r.label == "Compare"][0]
    mode.set_value("Regions").run()
    assert not at.exception, [str(e) for e in at.exception]
    labels = [s.label for s in at.multiselect]
    assert "Regions" in labels and "Measures" not in labels


# --- control combinations ------------------------------------------------
# The default render passing proves very little. A duplicate-label crash on
# Movers at GDP-grouping level survived a green suite because every test used
# the default selections.

@pytest.mark.parametrize("level", ["Division (SIC2)", "Section", "GDP grouping"])
def test_movers_renders_at_every_level(level):
    at = _run("Movers")
    control = [s for s in at.selectbox if s.label == "Level"][0]
    control.set_value(level).run()
    assert not at.exception, f"{level}: {[str(e) for e in at.exception]}"


@pytest.mark.parametrize("measure", ["PFI (throughput)", "Inflows", "Outflows"])
def test_movers_renders_for_every_measure(measure):
    at = _run("Movers")
    control = [s for s in at.selectbox if s.label == "Measure"][0]
    control.set_value(measure).run()
    assert not at.exception, f"{measure}: {[str(e) for e in at.exception]}"


@pytest.mark.parametrize("basis", ["YoY", "MoM"])
@pytest.mark.parametrize("level", ["Division (SIC2)", "GDP grouping"])
def test_movers_level_and_basis_combinations(level, basis):
    at = _run("Movers")
    [s for s in at.selectbox if s.label == "Level"][0].set_value(level).run()
    [r for r in at.radio if r.label == "Compare with"][0].set_value(basis).run()
    assert not at.exception, f"{level}/{basis}: {[str(e) for e in at.exception]}"


def test_movers_renders_for_a_single_region():
    at = _run("Movers")
    control = [s for s in at.selectbox if s.label == "Region"][0]
    options = [o for o in control.options if o != "All UK"]
    if not options:
        pytest.skip("regional file not ingested")
    control.set_value(options[0]).run()
    assert not at.exception, [str(e) for e in at.exception]


@pytest.mark.parametrize("measure", ["PFI (throughput)", "Inflows", "Outflows"])
def test_decomposition_renders_for_every_measure(measure):
    at = _run("Why did it move?")
    [r for r in at.radio if r.label == "Measure"][0].set_value(measure).run()
    assert not at.exception, f"{measure}: {[str(e) for e in at.exception]}"


@pytest.mark.parametrize("basis", ["Including SIC 00", "Classified only"])
def test_decomposition_renders_on_both_bases(basis):
    at = _run("Why did it move?")
    [r for r in at.radio if r.label == "Basis"][0].set_value(basis).run()
    assert not at.exception, f"{basis}: {[str(e) for e in at.exception]}"


def test_decomposition_reconciles_to_the_panel():
    """The waterfall must sum to the panel figure on the SAME basis.

    Decomposing an including-SIC-00 change while quoting a classified headline
    produced a "63% of the move" claim measured against the wrong denominator.
    """
    import pandas as pd
    from pipeline import config, decompose, vintage

    edges = vintage.load_snapshot(sorted(config.VINTAGES.iterdir())[-1], "sic2")
    panel = pd.read_csv(config.OUTPUTS / "series_national.csv",
                        dtype={"sic2": str}, parse_dates=["month"])
    now = panel.month.max()
    base = now - pd.DateOffset(months=12)
    for code in ("66", "68", "72"):
        rows = decompose.decompose_measure(edges, code, now, base, measure="pfi",
                                           include_unclassified=False)
        got = decompose.summarise(rows)["total_change"]
        r = panel[panel.sic2 == code].set_index("month")
        expected = float(r.loc[now, "pfi"] - r.loc[base, "pfi"])
        assert got == pytest.approx(expected, abs=1.0), (
            f"SIC {code}: decomposed {got:,.0f} vs panel {expected:,.0f}")


@pytest.mark.parametrize("basis", ["Classified only", "Including SIC 00"])
def test_trends_renders_on_both_bases(basis):
    at = _run("Trends")
    [r for r in at.radio if r.label == "Basis"][0].set_value(basis).run()
    assert not at.exception, f"{basis}: {[str(e) for e in at.exception]}"


# --- gainers and losers --------------------------------------------------

@pytest.mark.parametrize("period", ["1 month", "3 months", "6 months",
                                    "12 months", "Year to date"])
def test_leaderboard_renders_for_every_period(period):
    at = _run("Gainers & losers")
    [s for s in at.selectbox if s.label == "Period"][0].set_value(period).run()
    assert not at.exception, f"{period}: {[str(e) for e in at.exception]}"


@pytest.mark.parametrize("rank_by", ["% change", "£ change"])
def test_leaderboard_ranks_both_ways(rank_by):
    at = _run("Gainers & losers")
    [r for r in at.radio if r.label == "Rank by"][0].set_value(rank_by).run()
    assert not at.exception, f"{rank_by}: {[str(e) for e in at.exception]}"


def test_month_dropdowns_are_newest_first():
    """The latest month is what anyone opens this for."""
    import pandas as pd
    for view, label in (("Movers", "Month"), ("Gainers & losers", "As at")):
        at = _run(view)
        box = [s for s in at.selectbox if s.label == label][0]
        options = [pd.Timestamp(o) for o in box.options]
        assert options == sorted(options, reverse=True), f"{view}: not newest-first"
        assert box.value == options[0], f"{view}: latest month not preselected"


def test_summary_is_generated_for_the_current_selection():
    """The 'what changed' lines must follow the controls, not the pipeline.

    They used to be read from alerts.csv, which only holds lines for All-UK,
    classified, division level - stale the moment a region or basis changed.
    """
    at = _run("Movers")
    before = [m.value for m in at.markdown]
    [s for s in at.selectbox if s.label == "Measure"][0].set_value("Outflows").run()
    after = [m.value for m in at.markdown]
    assert before != after, "the summary did not change with the measure"


def test_decomposition_reconciles_on_screen():
    at = _run("Why did it move?")
    assert not at.exception
    text = " ".join(c.value for c in at.caption if isinstance(c.value, str))
    assert "Reconciliation" in text or "sum exactly" in text


# --- sidebar navigation --------------------------------------------------
# Two faults reported after use: a mysterious "—" option, which was a
# placeholder meaning "nothing selected in this group"; and both groups
# showing a selection at once, so Phase 1 still looked active while the reader
# was on the Glossary.

def test_sidebar_has_no_placeholder_option():
    at = _run()
    for radio in at.sidebar.radio:
        assert "—" not in list(radio.options), (
            f"{radio.label} still offers a placeholder option"
        )
        assert all(str(o).strip() for o in radio.options), "blank option label"


def test_only_one_sidebar_group_is_ever_selected():
    at = _run()
    selected = [r.value for r in at.sidebar.radio if r.value is not None]
    assert len(selected) == 1, f"{len(selected)} groups selected at start"

    for group, option in (("Reference", "Glossary"), ("Phase 1", "Outliers"),
                          ("Reference", "The dataset")):
        [r for r in at.sidebar.radio if r.label == group][0] \
            .set_value(option).run()
        selected = [r.value for r in at.sidebar.radio if r.value is not None]
        assert selected == [option], (
            f"after choosing {option}: {selected} - exactly one group must hold "
            f"the selection"
        )


def test_every_view_is_reachable_from_exactly_one_group():
    at = _run()
    groups = {r.label: list(r.options) for r in at.sidebar.radio}
    everywhere = [o for opts in groups.values() for o in opts]
    assert len(everywhere) == len(set(everywhere)), "a view appears in two groups"
    assert "Movers" in groups["Phase 1"]
    assert "Glossary" in groups["Reference"]


def test_phase_one_is_ordered_as_an_investigation_runs():
    """What moved -> is it unusual -> why -> does it persist -> longer view.

    Each view should answer the question the one above it raises.
    """
    at = _run()
    phase1 = [r for r in at.sidebar.radio if r.label == "Phase 1"][0].options
    assert list(phase1) == ["Overview", "Movers", "Outliers", "Why did it move?",
                            "Trends", "Gainers & losers"]


def test_playbook_is_reachable_and_renders():
    at = _run("Playbook")
    assert not at.exception, [str(e) for e in at.exception]
    text = " ".join(m.value for m in at.markdown if isinstance(m.value, str))
    assert "bulletin" in text.lower(), "the monthly sequence must be there"
    assert "Price or volume" in text, "the investigations must be there"


def test_phase_two_is_its_own_group_and_stays_exclusive():
    """Influence is Phase 2; selecting it must clear Phase 1 and Reference."""
    at = _run()
    groups = {r.label: list(r.options) for r in at.sidebar.radio}
    assert "Phase 2" in groups and "Influence" in groups["Phase 2"]
    assert "Influence" not in groups["Phase 1"]

    [r for r in at.sidebar.radio if r.label == "Phase 2"][0] \
        .set_value("Influence").run()
    selected = [r.value for r in at.sidebar.radio if r.value is not None]
    assert selected == ["Influence"], f"{selected} - exactly one group must hold it"


def test_influence_view_renders():
    at = _run("Influence")
    assert not at.exception, [str(e) for e in at.exception]
    labels = [m.label for m in at.metric]
    assert "Influence vs size" in labels, "the correlation must be on the page"


def test_phase_two_lists_both_built_features():
    at = _run()
    groups = {r.label: list(r.options) for r in at.sidebar.radio}
    assert groups["Phase 2"] == ["Structural shifts", "Influence",
                                 "Economic clusters"]


def test_clusters_view_renders_and_states_its_modularity():
    at = _run("Economic clusters")
    assert not at.exception, [str(e) for e in at.exception]
    labels = [m.label for m in at.metric]
    assert "Modularity" in labels, "the number governing interpretation must show"
