"""Panel construction: PFI, bases, and aggregation levels.

Both cases here are regressions from bugs found by using the app, not by
running the tests - which is why they are pinned.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from pipeline import config as cfg
from pipeline.series import _throughput, build_national, build_section

UNCL = cfg.UNCLASSIFIED_SIC


def _edges(rows) -> pd.DataFrame:
    return pd.DataFrame([
        {"payer": p, "payee": q, "payer_region": None, "payee_region": None,
         "month": pd.Timestamp(m), "value": v, "n_tx": 1.0,
         "suppressed_type": None, "grain": cfg.LEVEL_SIC2}
        for p, q, m, v in rows
    ])


def _lookup(codes) -> pd.DataFrame:
    return pd.DataFrame([
        {"sic2": c, "division": f"Industry {c}",
         "section": s, "section_desc": f"Section {s}",
         "gdp_grouping": cfg.GDP_GROUPING.get(s, "Unclassified")}
        for c, s in codes
    ])


# --- throughput ---------------------------------------------------------

def test_throughput_subtracts_self_flow_once():
    got = _throughput(pd.Series([100.0]), pd.Series([80.0]), pd.Series([30.0]))
    assert got.iloc[0] == pytest.approx(150.0)


def test_throughput_is_null_when_nothing_is_recorded():
    """A suppressed cell is unknown, not zero."""
    got = _throughput(pd.Series([np.nan]), pd.Series([np.nan]), pd.Series([75.0]))
    assert np.isnan(got.iloc[0]), "no recorded flow must give null, not a negative"


def test_throughput_never_returns_a_negative_from_missing_legs():
    got = _throughput(pd.Series([np.nan]), pd.Series([np.nan]), pd.Series([1e9]))
    assert not (got < 0).any()


# --- bases --------------------------------------------------------------

def test_unclassified_has_no_classified_throughput():
    """SIC 00 has no classified counterparties by definition.

    Mixing bases here produced a PFI of -£75bn: a classified inflow of null
    minus a self-flow taken from the full table.
    """
    edges = _edges([
        (UNCL, UNCL, "2026-01-01", 75e9),
        ("10", "20", "2026-01-01", 100.0),
    ])
    panel = build_national(edges, _lookup([(UNCL, "X"), ("10", "C"), ("20", "C")]))
    row = panel[panel.sic2 == UNCL].iloc[0]
    assert pd.isna(row.pfi), "classified PFI of Unclassified must be null"
    assert row.self_flow_incl00 == pytest.approx(75e9)
    assert (panel.pfi.dropna() >= 0).all()


def test_classified_basis_excludes_sic00_counterparties():
    edges = _edges([
        ("10", "20", "2026-01-01", 100.0),
        (UNCL, "20", "2026-01-01", 900.0),
    ])
    panel = build_national(edges, _lookup([(UNCL, "X"), ("10", "C"), ("20", "C")]))
    row = panel[panel.sic2 == "20"].iloc[0]
    assert row.inflow == pytest.approx(100.0), "classified inflow excludes SIC 00"
    assert row.inflow_incl00 == pytest.approx(1000.0)
    assert row.from_00 == pytest.approx(900.0)


# --- aggregation levels -------------------------------------------------

def test_section_totals_reconcile_to_division_totals():
    edges = _edges([("10", "20", "2026-01-01", 100.0),
                    ("20", "30", "2026-01-01", 250.0)])
    lookup = _lookup([("10", "C"), ("20", "C"), ("30", "F")])
    panel = build_national(edges, lookup)
    section = build_section(panel)
    assert section.inflow.sum() == pytest.approx(panel.inflow.sum())


def test_gdp_grouping_spans_several_sections_without_duplicate_labels():
    """Production is sections B, C, D and E.

    Indexing the section panel by gdp_grouping rather than aggregating it
    yields four rows labelled "Production" and pandas refuses to reindex.
    """
    edges = _edges([("05", "10", "2026-01-01", 10.0),   # B -> C
                    ("10", "35", "2026-01-01", 20.0),   # C -> D
                    ("35", "36", "2026-01-01", 30.0)])  # D -> E
    lookup = _lookup([("05", "B"), ("10", "C"), ("35", "D"), ("36", "E")])
    section = build_section(build_national(edges, lookup))
    assert section[section.month == "2026-01-01"].gdp_grouping.eq("Production").sum() > 1, (
        "this fixture must actually produce several sections in one grouping"
    )
    rolled = (section[section.month == "2026-01-01"]
              .groupby("gdp_grouping", observed=True).inflow.sum(min_count=1))
    assert rolled.index.is_unique
