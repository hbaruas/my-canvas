"""The audit itself must work, and must be able to fail.

A reconciliation that cannot detect a discrepancy is worse than none: it
produces a clean report over broken numbers. These tests corrupt an output on
purpose and check the audit notices.
"""
from __future__ import annotations

import shutil

import numpy as np
import pandas as pd
import pytest

from pipeline import audit, config as cfg

pytestmark = pytest.mark.skipif(
    not (cfg.OUTPUTS / "series_national.csv").exists(),
    reason="pipeline outputs not built; run python -m pipeline.run",
)

PANEL = cfg.OUTPUTS / "series_national.csv"


@pytest.fixture
def restore_panel(tmp_path):
    backup = tmp_path / "series_national.csv"
    shutil.copy(PANEL, backup)
    yield
    shutil.copy(backup, PANEL)


def test_audit_passes_on_the_real_outputs():
    """Core scope here; the full run including the regional file is the CLI."""
    assert audit.run(scope="core") == 0, \
        "the audit reports a discrepancy in current outputs"


@pytest.mark.slow
def test_full_audit_including_the_regional_file():
    assert audit.run(scope="full") == 0


def test_audit_detects_a_shifted_value(restore_panel, capsys):
    """Move one industry-month by £1m. The totals must stop reconciling."""
    df = pd.read_csv(PANEL, dtype={"sic2": str, "section": str},
                     keep_default_na=False, na_values=[""], low_memory=False)
    target = df.index[(df.sic2 != "00") & df.inflow.notna()][0]
    df.loc[target, "inflow"] += 1_000_000
    df.to_csv(PANEL, index=False)
    assert audit.run(scope="core") != 0, "a £1m discrepancy went undetected"


def test_audit_detects_a_broken_identity(restore_panel):
    """Break PFI = inflow + outflow - self_flow on a single row."""
    df = pd.read_csv(PANEL, dtype={"sic2": str, "section": str},
                     keep_default_na=False, na_values=[""], low_memory=False)
    target = df.index[(df.sic2 != "00") & df.pfi.notna()][0]
    df.loc[target, "pfi"] = float(df.loc[target, "pfi"]) * 2
    df.to_csv(PANEL, index=False)
    assert audit.run(scope="core") != 0, "a broken PFI identity went undetected"


def test_audit_detects_an_infinity(restore_panel):
    """The exact bug this was written after: a division by zero reaching a CSV."""
    df = pd.read_csv(PANEL, dtype={"sic2": str, "section": str},
                     keep_default_na=False, na_values=[""], low_memory=False)
    df.loc[df.index[0], "avg_tx_value_in"] = np.inf
    df.to_csv(PANEL, index=False)
    assert audit.run(scope="core") != 0, "an infinity in an output went undetected"


# --- the guard that produced the fix -----------------------------------

def test_safe_divide_returns_null_not_infinity():
    from pipeline.series import safe_divide
    out = safe_divide(pd.Series([7000.0, 100.0]), pd.Series([0.0, 4.0]))
    assert pd.isna(out.iloc[0]), "division by zero must give null, not inf"
    assert out.iloc[1] == pytest.approx(25.0)


def test_safe_divide_handles_nulls_and_text():
    from pipeline.series import safe_divide
    out = safe_divide(pd.Series([10.0, np.nan]), pd.Series([np.nan, 2.0]))
    assert out.isna().all()


def test_no_output_contains_an_infinity():
    import glob
    for path in glob.glob(str(cfg.OUTPUTS / "*.csv")):
        num = pd.read_csv(path, low_memory=False).select_dtypes("number")
        n = int(np.isinf(num).sum().sum())
        assert n == 0, f"{path} contains {n} infinite values"


def test_identifier_columns_survive_the_parquet_round_trip():
    pq = cfg.OUTPUTS / "series_national.parquet"
    if not pq.exists():
        pytest.skip("parquet companion not written")
    codes = pd.read_parquet(pq).sic2
    assert str(codes.dtype) in ("object", "string")
    assert "00" in set(codes), "zero-padded codes lost their leading zero"
    assert "01" in set(codes)
