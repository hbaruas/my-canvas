"""Every term a user meets must be defined where they meet it.

Each assertion here traces to a specific question the stakeholder asked after
first using the dashboard. A definition that lives only in the glossary is a
definition nobody reads, so these check the point of use.
"""
from __future__ import annotations

from pathlib import Path

import pytest

APP = Path("app.py").read_text()
PAGES = {p.name: p.read_text() for p in Path("app_pages").glob("*.py")}


def _any(*needles: str) -> str:
    """All page sources joined, for 'defined somewhere sensible' checks."""
    return APP + "".join(PAGES.values())


def test_pfi_formula_is_stated_not_just_named():
    text = PAGES["explain.py"]
    assert "inflow + outflow" in text and "self-flow" in text
    assert "not an index" in text.lower(), (
        "PFI is a value in pounds; the name misleads and must be corrected"
    )


def test_pfi_definition_reaches_every_view_that_offers_it():
    """Reachable from the page, not necessarily pasted into it.

    Each page now opens one guide with the measures on a tab, so the check is
    that the tab is there rather than that the page holds the words.
    """
    import app_pages.method as M
    for page in ("movers", "outliers", "trends", "decomposition"):
        labels = [label for label, _ in M.PAGE_TABS[page]]
        assert "The three measures" in labels, (
            f"{page} lets the user pick PFI but never defines it")
    labels = [label for label, _ in M.PAGE_TABS["leaderboard"]]
    assert "The three measures" in labels, (
        "Gainers & losers lets the user pick PFI but never defines it")


def test_self_flow_subtraction_is_justified_with_a_figure():
    """The magnitude must be there, and must be the current one.

    test_ground_truth.py checks the figure against the data; this checks it is
    quoted where the user meets the decision.
    """
    assert "14.3%" in PAGES["explain.py"], (
        "the reason for subtracting self-flow needs its magnitude, or it reads "
        "as an arbitrary adjustment"
    )


def test_classified_flow_is_defined_where_it_is_shown():
    """The headline moved off every page into its own Overview view."""
    import app_pages.method as M
    ov = M.WHAT_OVERVIEW
    assert "both ends" in ov.lower() and "SIC 00" in ov
    assert "money is just as real" in ov, (
        "unclassified flow must be described as real money, not missing data"
    )
    assert 'method.page_guide("overview")' in PAGES["overview.py"]


def test_overview_shows_both_bases_and_both_comparisons():
    ov = PAGES["overview.py"]
    assert "All flow" in ov and "Classified only" in ov
    assert ov.count("Month on month") >= 1 and ov.count("Year on year") >= 1


def test_suppression_attribution_is_explicit():
    """Andrew asked whether we suppress, or the provider does."""
    joined = _any()
    assert "provider" in joined.lower()
    assert "We suppress nothing" in joined or "We do not suppress" in joined


def test_counterparty_is_defined():
    joined = _any()
    assert "counterparty" in joined.lower()
    assert "payer" in joined.lower() and "payee" in joined.lower()


def test_severity_and_confidence_are_explained_where_shown():
    """The explanation has to be reachable from the page, not merely to exist.

    These definitions used to be pasted into each page, which let four pages
    drift apart. They now live in method.py and are rendered by the page, so
    the check is that the page calls the explainer and the explainer holds the
    substance.
    """
    import app_pages.method as M
    labels = [label for label, _ in M.PAGE_TABS["movers"]]
    assert any("severity" in l for l in labels), "no severity tab on Movers"
    assert "Confidence" in labels, "no confidence tab on Movers"
    # The common component and the baseline are steps of the severity
    # calculation, so they live on that tab rather than on tabs of their own.
    severity_tab = dict(M.PAGE_TABS["movers"])["'Unusual?' — severity"]()
    assert "common component" in severity_tab
    assert "provisional" in severity_tab

    method = PAGES["method.py"]
    assert "common component" in method, "the cross-sectional step must be stated"
    assert "MAD" in method and "median" in method
    assert "never blended" in method
    # The claim that a big move can be a recording change needs a real case.
    assert "hotel group" in method and "restaurant chain" in method


def test_severity_and_confidence_are_explained_on_every_page_that_shows_them():
    """Whichever page prints the two columns must carry both tabs."""
    import app_pages.method as M
    for page in ("movers", "outliers"):
        labels = [label for label, _ in M.PAGE_TABS[page]]
        assert any("severity" in l.lower() or "Severity" in l for l in labels), (
            f"{page} prints a severity score with no derivation on the page")
        assert "Confidence" in labels, (
            f"{page} prints a confidence label with no derivation on the page")


def test_decomposition_metrics_are_each_defined():
    """The four headline figures, and where each is explained.

    The labels are on the page; what they mean is on the guide's "three kinds
    of bar" tab, with a live sentence under the figures reading them for the
    current selection.
    """
    import app_pages.method as M
    d = PAGES["decomposition.py"]
    for phrase in ("From continuing flows", "appearing / vanishing",
                   "Presence share"):
        assert phrase in d
    assert "In words:" in d, (
        "the four figures need a plain sentence reading them for this selection"
    )
    # Markdown emphasis can fall anywhere in the sentence, so match on the
    # words rather than on a contiguous phrase.
    prose = M.PRESENCE_METHOD.replace("**", "").replace("*", "")
    assert "withholds a cell" in prose, (
        "a vanishing counterparty needs its cause explained"
    )
    assert "is not evidence that a business stopped trading" in prose


def test_volume_outlier_explanation_shows_its_evidence():
    """The month must be described with its numbers, and its effect on our
    own figures stated — without claiming to know why the data looks that way.
    """
    ds = PAGES["dataset.py"]
    assert "74 of 88" in ds, "the measured consequence needs stating"
    assert "What the data records" in ds, "the observation must lead"
    assert "not something this data can settle" in ds, (
        "the limit of what we can conclude must be explicit"
    )


def test_dataset_page_answers_the_unknown_split():
    ds = PAGES["dataset.py"]
    assert "Both parties classified" in ds or "classification" in ds
    assert "Both parties unclassified" in ds or "both_uncl" in ds


def test_sidebar_separates_phases():
    assert "PHASE_1" in APP and "PHASE_2" in APP
    assert "Phase 2" in APP


def test_movers_slider_can_reach_every_industry():
    m = PAGES["movers.py"]
    assert "max(n_available" in m, (
        "the slider must extend to every available industry, not a fixed cap"
    )


# --- the playbook must say HOW, not just what -------------------------

def test_bulletin_steps_name_the_view_and_the_controls():
    """'Check three things' is not an instruction if it never says where."""
    pb = PAGES["playbook.py"]
    for marker in ("**Open:**", "**Set:**", "**Do this:**"):
        assert marker in pb, f"the bulletin sequence lacks {marker}"
    assert pb.count("**Open:**") >= 5, "most steps should name their view"
    assert "Reference → **The dataset**" in pb


def test_plain_english_guide_explains_the_scores():
    pb = PAGES["playbook.py"]
    for term in ("Severity —", "Confidence —", "Presence share",
                 "Structural score", "Provisional"):
        assert term in pb, f"{term} is not explained in plain words"
    assert "No statistics assumed" in pb


def test_unclassified_is_described_as_real_money():
    pb = PAGES["playbook.py"]
    assert "not missing data" in pb.lower() or "the money is real" in pb.lower()
