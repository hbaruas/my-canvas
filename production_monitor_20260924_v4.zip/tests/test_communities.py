"""Community detection, and the honesty of what is claimed for it.

Modularity here is ~0.24 against roughly 0.3 as the floor for structure worth
interpreting. The view must say so rather than presenting a picture that looks
more conclusive than the number supports.
"""
from __future__ import annotations

from pathlib import Path

import networkx as nx
import numpy as np
import pandas as pd
import pytest

from pipeline import communities, config as cfg

pytestmark = pytest.mark.skipif(
    not (cfg.OUTPUTS / "communities.csv").exists(),
    reason="communities not built; run python -m pipeline.run --with-sic5",
)


@pytest.fixture(scope="module")
def members() -> pd.DataFrame:
    return pd.read_csv(cfg.OUTPUTS / "communities.csv", dtype={"node": str},
                       parse_dates=["period"], keep_default_na=False,
                       na_values=[""])


@pytest.fixture(scope="module")
def summary() -> pd.DataFrame:
    return pd.read_csv(cfg.OUTPUTS / "community_summary.csv",
                       parse_dates=["period"])


# --- the honesty requirement -------------------------------------------

def test_modularity_is_below_the_interpretive_floor(summary):
    """If this ever rises above 0.3 the page's framing should change too."""
    assert summary.modularity.max() < 0.30, (
        f"modularity has reached {summary.modularity.max():.3f} - the view "
        f"describes this structure as weak, which would no longer hold"
    )
    assert summary.modularity.min() > 0.15, "structure has collapsed entirely"


def test_the_view_states_modularity_on_its_face():
    src = Path("app_pages/clusters.py").read_text()
    assert "0.30" in src or "MODULARITY_FLOOR" in src
    assert "hypothesis" in src.lower(), (
        "the page must say these are a place to look, not a result"
    )


def test_sic2_was_rejected_for_being_too_dense():
    src = Path("pipeline/communities.py").read_text()
    assert "0.163" in src and "86%" in src, (
        "the reason for working at SIC5 should be recorded where someone "
        "would otherwise switch it back"
    )


# --- temporal keys ------------------------------------------------------

def test_community_keys_persist_across_periods(members):
    """Louvain numbers groups arbitrarily each run; without matching, a
    community cannot be followed through time at all."""
    per_period = members.groupby("community_key").period.nunique()
    assert (per_period > 1).sum() >= 3, (
        "almost no community spans more than one period - the Jaccard "
        "matching is not working"
    )
    assert per_period.max() == members.period.nunique(), (
        "no community persists across every period"
    )


def test_membership_is_reasonably_stable(members):
    stab = communities.stability(members)
    assert stab.retained.median() > 0.5, (
        f"median retention {stab.retained.median():.2f} - communities are "
        f"being rebuilt each year rather than persisting"
    )


def test_every_node_is_in_exactly_one_community_per_period(members):
    counts = members.groupby(["period", "node"]).size()
    assert counts.max() == 1, "a node appears in two communities in one period"


# --- determinism --------------------------------------------------------

def test_detection_is_reproducible():
    """A fixed seed, so the same data always gives the same clusters."""
    rng = np.random.default_rng(0)
    nodes = [f"{i:05d}" for i in range(60)]
    rows = []
    for i, a in enumerate(nodes):
        for b in nodes[i + 1:]:
            # two dense blocks, sparse between them
            same = (i < 30) == (nodes.index(b) < 30)
            if rng.random() < (0.6 if same else 0.05):
                rows.append({"payer": a, "payee": b,
                             "value": float(rng.integers(1, 100))})
    edges = pd.DataFrame(rows)
    first, mod_a, _ = communities.detect(edges)
    second, mod_b, _ = communities.detect(edges)
    assert mod_a == mod_b
    assert [sorted(c) for c in first] == [sorted(c) for c in second]


def test_detection_finds_planted_structure():
    """A sanity check the real data cannot give: two clear blocks."""
    rng = np.random.default_rng(1)
    rows = []
    for block in (range(0, 30), range(30, 60)):
        for a in block:
            for b in block:
                if a < b:
                    rows.append({"payer": f"{a:05d}", "payee": f"{b:05d}",
                                 "value": 100.0})
    rows.append({"payer": "00001", "payee": "00031", "value": 1.0})
    parts, mod, _ = communities.detect(pd.DataFrame(rows))
    assert len(parts) == 2, f"planted two blocks, found {len(parts)}"
    assert mod > 0.4, f"modularity {mod:.2f} on clearly separated blocks"


def test_self_loops_do_not_join_anything():
    edges = pd.DataFrame([{"payer": "00001", "payee": "00001", "value": 1e9}])
    parts, _, graph = communities.detect(edges)
    assert graph.number_of_edges() == 0


def test_unclassified_is_excluded_from_the_network(members):
    assert not members.node.str.startswith("00").any(), (
        "SIC 00 is both the largest source and sink; including it produces "
        "one giant community around it"
    )
