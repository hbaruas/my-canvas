"""Structural break detection.

The Education break is the reference case: SIC 85 falls 57% in March 2025 and
stays there, with suppressed-cell counts unchanged, so it is a classification
or coverage change rather than an economic event. Undetected, it scores z of
about -13 to -16.5 and ranks first on the alert table every month for a year.

The opposite requirement matters just as much: a shock that recovers is not a
break, or COVID would register one in almost every industry.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from pipeline.condition import adjust, detect_breaks


def _months(n: int, start: str = "2019-01-01") -> pd.DatetimeIndex:
    return pd.date_range(start, periods=n, freq="MS")


def test_permanent_level_shift_is_detected():
    idx = _months(72)
    values = np.r_[np.full(36, 1000.0), np.full(36, 450.0)]
    s = pd.Series(values, index=idx)
    breaks = detect_breaks(s)
    assert len(breaks) == 1
    assert breaks[0]["break_month"] == idx[36]
    assert breaks[0]["level_change_pct"] < -0.5


def test_break_month_is_the_first_month_of_the_new_regime():
    """A two-step fall must report the first step, not the second.

    Education steps 4581 -> 2790 -> 2145; the break is March, not April.
    """
    idx = _months(72)
    values = np.r_[np.full(36, 1000.0), [600.0], np.full(35, 450.0)]
    s = pd.Series(values, index=idx)
    breaks = detect_breaks(s)
    assert breaks[0]["break_month"] == idx[36], "should report the first step down"


def test_a_shock_that_recovers_is_not_a_break():
    idx = _months(72)
    values = np.full(72, 1000.0)
    values[30:36] = 300.0                      # deep dip, then full recovery
    s = pd.Series(values, index=idx)
    assert detect_breaks(s) == []


def test_gentle_trend_is_not_a_break():
    idx = _months(72)
    s = pd.Series(np.linspace(1000, 1400, 72), index=idx)
    assert detect_breaks(s) == []


def test_noise_alone_produces_no_breaks():
    rng = np.random.default_rng(0)
    idx = _months(72)
    s = pd.Series(1000 * np.exp(rng.normal(0, 0.05, 72)), index=idx)
    assert detect_breaks(s) == []


def test_seasonal_adjustment_removes_an_annual_cycle():
    idx = _months(96)
    seasonal = 200 * np.sin(np.arange(96) * 2 * np.pi / 12)
    s = pd.Series(1000 + seasonal, index=idx)
    out = adjust(s)
    # The seasonally adjusted series should be far flatter than the raw one.
    assert out.sa.std() < s.std() / 5


def test_gaps_survive_seasonal_adjustment_as_gaps():
    """Suppressed months are null and must not be filled in the output."""
    idx = _months(96)
    s = pd.Series(1000.0, index=idx)
    s.iloc[40:43] = np.nan
    out = adjust(s)
    assert out.sa.iloc[40:43].isna().all(), "interpolation must not leak into output"
