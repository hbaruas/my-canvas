"""Three-way change attribution.

The requirement is exactness: contributions must sum to the actual change with
no residual. A decomposition that differences only the counterparties present
in both months loses everything that appeared or disappeared - which on real
data was 99% of one industry's movement.
"""
from __future__ import annotations

import pandas as pd
import pytest

from pipeline import config as cfg
from pipeline.decompose import ABSENT, CONTINUING, NEWLY_PRESENT, decompose, summarise

NOW = pd.Timestamp("2026-06-01")
BASE = pd.Timestamp("2025-06-01")


def _edges(rows) -> pd.DataFrame:
    return pd.DataFrame([
        {"payer": p, "payee": q, "payer_region": None, "payee_region": None,
         "month": m, "value": v, "n_tx": 1.0, "suppressed_type": None,
         "grain": cfg.LEVEL_SIC2}
        for p, q, m, v in rows
    ])


@pytest.fixture
def mixed() -> pd.DataFrame:
    """One continuing counterparty, one that appears, one that vanishes."""
    return _edges([
        ("A", "29", BASE, 100.0), ("A", "29", NOW, 130.0),   # continuing +30
        ("B", "29", BASE, 200.0),                             # vanishes    -200
        ("C", "29", NOW, 50.0),                               # appears      +50
    ])


def test_contributions_sum_to_the_actual_change(mixed):
    rows = decompose(mixed, "29", NOW, BASE)
    actual = (mixed[(mixed.payee == "29") & (mixed.month == NOW)].value.sum()
              - mixed[(mixed.payee == "29") & (mixed.month == BASE)].value.sum())
    assert rows.contribution.sum() == pytest.approx(actual)
    assert rows.contribution.sum() == pytest.approx(-120.0)


def test_categories_are_assigned_correctly(mixed):
    rows = decompose(mixed, "29", NOW, BASE).set_index("counterparty")
    assert rows.loc["A", "category"] == CONTINUING
    assert rows.loc["B", "category"] == ABSENT
    assert rows.loc["C", "category"] == NEWLY_PRESENT
    assert rows.loc["B", "contribution"] == pytest.approx(-200.0)


def test_presence_share_measures_appearance_and_disappearance(mixed):
    s = summarise(decompose(mixed, "29", NOW, BASE))
    # -200 vanished, +50 appeared => net -150 of a -120 total change.
    assert s["presence_share"] == pytest.approx(150 / 120)
    assert s["continuing"] == pytest.approx(30.0)


def test_a_vanishing_counterparty_is_not_invisible():
    """The failure mode this module exists to prevent.

    A naive decomposition differences only the counterparties present in both
    months, and would report no change at all here.
    """
    edges = _edges([
        ("A", "29", BASE, 100.0), ("A", "29", NOW, 100.0),   # unchanged
        ("B", "29", BASE, 900.0),                             # vanishes
    ])
    s = summarise(decompose(edges, "29", NOW, BASE))
    assert s["continuing"] == pytest.approx(0.0)
    assert s["total_change"] == pytest.approx(-900.0)
    assert s["presence_share"] == pytest.approx(1.0)
    assert s["top_counterparty"] == "B"


def test_self_and_unclassified_are_flagged_not_dropped():
    edges = _edges([
        ("29", "29", BASE, 100.0), ("29", "29", NOW, 150.0),
        (cfg.UNCLASSIFIED_SIC, "29", BASE, 400.0),
        (cfg.UNCLASSIFIED_SIC, "29", NOW, 300.0),
    ])
    rows = decompose(edges, "29", NOW, BASE).set_index("counterparty")
    assert rows.loc["29", "is_self"]
    assert rows.loc[cfg.UNCLASSIFIED_SIC, "is_unclassified"]
    assert rows.contribution.sum() == pytest.approx(-50.0)


def test_outflow_side_uses_the_other_direction():
    edges = _edges([("29", "A", BASE, 100.0), ("29", "A", NOW, 175.0)])
    rows = decompose(edges, "29", NOW, BASE, side="out")
    assert rows.iloc[0].counterparty == "A"
    assert rows.contribution.sum() == pytest.approx(75.0)
