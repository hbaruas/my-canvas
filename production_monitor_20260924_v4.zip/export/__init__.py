"""Self-contained HTML export."""
from .report import Block, capture, clear, collected, render  # noqa: F401
