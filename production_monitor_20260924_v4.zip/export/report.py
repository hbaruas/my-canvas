"""Turn what is on screen into a self-contained HTML file.

One renderer, two entry points: the current view, and a standard monthly
briefing. Both produce a single file with no external references at all -
plotly.js is embedded rather than linked, because an ONS machine may have no
route to a CDN and a chart that renders as a blank box on the recipient's
screen is worse than a large attachment.
"""
from __future__ import annotations

import base64
import datetime as dt
import html
from dataclasses import dataclass, field
from typing import Any

import pandas as pd
import plotly.graph_objects as go
import plotly.io as pio
import streamlit as st

_KEY = "_export_blocks"


@dataclass
class Block:
    kind: str                      # heading | text | figure | table | note
    payload: Any = None
    caption: str = ""
    extra: dict = field(default_factory=dict)


# ----------------------------------------------------------------------
# collection - views append as they render
# ----------------------------------------------------------------------
def clear() -> None:
    st.session_state[_KEY] = []


def capture(block: Block) -> None:
    st.session_state.setdefault(_KEY, []).append(block)


def collected() -> list[Block]:
    return list(st.session_state.get(_KEY, []))


def heading(text: str) -> None:
    capture(Block("heading", text))


def text(md: str) -> None:
    capture(Block("text", md))


def note(md: str, tone: str = "info") -> None:
    capture(Block("note", md, extra={"tone": tone}))


def figure(fig: go.Figure, caption: str = "") -> None:
    capture(Block("figure", fig, caption))


def table(df: pd.DataFrame, caption: str = "") -> None:
    capture(Block("table", df, caption))


# ----------------------------------------------------------------------
# rendering
# ----------------------------------------------------------------------
_CSS = """
:root{
  --surface:#fcfcfb; --plane:#f9f9f7; --ink:#0b0b0b; --ink2:#52514e;
  --muted:#898781; --grid:#e1e0d9; --rule:#c3c2b7;
  --warn-bg:#fdf3e0; --warn-br:#fab219; --bad-bg:#fbeeee; --bad-br:#d03b3b;
}
@media (prefers-color-scheme: dark){
  :root:not([data-theme="light"]){
    --surface:#1a1a19; --plane:#0d0d0d; --ink:#ffffff; --ink2:#c3c2b7;
    --muted:#898781; --grid:#2c2c2a; --rule:#383835;
    --warn-bg:#2a2410; --warn-br:#fab219; --bad-bg:#2c1414; --bad-br:#e66767;
  }
}
*{box-sizing:border-box}
body{margin:0;background:var(--plane);color:var(--ink);
  font:15px/1.55 system-ui,-apple-system,"Segoe UI",sans-serif;}
.wrap{max-width:1100px;margin:0 auto;padding:32px 20px 64px;}
header{border-bottom:2px solid var(--rule);padding-bottom:16px;margin-bottom:8px}
h1{font-size:26px;margin:0 0 6px;letter-spacing:-0.01em}
h2{font-size:19px;margin:34px 0 10px;padding-top:18px;border-top:1px solid var(--grid)}
h2:first-of-type{border-top:0;padding-top:0}
.meta{color:var(--muted);font-size:13px;line-height:1.7}
.meta b{color:var(--ink2);font-weight:600}
.card{background:var(--surface);border:1px solid var(--grid);border-radius:10px;
  padding:14px;margin:14px 0}
.cap{color:var(--muted);font-size:13px;margin:8px 2px 0}
.note{border-left:3px solid var(--rule);background:var(--surface);
  padding:10px 14px;margin:14px 0;border-radius:0 8px 8px 0;font-size:14px}
.note.warn{border-color:var(--warn-br);background:var(--warn-bg)}
.note.bad{border-color:var(--bad-br);background:var(--bad-bg)}
table{border-collapse:collapse;width:100%;font-size:13.5px}
th,td{text-align:left;padding:7px 10px;border-bottom:1px solid var(--grid)}
th{color:var(--ink2);font-weight:600;white-space:nowrap}
td:nth-child(n+2){font-variant-numeric:tabular-nums}
tbody tr:last-child td{border-bottom:0}
.scroll{overflow-x:auto}
footer{margin-top:44px;padding-top:14px;border-top:1px solid var(--grid);
  color:var(--muted);font-size:12.5px}
@media print{body{background:#fff}.card{break-inside:avoid}}
"""


def _table_html(df: pd.DataFrame) -> str:
    head = "".join(f"<th>{html.escape(str(c))}</th>" for c in df.columns)
    rows = []
    for _, r in df.iterrows():
        cells = "".join(f"<td>{html.escape('' if pd.isna(v) else str(v))}</td>"
                        for v in r)
        rows.append(f"<tr>{cells}</tr>")
    return (f'<div class="scroll"><table><thead><tr>{head}</tr></thead>'
            f'<tbody>{"".join(rows)}</tbody></table></div>')


def render(title: str, blocks: list[Block], meta: dict) -> str:
    """Assemble one self-contained HTML document."""
    parts: list[str] = []
    first_figure = True
    for b in blocks:
        if b.kind == "heading":
            parts.append(f"<h2>{html.escape(str(b.payload))}</h2>")
        elif b.kind == "text":
            parts.append(f"<p>{b.payload}</p>")
        elif b.kind == "note":
            tone = b.extra.get("tone", "info")
            cls = {"warning": "warn", "error": "bad"}.get(tone, "")
            parts.append(f'<div class="note {cls}">{b.payload}</div>')
        elif b.kind == "figure":
            # plotly.js is inlined ONCE; later figures reference the same
            # bundle. Linking a CDN would leave a blank box on a machine with
            # no outbound route.
            frag = pio.to_html(b.payload, include_plotlyjs=first_figure,
                               full_html=False, config={"displayModeBar": False},
                               default_width="100%")
            first_figure = False
            cap = f'<div class="cap">{b.caption}</div>' if b.caption else ""
            parts.append(f'<div class="card">{frag}{cap}</div>')
        elif b.kind == "table":
            cap = f'<div class="cap">{b.caption}</div>' if b.caption else ""
            parts.append(f'<div class="card">{_table_html(b.payload)}{cap}</div>')

    generated = dt.datetime.now().strftime("%d %B %Y, %H:%M")
    meta_rows = "<br>".join(
        f"<b>{html.escape(k)}:</b> {html.escape(str(v))}" for k, v in meta.items())

    return f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{html.escape(title)}</title><style>{_CSS}</style></head>
<body><div class="wrap">
<header>
  <h1>{html.escape(title)}</h1>
  <div class="meta">{meta_rows}<br><b>Generated:</b> {generated}</div>
</header>
{"".join(parts)}
<footer>
  Derived from UK industry-to-industry payment flows (Pay.UK, Vocalink, ONS),
  official statistics in development. Figures are unweighted sample totals and
  are not official statistics.<br>
  <b>Handling:</b> check disclosure control before circulating outside the
  project team - combining SIC5 detail with SIC2 aggregates can allow
  suppressed cells to be recovered by differencing.
</footer>
</div></body></html>"""
