"""The monthly briefing: one click, the standard set.

Headline, what changed and why, the ranked movers, the largest single
decomposition, and the data-quality caveats that decide how much of it to
believe. Assembled from the same outputs the app reads, so nothing in a
briefing is unreproducible.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.graph_objects as go

from app_pages import movers as movers_view
from app_pages import theme

from .report import Block, render

MEASURE = "pfi"
BASIS = "YoY"


def _headline_blocks(panel, quality, month) -> list[Block]:
    q = quality[quality.month == month].iloc[0]
    prev = quality[quality.month == month - pd.DateOffset(months=1)]
    yr = quality[quality.month == month - pd.DateOffset(months=12)]
    mom = (q.classified_value / prev.classified_value.iloc[0] - 1) if len(prev) else np.nan
    yoy = (q.classified_value / yr.classified_value.iloc[0] - 1) if len(yr) else np.nan

    rows = pd.DataFrame([
        {"Measure": "Classified B2B flow", "Value": theme.money(q.classified_value)},
        {"Measure": "Change on previous month",
         "Value": f"{mom:+.1%}" if np.isfinite(mom) else "n/a"},
        {"Measure": "Change on a year earlier",
         "Value": f"{yoy:+.1%}" if np.isfinite(yoy) else "n/a"},
        {"Measure": "Value involving an unclassified counterparty",
         "Value": f"{q.share_unclassified:.0%}"},
        {"Measure": "Cells suppressed for disclosure",
         "Value": f"{q.share_cells_suppressed:.0%}"},
    ])
    blocks = [Block("heading", "Headline"), Block("table", rows)]
    if bool(q.get("volume_outlier", False)):
        blocks.append(Block(
            "note",
            f"<b>{month:%B %Y} looks incomplete.</b> "
            f"{q.n_tx/1e6:,.0f}m transactions against a neighbouring median of "
            f"{q.n_tx/q.volume_vs_neighbours/1e6:,.0f}m. Treat every comparison "
            f"involving this month with caution.",
            extra={"tone": "error"}))
    return blocks


def _systemic_note(alerts, month) -> list[Block]:
    sel = alerts[(alerts.month == month) & (alerts.measure == MEASURE)
                 & (alerts.basis == BASIS) & (alerts.level == "division")]
    if not len(sel) or "common_pct" not in sel:
        return []
    common = sel.common_pct.dropna()
    if not len(common) or abs(common.iloc[0]) < 0.20:
        return []
    return [Block(
        "note",
        f"<b>Every industry moved together this month</b> "
        f"({common.iloc[0]:+.0%} for the typical industry). That is usually a "
        f"data event rather than many separate economic shocks. Rankings below "
        f"are measured against the typical industry, not in absolute terms.",
        extra={"tone": "error"})]


def _what_changed(alerts, month) -> list[Block]:
    sel = alerts[(alerts.month == month) & (alerts.measure == MEASURE)
                 & (alerts.basis == BASIS) & (alerts.level == "division")
                 & (alerts.driver_line.astype(str).str.len() > 3)]
    if not len(sel):
        return []
    out = [Block("heading", "What changed this month")]
    for r in sel.nlargest(4, "severity").itertuples():
        tag = {"low": ' <span style="color:#d03b3b">(low confidence)</span>',
               "medium": ' <span style="color:#b8860b">(medium confidence)</span>'}\
            .get(r.confidence, "")
        out.append(Block("text", f"{r.driver_line}{tag}"))
    return out


def _movers_blocks(panel, alerts, month) -> list[Block]:
    changes = movers_view._changes(panel, "sic2", MEASURE, month, 12)
    changes = changes[changes.index != "00"]
    if changes.empty:
        return []
    names = dict(zip(panel.sic2, panel["name"]))
    labels = {k: f"{k} {v}" for k, v in names.items()}
    fig = movers_view._bar(changes, labels, 12)

    scored = alerts[(alerts.month == month) & (alerts.measure == MEASURE)
                    & (alerts.basis == BASIS) & (alerts.level == "division")] \
        .drop_duplicates(subset="code").set_index("code")
    order = pd.DataFrame({"delta": changes.delta.abs()})
    order["severity"] = scored.severity.reindex(order.index)
    tbl = changes.loc[order.sort_values(["severity", "delta"], ascending=False,
                                        na_position="last").index].head(12)
    rows = []
    for code, r in tbl.iterrows():
        a = scored.loc[code] if code in scored.index else None
        rows.append({
            "Industry": labels.get(code, code),
            "Change": theme.money(r.delta),
            "%": f"{r.pct:+.1%}" if np.isfinite(r.pct) else "n/a",
            "Unusual?": "n/a" if a is None or not np.isfinite(a.severity)
                        else f"{a.severity:.0f}",
            "Confidence": "-" if a is None else str(a.confidence),
            "Why": "" if a is None or not isinstance(a.confidence_reason, str)
                   else a.confidence_reason,
        })
    return [
        Block("heading", f"Movers - PFI, year-on-year, {month:%B %Y}"),
        Block("figure", fig, "Change in payment throughput against the same "
                             "month a year earlier. Classified flows only."),
        Block("table", pd.DataFrame(rows),
              "Ranked by how unusual the move is, then by size. "
              "<b>Unusual?</b> is 0-100 against the industry's own history "
              "after removing what every industry did that month. "
              "<b>Confidence</b> is a separate checklist of known ways these "
              "numbers move without money changing hands differently - a "
              "partner appearing or vanishing from the published data, a "
              "reclassification, or a month when every industry moved "
              "together. It is never blended into the severity score."),
    ]


def _quality_blocks(quality, breaks, stability) -> list[Block]:
    out = [Block("heading", "How far to trust this")]
    idio = breaks[breaks.likely.astype(str).str.startswith("idio")] \
        if len(breaks) else breaks
    if len(idio):
        t = idio.assign(
            Industry=idio.sic2 + " " + idio["industry"],
            Month=pd.to_datetime(idio.break_month).dt.strftime("%b %Y"),
            Change=(idio.level_change_pct * 100).round(0).astype(int).astype(str) + "%",
        )[["Industry", "Month", "Change", "break_cause"]]
        t.columns = ["Industry", "Break", "Change", "Cause"]
        out.append(Block("table", t,
                         "Industry-specific structural breaks. A "
                         "<b>reclassification</b> moves money between SIC 00 and a "
                         "real industry with nothing economic happening; a "
                         "<b>suppression-driven</b> break is a counterparty that "
                         "stopped being reported. Neither is an economic event."))
    if len(stability):
        s = stability.head(6).assign(
            Relationship=stability.head(6).payer + " → " + stability.head(6).payee,
            Present=stability.head(6).months_present.astype(int),
            Absent=stability.head(6).months_absent.astype(int),
            Typical=stability.head(6).mean_value_when_present.map(theme.money),
        )[["Relationship", "Present", "Absent", "Typical"]]
        out.append(Block("table", s,
                         "Counterparty relationships that move in and out of "
                         "disclosure suppression, months present against absent "
                         "out of 90. A large intermittent cell can make an "
                         "industry look as though it collapsed."))
    return out


def build(panel, alerts, quality, breaks, stability, month, vintage: str) -> str:
    """Assemble the monthly briefing as one self-contained HTML document."""
    blocks: list[Block] = []
    blocks += _headline_blocks(panel, quality, month)
    blocks += _systemic_note(alerts, month)
    blocks += _what_changed(alerts, month)
    blocks += _movers_blocks(panel, alerts, month)
    blocks += _quality_blocks(quality, breaks, stability)
    return render(
        f"Production Monitor - {month:%B %Y}",
        blocks,
        {"Source": "Pay.UK / Vocalink industry-to-industry payments",
         "Data release": vintage,
         "Latest month": f"{month:%B %Y}",
         "Sensitivity": "Internal - see handling note"},
    )
