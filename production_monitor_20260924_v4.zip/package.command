#!/usr/bin/env bash
# Build a transferable zip of this project (excludes the environment).
cd "$(dirname "$0")" || exit 1
NAME="production_monitor_$(date +%Y%m%d)"
OUT="dist/${NAME}.zip"
mkdir -p dist
echo "Packaging -> $OUT"
echo "(excluding .venv, outputs and the SIC5 file - all rebuilt or unused)"
zip -r "$OUT" . \
    -x '.venv/*' 'outputs/*' 'dist/*' '__pycache__/*' '*/__pycache__/*' \
       '*.pyc' '.DS_Store' '*/.DS_Store' '.git/*' 'Data/*sic5*' \
    >/dev/null
echo
echo "Created $OUT  ($(du -h "$OUT" | cut -f1))"
echo "Copy it across, unzip, then run install then run."
read -r -p "Press Return to close."
