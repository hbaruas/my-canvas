Industry-to-industry payment flows, SIC5, UK
/Users/saurabhkumar/Desktop/I21_VOCALINK/Data/2607_sic5.csv

This monthly, five-digit Standard Industrial Classification (SIC) level dataset provides the number and value of transactions flowing between UK organisations. These are official statistics in development. Source: Pay.UK and Vocalink.

Industry-to-industry payment flows, SIC2, UK
/Users/saurabhkumar/Desktop/I21_VOCALINK/Data/industrybusinesspaymentssic2dataset16072026.xlsx

This monthly, two-digit Standard Industrial Classification (SIC) level dataset provides the number and value of transactions flowing between UK organisations. These are official statistics in development. Source: Pay.UK and Vocalink



Industry-to-industry payment flows by region, UK
/Users/saurabhkumar/Desktop/I21_VOCALINK/Data/2607_sic2region_2025_2026.csv

This monthly 2-digit Standard Industrial Classification (SIC) level by International Territorial Level (ITL1) regional dataset provides the number and value of transactions flowing between UK organisations. These are official statistics in development. Source: Pay.UK and Vocalink.



Meeting Notes:

Project Goals and Analytical Focus: Matthew, Andrew, and Saurabh clarified the dual project goals of developing a reactive system for detecting short-term economic shocks and a framework for analysing long-term trends, agreeing that the primary initial focus should be on identifying granular industry shocks using payment data.

Clarification of Project Goals: Matthew outlined two main objectives: creating a system to detect short-term economic shocks (using examples like Jaguar Land Rover and major sporting events) and analysing long-term economic trends, with Andrew and Saurabh confirming alignment on these aims.

Granular Industry Shock Detection: Andrew emphasised that the primary function at this stage should be to let the data reveal unexpected industry shocks, both positive and negative, rather than relying on preconceived narratives, and that this approach would provide the most immediate value.

Timing and Data Limitations: Andrew and Saurabh discussed the limitations of payment data, such as the lack of clarity on whether payments are for finished goods or materials and the timing of payments, noting that these factors must be considered before using the data for GDP nowcasting.

Actionable Next Steps: The team agreed that the initial development should focus on building a dashboard to flag anomalous industry activity, with Saurabh tasked to begin work on this 'production monitor' as the first step, while keeping options open for more complex analyses in the future.

Data Structure, Analytical Value, and Limitations: Saurabh presented an overview of the payment dataset, highlighting its structure, analytical strengths for early economic signal detection, and key limitations such as regional attribution issues and the headquarter effect, with input from Matthew and Andrew on potential improvements.

Dataset Overview and Coverage: Saurabh described the dataset as comprising over 47 million rows of business-to-business payments from January 2019 to December 2025, covering 88 SIC-2 industries and 12 ITL-1 regions, with monthly updates and a significant portion of payment value lacking resolvable regional attribution.

Analytical Value and Timeliness: The team discussed the Payment Flow Index (PFI) as a timely economic indicator, available within days of month-end and capable of tracking major macroeconomic trends, providing a significant lead over official GDP statistics.

Regional Attribution and Headquarter Effect: Saurabh and Andrew noted that a large share of payment flows are attributed to company headquarters, especially in London, which distorts regional analysis and necessitates sector-level or more granular approaches for reliable economic signals.

Industry Network and Validation: The payment-derived network structure was shown to closely mirror official ONS input-output tables, validating the use of transaction data for mapping supply chain relationships and identifying key industry hubs such as wholesale trade and financial services.

Granularity and Anomaly Detection: Saurabh demonstrated that economic shocks, such as the September 2025 motor vehicle manufacturing collapse, are only detectable at granular SIC-2 or SIC-5 levels, with aggregation to broader industry sections masking these signals.

Regional Attribution Limitations and Potential Solutions: The team discussed the challenge of 52% of payment value being unresolvable to a specific region, with suggestions to use VAT or PAYE data to improve attribution, and Matthew noting ongoing work by Joseph to enhance matching over time.

Strategic Development Paths and Prioritisation: Saurabh outlined three potential development paths—production monitoring, GDP nowcasting, and supply chain stress testing—with the group agreeing to prioritise the production monitor dashboard for quick wins, while keeping more complex options open for future work.

Overview of Development Paths: Saurabh proposed three development options: (A) an automated dashboard for anomaly detection at the SIC-2 level, (B) a composite GDP nowcast indicator combining payment and VAT data, and (C) a supply chain stress test model using network analysis at the SIC-5 level.

Team Discussion and Prioritisation: Andrew and Matthew agreed that the production monitor (Path A) should be the immediate focus due to its feasibility and potential for rapid, actionable insights, while acknowledging the value of exploring Paths B and C in the longer term.

Action Items and Next Steps: Saurabh confirmed they would begin work on the production monitor dashboard, with Andrew and Matthew supporting this direction and suggesting that more advanced modelling could follow once the initial system is in place.

Strategic Questions and Integration with Other Indicators: The team addressed key strategic questions regarding the primary analytical goal, regional focus, publication appetite, and integration with other economic indicators, agreeing to focus on industry-level analysis and consider payment flows as a complementary flash indicator.

Primary Analytical Focus: The group agreed that the initial focus should be on monitoring granular industry shocks, with the potential to expand to GDP nowcasting as data limitations are addressed and analytical methods mature.

Regional Versus Industry Focus: Andrew advised deprioritising regional analysis due to attribution challenges, suggesting that industry-level analysis based on GVA weights is more actionable, and recommending consultation with other experts for specific industry needs.

Publication and Use of Experimental Statistics: Saurabh raised the question of publishing experimental statistics from the payment data, with Andrew suggesting that immediate dashboard outputs could inform monthly publications and provide supporting evidence for official GDP releases.

Integration with Other Indicators: The team discussed the high correlation between payment flows and the seven-day VAT diffusion index, agreeing that payment data could serve as a valuable flash indicator alongside existing measures, while dismissing the relevance of CHAPS data.

Future Collaboration and Related Analytical Work: Andrew, Matthew, and Saurabh discussed potential synergies with other teams and data sources, including linking payment data with weather-related analyses and ongoing work by colleagues such as Joseph and Keith, to enhance the robustness and applicability of their outputs.

Cross-Team Collaboration Opportunities: The team noted ongoing and potential collaborations with colleagues working on regional attribution improvements and weather-related economic analysis, highlighting the value of integrating payment data with other research efforts.

Follow-up tasks:

Dashboard Development for Industry Shock Detection: Build an automated monthly dashboard to flag industry anomalies at the SIG2 level using Z score anomaly detection, focusing initially on granular industry shocks as a quick win. (Saurabh)

Integration of Payment Flow Data with Other Indicators: Investigate further how the correlation between payment flow data and the seven-day flash estimate can be utilised to enhance economic analysis and indicator development. (Saurabh)

Industry Focus for Dashboard Analysis: Consult with Katherine Chant to determine which industries should be prioritised for dashboard analysis based on GVA weights and revision patterns. (Andrew)

Exploration of Construction Sector and Weather Linkages: Explore linking construction industry payment data with weather-related indicators to identify potential synergies for economic analysis. (Matthew)