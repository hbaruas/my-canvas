@echo off
REM Find a TCP port Windows will actually let this tool listen on, and record
REM it in port.txt so run.bat and run-full.bat use it from then on.
REM
REM Why this is needed: Streamlit's default 8501 can fail with
REM     PermissionError: [WinError 10013]
REM That is NOT "the port is busy". Windows reserves whole TCP ranges for
REM Hyper-V, WSL and Docker, and refuses anything inside them even when
REM nothing is listening. Corporate security software reserves ranges too.
REM Nothing in the error says which range, so trying ports is the quick way.
cd /d "%~dp0"
setlocal

echo ===============================================
echo  Finding a usable port
echo ===============================================
call "%~dp0_env.bat"
if not exist "%PY%" (
    echo.
    echo ERROR: the environment is not installed. Run install.bat first.
    echo.
    pause
    exit /b 1
)

echo.
echo Ranges Windows has reserved on this machine:
echo ^(anything inside these is refused, whether or not it is in use^)
netsh interface ipv4 show excludedportrange protocol=tcp

echo.
echo Testing candidate ports ...
"%PY%" "%~dp0scripts\find_port.py"
set "RC=%ERRORLEVEL%"

echo.
if "%RC%"=="0" (
    echo ===============================================
    echo  Done. The port above is written to port.txt.
    echo  Now run  run.bat
    echo ===============================================
) else (
    echo ===============================================
    echo  No candidate port worked.
    echo  Show the output above to whoever supports this machine -
    echo  outbound local ports may be blocked by policy.
    echo ===============================================
)
echo.
pause
