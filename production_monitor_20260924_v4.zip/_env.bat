@echo off
REM ---------------------------------------------------------------------------
REM Shared environment resolver. install.bat, run.bat and run-full.bat all call
REM this, so "which Python" and "which venv" are decided in one place.
REM
REM Sets, for the caller:
REM     PYTHON_EXE   the interpreter that CREATES the venv
REM     ENV_DIR      where the venv lives
REM     PY           the venv's python.exe - what everything actually runs with
REM
REM WHY THIS LOOKS SO PLAIN
REM An earlier version tested each candidate with
REM     python -c "... (3,10)<=sys.version_info[:2]<=(3,12) ..."
REM That silently failed on every machine. "<" is a redirection operator in
REM cmd.exe, and "call :label" RE-PARSES its line, so the quotes that should
REM have protected it no longer did. Every candidate was rejected, including
REM correct ones, and the script reported "no suitable Python found".
REM
REM So: no "<", no ">", no parentheses and no commas are passed to a candidate.
REM The version comes from "python -V" written to a temp file and compared as
REM plain text. Every candidate checked is printed, so a failure says which
REM paths were tried and what each one reported.
REM ---------------------------------------------------------------------------

REM --- 1. where the venv lives ------------------------------------------
REM Default is inside this folder, so the project stays self-contained and
REM travels in the zip. Override with PRODMON_VENV, or venv_path.txt beside
REM this file, if your site keeps environments centrally.
set "ENV_DIR=%~dp0.venv"
if defined PRODMON_VENV set "ENV_DIR=%PRODMON_VENV%"
if exist "%~dp0venv_path.txt" (
    for /f "usebackq delims=" %%L in ("%~dp0venv_path.txt") do (
        if not "%%L"=="" set "ENV_DIR=%%~L"
    )
)

REM --- 2. which interpreter creates it ----------------------------------
set "PYTHON_EXE="
set "_PMVER="
if "%PM_QUIET%"=="" echo Looking for Python 3.10, 3.11 or 3.12 ...

REM (a) passed in on the command line
if not "%~1"=="" call :try "%~1"

REM (b) environment variable
if not defined PYTHON_EXE if defined PRODMON_PYTHON call :try "%PRODMON_PYTHON%"

REM (c) python_path.txt beside this file - set once, then just double-click
if not defined PYTHON_EXE if exist "%~dp0python_path.txt" (
    for /f "usebackq delims=" %%L in ("%~dp0python_path.txt") do (
        if not defined PYTHON_EXE if not "%%L"=="" call :try "%%~L"
    )
)

REM (d) managed install locations. Add your own root here if it differs.
if not defined PYTHON_EXE call :scan "C:\ONSapps\My_Python"
if not defined PYTHON_EXE call :scan "%LOCALAPPDATA%\Programs\Python"
if not defined PYTHON_EXE call :scan "C:\Python"
if not defined PYTHON_EXE call :scan "C:\Program Files\Python"

REM (e) the py launcher
if not defined PYTHON_EXE call :try_py 3.12
if not defined PYTHON_EXE call :try_py 3.11
if not defined PYTHON_EXE call :try_py 3.10

REM (f) a bare python on PATH
if not defined PYTHON_EXE call :try "python"

set "PY=%ENV_DIR%\Scripts\python.exe"
exit /b 0


REM --- scan one root for the usual folder spellings ----------------------
:scan
if not exist "%~1" exit /b 0
if not defined PYTHON_EXE call :try "%~1\Python_3_12\python.exe"
if not defined PYTHON_EXE call :try "%~1\Python_3_11\python.exe"
if not defined PYTHON_EXE call :try "%~1\Python_3_10\python.exe"
if not defined PYTHON_EXE call :try "%~1\Python312\python.exe"
if not defined PYTHON_EXE call :try "%~1\Python311\python.exe"
if not defined PYTHON_EXE call :try "%~1\Python310\python.exe"
if not defined PYTHON_EXE call :try "%~1\3.12\python.exe"
if not defined PYTHON_EXE call :try "%~1\3.11\python.exe"
if not defined PYTHON_EXE call :try "%~1\3.10\python.exe"
exit /b 0


REM --- test one candidate ------------------------------------------------
REM Nothing clever is passed to it: just  -V  , which every Python supports.
:try
if "%~1"=="" exit /b 0
if /i not "%~1"=="python" if not exist "%~1" exit /b 0
set "_PMVER="
del "%TEMP%\pm_pyver.txt" >nul 2>&1
"%~1" -V > "%TEMP%\pm_pyver.txt" 2>&1
if not exist "%TEMP%\pm_pyver.txt" exit /b 0
for /f "usebackq tokens=2" %%A in ("%TEMP%\pm_pyver.txt") do set "_PMVER=%%A"
del "%TEMP%\pm_pyver.txt" >nul 2>&1
if not defined _PMVER exit /b 0
call :accept "%~1"
exit /b 0


REM --- the py launcher ---------------------------------------------------
:try_py
set "_PMVER="
del "%TEMP%\pm_pyver.txt" >nul 2>&1
py -%1 -V > "%TEMP%\pm_pyver.txt" 2>&1
if not exist "%TEMP%\pm_pyver.txt" exit /b 0
for /f "usebackq tokens=2" %%A in ("%TEMP%\pm_pyver.txt") do set "_PMVER=%%A"
del "%TEMP%\pm_pyver.txt" >nul 2>&1
if not defined _PMVER exit /b 0
REM Resolve the launcher to a real path so everything downstream is a path.
REM Via a temp file again, for the same reason: no parentheses, no nested
REM quoting, nothing for cmd.exe to re-read the wrong way.
set "_PMPATH="
del "%TEMP%\pm_pypath.txt" >nul 2>&1
py -%1 -c "import sys;sys.stdout.write(sys.executable)" > "%TEMP%\pm_pypath.txt" 2>nul
if exist "%TEMP%\pm_pypath.txt" (
    for /f "usebackq delims=" %%P in ("%TEMP%\pm_pypath.txt") do set "_PMPATH=%%P"
    del "%TEMP%\pm_pypath.txt" >nul 2>&1
)
if not defined _PMPATH set "_PMPATH=py -%1"
call :accept "%_PMPATH%"
exit /b 0


REM --- accept it only if the version string starts 3.10 / 3.11 / 3.12 ----
:accept
set "_PMOK="
if "%_PMVER:~0,5%"=="3.10." set "_PMOK=1"
if "%_PMVER:~0,5%"=="3.11." set "_PMOK=1"
if "%_PMVER:~0,5%"=="3.12." set "_PMOK=1"
if "%_PMVER%"=="3.10" set "_PMOK=1"
if "%_PMVER%"=="3.11" set "_PMOK=1"
if "%_PMVER%"=="3.12" set "_PMOK=1"
if defined _PMOK (
    if "%PM_QUIET%"=="" echo    [use] %~1  -  Python %_PMVER%
    set "PYTHON_EXE=%~1"
) else (
    if "%PM_QUIET%"=="" echo    [skip] %~1  -  Python %_PMVER%  ^(need 3.10-3.12^)
)
exit /b 0
