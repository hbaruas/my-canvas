# VocaLink B2B Payments — Production Monitor
## Data findings and implementation plan

Status: **planning only, nothing built yet.**
Prepared: 15 September 2026 · Owner: Saurabh · Stakeholder: Andrew · Sponsor: Matthew

---

## 1. What we agreed in the meeting

| | |
|---|---|
| **Primary goal** | A reactive system that detects short-term economic shocks at granular industry level, letting the data reveal surprises rather than testing preconceived narratives (Andrew). |
| **Secondary goal** | A framework for long-term structural trend analysis. |
| **Immediate deliverable** | Path A — "Production Monitor": automated monthly dashboard flagging SIC-2 industry anomalies via z-score detection. |
| **Parked** | Path B (GDP nowcast w/ VAT), Path C (SIC-5 supply-chain stress test). Revisit once A is live. |
| **Deprioritised** | Regional analysis — attribution unreliable (Andrew). |
| **Framing for outputs** | Flash/complementary indicator feeding monthly publications and supporting evidence for GDP releases — not a competing estimate. |

---

## 2. What the data actually contains

Profiled all three files in `Data/`. Headline numbers differ from those quoted in the meeting, and four findings change the design.

### 2.1 Coverage (updated)

| Source | Grain | Period | Rows | Suppressed cells |
|---|---|---|---|---|
| `industrybusinesspaymentssic2dataset16072026.xlsx` | SIC2 × SIC2 × month | **Jan 2019 – Jun 2026 (90 months)** | 682,809 | **18.7%** |
| `2607_sic5.csv` | SIC5 × SIC5 × month | Jan 2019 – Jun 2026 | 26.96m | **65.3%** |
| `2607_sic2region_2025_2026.csv` | SIC2 × ITL1 × SIC2 × ITL1 × month | **Jan 2025 – Jun 2026 only (18 months)** | 10.19m | **73.1%** |

- Release date on the workbook is 16 July 2026 — so we have **six more months than the Dec-2025 endpoint discussed in the meeting.**
- 89 SIC2 codes (88 industries + `00 Unclassified`), mapped to 22 sections via the `SIC2 Lookup` sheet.
- Suppression tokens are `[c]` (disclosure) and `[-]` (no data). **These are not zero** and must never be coerced to zero.

### 2.2 Finding 1 — 63% of payment value involves an unclassified counterparty

Total value across the SIC2 file is £32.1tn, but **£20.3tn (63%) involves SIC `00`**, and £6.0tn is `00 → 00`. Classified industry-to-industry flow is **£11.7tn, ≈ £150bn/month**.

*Implication:* every series must be built on classified-only flows. Any headline "total payment flow" including `00` is measuring the coverage of the classification process as much as the economy. The `00` block should be tracked separately as a data-quality series, since a shift in classification rates would otherwise read as an economic move.

### 2.3 Finding 2 — SIC5 is too suppressed to measure with, but fine to investigate with

Aggregating the SIC5 file up to classified SIC2 pairs for May 2026 gives **£116.1bn against the SIC2 file's £149.0bn — a 22% value loss** to disclosure suppression. The regional file is worse (73% of cells suppressed).

*Implication:* SIC2 is the measurement layer. SIC5 is a **drill-down/diagnostic layer only**, always displayed with its coverage caveat. This is a real constraint on Path C later.

### 2.4 Finding 3 — region supports levels and changes, but not anomaly detection

**Partly superseded — the attribution problem is smaller than first measured.** The 51.5% payee-side / 47.0% payer-side `unknown` figures cover the whole file *including* the SIC 00 block. Restricted to the classified industry-to-industry flows we actually analyse, **78–80% of value has both regions known**, stable across all 18 months, with 900 of 964 industry-region series complete. London (TLI) remains 18–19% of resolved value, consistent with the headquarter effect.

The binding constraint is history, not attribution: **18 months** is not enough for a seasonal baseline or a stable variance estimate, so **anomaly detection stays national**. Regional levels, MoM and YoY changes are in scope and are specified as a first-class dimension in `BUILD_SPEC.md` §6.6.

One hazard to carry: payer-side `unknown` has fallen from 19.3% to 16.0% over the 18 months. As attribution improves — which Joseph's matching work will accelerate — named regions gain value that was previously unknown, which is indistinguishable from regional growth unless the unknown series is shown alongside.

### 2.5 Finding 4 — a plain z-score threshold is a very blunt instrument on this data

Each industry's alert sensitivity depends on its own historical volatility. Measured across the 78 industries with meaningful volume, the year-on-year move required to clear **|z| = 3**:

| | |
|---|---|
| Median industry | **32%** |
| Upper quartile | **47%** |
| Industries needing a >40% move to register at all | **27 of 78** |
| Worst case | 254% |

*Implication:* a fixed threshold means wildly different economic sensitivity across industries — a 30% collapse registers in one industry and is invisible in another. Two consequences for the design: **rank alerts on a continuous severity score rather than firing binary flags at a cut-off**, and **include a persistence component** so that a sustained moderate move in a noisy industry can accumulate enough evidence to surface, rather than being judged one month at a time.

(Related: excluding COVID from variance estimation matters less than expected — with robust median/MAD statistics it moves the median required move from 37% to 32%, because outliers don't shift a median much. Still worth doing, but it is a refinement, not a fix.)

### 2.6 Finding 5 — the Education artefact is a reclassification, and no money moved

SIC 85 (Education) inflows fall from **£5,245m (Jan-25) to £2,790m (Mar-25) to £2,145m (Apr-25)** and stay at that level through Jun-2026. Suppressed-cell counts are unchanged across the break, so it is not a disclosure effect.

**The build established the cause.** Classified inflow fell 58% (£5,159m → £2,184m) while inflow from SIC 00 rose 218% (£1,558m → £4,948m) — and **total money in rose 6%** (£6,717m → £7,132m). The share arriving from unclassified payers went from 23% to 70%. The payments never stopped; 47 percentage points of Education's payers stopped being classified in March 2025.

This was only diagnosable because SIC 00 is retained as a labelled category rather than filtered out.

It scores **z ≈ −13 to −16.5**, dwarfing every genuine signal, and would rank #1 on the alert table **every month for twelve months** until it clears the year-on-year window.

*Implication:* structural-break detection is not a refinement, it is a precondition. Shipping the obvious version of this dashboard would put a false positive at the top of the first screen Andrew sees.

### 2.7 Settled — monitor inflows, corroborate with outflows

The table is directional, so each industry yields two series: **inflows** (money in, as payee — a sales proxy) and **outflows** (money out, as payer — an input-purchase proxy). These are the terms used throughout `BUILD_SPEC.md`, alongside **PFI** = inflows + outflows − self-flows. I checked whether they tell different stories or whether one leads the other:

- Median correlation between the two growth series is **0.74**; only 5 of 77 industries fall below 0.3.
- Cross-correlation peaks sharply at **lag 0** (0.74) and falls to 0.27–0.42 at every other lag from −3 to +3. **Neither series leads the other.**

*Decision:* rank alerts on **inflows**. Compute outflows too — it is the same aggregation on the other key, so it costs nothing — and show it in the drill-down as corroboration. Where the two diverge it is informative (margin or inventory effects); where they agree, which is usually, it raises confidence. No extra machinery.

### 2.8 Finding 6 — the payment network is hub-and-spoke at every granularity

Relevant to the network analytics now planned as Phase 2 (`BUILD_SPEC.md` §12).

| | SIC2 | SIC5 |
|---|---|---|
| Nodes | 88 | 706 |
| Directed edges (value > 0) | 5,935 | 104,263 |
| **Density** | **77.8%** | **20.9%** |
| Median out-degree | 73 of 88 possible | — |

At SIC2 the median industry pays 73 of the 88 possible counterparties. PageRank works well on this and reproduces the hub structure the meeting noted as matching ONS input-output tables — 64 Finance (0.101), 46 Wholesale (0.071), 82 Business support, 84 Public administration. But betweenness centrality degenerates: **83% of industries score exactly zero at SIC2 and 80% at SIC5**, with the non-zero scores landing on the same nodes PageRank already identifies. Density is not the cause — sparsifying the SIC2 graph from 77% to 19% leaves the zero-share at 82%. The economy is hub-and-spoke at every level tested.

Community structure is weak but real: modularity 0.163 at SIC2, 0.249 at SIC5, against ~0.3 as the conventional threshold for meaningful structure.

### 2.9 Finding 7 — suppression does not distort network structure

Simulating SIC5-style suppression on the SIC2 network by dropping the smallest edges — which is what disclosure suppression targets — leaves **community membership 100% identical and modularity unchanged at 65% of edges removed**, while 96.4% of value is retained. Suppressed cells are small-value weak ties.

This matters because it separates two concerns that look alike. SIC5's 65% suppression is disqualifying for *measurement* (§2.3) but **harmless for network topology**, which de-risks all Phase-2 work at that level.

---

## 3. What this means for the build

The meeting action item — *"automated monthly dashboard to flag industry anomalies at SIC2 level using z-score anomaly detection"* — is the right product. The findings say the detection layer needs two things the plain specification doesn't have:

1. **A break register**, so artefacts are classified as breaks rather than shocks (§2.6).
2. **Continuous ranking plus a persistence component**, rather than a single-month binary threshold (§2.5).

Everything else stays deliberately simple.

---

## 4. Plan

### Phase 0 — Environment and data foundation
- Dedicated project environment. The active `movie_maker` env is missing `duckdb`, `pyarrow`, `statsmodels`, `ruptures` and any dashboard library. Pin an `environment.yml`.
- Ingest all three sources into one tidy store (DuckDB/parquet). Canonical schema: `payer, payee, date, value, n_transactions, suppressed_flag, source, grain`.
- Preserve `[c]` / `[-]` as flags. Carry a per-industry-month **suppressed-cell count** as a first-class coverage metric.
- Join SIC2 lookup → division name, section.
- Build per-industry **inflow**, **outflow** and **PFI** series on both a classified-only and an including-SIC-00 basis, keeping self-flows and the SIC-00 component as separate columns (`BUILD_SPEC.md` §6.1–6.4), plus transaction counts and average transaction size.
- *Deliverable: a reproducible data layer + a short data-quality note covering §2. This note is worth circulating on its own.*

### Phase 1 — Series conditioning
- **Seasonal and working-day adjustment.** Monthly payment values carry heavy month-length, trading-day and Easter effects. Use the ONS-standard approach (X-13ARIMA-SEATS) rather than a bespoke method — it matters for credibility if outputs feed a publication.
- **Structural break detection** per series, producing a maintained break register. Baselines estimated only on the post-break segment. Breaks surfaced in the UI, never silently patched.
- **COVID treatment.** Mar-2020 to ~Jun-2021 excluded from variance estimation, retained for display. Documented.

### Phase 2 — Detection
Four signals per industry-month, combined into one ranked severity score:

| Signal | Catches |
|---|---|
| **a. Level deviation** | Sharp single-month shocks — robust z of the SA log level against a local trend + seasonal forecast |
| **b. Year-on-year deviation** | Persistent level shifts, post-break window |
| **c. Momentum / CUSUM** | Sustained drift that single-month tests miss (§2.5) |
| **d. Counterparty breadth** | Whether a move is industry-wide or one large counterparty — serves Andrew's "let the data speak", and guards against a single firm dropping out of the sample |

Output is a **ranked monthly watchlist**, not a set of binary flags. Each entry carries direction, £ magnitude, % change, persistence, breadth, and a data-quality tag.

**Calibration.** We have no pre-labelled event set, so this is done in two parts, honestly:
- *Must-hold behaviours:* COVID (Apr 2020) fires broadly; the Education break (Mar 2025) is classified **BREAK**, not shock; known seasonal patterns don't fire.
- *Volume tuning:* target ~3–6 substantive alerts per month across 88 industries, then review the historical alert log qualitatively. Prototype volumes already sit in range (1.4/month at |z|>2.5 plain, 3.6/month at |z|>3 robust).

### Phase 3 — Streamlit app with HTML export

**Architecture decision: local Streamlit app over a clean artifact layer, with on-demand export.** No hosting, no publishing, no static site generator running every month.

```
pipeline/   ingest -> condition -> detect        (all analytical logic lives here)
outputs/    alerts.csv, series.csv, breaks.csv   (also directly useful on their own)
app.py      Streamlit, run locally               (reads outputs/, contains no logic)
export/     render current view -> self-contained .html
```

The artifact layer stays for two reasons: it keeps logic out of the UI, and it is what makes export a small function rather than a second front end. The CSVs are also a deliverable in their own right — Andrew may simply want the alert table as a spreadsheet, which costs us nothing.

**Chart library: Plotly.** This decision now carries weight, because it is what makes export nearly free:

- A Plotly figure renders in the app via `st.plotly_chart(fig)` and serialises to a standalone file via `fig.to_html()` — **the same figure object, no second rendering path.** Export becomes a small module, not a parallel implementation.
- Exported charts stay interactive — hover, zoom, series toggle — which is most of the value of sending a chart rather than a screenshot.
- Matplotlib would mean static images and a dual code path; Altair/Vega would also work, but Plotly's Streamlit integration is the most direct.

**Inline the JS bundle, don't use the CDN.** `include_plotlyjs=True` embeds ~3–4 MB of plotly.js into each file; `'cdn'` produces a small file that fetches the library at open time. Default to inlining: an ONS internal network may block external CDNs, and a chart that renders as a blank box on the recipient's machine is worse than a large attachment. Chunky for email, but it works offline and on locked-down machines.

**What export produces.** One function, two entry points:
- **Export current view** — whatever you have on screen (industry, date range, filters) as a self-contained HTML file, bundling the charts *and* the alert table around them, so the numbers travel with the picture.
- **Monthly briefing preset** — assembles the standard set in one click: headline, ranked alert table, charts for the top N alerted industries, data-quality summary. Same renderer, fixed selection.

**Four views in the app:**
1. **Headline** — total index, MoM/YoY, alert count, one-paragraph "what changed this month".
2. **Alert table** — ranked watchlist, severity, direction, £ impact, breadth, data-quality flag.
3. **Industry drill-down** — inflow series with baseline band and break markers; outflow series alongside; top counterparty pairs driving the move; SIC5 detail with the 22% coverage caveat on the face of the chart. Running locally means this can be unbounded — arbitrary pairs, full SIC5 detail — with no payload limit to design around.
4. **Data quality** — suppression rates, unclassified share, coverage changes, break register.

Also the place to tune detection thresholds interactively during Phase 2 calibration, which is easier in Streamlit than in a notebook.

One command reruns the pipeline against a new monthly release; the app picks up the new `outputs/` on refresh.

**Disclosure note, reduced but not gone.** Local-only running removes the public-hosting governance question entirely. It does not remove the disclosure issue from *exported* files: a briefing combining SIC5 drill-downs with SIC2 aggregates could in principle let suppressed cells be recovered by differencing. This matters at the point an export is circulated, not while it sits on your machine — so the export module should stamp each file with a provenance and sensitivity header rather than us trying to solve it structurally now.

### Phase 4 — Validation and write-up (end of Phase 1 product)
- Back-test the alert log over 2022–2026; record hits *and* misses.
- Method note in the "official statistics in development" register.

### Phase 5 onwards — network analytics

Specified in full in `BUILD_SPEC.md` §12. In short: **PageRank** and centrality at SIC2 (works today, validates against input-output tables); **Isolation Forest** structural anomaly detection on engineered network features, composing with the Phase-1 level detector; **Louvain** communities with temporal tracking at SIC5, shipped as exploratory with modularity displayed. **Betweenness is computed but not given a view** (§2.8). A GNN embedding layer was considered and rejected — 7,920 node-months cannot train one, and neighbourhood aggregation on a near-complete graph averages away the signal it exists to capture.

Phase 1 carries eight small design decisions so that none of this needs rework — an edge store, a cross-level node-ID scheme, a single graph-construction entry point, and a golden direction test among them (`BUILD_SPEC.md` §12.6).

---

## 5. Explicitly deferred

Confirmed available but **deliberately not in scope now** — the build is complex enough without them:

- **ONS GVA industry weights.** Would let alerts rank by economic materiality rather than statistical extremity. Natural first extension once the monitor is stable, and it's where Andrew's Katherine Chant action lands. Design note: keep the alert output as a table with a joinable SIC2 key so a weight column can be added later without reworking anything.
- **7-day VAT flash diffusion index.** The second meeting action item — correlation and lead/lag against payment flows. Phase B work.

---

## 6. Open questions

1. **Does an exported briefing need clearance before it goes to anyone outside the three of you?** Local running settles the hosting question, but a circulated export is still a disclosure surface (see Phase 3). Worth knowing the answer before the first one gets emailed, not after.
2. **Is the March-2025 Education break known to ONS or Pay.UK?** Worth asking Joseph or the supplier — it determines whether we filter it or correct it, and there may be others we haven't detected yet.
3. **Regional — confirmed parked?** 18 months of history plus 52% unresolved value means it can't support baselines at all yet. Recommend revisiting only after Joseph's matching work lands.

---

## 7. Suggested sequencing

| # | Chunk | Output |
|---|---|---|
| 1 | Phase 0 | Data layer + data-quality note (§2) — fast, and it's what makes everything after it credible |
| 2 | Phase 1 | Conditioned series + break register |
| 3 | Phase 2 | Detection + calibration |
| 4 | Phase 3 | Streamlit app + HTML export |
| 5 | Phase 4 | Back-test and method note |
| 6 | Phase 5+ | Network analytics — PageRank, structural anomalies, communities |

Chunk 1 is worth shipping to Andrew and Matthew on its own. The Education break and the 63% unclassified share are findings they need regardless of what we build next.
