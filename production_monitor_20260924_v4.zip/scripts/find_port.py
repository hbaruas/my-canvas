"""Find a TCP port this machine will let us bind, and record it in port.txt.

Written because Streamlit failed on a managed Windows machine with

    PermissionError: [WinError 10013]
    An attempt was made to access a socket in a way forbidden by its
    access permissions

which reads like "the port is in use" and is not. Windows reserves whole TCP
ranges for Hyper-V, WSL and Docker, and refuses any bind inside them even when
nothing is listening. The error names no range, so the practical answer is to
try ports until one binds.

Binding and releasing a socket is exactly what Streamlit will do, so a port
that passes here is a port that will work - this tests the real thing rather
than guessing from the reserved-range table.
"""
from __future__ import annotations

import socket
import sys
from pathlib import Path

# Spread across ranges so a single reserved block cannot take them all.
CANDIDATES = [8501, 8502, 8510, 8600, 8700, 8888, 9000, 9500,
              5000, 5050, 3000, 7860, 10500, 11000]

HOST = "127.0.0.1"


def usable(port: int) -> tuple[bool, str]:
    """Try to bind the way the server will, and report what happened."""
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((HOST, port))
        s.listen(1)
        return True, "free"
    except PermissionError:
        # WinError 10013 - reserved or blocked by policy, not occupied.
        return False, "refused by Windows (reserved range or policy)"
    except OSError as exc:
        if getattr(exc, "winerror", None) == 10048 or exc.errno in (48, 98):
            return False, "already in use by something else"
        return False, f"{type(exc).__name__}: {exc}"
    finally:
        s.close()


def main() -> int:
    chosen = None
    for port in CANDIDATES:
        ok, why = usable(port)
        print(f"  {port:>6}  {'OK' if ok else 'no'}  {why}")
        if ok and chosen is None:
            chosen = port
            # Keep testing so the printout shows the full picture, which is
            # what gets pasted to whoever supports the machine.

    print()
    if chosen is None:
        print("None of the candidates could be bound.")
        print("Every one was refused, which points at machine policy rather")
        print("than at this tool. The reserved-range table printed above is")
        print("the thing to show your IT support.")
        return 1

    Path(__file__).resolve().parent.parent.joinpath("port.txt").write_text(
        str(chosen), encoding="utf-8")
    print(f"Using port {chosen}. Written to port.txt.")
    print(f"The dashboard will open at  http://localhost:{chosen}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
