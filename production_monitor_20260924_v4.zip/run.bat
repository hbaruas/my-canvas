@echo off
REM Production Monitor - one-click run (Windows)
REM Checks the environment and data, runs the full analysis, launches the app.

cd /d "%~dp0"
setlocal

echo ===============================================
echo  Production Monitor - quick run (audit skipped) - quick run
echo ===============================================

REM --- environment present? ---
call "%~dp0_env.bat"
if not exist "%PY%" (
    echo.
    echo ERROR: the environment is not installed at
    echo    %ENV_DIR%
    echo Double-click  install.bat  first.
    echo.
    pause
    exit /b 1
)

REM --- run the pipeline ^(it reports missing data itself, with detail^) ---
"%PY%" -m pipeline.run --use-cache --no-audit %*
set STATUS=%ERRORLEVEL%

if %STATUS%==2 (
    echo Place the delivery files in  Data\incoming\  and run this again.
    echo.
    pause
    exit /b 2
)
if not %STATUS%==0 (
    echo.
    echo ERROR: the pipeline failed ^(exit %STATUS%^). Nothing was launched.
    pause
    exit /b %STATUS%
)

REM --- launch the app ---
if not exist "app.py" (
    echo.
    echo Analysis complete. Outputs are in  outputs\
    echo ^(The dashboard is not built yet - pipeline results only.^)
    echo.
    pause
    exit /b 0
)

REM --- which port -------------------------------------------------------
REM 8501 is Streamlit's default, but Windows can REFUSE it outright with
REM   PermissionError: [WinError 10013]
REM That is not "already in use". Windows reserves whole TCP ranges for
REM Hyper-V, WSL and Docker, and a port inside a reserved range is forbidden
REM even when nothing is listening on it. Corporate security software blocks
REM ranges the same way.
REM
REM Override by creating  port.txt  beside this script with just a number in
REM it, or by setting PRODMON_PORT. To see what is reserved on this machine:
REM   netsh interface ipv4 show excludedportrange protocol=tcp
set "PORT=8501"
if defined PRODMON_PORT set "PORT=%PRODMON_PORT%"
if exist "%~dp0port.txt" (
    for /f "usebackq delims=" %%P in ("%~dp0port.txt") do (
        if not "%%P"=="" set "PORT=%%P"
    )
)

echo.
echo Starting the dashboard - it opens at  http://localhost:%PORT%
echo Leave this window open while you use it. Ctrl+C here stops it.
echo.
REM --- skip Streamlit's first-run prompt ---------------------------------
REM On a machine that has never run Streamlit, "streamlit run" prints a
REM welcome banner and asks for an email address at the prompt. That prompt
REM comes from a credentials file in the USER PROFILE, not from the project,
REM so a config.toml inside this folder cannot suppress it - which is why the
REM one shipped earlier would not have helped.
REM Writing an empty email here answers it once, locally, with nothing sent.
if not exist "%USERPROFILE%\.streamlit" mkdir "%USERPROFILE%\.streamlit" >nul 2>&1
if not exist "%USERPROFILE%\.streamlit\credentials.toml" call :writecreds

"%PY%" -m streamlit run app.py --browser.gatherUsageStats=false --server.port=%PORT%
set "RC=%ERRORLEVEL%"

REM Never let the window close on its own: if Streamlit fails to start, the
REM message is the only evidence of why, and it goes with the window.
echo.
echo ===============================================
if "%RC%"=="0" (
    echo  The dashboard was stopped. Nothing is wrong.
) else (
    echo  The dashboard exited with code %RC%.
    echo.
    echo  If you see  WinError 10013  above, Windows REFUSED port %PORT%.
    echo  That does not mean something else is using it - Windows reserves
    echo  whole ranges for Hyper-V, WSL and Docker, and blocks everything
    echo  inside them.
    echo.
    echo  To fix it, pick a port outside the reserved ranges. Check them with:
    echo     netsh interface ipv4 show excludedportrange protocol=tcp
    echo.
    echo  Then write a free port into port.txt and run this again, e.g.:
    echo     echo 8600^> port.txt
    echo.
    echo  Other causes:
    echo    - something really is on port %PORT%:  netstat -ano ^| findstr :%PORT%
    echo    - the environment is incomplete: re-run install.bat
)
echo ===============================================
echo.
pause
REM Stop here. Without this the script falls straight through into the
REM subroutine below and runs it a second time - labels do not end execution.
exit /b 0


REM --- write the credentials file in one grouped redirect ----------------
REM Grouped rather than two appends: "" immediately followed by >> is the
REM kind of thing cmd.exe reads differently depending on what surrounds it.
:writecreds
(
echo [general]
echo email = ""
) > "%USERPROFILE%\.streamlit\credentials.toml"
exit /b 0
