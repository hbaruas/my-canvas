# Production Monitor — Build Specification

Companion to `PROJECT_PLAN.md`, which holds the findings and the reasoning behind them. This document is **what we are building**, concrete enough to verify before any code is written.

Status: **specification under review. Nothing built.**
Revision 6 · 16 September 2026

---

## 1. What this is

A local Python pipeline that ingests the monthly Pay.UK/Vocalink industry payment files, builds monthly **inflow**, **outflow** and **PFI** series for each of the 88 SIC-2 industries, detects which industries moved anomalously, and writes a ranked alert table to disk. A local Streamlit app reads those outputs and provides four views: what moved, how it has trended, why it moved, and how far the data can be trusted. An export button turns any view into a self-contained HTML file for Andrew or Matthew. It runs on your machine, on demand. Nothing is hosted.

**Phase 1** (§§3–11) is that monitor. **Phase 2** (§12) adds network analytics — PageRank, communities, and structural anomaly detection — over the same data. Phase 1 carries eight small design decisions (§12.6) that exist solely so Phase 2 needs no rework; they are listed as Chunk 0 in the build order.

---

## 2. Dataset facts

Reference figures, all verified against the July 2026 delivery. Cited throughout rather than repeated.

### 2.1 The three files

| | SIC2 workbook | SIC5 flows | Regional flows |
|---|---|---|---|
| Grain | SIC2 × SIC2 × month | SIC5 × SIC5 × month | SIC2 × ITL1 × SIC2 × ITL1 × month |
| Period | Jan 2019 – Jun 2026 (**90 months**) | Jan 2019 – Jun 2026 | **Jan 2025 – Jun 2026 (18 months)** |
| Rows | 682,809 | 26,964,541 | 10,190,814 |
| Cells suppressed | **18.7%** | **65.3%** | **73.1%** |
| Classified flow | ~£150bn/month | ~£116bn/month equivalent | ~£105bn/month |

The SIC5 and regional files lose value to suppression that the SIC2 file retains. Aggregating SIC5 up to SIC2 pairs for May 2026 recovers £116.1bn against the SIC2 file's £149.0bn — a **22% shortfall**. The regional file runs about **30% below** national on the same basis. These files are not interchangeable and must never be summed together or compared on one axis.

### 2.2 Scale

| | Value | Transactions |
|---|---|---|
| Total, all 90 months | £32.1tn | **7,139,599,600** |
| Classified only (excl. SIC 00) | £11.7tn | 2,472,391,700 |
| Involving SIC 00 | £20.3tn (63%) | 4,667,207,900 (65.4%) |
| Per month, average | £357bn / £150bn classified | 79.3m / 27.5m classified |
| Latest month (Jun 2026) | £154.9bn classified | 30.9m classified |

Average classified transaction, June 2026: **£5,014**. Transaction volumes grew from 876m (2019) to 1,037m (2025).

Both totals **understate**, because 18.7% of cells are suppressed and contribute nothing.

### 2.3 Classification and geography

- **89 SIC2 codes** — 88 industries plus `00 Unclassified` — across 22 sections.
- **13 region categories** — 12 ITL1 codes `TLC`–`TLN` plus `unknown`.
- Suppression tokens: `[c]` disclosure-suppressed, `[-]` no data.

---

## 3. Repository structure

```
I21_VOCALINK/
├── Data/
│   ├── incoming/                 <- drop each new delivery here, any filename
│   └── archive/                  <- processed deliveries, moved here after ingest
├── pipeline/
│   ├── ingest.py                 <- read deliveries -> normalised long table
│   ├── vintage.py                <- snapshot store + revision diffing
│   ├── series.py                 <- build inflow / outflow / PFI series
│   ├── condition.py              <- seasonal adjustment + break detection
│   ├── detect.py                 <- four signals -> severity score
│   ├── decompose.py              <- three-way change attribution
│   ├── narrate.py                <- plain-English driver lines
│   ├── graph.py                  <- THE single graph constructor (§12.6)
│   └── run.py                    <- orchestrator; one command runs everything
├── outputs/
│   ├── series_national.csv       <- industry panel, 90 months
│   ├── series_regional.csv       <- industry x region panel, 18 months
│   ├── alerts.csv                <- ranked watchlist
│   ├── decomposition.csv         <- counterparty attribution per alert
│   ├── breaks.csv                <- structural break register
│   ├── revisions.csv             <- what changed vs the previous delivery
│   ├── quality.csv               <- coverage and suppression metrics
│   ├── node_metrics.csv          <- long-format metric store (§12.6)
│   ├── edges/                    <- partitioned edge list, level/month (§12.6)
│   └── vintages/<release>/       <- one snapshot per delivery
├── app.py                        <- Streamlit entry point
├── app_pages/                    <- movers, trends, decomposition, quality
├── export/report.py              <- view -> self-contained HTML
├── reference/
│   ├── sic2_lookup.csv           <- division -> name, section, GDP grouping
│   └── itl1_lookup.csv           <- region code -> name
├── environment.yml
└── PROJECT_PLAN.md / BUILD_SPEC.md
```

---

## 4. Handling the monthly delivery

Deliveries arrive roughly monthly, sometimes two months late. **Each delivery is a complete restatement of the whole history, not an increment** — the workbook contains all of 2019–2026 every time, and the cover sheet states that work is ongoing to improve sample size, data quality and industry classification. That is notice that history will be revised.

So each delivery loads as a full snapshot (a **vintage**) which replaces the working dataset, while the previous vintage is retained and diffed. From your side it stays one command. What it buys is `revisions.csv`: if a prior month's figure changes between releases, we see it as a revision instead of discovering it later as a phantom economic shock.

This matters directly for the March-2025 Education break (§9.2). If that break is a reclassification applied in some past release, a vintage diff identifies it as a data event on the day it appears. We cannot confirm that from one delivery — the second one will tell us.

The pipeline therefore:

- **Reads whatever is in `Data/incoming/`, regardless of filename.** Delivery names vary (`2607_sic5.csv`, `industrybusinesspaymentssic2dataset16072026.xlsx`, `2607_sic2region_2025_2026.csv`), so files are identified by inspecting structure, not by matching names.
- **Derives the latest month from the data, never the calendar.** No run assumes exactly one new month arrived.
- **Handles 0, 1 or several new months** without special-casing, including a re-release of a period already held.
- **Writes `revisions.csv`** every run; revisions above a threshold surface in the app rather than being buried.
- **Moves processed files to `Data/archive/`**, so `incoming/` is always a clear to-do list.

---

## 5. Data contract

### 5.1 Inputs

| Source | How it's read | Notes |
|---|---|---|
| SIC2 workbook (`.xlsx`) | sheet `SIC2_2019_2026`, header row 9 | `Payer (2-digit SIC)`, `Payee (2-digit SIC)`, `Date`, `Value (£)`, `Number of transactions`. Dates are text: `"January 2019"`. |
| SIC5 flows (`.csv`) | direct | `payer_5_digit_sic, payee_5_digit_sic, date, value_£, number_of_transactions`. Dates: `"01-JAN-19"`. |
| Regional flows (`.csv`) | direct | Adds `payer_region`, `payee_region` — `TLC`–`TLN` plus `unknown`. |
| SIC2 lookup | sheet `SIC2 Lookup`, header row 6 | Division code, description, **section**, section description. 89 rows: 88 divisions across sections A–U, plus SIC 00 whose section is the literal string `"N/A"`. |

**Four parsing rules, enforced everywhere:**

1. `[c]` (disclosure-suppressed) and `[-]` (no data) are **null, never zero**. The distinction between them is retained as a flag.
2. SIC codes are **zero-padded strings**. The lookup sheet mixes types — `'00'` and `'01'` arrive as text, `97`, `98`, `99` as integers. Unpadded codes fail to join silently, with no error.
3. SIC `00 Unclassified` and region `unknown` are **retained as labelled categories**, never dropped at ingest (§6.1). What each view includes is a presentation decision made downstream, not a parsing one.
4. Rows where `payer == payee` are **kept** (§6.2). They are normal flows, not duplicates.
5. The lookup sheet must be read with **`keep_default_na=False`**, and SIC 00's section code is then **normalised from `"N/A"` to `"X"`**. `"N/A"` is a pandas default NA string, so it becomes `NaN` not only at read time but on *every CSV round-trip afterwards* — meaning a downstream consumer opening `series_section.csv` with plain `read_csv` would silently lose Unclassified. Sections A–U are real; X is unused and unambiguous. Verified: 22 section values with the flag, 21 without, and 22 after a round-trip with the normalisation.

### 5.2 Outputs

**`series_national.csv`** — one row per industry-month:

```
sic2, name, section, section_desc, gdp_grouping, month,
inflow, outflow, pfi,                          # classified-only basis
inflow_incl00, outflow_incl00, pfi_incl00,     # full-money basis
self_flow, from_00, to_00,                     # component parts kept visible
n_tx_in, n_tx_out, avg_tx_value_in,
inflow_sa, inflow_trend, expected, residual,
suppressed_cells_in, suppressed_cells_out, share_from_00
```

**`series_section.csv`** — the same panel aggregated to section and GDP grouping, for reporting and external comparison (§6.3).

**`series_regional.csv`** — as above plus `region`, without the SA/expected columns (18 months cannot support them). `region` includes `unknown`.

**`alerts.csv`** — one row per flagged industry-month:

```
month, level, code, name, section, gdp_grouping,   # level = division | section
measure, basis,    # basis = MoM | YoY
severity,          # continuous 0-100 composite, the ranking key
direction,         # up | down
z_level, z_yoy, cusum, breadth,                # the four signals
gbp_delta, pct_delta,
presence_share,    # share of the change from cells appearing/disappearing (§6.7)
break_flag,        # inside a known structural break window
sic00_shift_flag,  # SIC-00 share moved materially this month
revision_flag,     # this month's value changed in the latest delivery
quality_flag,      # overall coverage warning
driver_line        # the generated sentence (§8.6)
```

**`decomposition.csv`** — `month, sic2, measure, basis, counterparty, contribution_gbp, category` where category is `continuing | newly_present | absent_suppressed | self | unclassified`.

**`breaks.csv`** — `sic2, break_month, pre_level, post_level, pct_change, detected_by, status` with status `auto | confirmed | dismissed`, editable by you.

**`revisions.csv`** — `month, sic2, prev_value, new_value, pct_revision, vintage_from, vintage_to`.

**`quality.csv`** — per month: suppression rate, SIC-00 share, unknown-region share (both sides), active industry count, total classified value, and deltas against the prior month.

**`edges/level=<sic2|sic5|sic2_region>/month=<YYYY-MM>/edges.parquet`** — the persisted edge list, written in Phase 1 even though Phase 1 has no view that reads it:

```
from_node, to_node, month, value, n_tx, suppressed_type, vintage
```

`node_id` format is `level:code[:region]` — `sic2:29`, `sic5:29100`, `sic2_region:29|TLL` — so an industry × region composite node is addressable without a schema change (§12.6).

**`node_metrics.csv`** — long format so new metrics never alter the schema:

```
level, node_id, month, metric, value, vintage
```

`metric` ∈ `pagerank | in_strength | out_strength | in_degree | out_degree | top_counterparty_share | community_id | community_key | modularity | anomaly_score`. Phase 1 populates the degree and strength metrics; Phase 2 adds the rest.

---

## 6. Analytical definitions

Fixed before the UI, because every view depends on them.

### 6.1 Categories are never silently dropped

Two categories are neither industries nor places, but they carry real money and are **visible labelled categories everywhere**, never filters.

**`unknown` region.** Payments we hold but cannot attribute geographically. A 13th category alongside the 12 ITL1 regions, selectable in every region control and included in "All UK" so regions sum to the total. It is **not** the same as `[c]` suppression — unknown has a value we can show, suppressed has no value at all. Displayed differently, never conflated.

Measured on classified flows, unknown is **asymmetric**: we know where money goes better than where it comes from.

| | Jan 2025 | Jun 2026 | Trend |
|---|---|---|---|
| Unknown on the **payee** side | 8.0% | 8.2% | flat |
| Unknown on the **payer** side | 19.3% | 16.0% | **falling ~3.5pp** |

That falling payer-side share is a live hazard, and Joseph's matching work will accelerate it. **As attribution improves, named regions gain value that was previously unknown — indistinguishable from regional growth.** Every regional comparison over time therefore shows the unknown series alongside, so the user can tell whether a region grew or merely became attributable.

**SIC `00` Unclassified.** The largest single counterparty for most industries. Share of each industry's inflows arriving from SIC 00, June 2026:

| SIC 85 Education | SIC 41 Construction | SIC 29 Motor veh. | SIC 64 Finance | SIC 46 Wholesale | SIC 10 Food |
|---|---|---|---|---|---|
| **68%** | 47% | 41% | 35% | 34% | 32% |

Dropping it would hide between a third and two thirds of where an industry's money comes from. So:

- **Rankings exclude it** — "Unclassified" is not an industry and cannot be ranked as one — but it appears as a separate row beneath the table so totals reconcile.
- **Decompositions and trends include it** as an explicit labelled bar or series.
- **Anomaly detection runs on classified-only**, for a stable series, but every alert carries a `sic00_shift_flag`, because a reclassification between `00` and a real industry would otherwise read as an economic move.

### 6.2 An industry pays itself, and a region pays itself

`payer == payee` is a normal, substantial flow, and the same holds for `payer_region == payee_region`. Intra-industry flows are **14.3% of all classified value** over the whole period. As a share of a single industry's inflow they range from **1% to 32%**, with a median of 7% — SIC 64 finance 31%, SIC 29 19%, SIC 46 16%, SIC 41 15% in the latest month.

- Self-flows are **included** in inflows and in outflows — they are genuine receipts and genuine payments.
- They are **subtracted once** in PFI, which would otherwise count them on both legs.
- They appear in every decomposition as a pinned bar labelled *"within-industry"*. For SIC 64 that bar is a fifth of the chart.
- They are never filtered out anywhere in the pipeline.

The same rule applies to intra-regional flows when a region is selected.

### 6.3 Aggregation hierarchy — detect low, report high

The `SIC2 Lookup` sheet carries a **Section** column, and every series is built and stored at three levels so the same numbers can be used for detection and for reporting:

| Level | Units | Role |
|---|---|---|
| **Division (SIC2)** | 88 + Unclassified | **The default, everywhere.** Detection runs here; every view opens here. |
| **Section (A–U)** | 21 + Unclassified | **Opt-in filter.** Comparison against GVA and VAT, and the level bulletins are written at. |
| **GDP grouping** | 4 | **Opt-in filter.** Agriculture (A), Production (B–E), Construction (F), Services (G–T) |

**Division is the default state of every control and is never pre-aggregated away.** Section and GDP grouping are filters the user selects deliberately, for reporting and external comparison — they are not a landing view and not a default.

**Detection stays at division level, and this is not a preference — aggregation destroys more than half the signal.** Running the same detector at both levels:

| | Divisions | Sections |
|---|---|---|
| Units | 78 | 21 |
| Alerts per month at \|z\|>3 | 3.57 | 1.04 |
| Division alerts that also register at section level | — | **48%** |
| Median alert \|z\| | 3.9 | 2.7 (**30% of signal lost**) |

Concrete cases: SIC 51 air transport scored z = −4.9 in June 2026, but section H Transportation showed −0.3 — completely masked. SIC 19 coke and refined petroleum scored −4.8 in April 2026 against −1.4 for section C Manufacturing, which contains 24 divisions of which the largest is only 24% of the total.

Where a section *is* a single division the signal passes through intact — section P Education reproduces SIC 85 exactly (z = −12.69 in both). Sections O, L and D are likewise one-to-one.

That is also why section cannot be the default. A dashboard opening at section level would show roughly **one alert a month instead of three and a half**, look reassuringly quiet, and give no indication that half the signal had been aggregated away. The user would have to know to drill down in order to discover there was something to drill into.

So the rule is: **detect at division, default to division, offer section as a filter, and always show which divisions drive a section figure.** Every section-level number expands to its divisions, and every division alert displays the section it belongs to, so a bulletin writer can move between the two without re-deriving anything.

### 6.4 The three measures

For industry *i* in month *m*:

| Measure | Definition | Reads as |
|---|---|---|
| **Inflow** | Σ value where *i* is the **payee**, including from itself and from SIC 00 | Money received — a sales proxy |
| **Outflow** | Σ value where *i* is the **payer**, including to itself and to SIC 00 | Money paid out — an input-purchase proxy |
| **PFI** | inflow + outflow − self-flow | Total payment throughput |

Each is computed on a **classified-only** basis (the detection series) and an **including-SIC-00** basis (the full-money view), switchable in the app, which always states which is shown.

PFI is the default headline. Inflows and outflows correlate **0.74 contemporaneously with neither leading** (plan §2.7), so combining them averages out payment-timing noise without losing signal.

### 6.5 Ranking changes

All ranking is in **£ change**, with % alongside. Two comparison bases, user-selectable: **MoM** (*m* vs *m−1*) and **YoY** (*m* vs *m−12*).

Ranking on absolute £ means a large move in a large industry outranks a large *percentage* move in a small one — the cheap stand-in for GVA weighting until real weights arrive.

### 6.6 Region handling

Restricted to the classified industry-to-industry flows we analyse, **78–80% of value has both payer and payee regions known**, stable across all 18 months. (The 52%-unresolvable figure quoted earlier in the project covers the whole file *including* the SIC 00 block; it does not describe the analytical subset.)

The binding constraints are elsewhere:

| | |
|---|---|
| History | **18 months** (Jan 2025 – Jun 2026) |
| MoM available | 17 months |
| YoY available | **6 months** (Jan – Jun 2026) |
| Anomaly detection | **Not possible regionally** — no seasonal baseline from 18 months |
| Usable series | 900 of 964 industry-region combinations complete; 528 exceed £10m/month |

**The region selector switches data source**, because national and regional files differ by ~30% (§2.1):

- **"All UK" (default)** → national SIC2 file. 90 months, YoY throughout, anomaly detection live.
- **A specific region, or a region comparison** → regional file. 18 months, YoY only from Jan 2026, the anomaly column shows **"n/a — insufficient history"** rather than a misleading number, and a banner states the coverage difference.
- **`Unknown / unattributed`** is selectable, and shown by default alongside any region comparison over time (§6.1).

The two sources are never mixed on one chart.

### 6.7 Three-way change attribution

Every change decomposes into three exhaustive parts which sum to the actual change with **zero residual**:

1. **Continuing** — counterparty present in both months; contribution = Δ
2. **Newly present** — absent before, present now; contribution = +value
3. **Absent or suppressed** — present before, gone now; contribution = −value

Categories 2 and 3 are **data-presence effects, not economic ones**, and are always rendered and labelled as such.

This is not a refinement. A naive decomposition that differences only the counterparties present in both months was tested against real data and silently failed:

> **SIC 29, June 2026 vs June 2025: actual change −£178m. Matched counterparties explain −£1m.** 99% of the move is invisible.

The missing £177m is one cell — payments from SIC 84 Public administration into SIC 29 — which ran at £81–186m from April to September 2025 and then **vanished from the data entirely**, having also been absent before April. Intermittent disclosure suppression, not an economic collapse.

Verified: the three-way split reconciles to £0.00m residual on every industry tested. For SIC 41 and SIC 46 the presence categories are 1% and 3% of the change and barely register; for SIC 29 they are the entire story.

Consequently `presence_share` is computed for **every** change in the system, and any change materially driven by appearance or disappearance is flagged wherever it is displayed — movers table, alert ranking, exports. Without it, intermittent suppression reads as economic news.

---

## 7. Modules

| Module | Responsibility |
|---|---|
| `ingest.py` | Identify files in `incoming/` by structure; parse; normalise to one long table `payer, payee, region_payer, region_payee, month, value, n_tx, suppressed_type, grain`; enforce the four parsing rules. |
| `vintage.py` | Write snapshot to `outputs/vintages/<release>/`; diff against previous vintage; emit `revisions.csv`. |
| `series.py` | Aggregate to per-industry **inflow**, **outflow**, **PFI** on both bases; keep `self_flow`, `from_00`, `to_00` as separate columns; attach transaction and suppression counts; join names and sections. Drops nothing. |
| `condition.py` | Seasonal and working-day adjustment (X-13ARIMA-SEATS); structural break detection producing `breaks.csv`; baselines estimated on the post-break segment with COVID excluded from variance. National series only. |
| `detect.py` | Compute the four signals; combine into `severity`; apply presence, break, SIC-00 and revision flags; write `alerts.csv`. |
| `decompose.py` | Three-way attribution (§6.7) for any industry-month-measure-basis; write `decomposition.csv`. |
| `narrate.py` | Generate `driver_line` from the decomposition (§8.6). |
| `graph.py` | **The single entry point for every graph built anywhere in the system.** `build_graph(level, month, region_scope, min_edge_value, include_unclassified, directed)`. The only place payer→payee direction, edge weighting and thresholds are defined. Phase 1 uses it for breadth and concentration metrics; Phase 2 builds every network feature on it (§12.6). |
| `run.py` | `python -m pipeline.run` — runs the above in order, prints a summary of what arrived, what was revised, and what fired. |

### 7.1 The four detection signals

Ranking uses a continuous severity score rather than a binary threshold, because a fixed z cut-off means very different economic sensitivity across industries: **the median industry needs a 32% year-on-year move to clear |z| = 3, the upper quartile 47%, and 27 of 78 industries need more than 40%** (plan §2.5).

| Signal | What it catches |
|---|---|
| `z_level` | Sharp single-month deviation of the SA level from expected |
| `z_yoy` | Persistent level shifts **in excess of the common component**, measured post-break |
| `cusum` | Sustained drift no single month would flag — the **mean** z over 6 months, not a sqrt-normalised sum |
| `breadth` | Share of counterparties moving the same way — separates an industry-wide move from one large counterparty |

**Every signal is measured against the cross-section, not only against the industry's own history.** The common component — the median log change across industries that month — is subtracted first. Andrew's requirement is to surface industries that moved *differently from the rest of the economy*; an industry moving with everything else is not an industry shock. Without this, July 2022 alone produces 74 false alerts (§9.3).

**CUSUM is a mean, not a sqrt-normalised sum.** The sqrt normalisation assumes independent observations, but consecutive year-on-year z-scores share eleven of their twelve base months. Measured on this data the sqrt version fired 14.6 times a month against 3.1 for a single-month z on the same series; as a mean it fires 1.5 times and reads plainly as "this industry has averaged z = −2 for six months".

**Severity and confidence are reported separately, never blended.** Severity (0–100) is how statistically unusual the move is; confidence (high/medium/low, with a stated reason) is how likely it is to be economic rather than an artefact. Blending them would bury the case that matters most — a very large move that is entirely a reporting change. Confidence drops to low when the move is presence-driven, sits on a break, coincides with a counterparty reclassification, or occurs in a month when the whole economy moved more than 20%.

Measured volume on this data: **5.2 alerts per month** above |z| = 3 across 88 industries, against a target of 3–6.

Target volume is ~3–6 substantive alerts per month across 88 industries. Prototype volumes sit in range: 1.4/month at |z| > 2.5 plain, 3.6/month at |z| > 3 robust.

---

## 8. The app

Streamlit, local, `streamlit run app.py`.

### 8.1 Movers — gainers and losers

The landing view, opening with headline figures for the latest month: total classified flow, MoM, YoY, alert count, and the month the data actually ends at.

Controls: **month** · **MoM / YoY** · **measure (inflow / outflow / PFI)** · **level (division ▸ default / section / GDP grouping)** · **basis (classified / incl. SIC 00)** · **region**. Everything refreshes together.

At section level the anomaly column is computed from the underlying divisions, not re-estimated on the aggregate — otherwise half the alerts disappear (§6.3). A section row expands to show which divisions drive it.

A diverging horizontal bar chart — gainers right, losers left, sorted by £ change — above the table:

| Rank | Industry | Δ £m | Δ % | Anomalous? | Driver | Data quality |
|---|---|---|---|---|---|---|
| 1 | 41 Construction | −194 | −5.1% | **Yes · 71** | broad-based | ok |
| 2 | 29 Motor vehicles | −178 | −31% | ⚠ presence-driven | **1 counterparty absent** | ⚠ |
| 3 | 46 Wholesale | +139 | +2.4% | No · 22 | broad-based | ok |

**Anomalous?** carries the severity score, sortable, with the yes/no as a badge — not a bare boolean. Unclassified appears as a separate reconciling row beneath the table, never ranked (§6.1).

### 8.2 Trends — line chart

Controls: **measure(s)** · **SIC code** (section and GDP grouping selectable, division by default) · **region(s)**.

Two mutually exclusive modes, enforced in the UI:

- **Compare measures** — one SIC, one region, any combination of inflow / outflow / PFI on shared axes.
- **Compare regions** — one SIC, one measure, several regions overlaid, with `unknown` shown by default (§6.1).

Three measures across five regions is fifteen lines and reads as noise, which is why the modes are exclusive. Baseline bands and break markers are drawn on national series only. Suppressed months are shown as **gaps, never interpolated**.

### 8.3 Change decomposition — waterfall

"Why did this move?" Controls: **SIC** (section selectable, division by default) · **MoM / YoY** · **£m or %** · **inflow side / outflow side**.

A section-level decomposition breaks down **by its own divisions first**, then by counterparty — "section C fell £400m, of which SIC 19 −£280m" is the answer a bulletin writer needs.

**Horizontal waterfall.** With 88 possible counterparties the labels are industry names, and horizontal is the only orientation that keeps them readable. Top ~12 contributors by absolute size; remainder collapsed into "all others".

Three bars are **always pinned regardless of rank**, because each is structurally large and hiding any of them misleads: **within-industry** (8–20% of inflows, §6.2), **SIC 00 Unclassified** (32–68% of inflows, §6.1), and, where a region is selected, **unknown region**.

Attribution is three-way per §6.7, with presence categories in a distinct colour and labelled as data effects.

### 8.4 Data quality

Suppression and SIC-00 trends, unknown-region shares on both sides, coverage changes, the break register, the revision log from §4, and a **cell-stability table** — counterparty relationships that are intermittently suppressed, ranked by how much value moves in and out of view. That table is what turns "SIC 29 collapsed" into "one cell stopped being reported".

### 8.5 Cross-cutting — the presence flag

Per §6.7, every £ change in the app carries a flag when a material share of it comes from cells appearing or disappearing rather than changing. Movers, alerts, decompositions, exports.

### 8.6 Cross-cutting — plain-English driver line

Each alert gets one generated sentence, assembled from its own decomposition:

> *"SIC 29 Motor vehicles: inflows down £178m (−31%) vs June 2025. 98% of the fall is payments from SIC 84 Public administration no longer present in the data — treat as a reporting change, not an economic signal."*

This is the highest-value single feature for stakeholder intuitiveness. Andrew should not have to read a waterfall to learn what the waterfall says.

### 8.7 Charts and export

Plotly throughout, so the same figure object renders in the app and serialises to standalone HTML. Two export buttons over one renderer:

- **Export current view** — charts plus the surrounding table.
- **Monthly briefing** — headline, movers, top decompositions, data-quality summary.

plotly.js is **embedded inline, not loaded from a CDN**, so files open on a locked-down ONS machine with no internet. Each export is stamped with source release date, vintage, and a sensitivity line.

---

## 9. Two things to watch in the data

### 9.1 Intermittent cell suppression
Counterparty cells appear and disappear between months (§6.7). Handled structurally by three-way attribution and the presence flag, and monitored in the cell-stability table.

### 9.2 The Education break — cause now established

**Diagnosed during the build. It is a counterparty reclassification, and no money moved.**

| SIC 85 inflows, monthly average | Sep 2024 – Feb 2025 | Apr – Sep 2025 | |
|---|---|---|---|
| Classified | £5,159m | £2,184m | **−58%** |
| From SIC 00 | £1,558m | £4,948m | **+218%** |
| **Total money in** | **£6,717m** | **£7,132m** | **+6%** |
| Share arriving from unclassified payers | 23% | 70% | |

The payments into Education never stopped. In March 2025, 47 percentage points of its payers moved from classified to unclassified. Measured on the classified basis this reads as a 58% collapse; measured on total money in, nothing happened.

This is only diagnosable because SIC 00 is retained as a labelled category (§6.1). Had it been filtered out, as an earlier draft of this spec specified, the industry would show an unexplained 58% collapse with no way to tell why.

### 9.3 July 2021 records far fewer transactions than the months around it

Found during the build. July 2021 records **52.2m transactions against 81.7m in June and 76.7m in August**, and £90.1bn against £120.1bn and £112.6bn. Whether that reflects the economy, the sample, or the collection is not something the data settles, and the tool does not assert it.

What does follow is arithmetic on our own figures. Every year-on-year comparison against it is inflated, so in **July 2022, 74 of 88 industries appeared to rise more than 25% year-on-year, with a median of +58.8%** — while month-on-month growth that month was +0.4%. An uncorrected detector reports 74 economic shocks that never happened.

Two defences, both now in the pipeline:

1. **`quality.csv` flags incomplete months** by comparing each month's transaction count against its neighbours. July 2021 scores 68% completeness and is the only month flagged in 90.
2. **Detection scores the excess over the common component** (§7.2) — the cross-sectional median change across industries — so a system-wide move, whatever its cause, is removed before any industry is judged.

### 9.4 The delivery repeats some keys

The July 2026 delivery has **104 duplicated `(payer, payee, month)` rows in the SIC2 file** (all May 2026) and **90,344 in the regional file** across 17 months. Each appears twice, once flagged `[c]` and once `[-]`. Both carry a null value so totals are unaffected, but any index-based operation fails on them. Collapsed at ingest, with a warning, rather than defended against downstream.

### 9.0 The delivery is the ground truth

Everything in this system is derived from the files Pay.UK and ONS supply, and the only question that can be tested is whether our figures faithfully represent them. `python -m pipeline.audit` is that test.

Three rules follow, and `tests/test_framing.py` enforces them:

1. **Report what the data records; never assert a figure in it is mistaken.** Where a month or a cell is unlike its neighbours, say so and show the numbers. We are not positioned to know why.
2. **Keep observation and inference apart.** "Classified inflow fell 58% while inflow from unclassified payers rose 218%, and the total moved 6%" is observed. "This is a reclassification" is inferred from it, and is labelled as such wherever it appears.
3. **Arithmetic on our own figures is ours to assert.** That a year-on-year comparison against a low month comes out large is a property of the calculation, not a claim about the source, and is stated plainly.

An earlier version of this document, and a briefing sent to the stakeholder, described these as "defects in the source data". That was the wrong footing: the findings below are properties of the delivery that change how it must be read, not faults to be reported back.

### 9.5 The workbook holds the data twice, and the copies give two readings

`SIC2_2019_2026` repeats the yearly sheets `SIC2_2019` … `SIC2_2026`. Checked cell by cell:

| | Result |
|---|---|
| Cells only in the combined sheet | 0 |
| Cells with different values in both | 0 |
| Cells only in the yearly sheets | 29,692 — all empty; the yearly sheets list the full 89×89 grid, the combined sheet omits empty pairs |
| **Published in combined, marked `[c]` in yearly** | **78 cells, £299.6m — 75 in April 2026** |

**Decision: the more restrictive reading wins.** Faced with two readings of the same cell, a cell marked suppressed in either sheet is treated as suppressed, so nothing shown or exported rests on a figure withheld elsewhere in the same release. This is a documented choice between two published readings, not a correction of one. 0.19% of April 2026 overall, but 20.6% of SIC 51's inflow and 10.5% of SIC 01's.

Also found reading the files cell by cell: the date column mixes text (667,356 rows) with real Excel dates (15,453); the code columns mix text with integers (2,936 of them below 10, needing a leading zero); the regional file marks suppression `[C]` where the workbook uses `[c]`; the latest two months of 2026 are not padded to the full grid in either sheet. All are handled and each is pinned by a test in `tests/test_source_format.py`.

### 9.6 Regional rows sharing a key are separate records

34,246 keys repeat in the regional file, in groups of up to nine, with **different** values. Collapsing them as duplicates lost £3.39tn of £6.5tn. They are summed.

### 9.7 Intermittent counterparty suppression — three confirmed cases
Counterparty cells appear and disappear between months, producing changes that look economic and are not:

| Industry | Period | Driver |
|---|---|---|
| SIC 29 Motor vehicles | Oct 2025 onward | SIC 84 Public admin cell, £81–186m, absent |
| **SIC 19 Coke & refined petroleum** | **Oct 2025 – May 2026** | **SIC 47 Retail cell, £330m of a £348m fall — returns Jun 2026** |
| SIC 84 → 29 | Apr – Sep 2025 only | present for 6 months of 90 |

SIC 19 scores higher than Education (8.38 against 6.61) and is 92% presence-driven. Handled structurally by three-way attribution (§6.7) and the presence flag; monitored in the cell-stability table.

---

## 10. Explicitly not in scope

- **Regional anomaly detection** — 18 months cannot support a seasonal baseline (§6.6). Regional levels, MoM and YoY changes *are* in scope.
- **SIC5 views** — the file is ingested and stored, but no view reads it in v1. It loses 22% of value to suppression (§2.1) and belongs in drill-down once the SIC2 product is stable.
- **GVA weighting** — outputs key on SIC2, section and GDP grouping (§6.3), so weights join at whichever level they arrive in without rework.
- **VAT flash comparison** — Phase B.
- **Hosting, publishing, scheduled automation.** You run it when a delivery lands.

---

## 11. Build order

| Chunk | Delivers | Verifiable by |
|---|---|---|
| 0 | `graph.py` + edge store + **golden direction test** | A known asymmetric pair orders payer→payee; PageRank on a toy graph matches hand calculation. Cheap now, invalidates every Phase-2 ranking if wrong (§12.6) |
| 1 | `ingest` + `vintage` + `series` → the three panels, `quality.csv`, `edges/` | Totals reconcile to §2.2 exactly; section totals reconcile to division totals; Unclassified survives section aggregation (§5.1 rule 5); regional sits ~30% below national |
| 2 | `condition` → `breaks.csv`, SA series | Education break Mar-2025 detected and registered |
| 3 | `detect` → `alerts.csv` | Volume ~3–6/month; COVID fires broadly; Education classified as break not shock |
| 4 | `decompose` → `decomposition.csv` | Three-way split reconciles to zero residual on all 88 industries; SIC 29 Jun-26 attributes 99% to presence |
| 5 | Movers + Trends views | Region switch changes data source and disables the anomaly column; suppressed months render as gaps |
| 6 | Decomposition view + `narrate` | Pinned bars always present; driver line matches the waterfall |
| 7 | Data quality view | Break register shows cause; incomplete months surfaced |
| 8 | Export | Exported file opens with no internet connection |

**Status: Phase 1 complete. Chunks 0–8 built, 80 tests passing.**

Closed since the first pass: section and GDP-grouping alerts inherited from their driving division (§6.3); driver lines surfaced in Movers and the decomposition view; a classified / including-SIC-00 toggle on Movers and the waterfall; severity-then-£ ordering; the baseline band on Trends; `sic00_shift_flag`, `revision_flag` and `quality_flag` in `alerts.csv`.

Three bugs fixed in the same pass, each of which produced a plausible wrong number rather than an error:
- **PFI could go negative.** The classified-basis PFI subtracted a self-flow taken from the full table, and `fillna(0)` turned suppressed cells into zeros, giving Unclassified a throughput of −£75bn.
- **Driver lines described the wrong quantity.** `narrate` decomposed inflows while quoting a PFI headline, so SIC 66 read as "down £2.7bn, largest contributor +£197m (63% of the move)". Decomposition is now measure- and basis-consistent and reconciles to £0.00m.
- **Per-month, not global, top-N.** Both driver lines and enrichment took a global top-N by severity, which July 2022 dominates, so the current month received none. This is why `sic00_shift_flag` fired on zero rows despite Education's 47-point shift.

Performance: a month-indexed edge view (`decompose.EdgeIndex`, lazily filtered and memoised) took one decomposition from 169 ms to 8 ms, which is what makes per-month enrichment affordable.

**Chunk 8 — export.** Two buttons over one renderer, producing a single ~4.6 MB HTML file with plotly.js embedded and **zero externally-loaded scripts**, verified by test. Three things the build settled:

- **Geographic charts would break offline.** plotly ships a default `topojsonURL` of `https://cdn.plot.ly/`. Nothing fetches it for bar, line or scatter charts, so exports are safe today — but a choropleth or `scattergeo` would request it at render time and show an empty map on a machine with no outbound route. Pinned by a test so it is noticed if anyone adds a map.
- **Never assert on the whole document.** At 4.6 MB, a failing assertion makes pytest's rewriting build an explanation from the entire string, which takes minutes and is indistinguishable from a hang. Export assertions reduce to a small derived fact first.
- **Breadth and concentration are different questions.** SIC 66 had most counterparties falling *and* a single one carrying 102% of the fall, so the table read "broad-based" beside a driver line naming one counterparty. Confidence now drops to medium when the top counterparty carries 70% or more of a move.

Chunk 1 is independently useful — it produces the data-quality findings in plan §2, worth sending to Andrew and Matthew regardless of what follows.

---

## 12. Phase 2 — network analytics

Four features to build after the monitor is live. All four are viable, but I tested each against the actual network before specifying it, and **two of them belong at SIC5 rather than SIC2.** The evidence is below, followed by the hooks Phase 1 must include so none of this requires rework.

### 12.1 The finding that shapes all four: this network is nearly complete

| | SIC2, Jun-2026 | SIC5, Jun-2026 |
|---|---|---|
| Nodes | 88 | **706** |
| Directed edges (value > 0) | 5,935 | 104,779 |
| **Density** | **77.8%** | **21.0%** |
| Median out-degree | 73 of 88 possible | — |

At SIC2, the median industry pays **73 of the 88 possible counterparties**. Almost everyone trades with almost everyone. That is fine for PageRank, but it undercuts the two algorithms that depend on sparse structure — there is no intermediation to detect when every pair is already directly connected.

**Suppression does not distort network metrics — this was worth checking and the answer is reassuring.** Simulating SIC5-style suppression on the SIC2 network by dropping the smallest edges (which is what disclosure suppression targets):

| Edges dropped | Density | Value retained | Betweenness = 0 | Modularity | Community agreement vs full |
|---|---|---|---|---|---|
| 0% | 77.5% | 100% | 83% | 0.163 | — |
| 50% | 43.6% | 98.7% | 82% | 0.165 | — |
| **65%** | **31.3%** | **96.4%** | **82%** | **0.169** | **100%** |
| 80% | 18.8% | 90.3% | 82% | 0.178 | — |

Even at 65% suppression, **community membership is 100% identical** and modularity is unchanged. Suppressed cells are small-value weak ties carrying ~3.6% of value; they do not determine structure. So SIC5's 65% suppression, while fatal for *measurement* (§2.1), is **not a problem for network topology**. That materially de-risks the SIC5 work.

The same table carries a warning, though: **sparsifying does not reduce the betweenness zero-share at all** — it sits at 82% regardless of density. That is the first sign that density is not what makes betweenness fail here. §12.4 follows it up.

### 12.2 PageRank and centrality — works at SIC2, build first

Verified on June 2026, classified-only, damping 0.85, `value` as edge weight:

| Rank | 1 | 2 | 3 | 4 | 5 | 6 |
|---|---|---|---|---|---|---|
| | 64 Finance **0.101** | 46 Wholesale 0.071 | 82 Business support 0.056 | 84 Public admin 0.053 | 62 IT services 0.050 | 47 Retail 0.037 |

This reproduces the hub structure the meeting noted as matching ONS input-output tables — wholesale and financial services as the economy's principal hubs — which is a useful independent validation of the payment data.

**The sink problem you flagged is real and measurable.** Including SIC 00, node `00` takes **0.341 — over a third of all PageRank in the network.** Unclassified is both the largest source and the largest sink, so it absorbs the random walker. PageRank therefore runs **classified-only by default**, with including-00 available as a diagnostic view and never as the headline.

**Directional sensitivity is the real engineering risk**, exactly as you note: flip payer and payee and the ranking inverts silently, with no error. §12.6 makes this a single-point-of-truth with a golden test.

Deliverables: PageRank over time per industry (the influence-drift line chart), in- and out-strength, and a leaderboard with month-on-month rank movement.

### 12.3 Louvain communities — weak at SIC2, build at SIC5

Run on the undirected value-weighted SIC2 graph (85.7% density after symmetrising):

| | |
|---|---|
| Communities found | 4 |
| **Modularity** | **0.163** |
| Stability across 10 seeds | **94.9% co-membership agreement**, community count 4 every time |

Two results matter here, and they point opposite ways.

**Your stability concern does not bite.** At 88 nodes the partition is essentially deterministic — 94.9% agreement across seeds, same community count every run. A fixed seed is still worth setting, but ensemble runs are not needed at this size.

**Modularity of 0.163 is the problem.** Structure is normally considered meaningful above roughly 0.3. At 0.16 the communities are barely better than chance, which is the expected consequence of an 86%-dense graph. Inspecting them confirms it: two of the four are economically coherent — an agri-food cluster (crop production, fishing, food, beverages, textiles) and an extractives cluster (coal, petroleum, mining support, non-metallic minerals) — but the largest is a 32-division catch-all spanning tobacco, electricity, accommodation and computer manufacturing, which is not an economic cluster by any reading.

**SIC5 improves it, but not decisively.** Tested on the June 2026 SIC5 graph (706 nodes, 20.9% density): **6 communities, modularity 0.249** — better than SIC2's 0.163 and approaching the conventional 0.3 threshold, but the community sizes (184, 181, 141, 113, 81, 6) are large and roughly even, which is itself a signature of weak structure rather than of genuine clusters.

So Louvain at SIC2 is **descriptive colour, not an analytical product**, and at SIC5 it is **exploratory but worth building**. Present SIC2 communities only as a coarse overlay, and always publish the modularity score next to the picture so weak structure is visible rather than implied. If SIC5 modularity stays near 0.25 across months, treat the output as a hypothesis generator for analysts, not as a finding for a bulletin.

The temporal work you describe — running per year and watching communities fracture through 2020 and reorganise after — is the strongest part of this feature and is unaffected by the level choice. It needs a stable node-matching scheme across years so "the same community" can be tracked, which §12.6 provides.

### 12.4 Betweenness centrality — does not work at SIC2

This is the one I'd change most. Measured on the real graph:

| Threshold | Nodes | Density | **Betweenness exactly 0** | Compute time |
|---|---|---|---|---|
| None | 88 | 77.5% | **73 of 88 (83%)** | 0.10s |
| ≥ £10m | 80 | 24.0% | 66 of 80 (82%) | 0.03s |
| ≥ £100m | 54 | 9.1% | 42 of 54 (78%) | 0.00s |

**Eighty-three percent of industries have a betweenness of exactly zero**, and the non-zero scores land on 64 Finance, 84 Public admin, 46 Wholesale, 82 Business support and 47 Retail — *the same nodes PageRank already identifies*. Filtering to sparsify barely changes the ranking. So at SIC2 betweenness adds no information over PageRank.

More fundamentally, **the premise of the feature cannot hold at this granularity.** A hidden chokepoint is a small sector with low PageRank and high betweenness. On a 78%-dense graph that combination is structurally impossible: money never needs an intermediary when the direct edge already exists. The chokepoints are not hidden — they are the five largest hubs, which we already knew about.

**Two corrections to the engineering assumptions.** The complexity concern is inverted: this data is pre-aggregated industry-to-industry, not firm-to-firm, so V = 88 and E ≈ 6,000. Brandes runs in **0.10 seconds**, not hours — there is no CPU problem to solve, at SIC5 either. And the noise-threshold safeguard, while sensible, turns out not to change the answer; it is worth keeping for SIC5 but it is not what makes the metric work.

**I initially recommended relocating this to SIC5. Having tested it there, that was wrong.** The SIC5 network, June 2026 — 706 nodes, 20.9% density, computed in 12.7 seconds:

| | SIC2 | SIC5 |
|---|---|---|
| Nodes | 88 | 706 |
| Density | 77.5% | **20.9%** |
| **Betweenness = 0** | 83% | **80%** |
| Top nodes | 64, 84, 46, 82 | 82990, 84110, 64999 — *also PageRank's top 3* |
| "Hidden chokepoints" (top-20 betweenness, outside top-60 PageRank) | — | **3 of 706** |

Quadrupling the sparsity and multiplying the node count eightfold moved the zero-share by three points. Combined with the suppression simulation in §12.1, where sparsifying the SIC2 graph from 77% to 19% density left the zero-share pinned at 82%, the conclusion is that **density was never the problem — the topology is.** This economy is hub-and-spoke at every level of granularity: a handful of nodes (business support, public administration, finance) sit on essentially every shortest path, and everyone else sits on none. That is a real structural fact about the network, but it is not one betweenness centrality is needed to discover.

**Recommendation: drop betweenness as a product feature.** It returns the same hubs PageRank already returns, at both levels, with 80%+ of nodes scoring exactly zero. The three genuine low-PageRank/high-betweenness nodes at SIC5 (25990, 46130, 47710) are worth a look as a one-off analytical curiosity, but they do not support a dashboard view.

Keep the *computation* available in `graph.py` — it costs 0.1s at SIC2 and 12.7s at SIC5, and the stress-testing use you describe is still a reasonable future application. Just don't build a view around it.

### 12.5 Anomaly detection — Isolation Forest yes, GNN no

The two-stage design is sound in principle, but the first stage does not fit this dataset.

**Why the GNN should be dropped.** Two independent reasons. First, size: 88 nodes × 90 months is **7,920 node-month observations** — nowhere near enough to train a graph network that generalises rather than memorises. Second, and more damaging, a GCN works by aggregating each node's neighbourhood; on a 78%-dense graph every node's neighbourhood is *almost the entire graph*, so the embeddings collapse toward a common mean and the structural signal they are supposed to capture is averaged away. The explainability cost you identify is real, but it is not the binding objection — the model would not learn much worth explaining.

**What to build instead.** Isolation Forest on **engineered structural features**, which keeps everything the GNN was there to provide and stays interpretable:

| Feature | Captures |
|---|---|
| PageRank, and its month-on-month change | Shift in systemic influence |
| In/out degree and strength | Counterparty count and concentration |
| Top-counterparty share (HHI) | Dependence on a single relationship |
| Community membership and whether it changed | Structural reorganisation |
| Presence churn (§6.7) | Counterparties appearing or disappearing |
| Self-flow share (§6.2) | Internalisation |

Every one of these is a number an economist can read, so an alert explains itself without SHAP. This also composes cleanly with the Phase-1 detector: Isolation Forest scores **structural** anomalies, the §7.1 signals score **level** anomalies, and an industry flagged by both is considerably more interesting than one flagged by either.

**Cold start is not an issue here** — we have 90 months, so the model trains on 2019–2024 and scores forward. Only the first 12–24 months of the series are unusable as scoring targets.

Keep the GNN as a genuine option if firm-level or SIC5-regional data ever arrives, where node counts reach the tens of thousands and the density problem disappears.

### 12.6 What Phase 1 must include so none of this needs rework

These are cheap now and expensive to retrofit. They go into the Phase-1 build.

**1. Persist the edge list, not just node series.** Phase 1's outputs are node-level panels; every feature here needs edges. `ingest.py` already produces the long table, so write it out as a first-class artefact partitioned by month:
```
outputs/edges/level=<sic2|sic5|sic2_region>/month=<YYYY-MM>/edges.parquet
    from_node, to_node, month, value, n_tx, suppressed_type, vintage
```

**2. One node-ID scheme across all levels.** Network nodes are not always industries. Regional Louvain needs *industry × region* composite nodes ("Manufacturing in Wales" is one node, not two facts). Define `node_id` now as `level:code[:region]` — `sic2:29`, `sic5:29100`, `sic2_region:29|TLL` — so a composite node is addressable without changing schemas later.

**3. A single `graph.py` with one entry point.** Every network feature calls one function:
```python
build_graph(level, month, region_scope, min_edge_value, include_unclassified, directed)
```
This is the **only** place payer→payee direction is set, the only place weights and thresholds are applied. It directly answers the directional-sensitivity risk in §12.2: one definition, one test.

**4. A golden direction test, in Phase 1.** Assert on a known asymmetric pair that money flows payer→payee and that PageRank orders accordingly. A silent axis flip is the failure mode that would invalidate every ranking here without raising an error.

**5. A long-format metrics store.** So new metrics never change the schema:
```
outputs/node_metrics.csv
    level, node_id, month, metric, value, vintage
```
`metric` ∈ `pagerank | in_strength | out_strength | betweenness | community_id | modularity | anomaly_score`.

**6. Community IDs stable across time.** Louvain labels are arbitrary per run — community "3" in 2019 has no relation to "3" in 2020. Without a matching step the temporal animation is meaningless. Store a `community_key` resolved by maximum Jaccard overlap with the prior period, plus the raw label, and set a fixed seed.

**7. Carry the vintage through.** Network metrics are recomputed per delivery like everything else (§4), so `node_metrics` is vintage-stamped and revisions are visible here too.

**8. Publish the diagnostic alongside every network output.** Modularity for Louvain, density and zero-share for betweenness, the SIC-00 share for PageRank. Each of these features has a regime where it stops being meaningful, and the diagnostic is what makes that visible on the chart instead of in a footnote.

### 12.6a PageRank: built, and what testing it changed

The premise in §12.2 was that importance and size differ, so a centrality
measure would rank industries differently from a size measure. On this data
they barely do: **the Spearman rank correlation between PageRank and inflow is
0.992**, and only 13 of 88 industries move five or more places. A PageRank
league table would be a size league table under another name, and is not built.

The informative part is the **divergence**. Of the industries ranked furthest
below their size — SIC 72 Scientific R&D (−11 places), SIC 87 Residential care
(−9), SIC 85 Education (−8), SIC 88 Social work (−7) — **four of the top six
have SIC 84 Public administration as their largest payer.** PageRank discounts
them because money from a payer that itself receives little passes on little
influence.

That is a real finding and is not visible in any size ranking: it identifies
industries that are large but sit outside the circulation of business-to-business
payments, funded from outside it. The **Influence** view is built around that
gap, states the 0.992 correlation on its own face, and does not present the
ranking as though it added information.

`node_metrics.csv` is now written — the last outstanding output from §12.6.

### 12.6b Structural anomalies: built, and what they add

Seven features describe the *shape* of an industry's inflows rather than their
size: how many industries pay it, how concentrated those payments are (HHI),
its largest single relationship, how much activity is internal, how much
arrives unclassified, counterparty turnover, and its network position. Each is
standardised **within** the industry, so the model asks whether a month is
unusual *for that industry* rather than rediscovering that industries differ in
size.

**It is not redundant with the Phase 1 detector: 184 of 234 alerts — 79% — are
not level alerts.** The case it exists for is SIC 47 Retail in April 2020,
which moved −1% year-on-year and was invisible to the level detector, while its
payments became far more concentrated: same money, different shape.

It also rediscovered the Education reclassification by an independent route,
flagging "more arriving from unclassified payers" in November 2025.

Two implementation notes worth keeping. A robust MAD scale **collapses** on a
feature that is usually constant — counterparty churn is zero in most months,
so its median and MAD are both zero, which nulled 95% of rows and left the
model 360 of 7,783 to learn from; the fallback to standard deviation fixes it.
And the first month has no prior to compare against, so churn is null there
rather than scored as total turnover, which would flag every industry in
January 2019.

The GNN remains rejected for the reasons in §12.5, recorded in the module so
nobody adds one without re-reading them.

### 12.6c Communities: built, and what the modularity says

Louvain over the SIC-5 network, once per year, 2019–2026. Modularity comes out
at **0.236–0.257 across all eight years** — stable, and consistently below the
~0.3 floor for structure worth interpreting. That was the spec's prediction and
it held, so the feature ships as exploratory with the number on the page rather
than in a footnote.

Two of the five clusters are economically recognisable: one is 58% manufacturing
with construction and wholesale, another manufacturing with wholesale and
agriculture. A third spans 215 codes with only 14% in its dominant section — a
residual rather than a community. That mix is exactly what a modularity of 0.24
predicts.

**Temporal keys work.** Louvain numbers its groups arbitrarily each run, so keys
are matched year to year by Jaccard overlap (§12.6 hook 6). Three communities
persist across all eight periods and median membership retention is 0.73, so a
cluster can be followed through time.

SIC-5 is streamed rather than ingested: 27 million rows reduced to 1.03 million
yearly edges in about 27 seconds, so no Phase 1 behaviour changes. The step runs
only under `--with-sic5`.

### 12.7 Suggested order

| | Feature | Level | Rationale |
|---|---|---|---|
| 1 | Edge store + `graph.py` + direction test | all | §12.6; unblocks everything else |
| 2 | ~~PageRank and centrality~~ | SIC2 | **Built**, but not as specified — see below |
| 3 | ~~Isolation Forest structural anomalies~~ | SIC2 | **Built** — 79% of its alerts are not level alerts |
| 4 | ~~Louvain communities + temporal tracking~~ | SIC5 | **Built** — exploratory, modularity 0.236–0.257 |
| — | ~~Betweenness~~ | — | **Dropped as a view** (§12.4). Computation retained in `graph.py` and written to `node_metrics.csv` for stress-testing. |
| 5 | ~~The §12.6 hooks, audited~~ | all | **Closed** — see §12.7a. Four were specified and not built. |

### 12.7a The hooks, audited after the features were built

The eight requirements in §12.6 are the ones that get skipped, because no view
depends on them and nothing fails when they are missing. Audited against the
running code, four were outstanding.

| Hook | Status found | Action |
|---|---|---|
| 1 edge store | built | — |
| 2 node-ID scheme | built | — |
| 3 single `graph.py` entry point | built | — |
| 4 golden direction test | built | — |
| 5 long-format metrics store | built, but **missing `betweenness`** | `betweenness` added to `network.METRICS` |
| 6 stable community keys | built | — |
| 7 vintage carried through | **applied to `node_metrics` only** | now stamped on `structural`, `communities`, `community_summary`, `community_stability`, `network_diagnostics` |
| 8 diagnostic beside every output | **modularity only** | `network_diagnostics.csv` added: density, betweenness zero-share, SIC-00 PageRank share, per month |

**The zero-share now rests on 90 months, not one.** §12.4 measured 83% on a
single month. Written for every month, it runs **71.6% to 83.0%, median
77.3%**, and never falls below 71.6%. The conclusion that betweenness separates
a handful of hubs from everyone else rather than ranking industries therefore
holds across the whole series, not just the month it was tested on. The
diagnostic is in `network_diagnostics.csv`.

**The betweenness finding is the instructive one.** §12.4 decided to drop the
*view* and keep the *computation* for stress-testing. Both were dropped — and
`network.py`'s own docstring went on saying "betweenness is computed but given
no view" while nothing computed it. A claim in a comment survives exactly as
long as nothing checks it. `tests/test_network.py` now checks it, and also
re-measures the 83% zero-share, so if the topology ever changes enough to make
a view worthwhile the test says so rather than the decision standing forever on
a measurement taken once.

**Hook 8 mattered most for PageRank.** §12.2 specified classified-only "with
including-00 available as a diagnostic view and never as the headline". The
classified-only half was built and the diagnostic was not, so a reader had no
way to see the size of what was excluded. The Influence page now states it:
SIC 00 takes roughly a third of all PageRank when included, which is *why* it
is excluded, and the exclusion is now visible rather than silent.

---

## 13. Open for your call

1. **PFI as throughput (in + out − self)?** The alternative is *net* (in − out), measuring whether an industry is a net receiver or payer — a different question, also useful. Throughput is specified as the headline because it is the more robust activity measure; net could be a fourth option.
2. **Do ONS or Pay.UK know about the March-2025 Education reclassification?** We now know *what* it is (§9.2): 47pp of SIC 85's payers moved from classified to unclassified, with total money in unchanged. Still worth raising with Joseph or the supplier — whether it was intentional, whether it will be corrected, and whether other industries were affected in the same release.
3. **Movers default sort — severity first, or £ first?** Severity-then-£ is specified, so the unusual outranks the merely large. Pure £ reads more intuitively but buries small-industry shocks.
4. **Waterfall bars before "all others"** — 12 specified.
5. **Does an exported briefing need clearance** before going to anyone outside the three of you? Local running settles hosting, but a circulated export is still a disclosure surface.

---

## 14. What changed in this revision

- **Categories retained, not filtered** (§6.1). SIC 00 and `unknown` region are labelled categories throughout. Previously SIC 00 was excluded from all analysis, which would have hidden 32–68% of every industry's inflows.
- **Self-flows made explicit** (§6.2). `payer == payee` is 14.8% of classified value, kept everywhere and pinned in decompositions.
- **Region upgraded from "not analysed" to a first-class dimension** (§6.6), on evidence that 78–80% of classified value resolves — the earlier 52% figure described the whole file, not the analytical subset. Anomaly detection remains national-only.
- **Three-way attribution made structural** (§6.7), after a naive decomposition was shown to miss 99% of a real change.
- **Terminology standardised** to inflow / outflow / PFI throughout, replacing mixed use of "receipts" and "payments".
- **Dataset facts consolidated** into §2, including transaction counts.

**Revision 4 additions:**
- **Section and GDP-grouping levels added** (§6.3) as **opt-in filters, not defaults**, so outputs can be compared against GVA and VAT and written into bulletins at the level those are published. Division remains the default state of every view.
- **Detection confirmed to stay at division level**, on evidence that section aggregation loses 52% of alerts and 30% of median signal strength.
- **Fifth parsing rule** (§5.1) for the `"N/A"` section string, which pandas silently nulls by default.

**Revision 5 additions:**
- **Phase 2 network analytics specified** (§12) — PageRank, Louvain, betweenness and structural anomaly detection, each tested against the real network before being specified.
- **Two features relocated to SIC5** on evidence that the SIC2 network is 77.8% dense, which makes betweenness degenerate (83% of nodes score exactly zero) and Louvain weak (modularity 0.163).
- **GNN replaced by engineered features** for the anomaly layer — 7,920 node-months cannot train one, and neighbourhood aggregation on a near-complete graph averages the signal away.
- **Eight Phase-1 design hooks added** (§12.6) so none of Phase 2 requires rework: edge-list persistence, a cross-level node-ID scheme, a single graph-construction entry point, a golden direction test, a long-format metrics store, stable community keys, vintage carry-through, and a published diagnostic per feature. These are now folded into the Phase-1 repo structure, outputs, modules and build order rather than only described in §12.
- **Betweenness dropped as a product feature** (§12.4) after testing at SIC5: 80% of 706 nodes score exactly zero, against 83% at SIC2, and the top nodes are PageRank's top nodes at both levels. Density was not the cause — the economy is hub-and-spoke at every granularity.
- **Suppression shown not to distort network structure** (§12.1): at simulated 65% suppression, community membership is 100% identical and modularity unchanged. This de-risks all SIC5 network work.
