@echo off
REM Production Monitor - one-click installer (Windows)
REM Creates an isolated environment. Touches nothing else on your system.
REM
REM If Python is not on PATH (managed/work builds usually are not), either:
REM     install.bat "C:\ONSapps\My_Python\Python_3_10\python.exe"
REM or put that path in python_path.txt beside this file and just double-click.

cd /d "%~dp0"
setlocal

echo ===============================================
echo  Production Monitor - install
echo ===============================================
echo Folder: %CD%
echo.

call "%~dp0_env.bat" %1

if not defined PYTHON_EXE (
    echo.
    echo ===============================================
    echo  ERROR: no usable Python found ^(need 3.10, 3.11 or 3.12^).
    echo ===============================================
    echo.
    echo Every path checked is listed above, with the version each reported.
    echo If your Python is not in that list, point this script straight at it.
    echo.
    echo FASTEST FIX - run these two lines in this folder, then double-click
    echo install.bat again. Replace the path with your own if it differs:
    echo.
    echo    echo C:\ONSapps\My_Python\Python_3_10\python.exe^> python_path.txt
    echo    install.bat
    echo.
    echo Or pass it in directly, just once:
    echo.
    echo    install.bat "C:\ONSapps\My_Python\Python_3_10\python.exe"
    echo.
    echo To find python.exe if you are unsure, run:
    echo    where python
    echo    dir /s /b C:\ONSapps\My_Python\python.exe
    echo.
    pause
    exit /b 1
)
echo Using interpreter: %PYTHON_EXE%
"%PYTHON_EXE%" -V
echo Environment:       %ENV_DIR%

REM --- create the virtual environment ---
if exist "%PY%" (
    echo Environment already exists - reusing it. Delete the folder for a clean rebuild.
) else (
    echo Creating environment ...
    "%PYTHON_EXE%" -m venv "%ENV_DIR%"
    if errorlevel 1 (
        echo ERROR: could not create the environment at %ENV_DIR%
        echo If that path is on a network or restricted drive, set PRODMON_VENV
        echo to somewhere writable, or put the path in venv_path.txt.
        pause
        exit /b 1
    )
)

REM --- install dependencies ---
echo Installing dependencies ^(this takes a few minutes the first time^) ...
"%PY%" -m pip install --upgrade pip --quiet
"%PY%" -m pip install -r requirements.txt
if errorlevel 1 (
    echo.
    echo ERROR: dependency install failed.
    echo On a corporate network pip often cannot reach the internet directly.
    echo Ask IT for the proxy or the internal package index, then retry with:
    echo    "%PY%" -m pip install -r requirements.txt --index-url ^<internal-url^>
    pause
    exit /b 1
)

REM --- verify ---
echo.
echo Verifying ...
"%PY%" -c "import pandas,numpy,scipy,statsmodels,pyarrow,openpyxl,networkx,sklearn,streamlit,plotly;print('  all packages import cleanly');import platform;print(f'  {platform.system()} {platform.machine()}, Python {platform.python_version()}')"
if errorlevel 1 (
    echo ERROR: verification failed.
    pause
    exit /b 1
)

echo.
echo ===============================================
echo  Install complete.
echo  Next: double-click  run-full.bat  ^(first time, ~15 min^)
echo        then           run.bat      ^(every day after^)
echo ===============================================
pause
