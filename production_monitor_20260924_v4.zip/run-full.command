#!/usr/bin/env bash
# Production Monitor - full run (macOS)
# Re-reads the delivery from scratch, reconciles every figure against the raw
# files, runs the test suite, then opens the dashboard. Use this when a new
# delivery arrives, or before quoting a number to anyone.

cd "$(dirname "$0")" || exit 1
set -u
echo "==============================================="
echo " Production Monitor - full run"
echo " Rebuild + audit + tests. Takes about 15 minutes."
echo "==============================================="
if [ ! -x ".venv/bin/python" ]; then
    echo; echo "ERROR: the environment is not installed."
    echo "Double-click  install.command  first."; echo
    read -r -p "Press Return to close."; exit 1
fi
PY="./.venv/bin/python"

echo; echo "--- 1 of 3: rebuilding from the delivery ---"
"$PY" -m pipeline.run "$@"
STATUS=$?
if [ $STATUS -eq 2 ]; then
    echo "Place the delivery files in  Data/incoming/  and run this again."
    echo; read -r -p "Press Return to close."; exit 2
elif [ $STATUS -ne 0 ]; then
    echo; echo "AUDIT FAILED - the outputs do not reconcile to the source data."
    echo "Treat the dashboard as unreliable until this is resolved."
    read -r -p "Press Return to close."; exit $STATUS
fi

echo; echo "--- 2 of 3: running the test suite ---"
if ! "$PY" -m pytest tests/ -q; then
    echo; echo "TESTS FAILED. The dashboard will still open, but something"
    echo "the tests guard has changed - read the failures above."
    read -r -p "Press Return to continue anyway, or Ctrl+C to stop."
fi

echo; echo "--- 3 of 3: starting the dashboard ---"
# --- which port -------------------------------------------------------
# Kept in step with run.bat: port.txt wins, then PRODMON_PORT, then 8501.
# macOS rarely refuses 8501, but the two platforms should not disagree about
# where the dashboard lives, and find-port writes the same file on both.
PORT=8501
[ -n "${PRODMON_PORT:-}" ] && PORT="$PRODMON_PORT"
[ -f "$(dirname "$0")/port.txt" ] && PORT="$(tr -d '[:space:]' < "$(dirname "$0")/port.txt")"
echo "Dashboard: http://localhost:$PORT"

"$PY" -m streamlit run app.py --browser.gatherUsageStats=false --server.port="$PORT"
