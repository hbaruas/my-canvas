#!/usr/bin/env bash
# Production Monitor - one-click installer (macOS)
# Creates an isolated .venv inside this folder. Touches nothing else on your system.

cd "$(dirname "$0")" || exit 1
set -u

echo "==============================================="
echo " Production Monitor - install"
echo "==============================================="
echo "Folder: $(pwd)"
echo

# --- locate a usable Python (3.10-3.12) ---
PY=""
for c in python3.12 python3.11 python3.10 python3; do
    if command -v "$c" >/dev/null 2>&1; then
        v=$("$c" -c 'import sys;print("%d.%d"%sys.version_info[:2])' 2>/dev/null) || continue
        case "$v" in
            3.10|3.11|3.12) PY="$c"; PYV="$v"; break ;;
        esac
    fi
done

if [ -z "$PY" ]; then
    echo "ERROR: no suitable Python found (need 3.10, 3.11 or 3.12)."
    echo
    echo "Install one of:"
    echo "  - python.org/downloads   (simplest)"
    echo "  - brew install python@3.11"
    echo
    read -r -p "Press Return to close."
    exit 1
fi
echo "Using $PY (Python $PYV)"

# --- create the virtual environment ---
if [ -d ".venv" ]; then
    echo ".venv already exists - reusing it. Delete the folder for a clean rebuild."
else
    echo "Creating .venv ..."
    "$PY" -m venv .venv || { echo "ERROR: could not create .venv"; read -r -p "Press Return to close."; exit 1; }
fi

# --- install dependencies ---
echo "Installing dependencies (this takes a few minutes the first time) ..."
./.venv/bin/python -m pip install --upgrade pip --quiet
if ! ./.venv/bin/python -m pip install -r requirements.txt; then
    echo
    echo "ERROR: dependency install failed. Check your internet connection and retry."
    read -r -p "Press Return to close."
    exit 1
fi

# --- verify ---
echo
echo "Verifying ..."
./.venv/bin/python -c "
import pandas, numpy, scipy, statsmodels, pyarrow, openpyxl, networkx, sklearn, streamlit, plotly
print('  all packages import cleanly')
import platform
print(f'  {platform.system()} {platform.machine()}, Python {platform.python_version()}')
" || { echo "ERROR: verification failed."; read -r -p "Press Return to close."; exit 1; }

echo
echo "==============================================="
echo " Install complete."
echo " Next: double-click  run.command"
echo "==============================================="
read -r -p "Press Return to close."
