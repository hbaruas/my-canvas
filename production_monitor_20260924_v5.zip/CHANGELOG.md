# Changelog

**Release 2026-09-22 — "every word and every number justified"**

Scope: the wording, the explanations and the arithmetic behind them. One
calculation defect was found while writing a worked example and is fixed here.

---

## How to read this file

Each entry states **what changed**, **why**, and — where a number appears —
**where that number comes from and how to reproduce it**. Nothing below is
asserted without a source. Three kinds of source appear:

| Marked | Means |
|---|---|
| **arithmetic** | Follows from a formula printed in the entry. Check it on a calculator |
| **measured** | Computed from this delivery's outputs. The command to reproduce it is given |
| **convention** | An external standard, named and dated. Not something we chose |

Where an entry says a number is **measured**, it was measured on the delivery
of **16 July 2026** (90 months, January 2019 – June 2026). Re-measuring on a
later delivery will move it, which is why the dashboard recomputes these live
rather than printing the figures written here.

---

## 1. Defect fixed: the baseline was counted wrong

**What was wrong.** `_rolling_robust_z` counted the baseline as *rows of the
index* rather than *months that actually held a value*. A year-on-year series
has no value in its first twelve months, and every withheld cell leaves a hole.
Both were being counted as baseline.

**Size of the error.** SIC 68 Real estate, June 2026, PFI: reported as resting
on **73 months** of baseline when **61 months** carried a value. The
finite-sample correction was therefore applied on 72 degrees of freedom instead
of 60.

**Which direction it erred in.** Towards **overconfidence**, in three places at
once:

1. The **published depth** overstated how much history a score rested on.
2. The **discount for a thin baseline** was too small, because the t
   distribution on more degrees of freedom is closer to normal. A score
   measured on a short history was penalised less than it should have been.
3. The **`provisional` flag** (fewer than 24 months) could fail to fire on a
   score with fewer than 24 real observations.

**Fix.** The history is now `dropna()`'d before it is counted, so
`baseline_months`, the degrees of freedom and the `provisional` flag all refer
to the same thing: months that carried a value.

**What it changed, measured before and after on the same delivery.** This is
not a cosmetic correction:

| | Before | After |
|---|---|---|
| Deepest baseline reported | 73 months | **68 months** |
| Division-level YoY rows scored | 16,575 | **12,543** |
| Share clearing severity 63 | 13.3% | **6.4%** |
| Industries flagged per month (PFI, YoY) | mean 9.5, median 5 | **mean 4.6, median 4** |
| SIC 68 Real estate, June 2026 | severity 68.6 | **68.3** |

**Read that table carefully: roughly half the previous alerts were resting on
overstated history.** The discount for a thin baseline was too small, so scores
that should have been pulled back were not. The new rate — between four and
five industries a month — is what the detector was always meant to produce.

Fewer rows are scored because `MIN_HISTORY = 12` now means twelve months that
actually hold a value, rather than twelve rows of the index. That is what the
constant was always documented to mean.

**The worked example now reconciles exactly.** The page recomputes SIC 68 as
**68.3** against a published **68.3**, and prints both. Before the fix it
recomputed 68.3 against a published 68.6 — a 0.3 gap that was the symptom.

**How it was found.** Not by a test. By writing out the severity calculation
step by step so a reader could repeat it, and finding that the recomputation
did not match the stored score (68.3 against 68.6). This is the argument for
showing the arithmetic on the page rather than describing it.

*Source: `pipeline/detect.py::_rolling_robust_z`. Reproduce with
`python -m pipeline.run` and compare `baseline_months` in `outputs/alerts.csv`
before and after.*

---

## 2. New: one place where every method is written down

**Added `app_pages/method.py`.** Every explanation of severity, confidence,
basis, baseline, the common component, the three decomposition categories, the
typical-range band, the diagnostics and the reconciliation line now lives in
one module and is rendered on every view that uses the term.

**Why.** The same term was being explained in slightly different words on four
pages. A reader comparing two pages could reasonably conclude they meant
different things.

**Two rules the module enforces.**

- **No claim without its arithmetic.** Where a threshold is used, the formula,
  the number it returns and the origin of the convention are printed.
- **No example that expires.** Illustrations of a *method* use round invented
  numbers, so they read identically in five years. Illustrations of *this
  dataset* are recomputed from the current outputs when the page opens, so they
  can never describe a month no longer in the data.

---

## 3. Severity: the whole calculation is now on the page

**Added a live worked example.** One real industry-month is recomputed from
`series_national.csv` and every intermediate value is printed: the two monthly
levels, the log change, the common component, the excess, the median and MAD
of the industry's own past, the raw ratio, the finite-sample correction and the
final score. It is chosen live — latest month, highest severity, full baseline,
high confidence — so it can never refer to a month that has dropped out.

**Where 63 comes from — now stated as arithmetic, not as an assertion.**

    severity = 100 × (1 − e^(−|z| / 3))
    at |z| = 3:  100 × (1 − e^(−1)) = 100 × (1 − 0.3679) = 63.2

**arithmetic.** 63 is not tuned. It is what the formula returns at |z| = 3.

**Why |z| = 3.** The three-sigma rule: the control limit Walter Shewhart set in
1931 for statistical process control, still the default convention in outlier
work. Under a normal distribution, |z| ≥ 3 occurs about **0.27%** of the time —
roughly 1 observation in 370. **convention.**

**And the honest caveat, which is new.** On this data, 63 flags **6.4%** of
scored industry-months, not 0.27% — about **24 times more often** than a normal
distribution would give. **measured**, on 12,543 division-level year-on-year
rows in `outputs/alerts.csv` after the fix in section 1.

The dashboard computes this figure at render time rather than printing the
6.4% written here, so it can never disagree with the outputs on screen.

The dashboard now says so, in these terms: business-to-business payment series
have far fatter tails than a bell curve, because large one-off settlements,
contract renewals and year-end payments are ordinary events. So **63 is a
browsing dial, not a verdict**, and the page says explicitly:

> Never write "significant" on the strength of this number alone. It is a
> distance from an industry's own recent history. It is not a hypothesis test,
> it carries no p-value that would survive these tails, and it says nothing
> about whether the cause was economic.

This matters for ONS publication: **"significant" has a specific meaning to an
ONS reader and this score does not earn it.**

**Disclosed for the first time: severity does not change between MoM and YoY.**
The score is computed once per industry-month from three signals, none of which
is a month-on-month comparison. Switching the comparison changes the £ change,
the % change and the common component shown beside the score — not the score.
This was always true and was never stated. It is now stated on the page.
**measured:** severity is identical across the two bases for every row of
`outputs/alerts.csv`.

---

## 4. Confidence: reframed from a judgement to a checklist

**The old framing was not defensible.** The dashboard said confidence judged
whether a move "looks genuinely economic". We cannot see inside a business and
have no basis for that claim.

**The new framing is what the code actually does.** Confidence is a checklist
of specific, measurable conditions, each known to move these numbers **without
any money changing hands differently**. The label reports which test fired, in
a fixed order, first match wins. Nothing is weighted, averaged or tuned.

The full ordered table is now printed on the page, with the threshold, the
label and the reason each condition is a warning sign:

| Order | Test | Threshold | Label |
|---|---|---|---|
| 1 | Whole economy moved | median industry change ≥ ±20% | low |
| 2 | On a known structural break | break register | low |
| 3 | Partners appearing/disappearing carry most of it | presence share ≥ 50% | low |
| 4 | Unidentified-payer share jumped | ≥ ±20 percentage points | low |
| 5 | Most cells withheld | suppressed share > 50% | low |
| 6 | One partner carries most of the move | top partner ≥ 70% | medium |
| 7 | Concentrated in a few partners | fewer than 40% moved alike | medium |
| 8 | Partly presence-driven | presence share ≥ 25% | medium |
| 9 | Thin baseline | fewer than 24 months | medium |
| — | Nothing fired | — | high |

**Where each threshold comes from — added, because it was being taken on
trust.** None was chosen by looking at which alerts it produced.

- **50%** and **70%** are the plain meanings of "most of it" and "nearly all of
  it". Above 50%, *more than half* of a move is one thing — arithmetic, not
  opinion.
- **20 percentage points** is a fifth of the whole, an order of magnitude above
  this data's normal month-to-month drift in the same share.
- **24 months** is two full years, the minimum that sees each calendar month
  twice, which is what a seasonal comparison requires.
- **40%** is "fewer than two in five", below which *"most partners did this"*
  stops being a true sentence.

These are constants at the top of `pipeline/detect.py`
(`SYSTEMIC_COMMON_PCT`, `CONCENTRATION_LIMIT`, `FULL_BASELINE`), not numbers
buried in the code, and any change to one will appear in this file.

**Added a live table** showing the highest-severity `high`, `medium` and `low`
row in the current month with the exact rule that fired, so the three words
attach to real rows rather than to definitions.

---

## 5. Driver lines: one fixed shape, every month

**The complaint.** A line read:

> SIC 85 Education: PFI up £444m (+12%) vs June 2025. Largest contributor
> SIC 84 Public administration and defence; compulsory social security at
> £307m (69% of the move).

A reader cannot tell whether SIC 84 was the largest, the closest or merely the
one we happened to name; whether 69% is of the move or of the industry's total;
or what they are supposed to do about it.

**The fix.** Every line now has the same two-part shape, every month:

1. **What moved** — industry, measure, direction, £, %, against which period.
2. **A cause clause that opens by naming the kind of cause in bold**, before
   any number.

There are exactly seven endings, and the bold phrase says which one you are
reading before you read a figure:

| Ending | Means | What to do |
|---|---|---|
| **Concentrated in one partner** | One partner accounts for the stated share; it traded in both months | Real, but one relationship — check for a single contract or settlement date |
| **More than accounted for by one partner** | One partner moved by **more than the net change**; others offset part of it | Remove that relationship and the industry barely moved. Never call it industry-wide |
| **No single partner drove it — the largest one moved the other way** | The biggest individual change pushed **against** the total | The move is spread across the rest. Do not name the largest partner as the cause |
| **Broad-based** | Most partners moved the same way | The strongest signal available here. Investigate |
| **Reporting change, not money changing hands** | The largest part is a partner that **disappeared** from the published data | Do not report as economic |
| **Coverage change, not new activity** | A partner **appeared** | Do not report as economic |
| **Most likely a classification change** | Money moved between identified and unidentified buckets | Check *Share from unclassified payers* on Trends |

**Two ambiguities removed by construction.** Where a partner is named it is
always the one whose payments changed **the most**, never the closest or an
illustrative pick; and every percentage now states which quantity it is a share
of.

### 5a. Two sign defects found while checking the new lines against real data

Neither was caught by a test, and both were producing sentences that stated the
opposite of the truth. Both were found by printing the generated lines for the
current month and reading them.

**The largest partner can move against the total.** **SIC 68 Real estate, June
2026, PFI:** the industry fell **£176m**, while its largest single change was
**SIC 47 Retail paying £93m more**. The line called SIC 47 "the largest
contributor at £93m, 53% of the move" — naming as the cause of a fall the one
partner that was pushing the other way. There is now a separate ending for this
case, which says the largest change moved *against* the total and that the move
is spread across the rest. **measured** from `outputs/alerts.csv` and the
counterparty decomposition.

**A share can exceed 100%, and printing it bare is meaningless.** **SIC 66,
June 2026:** SIC 64 accounts for **102%** of a £2.7bn fall, because other
partners moved up and offset £60m. The line now says so explicitly and adds the
sentence that matters: *remove this one relationship and the industry barely
moved.*

**Negative amounts rendered as "£-2.7bn".** The minus sign is now outside the
currency symbol: **−£2.7bn**.

All four cases are now tested on **generated output** rather than on the source
text, with synthetic edge tables constructed to force each branch. Testing the
source text was how the wrapped-phrase problem hid: a phrase split across two
lines of Python is one that neither a test nor a reader can find.

**A legend was added below the lines** giving the five endings and what each
means, so the shape is documented where it is used.

*Source: `pipeline/narrate.py::line`.*

---

## 6. Overview: the expiring example is gone

**Removed:** *"An industry can fall on one basis and rise on the other —
Education did exactly that in March 2025."*

**Two faults.** It used the word **basis** without defining it, and it was
pinned to one month. As deliveries accumulate, March 2025 recedes and the
sentence quietly becomes an anecdote about a month nobody is looking at.

**Replaced with:** a definition — *basis means which payments are counted* —
and a permanent worked example in round invented numbers:

| | Month 1 | Month 2 | Change |
|---|---|---|---|
| From partners we can identify | £100m | £110m | **+10%** |
| From partners we cannot (SIC 00) | £200m | £90m | −55% |
| **All flow** | **£300m** | **£200m** | **−33%** |

Same industry, same month: **up 10% on one basis, down 33% on the other.**
Neither is wrong; they answer different questions. This example cannot expire.

---

## 7. Movers: every industry code accounted for

**The question.** *"Why are there only 86 industries when there are 88 plus
unknown?"*

**The answer, which the page never gave.** A change requires a figure in
**both** months. Where either is withheld there is no change to state, and we
do not treat a withheld cell as zero. 88 real industries plus SIC 00 is 89 rows.

**measured** on this delivery: on **PFI** all 88 industries have a figure in
both months in every one of the 90 months. On **inflows**, three industries drop
out in some months — **SIC 05** (mining of coal and lignite), **SIC 07**
(mining of metal ores) and **SIC 12** (tobacco) — all very small, all
frequently withheld. The lowest count on inflows is 85; on outflows, 87.

*Reproduce: group `outputs/series_national.parquet` by `sic2` for a month and
its comparison month, subtract, and count the non-null rows.*

**Fix.** A caption under the chart now names every missing industry and the
reason, every time: `_coverage_note()` in `app_pages/movers.py`. If nothing is
missing it says so, rather than going silent and leaving the reader to count.

**SIC 00 is now drawn on the chart** when a basis that includes it is selected
— which is when it is real money in the total — with a checkbox to remove it.
It is still never ranked in the table, because it is not an industry. Before
this change, selecting *Including SIC 00* produced a chart that did not add up
to the total on the Overview, with no explanation of the difference.

---

## 8. Why did it move?: four fixes

**a. The month dropdown ran oldest-first.** Now newest-first, matching every
other view. The latest month is what anyone opens this for.

**b. The counterparty slider stopped at 24.** It now runs to the number of
partners the selected industry actually has. 24 was an invented round number
that silently truncated the tail on most industries. The help text states how
many partners exist and that the remainder are gathered into a single "All
other counterparties" bar, so the chart still reconciles.

**c. "Negative bars on a chart of inflows."** The chart was never labelled
clearly enough. The bars are **contributions to the change**, not amounts
received. A new box works it through in round numbers:

| Partner | Last June | This June | Bar |
|---|---|---|---|
| A | £100m | £130m | **+£30m** |
| B | £80m | £50m | **−£30m** |
| C | £60m | £75m | **+£15m** |
| **Total inflows** | **£240m** | **£255m** | **+£15m** |

No inflow is negative. Partner B simply paid £30m less than last year, so its
contribution to the *change* is −£30m and its bar points left. The bars sum to
+£15m, the change in the total. **A bar pointing left means "this partner held
the total back", not "this partner paid a negative amount".**

**d. The reconciliation line was unexplained.** It now names all three figures
and where each comes from, and says what zero means: **every pound of the
change has been assigned to a named partner** — *not* that positive and
negative bars cancelled. It also states that a non-zero residual would be **a
fault in this tool, not a feature of the data**, and that the check is printed
every time rather than verified once and assumed.

---

## 9. The three decomposition categories, in everyday terms

The definitions were correct and unusable. Each now carries a concrete
situation, using one industry (bakeries) and its paying customers:

- **Continuing.** A supermarket paid bakeries £10m last June and £12m this
  June. In both months. Paid **£2m more**. *Real money genuinely changed hands
  differently.*
- **Newly present.** A hotel group shows £3m this June and nothing last June.
  Either it really started buying bread, **or** it was buying all along and
  last June's figure was withheld. *The total rises £3m either way, and these
  numbers cannot tell which happened.*
- **Absent or suppressed.** A restaurant chain paid £4m last June and has no
  figure this June. Either it stopped, **or** the figure was withheld. *The
  chain may still be buying exactly as much bread as before.*

**The sentence this is all for, now stated plainly:** the provider withholds a
cell whenever publishing it might identify an individual organisation, and that
test is applied **separately every single month**. A stable relationship can be
published in June, withheld in July and published again in August with nothing
having changed but what we are allowed to see. **A figure vanishing is not
evidence that a business stopped trading.**

**The 50% presence-share rule is now presented as the definition it is**, not
as a finding:

    presence share = | newly present + absent | ÷ | total change |

Above 50%, *more than half* of the move is attributable to partners present in
only one month. That is arithmetic. The defensible sentence above 50% is
*"at least half of this move is about what was published"*, never *"this
industry fell"*.

---

## 10. Trends: the band and the diagnostics explained

**The shaded band** was described as "the 10th to 90th percentile since its
last structural break" with no statement of what that means to a reader. Now:

- Drawn in four steps, spelled out: take the months since the last break, sort
  them, find the value 10% and 90% of the way up, shade between.
- **What it means in words:** by construction, one month in ten sat below and
  one in ten above. The caption under the chart prints the actual bounds in £m
  and the number of months they were computed from.
- **What it is not:** not a forecast, not a confidence interval, no probability
  attached. It describes months that have already happened.
- **When it disagrees with severity, severity is the measured one.** The band
  uses the raw level; severity uses the change with the common component
  removed. A point can sit outside the band and score low.
- **Why it starts at the last break:** including pre-break months would widen
  the band to span two levels, after which almost nothing would fall outside
  it — the band would still be drawn and would have stopped meaning anything.

**Diagnostics** had a one-line tooltip. Now a full table of what each one is
and the question it settles, plus a one-line explanation printed beside the
chart whenever a diagnostic is selected.

**The comparison that earns the mode its place:** a total can rise because
there were **more payments**, or because **each payment was bigger**. Put
*Payments received* and *Average payment received* on screen one after the
other and the answer is usually visible at a glance. **This is the closest this
dataset comes to separating volume from value**, and none of the PFI, inflow or
outflow series can do it.

**Two cautions added.** Transaction counts are rounded by the provider, so a
small industry can show a count of zero against a non-zero value — the average
payment is then left **blank rather than infinite**. And a rising *Share from
unclassified payers* is **not economic news**: it moves when coverage changes,
with no change in trading, and a jump of 20 points or more automatically sets
that month's confidence to low.

---

## 11. "After removing what every industry did that month"

The phrase appeared on two pages and was never explained. It now has its own
box.

**What it does.** Before scoring, the **median** log change across all
industries that month is subtracted from every industry. What is left is the
part specific to that industry. Median, not mean, so one enormous industry
cannot define "normal" for everybody.

**The case it was built for. measured:**

- **July 2021** recorded **£90.1bn** across **52.2m transactions**. **June
  2021** recorded **£120.1bn** across **81.7m**.
- Twelve months on, every year-on-year comparison divides by that smaller base.
  In **July 2022**, **74 of 88 industries** rose more than 25% year on year,
  median **+58.8%** — while the same month against *June 2022* grew **+0.4%**.

Without the correction the detector reports **74 economic shocks that did not
happen**. With it, the common +58.8% is removed and only industries that moved
differently from the rest are flagged.

**What it costs, stated rather than hidden.** An industry that genuinely moves
*with* the whole economy will score low. That is a deliberate trade: this tool
finds industries moving **differently** from the rest. The economy-wide picture
is the job of GDP, not of this dashboard.

---

## 12. Baseline and "provisional"

**Baseline** is the number of past months a score was measured against. A month
counts only if it is before the scored month, outside March 2020 – June 2021,
after the industry's last structural break, and actually holds a value. (The
last of those four is the defect fixed in section 1.)

**`provisional`** means fewer than **24** months. It does **not** mean the score
is wrong or that the row should be ignored. It means two things:

1. **The score has already been reduced for it.** The finite-sample correction
   is applied before the number is displayed. The label is a **disclosure**,
   not a second penalty.
2. **It will change as history accumulates**, which is correct behaviour.

**Why an industry has a short baseline at all:** almost always a structural
break, which resets the count. An industry can sit at `provisional` for up to
two years after a genuine change in its series.

---

## 13. Terms that were removed

| Removed | Why | Replaced with |
|---|---|---|
| "looks genuinely economic" | We cannot observe this and had no basis for the claim | "no artefact test fired" — naming which tests were run |
| "the move is mostly…" (unqualified) | Read as a judgement; it is arithmetic | "more than half the move is…", with the division shown |
| "Education did exactly that in March 2025" | Expires as deliveries accumulate | A permanent worked example in round numbers |
| "About 63 is the conventional \|z\| = 3" | An assertion the reader had to trust | The formula, the substitution, the result, the origin of the convention, and what it does on this data |
| "a separate judgement about whether the move looks economic at all" | Same as the first row | "a checklist of known ways these numbers move without money changing hands differently" |

**The standing rule this establishes.** The words *significant*, *economic*,
*mostly*, *likely* and *typical* are not free. If one appears on a page, the
page has to show the calculation that earns it or use a weaker word. This is
enforced by `tests/test_framing.py`.

---

## 14. Tests

Added to `tests/test_explanations.py` and `tests/test_framing.py`:

- The severity worked example reproduces the stored score to within 0.5 points.
- 63 is what the severity formula returns at |z| = 3, to one decimal place.
- Every confidence threshold quoted in the UI equals the constant in
  `pipeline/detect.py` — so a threshold cannot be changed in code without the
  explanation going stale.
- Driver lines always begin with the industry and always contain one of the
  five bold cause phrases.
- No user-facing string contains a month-specific example presented as a
  general rule.
- `baseline_months` never exceeds the count of non-null usable history.
- A partner moving against the total is never named as the cause (synthetic
  edges force the branch).
- A share above 100% is explained rather than printed bare.
- `_money(-2.7e9)` renders as `-£2.7bn`, not `£-2.7bn`.

- Stored `driver_line` text in `outputs/alerts.csv` matches what the current
  `narrate.py` produces for the latest month.

**Driver-line tests run on generated output, not on the source text.** A phrase
wrapped across two lines of Python is invisible to a grep-style test and to
anyone searching the codebase; three assertions in the first draft of this work
failed for exactly that reason.

---

## 15. A staleness trap closed: stored text in the outputs

**The Overview reads `driver_line` straight from `outputs/alerts.csv`** rather
than regenerating it, because that page always shows the selection the pipeline
pre-computes. That is efficient and it is silent: change `narrate.py` and the
page keeps printing the old wording with nothing to indicate it.

**It happened during this release.** The sign fixes in section 5a landed after the
pipeline had already written its lines, so the Overview went on printing *"the
largest contributor is SIC 47 at £93m"* for an industry that fell while SIC 47
paid more — the exact sentence the fix existed to remove.

**Now tested.** `test_stored_driver_lines_match_what_the_generator_produces_now`
regenerates the top four lines of the latest month and compares them with what
is stored. Regenerating against a month-indexed edge table costs a few hundred
milliseconds, so there was never a reason not to check. The test failed as soon
as it was written, which is how the stale column was found.

**If it fails after a code change, rerun the pipeline.** The message says so.

---

## 16. A stale figure removed: the detector-overlap share

**"79% of structural alerts are not level alerts"** appeared in four files. It
was measured when the structural detector was first built. Adding the two
volume-weighted features in the previous release moved it, and nothing caught
that, because the number was prose.

**measured now: 96%** — 221 of 231 structural alerts are not also level alerts
at severity 63. (It was 69% before the baseline fix in section 1, which roughly halved
the number of level alerts. That a single number moved from 79% to 69% to 96%
across three releases is the whole argument for computing it live.)

**The fix is not to write 69% instead.** It is computed live by
`_detector_overlap()` in `app_pages/method.py` from `outputs/structural.csv`
and `outputs/alerts.csv`, printed with both counts, and labelled as describing
the delivery in front of the reader. The four prose copies now say "most" and
point at the live figure.

**The general rule this produced:** any figure that depends on the pipeline's
own behaviour is computed at render time, never written into prose. Figures
about the *source data* (£90.1bn in July 2021, 52.2m transactions) can be
written down, because the delivery does not change underneath us.

---

## 17. Modularity's 0.3 floor is now attributed

The Economic clusters page said 0.3 was "the conventional floor for structure
worth interpreting" without saying whose convention. It is **Newman and
Girvan's**, from the 2004 paper that defined modularity: they reported that
values above roughly 0.3 indicate community structure worth interpreting.
**convention.**

The page now says so, and adds what was implicit: it is a **rule of thumb from
the network-science literature, not a test.** There is no p-value behind it and
we did not derive it from this data. This network sits below 0.3, so the page
also says the groups should not be described as "communities" in anything
published without that caveat attached.

---

## 18. One warning silenced by fixing its cause

`app_pages/shifts.py` added a column to a DataFrame slice, which raised
`SettingWithCopyWarning` on three tests. pandas does not guarantee that such an
assignment reaches the object you are holding, so the warning was pointing at a
real hazard rather than at noise. The slice is now `.copy()`'d before the
column is added.

---

## 19. Verification for this release

| Check | Result |
|---|---|
| Full test suite | **664 passed, 0 failed** (was 496 — 168 added) |
| Ground-truth audit (`python -m pipeline.audit`) | **42 of 42 checks passed** |
| Severity worked example, recomputed vs published | **68.3 against 68.3** |
| Stored driver lines vs current generator | **match** |

The audit recomputes headline figures **from the original workbook using a
deliberately separate code path** — openpyxl row by row, its own date parser,
no pipeline imports — so it cannot agree with the pipeline by sharing a bug
with it.

**Reproduce the whole thing:** `./run-full.command` (macOS) or `run-full.bat`
(Windows). It rebuilds from the delivery, runs the audit and runs the tests
before opening the dashboard.

---

## 20. One box per page

**The problem this release created.** Answering "justify every number" by
writing more words produced pages with five to nine separate explanation boxes:

| Page | Boxes before | Boxes now |
|---|---|---|
| Outliers | 9 | **1** |
| Movers | 8 | **1** |
| Why did it move? | 7 | **1** |
| Trends | 5 | **1** |
| Overview | 3 | **1** |
| Gainers & losers, Structural shifts, Influence, Economic clusters | 1 each, under a different title | **1 each, same title** |

Somebody opening Outliers for the first time met nine boxes before they
reached a number. That is not simple, whatever is inside them.

**Nothing was removed.** Every word is still there. Each page now opens exactly
one box — *How to read this page, and how every number on it is calculated* —
with the page's topics on tabs inside it, in reading order. One click to open,
one click to move between topics.

**The first tab is always "What this shows".** Somebody who opens the box and
reads nothing else still learns the point of the page they are on.

**Two boxes were folded into the topic they belong to.** The common component
and the baseline are steps 3 and 5 of the severity calculation, so they sit
with severity rather than in boxes of their own. Splitting them out was a
filing decision that made sense to whoever wrote the code and to nobody
reading the page.

**Every view now uses the same door.** Gainers & losers, Structural shifts,
Influence and Economic clusters each had a box titled "How to read this" — same
purpose, different title, different position. Somebody moving between views had
to notice that twice.

**One definition, one place.** The dataset page defined "classified flow" a
second time, in its own words. It now renders the shared definition. Two
definitions of a core term in two places is how they come to disagree.

**Eleven dead functions removed.** The per-term explainer wrappers
(`severity_explainer()`, `confidence_explainer()` and nine others) are gone;
the guide renders the text directly. Two ways to show the same words is how
they drift.

**Tested.** `test_each_analysis_page_opens_exactly_one_explanation_box` fails
if any page opens an explanation box of its own again, and
`test_every_guide_tab_renders_without_error_and_is_not_empty` calls every tab
on every page, because a tab that raises would be invisible until somebody
clicked it.

---

## 21. Re-audit against the original feedback

Every point in the original feedback was re-checked against the running code
rather than from memory. Two gaps were found and are fixed here.

### 21a. Confidence had no worked example

The feedback asked for a hand calculation for **both** scores. Severity had
one; confidence had the rule table and a live summary of which rule fired for
three industries — but not **the numbers that made it fire**, so the label
still read as a black box.

**Added:** the checklist walked on one real row, with every measured value
printed beside its threshold, running top to bottom and stopping at the first
test that fires. On the current delivery it lands on a genuinely instructive
case: test 6 measures **69%** against a **70%** threshold and does **not**
fire, so the reader sees how close a threshold call can be.

**It is checked against the detector.** The walk re-applies the thresholds
independently, so it could disagree with the label in `alerts.csv`. If it ever
does, the page says so instead of printing two answers, and
`test_the_confidence_walk_agrees_with_the_stored_label` fails.

### 21b. The most-quoted example in the whole tool had drifted

**SIC 19** is cited on four pages as the reason severity and confidence are
never blended. Checked against the data, three things were wrong:

| Quoted | Actual | Where the real figure lives |
|---|---|---|
| "fell 66%" | **−65.5%**, and it is a **structural break level shift**, not a year-on-year change | `outputs/breaks.csv`, `level_change_pct` |
| "£330m of a £348m fall" | **£313m of £342m** (year-on-year inflow, classified) | counterparty decomposition |
| "the single largest anomaly in this dataset" | **it is not scored at all** | — |

That last one is the serious one. **The industry's own break resets its
baseline**, and fewer than 12 usable months have accumulated since, so the
detector has nothing to measure it against. That is correct behaviour — the
Movers page already lists it among the industries it could not score — but four
pages went on describing it as the top of a ranking it had dropped out of.

A reader would also have been misled by the 66%: presented next to a
year-on-year chart, it reads as a year-on-year change. It is not. The
year-on-year PFI change for that month is **−50.7%** and the inflow change is
**−60.3%**.

**Fix: the example now computes itself.** `suppression_case()` finds the
largest suppression-driven break in the break register, decomposes that
industry's inflow across it, and reports what comes back — the industry, the
month, the break size, the largest partner, its share, the presence share, and
whether the case is currently scored. A future delivery with a bigger case will
update the text by itself.

**The written-down copies are gone**, and `test_the_stale_figures_are_gone_from_every_user_facing_page`
fails if any of them returns. The two developer docstrings that carried the same
figures now state the delivery they were measured on and point at the live
function.

### 21c. Everything else re-verified

All 27 points from the original feedback were checked individually against the
running code — the wording on each page, the driver-line output for the current
month, the slider bounds, the dropdown order, and the presence of each worked
example. The results are in the session record; nothing else required a change.

---

## 22. Phase 2: the four structural requirements that were never built

The Phase 2 status table said all four features were built or dropped, and
that was true. The **eight structural requirements** behind them (BUILD_SPEC
12.6) had not been audited, and those are the ones that get skipped: no view
depends on them, and nothing fails when they are missing.

Four of the eight were outstanding.

### 22a. Betweenness: the decision was half-executed

§12.4 decided to **drop the view** and **keep the computation** for
stress-testing. Both were dropped — and `network.py`'s own docstring went on
stating *"betweenness is computed but given no view"* while no code computed
it. **A claim in a comment survives exactly as long as nothing checks it.**

**Now implemented**, in `graph.betweenness()`, weighted on `distance` (1/value,
so a high-value link is a short path). Passing `value` instead would invert the
meaning silently, the same failure mode as a payer/payee flip, so the default
is asserted by a test.

**It reproduces the original measurements exactly** on June 2026: **83.0%**
zero-share, density **78.6%**, hubs **64, 84, 46, 82, 47**. Cost 0.15s a month.

**And it extends them.** §12.4 measured one month. Written for all 90, the
zero-share runs **71.6% to 83.0%, median 77.3%**, and never falls below 71.6%.
The conclusion — that betweenness separates a few hubs from everyone else
rather than ranking industries — now rests on the whole series rather than on
one month. A test re-measures it, so if the topology ever changes enough to
make a view worthwhile, the test says so instead of a decision standing forever
on a single reading.

### 22b. Hook 8: the diagnostic that qualifies each metric

Hook 8 required a diagnostic beside every network output, because each of
these metrics has a regime where it stops meaning anything. Only modularity
(for Louvain) was published.

**Added `outputs/network_diagnostics.csv`**, one row per month:

| Column | What it guards against |
|---|---|
| `density` | Above ~70% there is no intermediation left to detect. **Measured: 78.3% mean** |
| `betweenness_zero_share` | A column where four nodes in five score zero is not a ranking. **Measured: 77.3% median** |
| `sic00_pagerank_share` | How much of the ranking one unidentified node would absorb. **Measured: 0.341 in June 2026** |

### 22c. PageRank excluded a third of the money without saying so

§12.2 specified PageRank runs classified-only **"with including-00 available as
a diagnostic view and never as the headline"**. The classified-only half was
built. The diagnostic was not.

So the Influence page excluded roughly a third of the money with no statement
of what was excluded or why — which is precisely what this project is not
supposed to do, and it contradicts the standing instruction that unclassified
must be visible everywhere.

**The page now states it**: add SIC 00 back and that single node takes
**34.1%** of all PageRank — not of the money, of the *ranking* — because it is
both the largest source and the largest sink, so the random walk falls into it
and struggles to leave. One node absorbing a third of the walk deflates every
other score, silently.

The note explains why the two are not comparable and neither is wrong:
classified-only asks *"among the industries we can name, who is most
central?"*; including SIC 00 asks *"where does money go?"* and answers *"a
great deal of it goes somewhere we cannot identify"* — true, reported on the
Overview, but not a ranking of industries.

### 22d. Hook 7: vintage stamping was applied to one file in six

Network outputs are recomputed per delivery like everything else, so
`node_metrics` was vintage-stamped. `structural.csv`, `communities.csv`,
`community_summary.csv` and `community_stability.csv` were not — so **a
revision in any of them would have been invisible**, which is the entire point
of the vintage column.

All six now carry it, and a parametrised test fails if any Phase 2 output
loses it.

### 22e. Hook 5: the long store was missing a metric

The long-format store exists "so that adding a metric never changes the
schema". `betweenness` is now in `network.METRICS` and written for every
node-month — 7,920 rows.

**Verification:** 21 network tests pass, the 42 ground-truth audit checks pass
on the rebuilt outputs, and the SIC-00 PageRank share came back at **0.341**,
matching the figure measured when the spec was written.

---

## 23. Phase 2 explained to the same standard as Phase 1

**The gap, measured.** Phase 1 guides ran 1,100–5,000 words with worked
examples. The Phase 2 guides ran **114–249 words with none**:

| Page | Guide before | Guide now |
|---|---|---|
| Influence (PageRank) | 114 words, 1 tab | **1,257 words, 4 tabs** |
| Economic clusters (Louvain) | 249 words, 1 tab | **1,456 words, 4 tabs** |
| Structural shifts (Isolation Forest) | 146 words, 1 tab | **1,485 words, 4 tabs** |
| Gainers & losers | 131 words | **1,039 words, 3 tabs** |

Same tool, same reader, same standard. All nine views now use one box with the
same title, and a test fails if any view shows a number without a guide.

**Six parameters were in the code and justified nowhere.** Every one now states
what it does and where it came from:

| Parameter | Value | Justification now given |
|---|---|---|
| PageRank damping | **0.85** | Brin & Page's original 1998 value, the standard default since. Explicitly *not* chosen by looking at what it did to our rankings |
| Louvain seed | **0** | Louvain is randomised; the same delivery must cluster the same way twice |
| Smallest community reported | **3** | A group of two is a trading pair, not a community. Smaller groups are reported as *unclustered* |
| Community matching | **25%** Jaccard overlap | Louvain's labels are arbitrary per run. Below 25% overlap a group is reported as **new** rather than forced onto an old label |
| Isolation Forest contamination | **3%** | **Labelled as the one genuine judgement.** It sets where the line is drawn on a continuous score — roughly two or three flags a month — and explicitly does *not* decide what is unusual |
| Score rescale | **1st–99th percentile** | Stops one extreme month compressing everything else into the bottom of the range |

**Each method is explained without mathematics first**, then with it:

- **PageRank** — somebody following payments at random, millions of times;
  PageRank is the proportion of time they spend in each industry. The damping
  factor is the 15% chance they get bored and jump, which is what stops the
  walk falling into a sink and never leaving. A worked example with two
  industries of identical size shows why the one paid by Finance outranks the
  one paid by a backwater.
- **Louvain** — repeatedly ask whether moving an industry into its neighbour's
  group improves things, until no single move does. Modularity is the score
  for "improves".
- **Isolation Forest** — how few random yes/no questions it takes to single a
  month out. An ordinary month sits in the crowd and needs many; an odd one is
  isolated in two or three. Explicitly *not* a distance from an average.

**Live examples on all three**, recomputed when the page opens: the PageRank
size-versus-influence gap (ρ = 0.992 on this delivery, 13 of 88 industries
moving 5+ places), modularity per year, and one flagged industry-month with all
nine of its feature distances.

### 23a. Three faults in the first draft of this, caught before it shipped

**Industry names truncated mid-word** — "Manufacture of coke and refined pe"
reads as a bug rather than an abbreviation. Now truncated on a word boundary.

**"Furthest from normal" was labelling seven rows at once.** Now the single
largest mover is marked as such, and the rest are labelled *unusual for this
industry* or *within its normal range* against the ±2 threshold.

**The worked example over-claimed.** It said *"no single one of these numbers
would necessarily be alarming on its own"* beside a feature sitting **12.8
standard deviations** out. That sentence is now conditional on what the data
actually shows, and a test fails if the unconditional version returns.

### 23b. And one duplication, removed

Lifting each page's text into `method.py` left the **0.3 modularity
convention explained twice** — once on *What this shows* and once on *How
Louvain works*. Two copies of a definition are two definitions that will
eventually disagree, which is the failure this whole release has been about.
The derivation stays on the method tab; the summary tab points at it.
`test_no_explanation_is_written_twice` now guards it.

---

## 24. What a real managed Windows machine exposed

Four defects, none of which could be found on the machine that wrote the code.
Each is the same shape: **a default that differs between platforms**, so the
code is correct where it was written and broken where it runs.

### 24a. `pytest` was never installed

`run-full.bat` runs the test suite. `requirements.txt` did not contain pytest.
It worked on the development Mac because that `.venv` predated the pinned
file. A clean install rebuilt and reconciled 42 of 42 checks, then said
**`No module named pytest`** at step 2 of 3.

Pinned at `pytest==9.1.1`. Running the tests is a supported workflow, so its
runner is a requirement, not a developer extra.

### 24b. The window closed and took the error with it

Neither run script had a `pause` after launching the dashboard. When Streamlit
failed to start, the batch file ended and the window shut — **after a
twenty-minute run**, with the only diagnosis on screen for a fraction of a
second.

Both scripts now end in `pause`, report the exit code, and explain the likely
causes. A window that closes on its own has destroyed the evidence.

### 24c. `WinError 10013` is not "port already in use"

```
PermissionError: [WinError 10013] An attempt was made to access a
socket in a way forbidden by its access permissions
```

Windows **refused** port 8501. It reserves whole TCP ranges for Hyper-V, WSL
and Docker and blocks any bind inside them, whether or not anything is
listening. The first error message this project produced for it said
"already in use", which was wrong and would have sent someone hunting a
process that does not exist.

Added `find-port.bat` and `scripts/find_port.py`: prints the reserved ranges,
then tries fourteen candidate ports **by binding each one**, which is the
operation that actually fails, and writes the first that works to `port.txt`.
Both platforms read that file.

### 24d. `read_text()` uses the machine's locale, not UTF-8

```
UnicodeDecodeError: 'charmap' codec can't decode byte 0x81
in position 6480: character maps to <undefined>
```

`Path.read_text()` with no `encoding=` uses the locale encoding: UTF-8 on
macOS, **cp1252 on Windows**. This project's source is full of em dashes,
pound signs and Greek letters. Four test modules failed at import, so the
suite never ran at all.

Fixed in **18 places across 8 files**, one of them `pipeline/vintage.py` —
runtime code, not a test.

The export path was checked and was already safe: both downloads share one
renderer that declares `charset=utf-8`, and pandas writes CSVs as UTF-8
everywhere.

### 24e. And the guard for it was broken

`tests/test_portability.py` fails if any file is read or written without
naming its encoding — the only way to catch this class of bug from a Mac.

**The first version passed when it should have failed.** Reintroducing the
bug deliberately left it green: the tokeniser joins with spaces, so the source
reads `. read_text (`, and the pattern `\.read_text\(` matched nothing. The
check was not catching anything — it was always passing.

Fixed, then verified the way it should have been the first time: bug in →
fails, bug out → passes. It then found two more files that had been missed,
including one in `pipeline/audit.py`.

**A check that silently does nothing is indistinguishable from a check that
passes.** That is the lesson of this entire release, and it applied to the
test written to enforce the lesson.

---

## 25. Known limitations, unchanged by this release

- **Next delivery is the real test.** Vintages, revisions and the sheet
  cross-check have only ever run against one file. `revisions.csv` is empty.
- **Two questions outstanding for Andrew.** Does Pay.UK know about the
  March 2025 Education classification change? Does a circulated export need
  disclosure clearance?
- **Regional data** covers 18 months only and carries ~30% less value than the
  national file. It cannot support a seasonal baseline, so no regional anomaly
  scores exist.
