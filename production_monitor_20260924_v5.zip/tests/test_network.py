"""Network metrics, and the honesty of what is claimed for them.

PageRank was specified on the premise that importance and size differ. On this
data they barely do - the rank correlation is 0.992 - so the view must not
present a league table as if it added information. These tests pin both the
arithmetic and that framing.
"""
from __future__ import annotations

from pathlib import Path

import networkx as nx
import numpy as np
import pandas as pd
import pytest

from pipeline import config as cfg, graph, network

pytestmark = pytest.mark.skipif(
    not (cfg.OUTPUTS / "node_metrics.csv").exists(),
    reason="network metrics not built; run python -m pipeline.run",
)


@pytest.fixture(scope="module")
def metrics() -> pd.DataFrame:
    return pd.read_csv(cfg.OUTPUTS / "node_metrics.csv", parse_dates=["month"],
                       keep_default_na=False, na_values=[""])


@pytest.fixture(scope="module")
def edges() -> pd.DataFrame:
    v = sorted(p for p in cfg.VINTAGES.iterdir() if p.is_dir())
    e = pd.read_parquet(v[-1] / "sic2.parquet")
    e["grain"] = cfg.LEVEL_SIC2
    return e


# --- arithmetic ---------------------------------------------------------

def test_pagerank_sums_to_one_each_month(metrics):
    pr = metrics[metrics.metric == "pagerank"].groupby("month").value.sum()
    assert np.allclose(pr, 1.0, atol=1e-6), (
        f"PageRank is a probability distribution; worst month sums to "
        f"{pr.min():.4f}"
    )


def test_in_and_out_strength_total_the_same(metrics):
    """Every pound paid by one industry is received by another."""
    s = metrics[metrics.metric.isin(["in_strength", "out_strength"])]
    totals = s.pivot_table(index="month", columns="metric", values="value",
                           aggfunc="sum")
    gap = (totals.in_strength - totals.out_strength).abs().max()
    assert gap < 1.0, f"largest discrepancy £{gap:,.2f}"


def test_strengths_reconcile_to_the_edge_table(edges, metrics):
    """Network in-strength must equal classified inflow from the raw edges."""
    month = metrics.month.max()
    cur = edges[(edges.month == month) & (edges.payer != cfg.UNCLASSIFIED_SIC)
                & (edges.payee != cfg.UNCLASSIFIED_SIC)]
    expected = cur.groupby("payee").value.sum()
    sel = metrics[(metrics.month == month) & (metrics.metric == "in_strength")]
    got = sel.assign(code=sel.node_id.str.split(":").str[-1]).set_index("code").value
    for code, want in expected.items():
        assert got.get(code, 0.0) == pytest.approx(want, abs=1.0), (
            f"SIC {code}: network {got.get(code)} vs edges {want}"
        )


def test_unclassified_is_excluded_from_the_network(metrics):
    """SIC 00 takes 0.341 of all PageRank if included."""
    codes = set(metrics.node_id.str.split(":").str[-1])
    assert cfg.UNCLASSIFIED_SIC not in codes


def test_top_counterparty_share_is_a_share(metrics):
    v = metrics[metrics.metric == "top_counterparty_share"].value.dropna()
    assert ((v >= 0) & (v <= 1 + 1e-9)).all()


# --- the claim the view makes -------------------------------------------

def test_pagerank_really_is_almost_the_same_as_size(metrics):
    """The finding the view is built around. If this ever stops being true,
    the page's framing needs rewriting, not just its numbers."""
    month = metrics.month.max()
    cur = metrics[metrics.month == month]
    wide = cur.pivot_table(index=cur.node_id.str.split(":").str[-1],
                           columns="metric", values="value")
    rho = wide.pagerank.corr(wide.in_strength, method="spearman")
    assert rho > 0.95, (
        f"rank correlation has fallen to {rho:.3f}; the Influence page states "
        f"that PageRank adds little over size, and that would no longer hold"
    )


def test_the_view_states_the_correlation_rather_than_hiding_it():
    src = Path("app_pages/influence.py").read_text(encoding="utf-8")
    assert "0.992" in src, "the correlation must be stated in the page's own text"
    assert "would be a size league table" in src or "adds nothing" in src


def test_the_gap_identifies_industries_funded_from_outside_the_network(metrics, edges):
    """The actual finding: industries ranked below their size are paid mainly
    by public administration, which receives little itself."""
    month = metrics.month.max()
    cur = metrics[metrics.month == month]
    wide = cur.pivot_table(index=cur.node_id.str.split(":").str[-1],
                           columns="metric", values="value").dropna(
        subset=["pagerank", "in_strength"])
    gap = (wide.in_strength.rank(ascending=False)
           - wide.pagerank.rank(ascending=False))
    below = gap.nsmallest(6).index

    top_payers = []
    for code in below:
        sel = edges[(edges.month == month) & (edges.payee == code)
                    & (edges.payer != cfg.UNCLASSIFIED_SIC)]
        if len(sel):
            top_payers.append(sel.nlargest(1, "value").payer.iloc[0])
    assert top_payers.count("84") >= 3, (
        f"expected public administration to dominate; got {top_payers}"
    )


# --- graph construction -------------------------------------------------

def test_graph_index_and_frame_give_the_same_graph(edges):
    month = edges.month.max()
    direct = graph.build_graph(edges, month=month)
    indexed = graph.build_graph(graph.as_index_for(edges, cfg.LEVEL_SIC2),
                                month=month)
    assert direct.number_of_nodes() == indexed.number_of_nodes()
    assert direct.number_of_edges() == indexed.number_of_edges()
    assert nx.is_isomorphic(direct, indexed)


def test_rank_changes_measures_movement_not_level(metrics):
    rc = network.rank_changes(metrics, "pagerank", window=12)
    assert not rc.empty
    assert {"rank_now", "rank_then", "rank_change"} <= set(rc.columns)
    assert (rc.rank_change == rc.rank_then - rc.rank_now).all()


# ---------------------------------------------------------------------------
# BUILD_SPEC 12.6 hooks: the structural requirements, not the features
# ---------------------------------------------------------------------------

def test_betweenness_is_computed_and_kept():
    """12.4 said drop the VIEW and keep the COMPUTATION for stress-testing.

    Both were dropped. The module docstring went on claiming "betweenness is
    computed but given no view" while no code computed it, which is the kind
    of claim that survives precisely because nothing checks it.
    """
    from pipeline import graph as g, network
    assert hasattr(g, "betweenness")
    assert "betweenness" in network.METRICS


def test_betweenness_reproduces_the_spec_measurements():
    """83% zero-share at SIC2, hubs 64/84/46/82. If this moves, the reasoning
    in 12.4 for dropping the view no longer applies and should be revisited."""
    import pandas as pd
    from pipeline import graph as g, config as cfg
    v = sorted(x for x in cfg.VINTAGES.iterdir() if x.is_dir())
    if not v:
        pytest.skip("no vintage")
    e = pd.read_parquet(v[-1] / "sic2.parquet")
    e["grain"] = cfg.LEVEL_SIC2
    G = g.build_graph(e, month=e.month.max(), include_unclassified=False)
    b = g.betweenness(G)
    assert 0.70 <= g.zero_share(b) <= 0.92, (
        f"zero share {g.zero_share(b):.2f}; 12.4 measured 0.83")
    assert set(b.nlargest(4).index) <= {"64", "84", "46", "82", "47"}, (
        "the hubs have changed; revisit the decision not to build a view")


def test_betweenness_uses_distance_not_value():
    """A high-value link is a SHORT path. Passing 'value' inverts the meaning
    and, like the payer/payee flip, does it silently."""
    import inspect
    from pipeline import graph as g
    assert inspect.signature(g.betweenness).parameters["weight"].default == "distance"


def test_zero_share_is_published_with_betweenness():
    """Hook 8: a metric where four nodes in five score zero must not be shown
    without saying so."""
    import pandas as pd
    from pipeline import config as cfg
    p = cfg.OUTPUTS / "network_diagnostics.csv"
    if not p.exists():
        pytest.skip("no outputs")
    d = pd.read_csv(p)
    for col in ("density", "betweenness_zero_share", "sic00_pagerank_share"):
        assert col in d.columns, f"hook 8 diagnostic {col} missing"
    assert d.betweenness_zero_share.between(0, 1).all()


def test_the_sic00_pagerank_share_is_measured_and_large():
    """12.2's reason for running classified-only. If it were small, the
    exclusion would need a different justification."""
    import pandas as pd
    from pipeline import config as cfg
    p = cfg.OUTPUTS / "network_diagnostics.csv"
    if not p.exists():
        pytest.skip("no outputs")
    d = pd.read_csv(p)
    assert d.sic00_pagerank_share.median() > 0.15, (
        "SIC 00 no longer dominates the walk; revisit why it is excluded")


def test_the_influence_page_states_what_excluding_sic00_costs():
    """Excluding a third of the money silently is what this project is not
    supposed to do."""
    from pathlib import Path
    src = Path("app_pages/influence.py").read_text(encoding="utf-8")
    assert "_sic00_note" in src
    assert "never hidden" in src or "never dropped" in src or "not dropped" in src


@pytest.mark.parametrize("name", ["node_metrics", "structural", "communities",
                                  "community_summary", "network_diagnostics"])
def test_every_phase_2_output_is_vintage_stamped(name):
    """Hook 7. Network metrics are recomputed per delivery like everything
    else, so revisions have to be visible here too. It was applied to
    node_metrics only."""
    import pandas as pd
    from pipeline import config as cfg
    p = cfg.OUTPUTS / f"{name}.csv"
    if not p.exists():
        pytest.skip(f"{name} not built (SIC5 outputs need --with-sic5)")
    assert "vintage" in pd.read_csv(p, nrows=1).columns, (
        f"{name}.csv carries no vintage; a revision in it would be invisible")
