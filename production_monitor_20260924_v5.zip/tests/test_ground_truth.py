"""Claims the dashboard makes, checked against the raw delivery.

The UI and the glossary state specific figures — "14.8% of classified value",
"74 of 88 industries", "£330m of a £348m fall". Those are asserted to users, so
they need to be true of the data rather than true of a comment written months
ago. Each test here recomputes its claim from the source file or the edge
store, independently of the code path that produced the number on screen.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from pipeline import config as cfg

pytestmark = pytest.mark.skipif(
    not (cfg.OUTPUTS / "series_national.csv").exists(),
    reason="pipeline outputs not built; run python -m pipeline.run",
)

U = cfg.UNCLASSIFIED_SIC


@pytest.fixture(scope="module")
def edges() -> pd.DataFrame:
    """The edge store — one row per payer/payee/month, as ingested."""
    vintages = sorted(p for p in cfg.VINTAGES.iterdir() if p.is_dir())
    return pd.read_parquet(vintages[-1] / "sic2.parquet")


@pytest.fixture(scope="module")
def panel() -> pd.DataFrame:
    return pd.read_csv(cfg.OUTPUTS / "series_national.csv",
                       dtype={"sic2": str, "section": str}, parse_dates=["month"],
                       keep_default_na=False, na_values=[""], low_memory=False)


SOURCES = {p.name: p.read_text(encoding="utf-8") for p in Path("app_pages").glob("*.py")}
ALL_UI = "".join(SOURCES.values())


# --- claims about composition ------------------------------------------

def test_intra_industry_share_matches_the_stated_figure(edges):
    """The UI states self-flows as a share of ALL classified value.

    It previously said 14.8%, which was the latest month alone quoted as a
    whole-period figure. The two differ by half a point and this test is what
    found it.
    """
    k = edges[(edges.payer != U) & (edges.payee != U)]
    share = k[k.payer == k.payee].value.sum() / k.value.sum()
    assert share == pytest.approx(0.143, abs=0.004), (
        f"self-flow share over the whole period is {share:.2%}; "
        f"the UI claims 14.3%"
    )
    for page in ("explain.py", "glossary.py"):
        assert "14.3%" in SOURCES[page], f"{page} quotes a stale figure"
        assert "14.8%" not in SOURCES[page]


def test_per_industry_self_flow_range_matches_the_stated_range(edges):
    """The UI claims self-flow runs to 32% of a single industry's inflow."""
    month = edges.month.max()
    cur = edges[(edges.month == month) & (edges.payer != U) & (edges.payee != U)]
    inflow = cur.groupby("payee").value.sum()
    self_flow = cur[cur.payer == cur.payee].groupby("payee").value.sum()
    share = (self_flow / inflow).reindex(inflow[inflow > 50e6].index).dropna()
    assert share.max() == pytest.approx(0.32, abs=0.03), (
        f"largest self-flow share is {share.max():.0%}; the UI claims 32%"
    )
    assert share.min() < 0.05, "the UI claims the range starts near 1%"
    # The UI names financial services specifically, at 31%.
    assert share["64"] == pytest.approx(0.31, abs=0.03), (
        f"SIC 64 self-flow share is {share['64']:.0%}; the UI names 31%"
    )


def test_sic00_inflow_shares_match_the_stated_figures(edges):
    """The glossary quotes per-industry shares of inflow from SIC 00."""
    month = edges.month.max()
    cur = edges[edges.month == month]
    claimed = {"85": 0.68, "41": 0.47, "29": 0.41}
    for code, want in claimed.items():
        sel = cur[cur.payee == code]
        got = sel[sel.payer == U].value.sum() / sel.value.sum()
        assert got == pytest.approx(want, abs=0.02), (
            f"SIC {code}: {got:.0%} of inflow from SIC 00, UI claims {want:.0%}"
        )


def test_unclassified_share_of_value_is_about_63_percent(edges):
    share = edges[(edges.payer == U) | (edges.payee == U)].value.sum() \
        / edges.value.sum()
    assert share == pytest.approx(0.63, abs=0.02)


# --- claims about specific episodes -------------------------------------

def test_education_break_is_a_reclassification_not_a_collapse(edges):
    """The headline claim: classified inflow fell, total money in did not."""
    ed = edges[edges.payee == "85"]
    before = ed[(ed.month >= "2024-09-01") & (ed.month <= "2025-02-01")]
    after = ed[(ed.month >= "2025-04-01") & (ed.month <= "2025-09-01")]

    def split(df):
        classified = df[df.payer != U].value.sum() / df.month.nunique()
        from_00 = df[df.payer == U].value.sum() / df.month.nunique()
        return classified, from_00

    c_before, u_before = split(before)
    c_after, u_after = split(after)

    assert (c_after / c_before - 1) == pytest.approx(-0.58, abs=0.03), \
        "classified inflow should fall ~58%"
    assert (u_after / u_before - 1) > 2.0, "inflow from SIC 00 should more than triple"
    total_change = (c_after + u_after) / (c_before + u_before) - 1
    assert abs(total_change) < 0.10, (
        f"total money into Education moved {total_change:+.1%} - the claim that "
        f"no money moved requires this to stay small"
    )


def test_sic19_fall_is_one_counterparty_going_dark(edges):
    """£330m of a £348m fall, attributed to SIC 47."""
    sel = edges[edges.payee == "19"]
    now = sel[sel.month == "2025-10-01"].set_index("payer").value
    base = sel[sel.month == "2024-10-01"].set_index("payer").value
    vanished = base[~base.index.isin(now.dropna().index) | now.reindex(base.index).isna()]
    vanished = vanished.dropna()
    assert not vanished.empty
    assert vanished.idxmax() == "47", (
        f"largest vanished counterparty is {vanished.idxmax()}, UI claims SIC 47"
    )
    assert vanished.max() / 1e6 == pytest.approx(330, abs=40)


def test_sic84_to_29_cell_is_intermittent(edges):
    """Present in only a handful of months out of 90."""
    cell = edges[(edges.payer == "84") & (edges.payee == "29")]
    present = int(cell.value.notna().sum())
    assert 5 <= present <= 30, f"present in {present} months; UI implies ~15 of 90"
    assert present < edges.month.nunique() / 2


def test_july_2021_is_the_only_volume_outlier(edges):
    """One month in 90 records a volume unlike its neighbours, and which."""
    tx = edges.groupby("month").n_tx.sum(min_count=1)
    neighbours = tx.rolling(7, center=True, min_periods=3).median()
    short = tx[(tx / neighbours) < 0.75]
    assert len(short) == 1, f"{len(short)} volume outliers found, UI describes 1"
    assert short.index[0] == pd.Timestamp("2021-07-01")


def test_july_2022_yoy_inflation_matches_the_stated_count(panel):
    """'74 of 88 industries appeared to rise more than 25%'."""
    k = panel[panel.sic2 != U].pivot_table(index="month", columns="sic2",
                                           values="pfi")
    yoy = (k / k.shift(12) - 1).loc["2022-07-01"].dropna()
    risers = int((yoy > 0.25).sum())
    assert risers == pytest.approx(74, abs=4), (
        f"{risers} of {len(yoy)} industries rose >25%; UI claims 74 of 88"
    )
    assert "74 of 88" in ALL_UI


def test_july_2022_month_on_month_was_flat(panel):
    """The contrast that makes the July 2021 argument: +0.4% MoM."""
    total = panel[panel.sic2 != U].groupby("month").pfi.sum()
    mom = total.loc["2022-07-01"] / total.loc["2022-06-01"] - 1
    assert abs(mom) < 0.05, f"month-on-month was {mom:+.1%}, UI implies roughly flat"


# --- claims about the network -------------------------------------------

def test_duplicate_keys_are_summed_not_dropped(edges):
    """Rows sharing a key are separate records; collapsing lost £3.39tn."""
    dup = edges.duplicated(subset=["payer", "payee", "month"], keep=False)
    assert not dup.any(), "the ingested edge table must be unique on its key"
    # and the total must still match the raw file, which the audit checks
    assert edges.value.sum() > 30e12, "total value looks truncated"


def test_every_industry_month_exists_for_every_industry(panel):
    """A dropped industry-month would show as a gap nobody notices."""
    counts = panel[panel.sic2 != U].groupby("sic2").month.nunique()
    assert counts.nunique() == 1, (
        f"industries have differing month counts: {counts.value_counts().to_dict()}"
    )
    assert counts.iloc[0] == panel.month.nunique()
