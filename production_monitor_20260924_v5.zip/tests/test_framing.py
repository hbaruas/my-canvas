"""The delivery is the ground truth; our figures are what gets tested.

Two consequences this suite enforces:

  * We report what the data records and never assert that a figure in it is
    mistaken. We are not in a position to know.
  * Observation and inference are kept apart. "Classified inflow fell 58% while
    unclassified inflow rose 218%" is observed. "This is a reclassification" is
    inferred, and has to be labelled as such.

Arithmetic on our own derived figures is still ours to assert plainly - that a
comparison against a low month comes out large is a property of the
calculation, not a claim about the source.
"""
from __future__ import annotations

import re
from pathlib import Path

import pytest

UI = {p.name: p.read_text(encoding="utf-8") for p in Path("app_pages").glob("*.py")}
PIPELINE = {p.name: p.read_text(encoding="utf-8") for p in Path("pipeline").glob("*.py")}
EXPORT = {p.name: p.read_text(encoding="utf-8") for p in Path("export").glob("*.py")}
USER_FACING = "\n".join(list(UI.values()) + list(EXPORT.values()))

# Phrases that assert the supplied data is mistaken, rather than describing it.
VERDICTS = [
    r"\bdata defect\b",
    r"\bincomplete month\b",
    r"\bis incomplete\b",
    r"\bwrong upstream\b",
    r"\bno economic mechanism\b",
    r"\bthe data is wrong\b",
    r"\bbug in the (?:data|source|delivery)\b",
    r"\berror in the (?:data|source|delivery)\b",
]


@pytest.mark.parametrize("pattern", VERDICTS)
def test_user_facing_text_does_not_declare_the_source_mistaken(pattern):
    hits = [m.group(0) for m in re.finditer(pattern, USER_FACING, re.I)]
    assert not hits, (
        f"{hits[:3]} asserts the delivery is wrong. Describe what it records "
        f"instead, and label any conclusion about cause as an inference."
    )


def test_the_volume_flag_is_named_for_what_it_measures():
    """`incomplete_month` was a verdict. `volume_outlier` is a measurement."""
    q = PIPELINE["quality.py"]
    assert "volume_outlier" in q and "incomplete_month" not in q
    assert "ground truth" in q.lower(), (
        "the function needs to say why it stops short of calling the month wrong"
    )


def test_the_ground_truth_principle_is_stated_to_users():
    g = UI["glossary.py"]
    assert "ground truth" in g.lower()
    assert "never assert" in g.lower() or "do not assert" in g.lower()
    assert "inference" in g.lower(), "observation and inference must be separated"


def test_education_finding_separates_observation_from_inference():
    g = UI["glossary.py"]
    section = g[g.index("Education, March 2025"):][:900]
    assert "**Observed:**" in section and "**Inferred:**" in section, (
        "the reclassification conclusion must be labelled as inference"
    )


def test_sheet_choice_is_framed_as_a_choice_not_a_correction():
    d = UI["dataset.py"]
    assert "two readings" in d
    assert "not a correction" in d, (
        "choosing between two published readings is not correcting an error"
    )


def test_arithmetic_consequences_are_still_asserted_plainly():
    """Restraint about the source must not become vagueness about our own sums."""
    joined = USER_FACING
    assert "74 of 88" in joined, "the measured consequence should still be stated"
    assert re.search(r"0\.4%", joined), "the month-on-month contrast is the point"


def test_both_bases_are_offered_wherever_money_is_shown():
    """Unclassified payments are real money. Every money view must let the
    reader include them."""
    for page in ("movers.py", "leaderboard.py", "trends.py",
                 "decomposition.py", "overview.py"):
        src = UI[page]
        assert "Including SIC 00" in src or "All flow" in src, (
            f"{page} shows money but offers no way to include unclassified "
            f"counterparties"
        )


def test_audit_describes_itself_as_checking_our_outputs():
    a = PIPELINE["audit.py"]
    head = a[:1400].lower()
    assert "raw" in head or "source" in head
    assert "recompute" in head, (
        "the audit's purpose is to recompute from the delivery and compare, "
        "not to evaluate the delivery"
    )
