"""Things that work on macOS and fail on Windows.

Every check here traces to a real failure on a managed Windows machine that
no amount of testing on the development Mac could have produced, because the
two platforms disagree about defaults rather than about behaviour.

The one that started this file:

    UnicodeDecodeError: 'charmap' codec can't decode byte 0x81
    in position 6480: character maps to <undefined>

`Path.read_text()` with no `encoding=` uses the *locale* encoding. On macOS
and Linux that is UTF-8, so it works. On Windows it is cp1252, which cannot
represent the em dashes, pound signs and Greek letters this project's source
is full of. Four test modules failed at collection, so the suite never ran.
"""
from __future__ import annotations

import re
from pathlib import Path

import pytest

# Everything we ship and might read back at runtime or in a test.
SOURCE_DIRS = ("pipeline", "app_pages", "export", "tests", "scripts")
PY_FILES = sorted(
    p for d in SOURCE_DIRS for p in Path(d).glob("*.py")
) + [Path("app.py")]


def _strip_strings_and_comments(src: str) -> str:
    """Remove literals and comments so only real code is inspected.

    Tokenised rather than pattern-matched: this module's own source contains
    the string "open(" inside a regex, and a cruder stripper flagged this file
    as an offender against itself.
    """
    import io
    import tokenize

    out = []
    try:
        for tok in tokenize.generate_tokens(io.StringIO(src).readline):
            if tok.type in (tokenize.STRING, tokenize.COMMENT):
                continue
            out.append(tok.string)
    except (tokenize.TokenError, IndentationError):
        return src
    return " ".join(out)


@pytest.mark.parametrize("path", PY_FILES, ids=lambda p: p.as_posix())
def test_no_file_is_read_or_written_in_the_locale_encoding(path):
    """read_text / write_text / open must always name their encoding.

    Without it the behaviour depends on the machine's locale, which means the
    code is correct on the machine that wrote it and broken on the machine
    that runs it - the worst possible split, because the author cannot see it.
    """
    code = _strip_strings_and_comments(path.read_text(encoding="utf-8"))
    offenders = []

    # The stripper joins tokens with spaces, so the argument reads
    # "encoding =" rather than "encoding=". Match the keyword, not the sign.
    def names_encoding(fragment: str) -> bool:
        return re.search(r"\bencoding\b", fragment) is not None

    def call_args(at: int) -> str:
        """Text up to the closing bracket of the call starting at `at`."""
        depth, i = 1, at
        while i < len(code) and depth:
            if code[i] == "(":
                depth += 1
            elif code[i] == ")":
                depth -= 1
            i += 1
        return code[at:i]

    # \s* after the dot: the stripper joins tokens with spaces, so the source
    # reads ". read_text (" here. Without it this matched nothing at all and
    # the check passed on a file that still had the bug.
    for m in re.finditer(r"\.\s*(read_text|write_text)\s*\(", code):
        if not names_encoding(call_args(m.end())):
            offenders.append(m.group(1))

    for m in re.finditer(r"(?<![\w.])open\s*\(", code):
        args = call_args(m.end())
        # Binary modes carry no encoding, and that is correct.
        if not names_encoding(args) and not re.search(r"\b[rwax]b\b", args):
            offenders.append("open")

    assert not offenders, (
        f"{path}: {sorted(set(offenders))} used without encoding=. "
        f"On Windows this defaults to cp1252 and raises UnicodeDecodeError "
        f"on any non-ASCII character. Pass encoding='utf-8' explicitly."
    )


def test_the_source_really_does_contain_characters_cp1252_cannot_read():
    """If this ever fails, the check above has stopped being necessary -
    which would be surprising, and worth knowing rather than assuming."""
    offending = {}
    for path in PY_FILES:
        text = path.read_text(encoding="utf-8")
        try:
            text.encode("cp1252")
        except UnicodeEncodeError as exc:
            offending[path.as_posix()] = text[exc.start:exc.start + 1]
    assert offending, (
        "no source file contains a character cp1252 cannot encode")


def test_no_hardcoded_path_separators_in_paths():
    """A backslash or a leading slash in a path literal is a platform bug."""
    bad = []
    for path in PY_FILES:
        code = _strip_strings_and_comments(path.read_text(encoding="utf-8"))
        for m in re.finditer(r"""Path\(\s*["']([^"']+)["']""", code):
            value = m.group(1)
            if value.startswith("/") or "\\" in value:
                bad.append(f"{path.as_posix()}: Path({value!r})")
    assert not bad, bad


def test_outputs_are_written_by_pandas_or_with_an_explicit_encoding():
    """pandas to_csv defaults to utf-8 on every platform, so those are safe.

    This pins the reasoning: if anything ever writes an output by hand, it
    has to say what encoding it is using.
    """
    run = Path("pipeline/run.py").read_text(encoding="utf-8")
    assert ".to_csv(" in run
    assert "open(" not in _strip_strings_and_comments(run)
