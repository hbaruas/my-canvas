# Project state — read this first

**Purpose of this file.** If you return to this project after months, or the
conversation history is gone, read this instead of the codebase. It says what
this is, why the non-obvious decisions were made, what is built, and what to do
next.

Last updated: 22 September 2026 · data release 16 July 2026

---

## 1. What this is

A local tool that monitors UK business-to-business payment flows (Pay.UK /
Vocalink, published by ONS as official statistics in development) and flags
industries whose activity moved unusually.

- **Owner:** Saurabh · **Stakeholder:** Andrew · **Sponsor:** Matthew
- **Commissioned as:** "Path A — production monitor", a dashboard flagging
  granular industry shocks. Chosen over GDP nowcasting and supply-chain stress
  testing because it was the quick win.
- **Runs locally.** Nothing is hosted, nothing published. Streamlit + a Python
  pipeline, rebuilt from a delivery dropped into `Data/incoming/`.

### Start here
```bash
./install.command          # once — builds an isolated .venv
./run.command              # quick: rebuild from cache, no audit, open dashboard
./run-full.command         # new delivery: full rebuild + audit + tests
python -m pipeline.audit   # reconcile outputs against the raw files
```
Windows equivalents: `install.bat`, `run.bat`, `run-full.bat`.

---

## 2. The data, and what is strange about it

90 months (Jan 2019 – Jun 2026), 88 industries plus `00 Unclassified`,
7.14bn transactions, £32.1tn total value of which £11.7tn is classified.

**Eight properties that will mislead you if you do not know them.** Each was
found the hard way; each is handled in code and pinned by a test.

| | What |
|---|---|
| 1 | **Only 36.6% of value has both ends classified.** `SIC 00` is the largest single counterparty for most industries — 68% of Education's inflow. Never filter it out silently. |
| 2 | **90 rows carry 18.6% of all value** — the `00 → 00` cell, one per month. |
| 3 | **`[c]` and `[-]` are null, never zero.** Suppression is applied by the provider, not us. Treating them as zero manufactures collapses. |
| 4 | **The date column mixes types** — 667,356 text dates, 15,453 real Excel dates. Industry codes mix too (30,906 integers, 2,936 of them below 10 needing a leading zero). |
| 5 | **The regional file repeats keys** — 34,246 keys across up to 9 rows each, with *different values*. They are separate records and must be **summed**. Deduplicating them lost £3.39tn of £6.5tn. |
| 6 | **The workbook holds the data twice** — `SIC2_2019_2026` and the yearly sheets. They agree on every value, but 78 cells are published in one and suppressed in the other (£299.6m, mostly April 2026). **Decision: the more restrictive reading wins.** |
| 7 | **July 2021 records 52.2m transactions** against ~80m either side. Every year-on-year comparison against it comes out large — 74 of 88 industries appeared to grow >25% in July 2022 while month-on-month was +0.4%. |
| 8 | **Counterparty cells vanish and return.** SIC 19 fell 66% in Oct 2025; £330m of a £348m fall was one retail counterparty absent for eight months, then back. |

### Findings worth remembering
- **Education, March 2025** — classified inflow −58%, from SIC 00 +218%,
  **total +6%**. The payers stopped being classified; no money moved. This is an
  *inference* from the observation, and is labelled as such everywhere.
- **Retail, April 2020** — PFI −0.6% year-on-year, but public administration went
  from 18% to 40% of its entire inflow. Invisible to any level measure. This is
  the case the structural detector exists for.

---

## 3. Decisions that look odd until you know why

| Decision | Why |
|---|---|
| **63 is the default severity threshold** | Not tuned. `severity = 100 × (1 − e^(−\|z\|/3))` returns 63.2 at \|z\| = 3, the three-sigma convention (Shewhart, 1931). On this data it fires far more often than the 0.27% a normal curve implies — payment flows have much fatter tails. The exact share is measured live and printed on the Outliers page, never written into prose. It is a browsing dial, **not a significance test**, and the UI says so |
| **Confidence is a checklist, not a judgement** | We cannot observe whether a move is "economic". Nine measurable artefact tests run in a fixed order; first match sets the label; the *Why* column names the test |
| Detect at **division (SIC2)**, report at section | Section aggregation loses 52% of alerts; SIC 51 scored −4.9 while its whole section showed −0.3 |
| **Severity and confidence never blended** | The largest anomaly in the data is a reporting change. One number would bury that |
| Subtract the **cross-sectional median** before scoring | Without it, July 2022 alone produces 74 false alerts |
| CUSUM is a **mean**, not a sqrt-normalised sum | YoY z-scores are autocorrelated; sqrt normalisation fired 14.6×/month against 3.1 |
| **z-scores discounted for short baselines** (t-reference) | Education came back from its break scoring 97.8 on a +12% move |
| `MIN_HISTORY = 12`, not 24 | 24 cost 28 months of history and made COVID unscoreable, while changing the recent alert rate from 3.9 to 4.1 |
| Regional data: **no anomaly scores** | 18 months cannot support a seasonal baseline |
| **Betweenness dropped as a view, kept as a computation** | Zero-share runs 71.6–83.0% across all 90 months (median 77.3%), and the non-zero scores are PageRank's hubs. Density was not the cause — the economy is hub-and-spoke at every level. It is still written to `node_metrics.csv` for stress-testing, with its zero-share beside it in `network_diagnostics.csv` |
| **PageRank excludes SIC 00, and says so on the page** | Included, that one node takes **34.1%** of all PageRank (Jun 2026) — it is both the largest source and the largest sink, so it absorbs the walk. The Influence page states the figure rather than excluding it silently |
| **GNN rejected** | 7,920 node-months is too few, and at 78% density neighbourhood aggregation averages the signal away |
| Communities at **SIC5**, exploratory | SIC2 modularity 0.163 (too dense); SIC5 0.246, still below the ~0.3 floor |
| PageRank built as a **gap**, not a league table | PageRank vs size correlates 0.992 — the ranking adds nothing, the divergence does |
| Section codes: `"N/A"` → `"X"` | `N/A` is a pandas NA string and vanishes on every CSV round-trip |
| CSV **and** parquet written | CSV cannot carry dtypes; `"01"` reads back as `1` |

### A presentation rule, added 22 September 2026
**One explanation box per page, and the same one everywhere.** Not because the
explanations were wrong, but because nine boxes on a page is not usable by
someone who has never seen the project. The instruction from ONS was *quality
over quantity — whatever we have, do it properly*: nothing is cut, everything
is behind one door. `tests/test_method.py` enforces it.

### A second framing rule, added 22 September 2026
**Every word and every number on a user-facing page has to be justified.** If a
page uses *significant*, *economic*, *mostly*, *likely* or *typical*, it must
show the calculation that earns the word or use a weaker one. If it prints a
threshold, it must print the formula that produces it and where the convention
came from. If it gives an example, that example must either be invented round
numbers (which never expire) or be recomputed live from `outputs/` (which
cannot go stale). `tests/test_method.py` enforces this.

### A framing rule that governs the writing
**The delivery is the ground truth.** We report what it records and never
assert a figure in it is mistaken. Observation and inference are kept separate.
Arithmetic on *our own* figures is stated plainly. `tests/test_framing.py`
enforces this — an earlier briefing called these "data defects" and was
rightly rejected.

---

## 4. What is built

**Phase 1 — the monitor.** Seven views: Overview, Movers, Outliers, Why did it
move?, Trends, Gainers & losers, plus Reference (Playbook, The dataset, Data
quality, Glossary).

**Phase 2 — network analysis.** Three views: Structural shifts, Influence,
Economic clusters.

| Module | Does |
|---|---|
| `ingest.py` | Reads deliveries by structure, not filename. Five parsing rules |
| `vintage.py` | Snapshot per delivery, diffed for revisions |
| `series.py` | Inflow / outflow / PFI on both bases; `safe_divide` |
| `condition.py` | STL seasonal adjustment, structural break register |
| `detect.py` | Four signals → severity; confidence separately |
| `decompose.py` | Three-way attribution; `EdgeIndex` (169ms → 8ms) |
| `narrate.py` | Plain-English driver lines, one fixed shape, five endings |
| `network.py` | PageRank by value **and** by volume, betweenness, per-month diagnostics |
| `structural.py` | Nine features + Isolation Forest |
| `communities.py` | Louvain at SIC5, Jaccard-matched across years |
| `profile.py` | Dataset composition |
| `audit.py` | **Independent reconciliation against the raw files** |

Plus `app_pages/method.py` — the single source for every methodological
explanation shown in the UI, with worked examples recomputed live from
`outputs/` so they can never describe a month that has dropped out of the data.
See `CHANGELOG.md` for what each explanation says and where its numbers come
from.

**Every page opens exactly one explanation box**, titled *How to read this
page, and how every number on it is calculated*, with its topics on tabs
inside. `method.PAGE_TABS` defines which tabs each page gets, for all nine
views including Phase 2. A page must not open an explanation box of its own —
a test fails if one does. The first tab is always "What this shows".

**Phase 2 is explained to the same standard as Phase 1.** Each of PageRank,
Louvain and the Isolation Forest has a plain-English account of the method, a
justification for every parameter it uses (damping 0.85, seed 0, minimum
community 3, Jaccard 0.25, contamination 3%), and a live example recomputed
from the current outputs. They previously carried 114–249 words and no
derivation.

**~9,200 lines. 664 tests. 42 audit checks.**

### The audit is the thing to trust
`python -m pipeline.audit` recomputes headline figures **from the original
workbook using a deliberately separate code path** — openpyxl row by row, its
own date parser — and compares. It checks 31,680 industry-month values
individually, both sheets against each other, and the regional file. It is
tested against deliberate corruption, because a reconciliation that cannot fail
is worse than none.

---

### Windows, the short version
Managed builds keep Python at a fixed path and off PATH, so `_env.bat`
resolves it: command-line argument, `PRODMON_PYTHON`, `python_path.txt`, then
known managed roots including `C:\ONSapps\My_Python`. If the dashboard fails
with `WinError 10013`, Windows has **refused** the port rather than found it
busy — run `find-port.bat`, which writes a usable one to `port.txt`.

Three things were found only by running on a real managed machine, none of
which any amount of local testing would have surfaced:

- **`pytest` was missing from `requirements.txt`** while `run-full` ran it.
  The development machine already had it.
- **Both run scripts lacked a final `pause`**, so a failed dashboard launch
  closed the window and took the error with it — after a 20-minute run.
- **Port 8501 is reserved** on that machine. The first error message this
  project produced for it said "already in use", which was wrong.

## 5. What to do next

1. **The next delivery is a real test.** Vintages, revisions and the sheet
   cross-check have only ever run against one file. `revisions.csv` is still
   empty. Run `./run-full.command` when it lands.
2. **Two open questions for Andrew** — does Pay.UK know about the March-2025
   Education classification change; does a circulated export need disclosure
   clearance.
3. **GVA weights** via Katherine Chant, to rank alerts by economic materiality
   rather than pounds. Outputs already key on SIC2/section/GDP grouping so
   weights join without rework.
4. **Phase B** — the 7-day VAT flash comparison. Never started; the data is not
   in the folder.

### Known limitations, not bugs
- The first 12 months can never be scored — year-on-year differencing needs a
  year first.
- An industry that breaks becomes unscoreable for 12 months while its baseline
  rebuilds (currently SIC 19 and SIC 85).
- Communities are exploratory. Modularity has never exceeded 0.257.

---

## 6. Where things are

```
PROJECT_STATE.md     this file
BUILD_SPEC.md        what was built and why — the detailed record
PROJECT_PLAN.md      the original findings and reasoning
README.md            install and run
pipeline/            the analysis
app_pages/           the dashboard views
export/              self-contained HTML export
tests/               386 tests
outputs/             CSV + parquet; regenerated by a run
Data/incoming/       drop new deliveries here
```

**If you change an analytical decision, update `BUILD_SPEC.md` and this file.**
The tests will tell you what you broke; only these say why it was that way.
